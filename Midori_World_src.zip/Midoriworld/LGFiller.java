import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.awt.Color;
/**
 * Write a description of class LGFiller here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class LGFiller  extends LogicGate
{
    private int delayLim;
    private int delay;
    private int xPos;
    private Color col = new Color(100,100,255,233);
    private boolean rapidFill = false;
    public LGFiller (int delay)
    {
        delayLim = delay;
        this.delay = delay;
        xPos = 0;
        getImage().clear();
    }
    public void act() 
    {
        if (getMWorld().esPause) return;
        if (delay > 0)
        {
            delay--;
        }
        else
        {
            fill();
            if (rapidFill)
            {
                for (int i = 0; i < 2; i++)
                fill();
            }
            delay = delayLim;
        }
    }    
    public void rapidFill()
    {
        rapidFill = true;
        delayLim = 0;
        delay = 0;
    }
    public void fill()
    {
        if (xPos >= getMWorld().getWidth()) return;
        for (int y = 0; y < getMWorld().getHeight(); y++)
        {
            if (isBlackAt(xPos,y))
            {
                getMWorld().setRGBColorAt(xPos,y,col);
                getMWorld().setBackgroundColorAt(xPos,y,col);
            }
        }
        if (xPos < getMWorld().getWidth())
        xPos++;
    }
}
