import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.awt.Color;
import java.awt.Font;

/**
 * Write a description of class Key here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Key extends Keyboard
{
    private String letter;
    private String orgLetter;
    private GreenfootImage image;
    private int acts = 0;
    private String curKey = "";
    
    public Key(String key)
    {
        letter = key;
        orgLetter = key;
        image = new GreenfootImage(50, 50);
        image.setColor(new Color(255,255,255, 128));
        image.fillRect(0, 0, 50, 50);
        image.setColor(new Color(0, 0, 0, 128));
        image.fillRect(5, 5, 40, 40);
        Font font = new Font("Courier", image.getFont().getStyle(), image.getFont().getSize()) ;
        font = font.deriveFont(50f);
        image.setFont(font);
        image.setColor(Color.WHITE);
        image.drawString(letter, 10, 40);
        //setUpperOrLower();
        setImage(image);
    }
    public void act() 
    {
        if (Greenfoot.mouseMoved(this))
        {
            image.setColor(Color.RED);
            image.drawString(letter, 10, 40);
        }
        else
        {
            image.setColor(Color.WHITE);
            image.drawString(letter, 10, 40);
        }
        setUpperOrLower();
        if ( (Greenfoot.mouseClicked(this) || Greenfoot.isKeyDown(orgLetter)) && acts == 0 )
        {
            Greenfoot.playSound("click.wav");
            acts = -15;
            image.setColor(Color.RED);
            image.drawString(letter, 10, 40);
            getLand().d.add(letter);
        }
        if (acts != 0)
        acts++;
        setImage(image);
    }    
    public void setUpperOrLower()
    {
        if (getLand().d.isUpperCase())
        {
            if (Character.isLowerCase(letter.charAt(0)) )
            {
                char a = Character.toUpperCase(letter.charAt(0));
                letter = ""+a;
                image.clear();
                image.setColor(new Color(255,255,255, 128));
                image.fillRect(0, 0, 50, 50);
                image.setColor(new Color(0, 0, 0, 128));
                image.fillRect(5, 5, 40, 40);
                Font font = new Font("Courier", image.getFont().getStyle(), image.getFont().getSize()) ;
                font = font.deriveFont(50f);
                image.setFont(font);
                image.setColor(Color.WHITE);
                image.drawString(letter, 10, 40);
            }
        }
        else
        {
            if (Character.isUpperCase(letter.charAt(0)) )
            {
                char a = Character.toLowerCase(letter.charAt(0));
                letter = ""+a;
                image.clear();
                image.setColor(new Color(255,255,255, 128));
                image.fillRect(0, 0, 50, 50);
                image.setColor(new Color(0, 0, 0, 128));
                image.fillRect(5, 5, 40, 40);
                Font font = new Font("Courier", image.getFont().getStyle(), image.getFont().getSize()) ;
                font = font.deriveFont(50f);
                image.setFont(font);
                image.setColor(Color.WHITE);
                image.drawString(letter, 10, 40);
            }
        }
    }
    
}
