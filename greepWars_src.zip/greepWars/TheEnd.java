import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Displays the end story line using jpg.
 * 
 * @author Anthony Hoang
 * @version 2.1
 */
public class TheEnd extends Actor
{
    private GreenfootImage a = new GreenfootImage("End/1.jpg");
    private GreenfootImage b = new GreenfootImage("End/2.jpg");
    private GreenfootImage c = new GreenfootImage("End/3.jpg");
    private GreenfootImage d = new GreenfootImage("End/4.jpg");
    private GreenfootImage e = new GreenfootImage("End/5.jpg");
    private GreenfootImage f = new GreenfootImage("End/6.jpg");
    private GreenfootImage g = new GreenfootImage("End/7.jpg");
    private GreenfootImage h = new GreenfootImage("End/8.jpg");
    

    private int delay = 0;
    private int cur = 0;
    public void act() 
    {
        if (delay < 0) delay++;
        if (delay == 0)
        {
            next();
            delay = -500;
        }
        if (cur >= 7 && delay%100 == 0) 
        {
            ((Space)getWorld()).addObject(new Greepers(0), Greenfoot.getRandomNumber(800), Greenfoot.getRandomNumber(600));
        }
    }    
    public void next()
    {
        cur++;
        if (cur == 1) setImage(a);
        if (cur == 2) setImage(b);
        if (cur == 3) setImage(c);
        if (cur == 4) setImage(d);
        if (cur == 5) setImage(e);
        if (cur == 6) setImage(g);
        if (cur == 7) setImage(h);
        //((Space)getWorld()).showScoreBoard();
    }
}
