import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class ScrollBackground here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class ScrollBackground  extends ScrollActor
{
    private int width, height;
    private static GreenfootImage bg;
    public ScrollBackground(int realX, int realY)
    {
        super(realX, realY);
        bg = new GreenfootImage("images/ground.png");
        setImage(bg);
        width = getImage().getWidth();
        height = getImage().getHeight();
    }
    
    public void act() 
    {
        super.act();
        //getWorld().getBackground().drawImage(bg, width/2 - getWorld().getSX(), height/2 - getWorld().getSY()); 
    }    
    
    public void setLocation(int x, int y)
    {
        super.setLocation(x + width/2, y + height/2);
    }
}
