import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.util.List;
/**
 * Write a description of class LGGateChecker here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class LGGateChecker  extends LogicGate
{
    private static GreenfootImage img;
    private static GreenfootImage img2;
    private String gate;
    private String curGate;
    
    public LGGateChecker(String gate)
    {
        this.gate = gate;
        if (img == null)
        {
            img = new GreenfootImage("logicgates/gatechecker.png");
            img2 = new GreenfootImage("logicgates/gatecheckerwrong.png");
        }
        setImage(img);
    }
    public void act() 
    {
        if (getMWorld().esPause) return;
        check();
    }    
    public void check()
    {
        List<LGGates> list = getIntersectingObjects(LGGates.class);
        for (LGGates lg : list)
        {
            if (lg.getX()==getX() && lg.getY()==getY())
            curGate = lg.getType();
        }
        if (list.size() == 0)
        curGate = "";
        if (!getMWorld().isBlackAt(getX(),getY()))
        {
            if (!isCorrect())
            {
                if (getImage().equals(img))
                setImage(img2);
            }
            else
            if (getImage().equals(img2))
            setImage(img);
        }
    }
    public boolean isCorrect()
    {
        return curGate.equals(gate);
    }
    
}
