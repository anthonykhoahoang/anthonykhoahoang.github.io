import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.util.ArrayList;
import java.util.List;
/**
 * Write a description of class LevelSwitch here.
 * 
 * @author Anthony Hoang
 * @version (v1)
 */
public class LatchSwitch  extends Switch
{
    private static GreenfootImage image1;
    private static GreenfootImage image2;
    private ArrayList<String> latches;
    private int delay = 0;
    public LatchSwitch(ArrayList<String> arr)
    {
        latches = arr;
        if (image1 == null)
        {
            image1 = new GreenfootImage("switch2.png");
            image2 = new GreenfootImage(image1);
            image2.mirrorVertically();
        }
        setImage(image1);
    }
    public void act() 
    {
        if (getMWorld().esPause) return;
        if (delay > 0)
        {
            delay--;
            return;
        }
        Actor a = getOneIntersectingObject(InGameCharacter.class);
        if (Greenfoot.isKeyDown(getMWorld().use)
        && Greenfoot.isKeyDown(getMWorld().use) && a != null)
        {
            Greenfoot.playSound("latch.wav");
            if (getImage().equals(image1))
            setImage(image2);
            else
            setImage(image1);
            switchLatches();
            delay = 10;
        }
    }    
    public void switchLatches()
    {
        List<Latch> list = getMWorld().getObjects(Latch.class);
        for (Latch l : list)
        if (latches.contains(l.getID()))
        l.switchOpenClose();
    }
}