import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Bullet6 - level 6 of the bullet the rocket can shoot.
 * 
 * @author (Anthony Hoang) 
 * @version (2.0)
 */
public class Bullet6 extends Bullet
{
    public Bullet6 (Vector speed, int rotation, int dmg, boolean sounds, Rocket rocket)
    {
        super(speed, rotation, dmg+30, false, rocket);
        if (sounds)
        Greenfoot.playSound("bullet6.wav");
    }
    public void act() 
    {
        super.act();
    }    
}
