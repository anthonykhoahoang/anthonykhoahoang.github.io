import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Bullet3 - level 3 of the bullets the rocket can shoot
 * 
 * @author (Anthony Hoang) 
 * @version (2.0)
 */
public class Bullet3 extends Bullet
{
    public Bullet3 (Vector speed, int rotation, int dmg, boolean sounds, Rocket rocket)
    {
        super(speed, rotation, dmg+15, false, rocket);
        if (sounds)
        Greenfoot.playSound("bullet3.wav");
    }

    public void act() 
    {
        super.act();
    }    
}
