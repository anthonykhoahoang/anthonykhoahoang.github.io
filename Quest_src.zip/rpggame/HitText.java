import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.awt.Color;
import java.awt.Font;

/**
 * Write a description of class HitText here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class HitText extends Battle
{
    private GreenfootImage image;
    private Color col;
    private int n = 0;
    public HitText(int amount, Color col)
    {
        this.col = col;
        n = amount;
        image = new GreenfootImage(100, 30);
        Font font = new Font("Courier", image.getFont().getStyle(), image.getFont().getSize()) ;
        font = font.deriveFont(50f);
        image.setFont(font);
        image.setColor(col);
        image.drawString(""+amount, 10, 25);
        setImage(image);
    }
    public void act() 
    {
        Font font = image.getFont();
        if (font.getSize() <= 1)
        getLand().removeObject(this);
        else
        {
            setLocation(getX(),getY()-1);
            image.clear();
            Font f = new Font("Courier", image.getFont().getStyle(), image.getFont().getSize()-1) ;
            image.setFont(f);
            image.setColor(col);
            image.drawString(""+n, 10, 25);
            setImage(image);
        }
    }    
}
