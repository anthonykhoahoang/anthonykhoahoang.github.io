import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Bullet7 - level 7 of the bullet the rocket can shoot.
 * 
 * @author (Anthony Hoang) 
 * @version (2.0)
 */
public class Bullet7 extends Bullet
{
    public Bullet7 (Vector speed, int rotation, int dmg, boolean sounds, Rocket rocket)
    {
        super(speed, rotation, dmg+35, false, rocket);
        if (sounds)
        Greenfoot.playSound("bullet7.wav");
    }
    public void act() 
    {
        super.act();
    }    
}
