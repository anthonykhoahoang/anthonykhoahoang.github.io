import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.util.List;
/**
 * Write a description of class SmallEnergyDrainSpike here.
 * 
 * @author Anthony Hoang
 * @version (v1)
 */
public class SmallEnergyDrainSpike  extends Particle
{
    private static GreenfootImage img;
    private int transparency = 150;
    private int transReduce = 5;
    private boolean firstInitialize = true;
    private double x;
    private double y;
    private int r;
    private Vector v = new Vector();
    private int curImage = 0;
    private static GreenfootImage[] images;
    
    public SmallEnergyDrainSpike(int r)
    {
        this.r = r;
        if (img == null)
        {
            img = new GreenfootImage("energyDrainSpike.png");
            img.scale(img.getWidth()/2, img.getHeight()/2);
        }
        if (images == null)
        {
            images = new GreenfootImage[30];
            int n = 0;
            for (int i = 0; i < 30; ++i)
            {
                images[i] = new GreenfootImage(img);
                images[i].setTransparency(this.transparency - n);
                n += this.transReduce;
            }
        }
        setImage(images[this.curImage]);
    }
    public void act() 
    {
        if (getMWorld().esPause) return;
        if (firstInitialize)
        {
            x = getX();
            y = getY();
            firstInitialize = false;
        }
        else
        {
            curImage += 1;
            if (curImage == 30) 
            {
                getMWorld().removeObject(this);
            }
            else 
            {
                checkHit();
                setImage(images[curImage]);
                random();
                move();
            }
        }
        
    }   
    public void checkHit()
    {
        List<InGameCharacter> list = getIntersectingObjects(InGameCharacter.class);
        List<HelperBot> list2 = getIntersectingObjects(HelperBot.class);
        if (list.size() > 0)
        {
            InGameCharacter c = list.get(0);
            if (Math.abs(c.getX()-getX()) < 10 && Math.abs(c.getY()-getY()) <20)
            {
                List<NanoSuit> list3 = getMWorld().getObjects(NanoSuit.class);
                if (list3.size() != 0)
                {
                    list3.get(0).lowerEnergy(5);
                }
            }
        }
        else
        if (list2.size() > 0)
        {
            HelperBot c = list2.get(0);
            if (Math.abs(c.getX()-getX()) < 5 && Math.abs(c.getY()-getY()) < 5)
            {
                c.hit();
            }
        }
    }
    public void random()
    {
        v.add(new Vector((int)(Math.random()*360),Math.random()*.3));
        v.add(new Vector(270, .04));
    }
    public void move()
    {
        v.add(new Vector(r, .05));
        x+=v.getX();
        y+=v.getY();
        setLocation((int)x,(int)y);
    } 
}
