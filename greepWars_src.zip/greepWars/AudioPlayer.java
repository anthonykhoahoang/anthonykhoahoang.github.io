import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import javax.sound.midi.*;
import java.net.URL;
import java.net.MalformedURLException;
import java.io.IOException;
import java.io.InputStream;
/**
 * Audioplayer plays midi files. It can be paused and resumed by clicking on the actor.
 * 
 * @author Anthony Hoang
 * @version 2.2
 */
public class AudioPlayer extends Actor
{
    private GreenfootImage sounds = new GreenfootImage("song.jpg");
    private GreenfootImage noSounds = new GreenfootImage("noSong.jpg");
    private Sequencer sequencer;
    private String file;
    private int numActs = 0;
    private boolean isOn;
    private boolean repeat;
    public AudioPlayer(String fileName, boolean r)
    {
        file = "music/"+fileName+".mid";
        load(file, true);
        setImage(sounds);
        repeat = r;
        
    }
    public void act() 
    {
        if (numActs == 0)
        {
            sequencer.start();
            numActs++;
            isOn = true;
        }
        if (Greenfoot.mousePressed(this) )
        if (!sequencer.isRunning())
        {
            isOn = true;
            sequencer.start();
            setImage(sounds);
        }
        else
        {
            isOn = false;
            sequencer.stop();
            setImage(noSounds);
        }
        
        if (repeat && sequencer.getTickPosition() == sequencer.getTickLength())
        {
            sequencer.setTickPosition(0);
            sequencer.start();
        }
    }    
    public void close()
    {
        sequencer.stop();
        ( (Space)getWorld()).removeObject(this);
    }
    public void play()
    {
        sequencer.start();
            numActs++;
            isOn = true;
    }
    public void load(String fileName, boolean loop)
    {
        try 
        {
            URL url = getClass().getClassLoader().getResource(fileName);
            if(url == null)
            throw new IOException("File not found: " + fileName);
            Sequence sequence = MidiSystem.getSequence(url);
            
            // Create a sequencer for the sequence
            sequencer = MidiSystem.getSequencer();
            sequencer.open();
            sequencer.setSequence(sequence);
        } 
        catch (MalformedURLException e) {
        } catch (IOException e) {
        } catch (MidiUnavailableException e) {
         } catch (InvalidMidiDataException e) {
            } 
    }

}
