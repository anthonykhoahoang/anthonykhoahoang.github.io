import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class EB6 here.
 * 
 * @author Anthony Hoang
 * @version 2.1
 */
public class EB6 extends EnemyBullet
{
    public EB6(int rotation, int life, boolean sounds, Enemy e)
    {
        super(rotation, life, 30, false, e);
        if (sounds)
        Greenfoot.playSound("bullet6.wav");
    }
}
