import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.awt.Color;

/**
 * Write a description of class FadeOut here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class FadeOut extends FadeIn
{
    public static final int WIDTH = 1024;
    public static final int HEIGHT = 600;
    private int t;
    
    private GreenfootImage image;
    
    public FadeOut()
    {
        t = 255;
        image = new GreenfootImage(WIDTH, HEIGHT);
        image.setColor(new Color(0, 0, 0, 255));
        image.fillRect(0, 0, WIDTH, HEIGHT);
        setImage(image);
    }
    public void act() 
    {
        t -=10;
        image.clear();
        if (t <255)
        image.setColor(new Color(0, 0, 0, t));
        image.fillRect(0, 0, WIDTH, HEIGHT);
        setImage(image);
        if (t <= 10)
        {
            getLand().isPause = false;
            getLand().removeObject(this);
        }
            
    }    
    public Land getLand()
    {
        return (Land)getWorld();
    }
}
