import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.io.BufferedInputStream;
import java.io.FileInputStream;
import java.net.URL;
import javazoom.jl.player.Player;
import java.io.IOException;
import java.io.InputStream;
/**
 * Plays mp3 file using Jlayer mp3 library
 * 
 * @author Anthony Hoang
 * @version 1
 */
public class MP3Player  extends Actor
{
    private Player player;
    private String fileName;
    private boolean repeat;
    private long prevPos = -1;
    private BufferedInputStream bis = null;
    private InputStream fis = null;
    private int checkDelay = 20;
    private Thread thread = null;
    private boolean paused = false;
    
    public MP3Player(boolean repeat)
    {
        getImage().clear();
        this.repeat = repeat;
    }
    public MP3Player()
    {
        getImage().clear();
        repeat = false;
    }
    public void pause()
    {
        paused = true;
        close();
    }
    public void close()
    {
        try {
            if (player!=null)
            player.close();
            if (bis != null)
            bis.close();
            if (fis != null)
            fis.close();
            repeat = false;
            //if (thread != null)
            //thread.stop();
        }
        catch(Exception e) {}
    }
    public void resume()
    {
        if (paused)
        {
            if (fileName != null)
            playFile(fileName, repeat);
            paused = false;
        }
    }
    public void act()
    {
        //System.out.println(player.getPosition());
        if (repeat && checkDelay == 0)
        {
            checkDelay = 20;
            long curPos = player.getPosition();
            if (prevPos == curPos)
            {
                prevPos = -1;
                playFile(fileName);
            }
            else prevPos = curPos;
        }
        else 
        if (checkDelay > 0) checkDelay--;
    }
    public void repeat(boolean bool)
    {
        repeat = bool;
    }
    public void playFile(String file, boolean rep)
    {
        this.repeat = rep;
        playFile(file);
    }
    public void playFile(String file)
    {
        this.fileName = file;
        if (!this.fileName.endsWith(".mp3"))
        fileName += ".mp3";
        try {
            prevPos = -1;
            if (player!=null)
            player.close();
            if (bis != null)
            bis.close();
            if (fis != null)
            fis.close();
           // if (thread != null)
            //thread.stop();
            URL url;
            url = getClass().getClassLoader().getResource(fileName);
            if(url == null)
            throw new IOException("IO ER" + fileName);
            fis = url.openStream();
            bis = new BufferedInputStream(fis);
            
            player = new Player(bis);
            thread = new Thread() {
            public void run() {

                try {
                 player.play(); }
                catch (Exception e) { System.out.println(e); }
            }
        };
        thread.setPriority(Thread.MIN_PRIORITY);
        thread.start();
        }
        catch (Exception e) {
            System.out.println("IO ER" + fileName);
            System.out.println(e);
        }
    }
}