import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.util.ArrayList;
import java.util.List;
/**
 * Write a description of class  here.
 * 
 * @author Anthony Hoang
 * @version (v1)
 */
public class BotReleaseSwitch  extends Switch
{
    private static GreenfootImage image1;
    private static GreenfootImage image2;
    private int[] x;
    private int[] y;
    private int delay;
    private int delayLim;
    private int range;
    
    public BotReleaseSwitch(int range, int delay, int[] x, int[] y)
    {
        if (image1 == null)
        {
            image1 = new GreenfootImage("switch3.png");
            image2 = new GreenfootImage(image1);
            image2.mirrorVertically();
        }
        setImage(image1);
        this.range = range;
        this.x = x;
        this.y = y;
        delayLim = delay;
        this.delay = 0;
    }
    public void act() 
    {
        if (getMWorld().esPause) return;
        if (delay > 0)
        {
            delay--;
            for (int i = 0; i < 2; i++)
            getMWorld().addObject(new SmokeParticle((int)(Math.random()*360)),getX(),getY());
            return;
        }
        else
        if (getImage().equals(image2))
            setImage(image1);
        Actor a = getOneIntersectingObject(InGameCharacter.class);
        if (Greenfoot.isKeyDown(getMWorld().use)
        && Greenfoot.isKeyDown(getMWorld().use) && a != null)
        {
            Greenfoot.playSound("latch.wav");
            if (getImage().equals(image1))
            setImage(image2);
            else
            setImage(image1);
            addBotHoles();
            delay = delayLim;
        }
    }    
    public void addBotHoles()
    {
        for (int i = 0; i < x.length; i++)
        getMWorld().addObject(new BotHole(range),x[i],y[i]);
    }
}