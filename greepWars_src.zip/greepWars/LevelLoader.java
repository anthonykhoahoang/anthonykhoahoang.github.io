import greenfoot.*;  // (World, Actor, GreenfootImage, and Greenfoot)
import java.awt.Color;
import java.awt.Font;
/**
 * Write a description of class GameMode here.
 * 
 * @author Anthony Hoang
 * @version 1.1
 */
public class LevelLoader extends GameMode
{
    public static final float FONT_SIZE = 25.0f;
    public static final int WIDTH = 155;
    public static final int HEIGHT = 50;
    private GreenfootImage image;
    public LevelLoader()
    {
         image = new GreenfootImage(WIDTH, HEIGHT);
         image.setColor(new Color(200, 50, 10, 128));
         image.fillRect(0, 0, WIDTH, HEIGHT);
         Font font = image.getFont();
         font = font.deriveFont(FONT_SIZE);
         image.setFont(font);
         image.setColor(Color.WHITE);
         image.drawString("Load Level", 15 , 35);
         setImage(image);
    }
    public void act()
    {
        image.clear();
        if (Greenfoot.mouseMoved(this))
            {
                image.setColor(new Color(255, 255, 10, 128));
                image.fillRect(0, 0, 225, HEIGHT);
                image.setColor(Color.WHITE);
                image.drawString("Load Level", 15 , 35);
            }
            else
            {
                image.setColor(new Color(200, 50, 10, 128));
                image.fillRect(0, 0, 225, HEIGHT);
            
                image.setColor(Color.WHITE);
                image.drawString("Load Level", 15 , 35);
            }
            if (Greenfoot.mousePressed(this))
            {
                getSpace().addKeyBoard();
                
                getSpace().removeMessage();
                getSpace().removeGameModes();
                return;
               // getSpace().removeObject(this);
            }
    }
     public Space getSpace() 
    {
        return (Space)getWorld();
    }
}