import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class FiveSoldier here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class FiveSoldiers extends Enemy
{
    private int numActs = 0;
    private boolean willAttack;
    public FiveSoldiers()
    {
    }
    public void act() 
    {
        if (getObjectsInRange(200, InGameChar.class).size() != 0)
        willAttack = true;
        if (willAttack)
        {
            getLand().addObject(new InstantText("soldier/halt", 200, 12f), getX(), getY()-100);
            Greenfoot.delay(50);
            int n = getLand().charLevel;
            getLand().loadBattleType1();
            int delay = 500 - n*10;
            if (delay < 100) delay = 100;
            
            getLand().addObject(new SmallThunderShard(), getX()+10, getY());
            getLand().addObject(new Potion(), getX(), getY());
            getLand().addObject(new Potion(), getX(), getY()-10);
            getLand().addObject(new BattleSoldier(n*10-5*(n-1), 0, delay-Greenfoot.getRandomNumber(20), 3*n - 2*(n-1)), 728, 396);
            getLand().addObject(new BattleSoldier(n*10-5*(n-1), 0, delay+Greenfoot.getRandomNumber(20), 3*n - 2*(n-1)), 728, 293);
            getLand().addObject(new BattleSoldier( n*10-5*(n-1), 0, delay-Greenfoot.getRandomNumber(20), 3*n - 2*(n-1)  ) , 835, 252);
            getLand().addObject(new BattleSoldier(n*10-5*(n-1), 0, delay+Greenfoot.getRandomNumber(20), 3*n - 2*(n-1)), 835, 346);
            getLand().addObject(new BattleSoldier(n*10-5*(n-1), 0, delay, 3*n - 2*(n-1)), 835, 436);
            //getLand().curEXP += 10;
            getLand().removeObject(this);
            
            
        }
    }    
}
