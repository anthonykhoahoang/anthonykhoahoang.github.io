import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
/**
 * Write a description of class BouncyPlatform here.
 * 
 * @author Anthony Hoang
 * @version v1
 */
public class BouncyPlatform  extends Platform
{
    private int h = 50;
    private int speed = 0;
    private int SPEEDMAX = 5;
    private boolean goingDown = false;
    private boolean firstHit = false;
    private double x2;
    private double nextAdd;
    private int x1, y1;
    private double num = 2*Math.PI;
    private boolean dd = false;
    public BouncyPlatform()
    {
        super();
        setImage(new GreenfootImage(platform1));
        speed = 0; 
        SPEEDMAX = 5;
        num = 2*Math.PI;
    }
    public BouncyPlatform(int h, int w, int speed)
    {
        this();
        this.h = h; //how high to bounce
        this.SPEEDMAX = speed;
        getImage().scale(w, getImage().getHeight());
    }
    public void act() 
    {
        if (getMWorld().esPause) return;
        if (!isAbove())
        {
            firstHit = false;
        }
        else
        {
            if (firstHit == false && !goingDown)
            {
                goingDown = true;
                dd = false;
                x2 = 0;
                //firstHit = true;
                num = 2*Math.PI;
                x1 = getX();
                y1 = getY();
            }
            firstHit = true;
        }
        if (goingDown)
        {
            bounceAndMoveChar();
        }
    }    
    public void bounceAndMoveChar()
    {
        if (x2 > 10*Math.PI)
        {
            goingDown = false;
            return;
        }
        nextAdd = h*Math.sin(x2);
        boolean isAbove = isAbove();
        setLocation(x1, y1+(int)nextAdd);
        if (isAbove)
        moveChar();
        x2+=.05;
    }
    public void moveChar()
    {
        Actor a = getOneIntersectingObject(InGameCharacter.class);
        if (a != null) 
        {
            int t = getY();
            a.setLocation(a.getX(), t-getImage().getHeight()/2-a.getImage().getHeight()/2);
        }
    }
}
