import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.util.List;

/**
 * This is the basic class of an enemy. Provides basic methods for enemies.
 * 
 * @author Anthony Hoang
 * @version (a version number or a date)
 */
public class Enemy2 extends Enemy
{
    private int curHealth;
    private int health;
    private int scoreAmount;
    private int speed = 3;
    public Enemy2(){}
    public Enemy2 (int h, int score)
    {
        health = h;
        curHealth = h;
        scoreAmount = score;
    }
    public int getHealth()
    {
        return curHealth;
    }
    public void act() 
    {
    }    
    public void hit(int damage)
    {
        curHealth -= damage;
        if(curHealth <= 0)
        {
            getSpace().removeEnemy();
            die();         
        }
    }
    public int healthPercent()
    {
        double d = (double)curHealth/(double)health*100.0;
        return (int)d;
    }
    public void heal(int amount) 
    {
        curHealth += amount;
        if (curHealth > health)
        curHealth= health;
    }
    private void die() 
    {
        Space space = getSpace();
        if (scoreAmount >= 100)
        {
            getSpace().addExplosion(getX(),getY());
        }
        if (this instanceof Greep)
        {
            getSpace().addGreepsKilled();
            getSpace().addGreepBlood(getX(), getY());
            if (randomChance(1)) space.addRandomWeaponLevelUpgrade(2);
        }
        if (this instanceof GreepShip)
        {
            if (randomChance(10))
            space.addRandomGreepHole2(1);
            if (randomChance(25))
            space.addRandomGreepShip(1);
            if (randomChance(10))
            space.addRandomGreepShip2(1);
            
            if (randomChance(2)) space.addRandomWeaponLevelUpgrade(2);
            space.addSpaceShipKilled();
        }
        getSpace().score(scoreAmount);
        getSpace().checkClear();
        getSpace().removeObject(this);
    }
    public void move2()
    {
        double angle = Math.toRadians( getRotation() );
        int x = (int) Math.round(getX() + Math.cos(angle) * 2);
        int y = (int) Math.round(getY() + Math.sin(angle) * 2);
        setLocation(x, y);
    }
    public void moveSlow()
    {
        double angle = Math.toRadians( getRotation() );
        int x = (int) Math.round(getX() + Math.cos(angle) * 1);
        int y = (int) Math.round(getY() + Math.sin(angle) * 1);
        if(x >= getWorld().getWidth()) 
        {
            x = 0;
        }
        if(x < 0) {
            x = getWorld().getWidth() - 1;
        }
        if(y >= getWorld().getHeight()) {
            y = 0;
        }
        if(y < 0) {
            y = getWorld().getHeight() - 1;
        }
        setLocation(x, y);
    }
    public void move()
    {
        double angle = Math.toRadians( getRotation() );
        int x = (int) Math.round(getX() + Math.cos(angle) * 3);
        int y = (int) Math.round(getY() + Math.sin(angle) * 3);
        if (atBottomEdge())
        {
            getSpace().score(-scoreAmount);
            setLocation(x, 0);
        }
        else
        setLocation(x, y);
    }
    public void turn(int angle)
    {
        setRotation(getRotation() + angle);
    }
    public void turnToShip()
    {
        List rocketL = getNeighbours(999, true, Plane.class);
        if (rocketL.size() != 0)
        {
            Rocket temp = (Rocket)rocketL.get(0);
            if (!temp.isDead )
            {
                int deltaX = (temp.getX() - getX());
                int deltaY = (temp.getY() - getY());
                setRotation((int) (180 * Math.atan2(deltaY, deltaX) / Math.PI));
            }
           else if (getSpace().twoP())
            {
                temp = (Rocket)rocketL.get(rocketL.size()-1);
            int deltaX = (temp.getX() - getX());
                int deltaY = (temp.getY() - getY());
                setRotation((int) (180 * Math.atan2(deltaY, deltaX) / Math.PI));
            }
        }
    }
    public int turnToShipInt()
    {
        List rocketL = getNeighbours(999, true, Plane.class);
        int turn = 0;
        if (rocketL.size() > 0)
        {
            Rocket temp = (Rocket)rocketL.get(0);
            if (!temp.isDead )
            {
                int deltaX = temp.getX()-getX();
                int deltaY = temp.getY()-getY();
            
                turn = (int) (180 * Math.atan2(deltaY, deltaX) / Math.PI);
            }
            else if (getSpace().twoP())
            {
                temp = (Rocket)rocketL.get(rocketL.size()-1);
            int deltaX = (temp.getX() - getX());
                int deltaY = (temp.getY() - getY());
                setRotation((int) (180 * Math.atan2(deltaY, deltaX) / Math.PI));
            }
        }
        return turn;
    }
    public boolean randomChance(int percent)
    {
        return Greenfoot.getRandomNumber(100) < percent;
    }
    public Space getSpace() 
    {
        return (Space)getWorld();
    }
    public boolean atLeftEdge()
    {
        if (getX() < 200)
        return true;
        return false;
    }
    public boolean atRightEdge()
    {
        if ( getX() > getWorld().getWidth() - 200)
        return true;
        return false;
    }
    public boolean atTopEdge()
    {
        if(getY() < 10 )
            return true;
        return false;
    }
    public boolean atBottomEdge()
    {
        if (getY() > getWorld().getHeight() - 10)
            return true;
        return false;
    }
    public boolean atWorldEdge()
    {
        if(getX() < 200 || getX() > getWorld().getWidth() - 200)
            return true;
        if(getY() < 10 || getY() > getWorld().getHeight() - 10)
            return true;
        else
            return false;
    }
    
    public void moveForward()
    {
        if (!atBottomEdge())
        setLocation(getX(), getY()+speed);
        else setLocation(getX(), getWorld().getHeight()-11);
    }
    public void moveBackward()
    {
        setLocation(getX(), getY()-speed);
    }
    public void moveLeft()
    {
        if (!atLeftEdge())
        setLocation(getX()-speed, getY());
    }
    public void moveRight()
    {
        if (!atRightEdge())
        setLocation(getX()+speed, getY());
    }
}
