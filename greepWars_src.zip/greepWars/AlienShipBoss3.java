import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * boss alienship
 * 
 * @author Anthony Hoang
 * @version 2.1
 */
public class AlienShipBoss3 extends AlienShipBoss2
{
    
    private int delay = 0;
    
    private int numActs = 0;
    
    /** Delay time for AAS attack */
    private int aasDelay = 200;
    private int num = 3;
     
    /**
     * Create a space ship. The parameter specifies at what height to land.
     */
    public AlienShipBoss3(int life)
    {
        super(life, 1000);
        setImage("enemyShip/spaceShipBoss4.png");
        numActs = 0;
    }
    public void act()
    {
        getSpace().bossLife.setLocation(this.getX(), this.getY() + getImage().getHeight() / 2);
        getSpace().bossLife.updateImage2(this.healthPercent());
        
        if (aasDelay <= 0)
        {
            AAS();
            //if (getRandomChance(10)
            if (num < 8)
            num++;
            getSpace().addAlienShips(num);
            aasDelay = 200;
            System.gc();
        }
        aasDelay--;
        moveSlow();
        if (aasDelay%4 == 0)
        shootRayGun();
        /*
            numActs++;
        if (numActs < 60)
        {
            if (delay == 0)
            {
                addGreepers();
                delay = 20;
            }
            else delay--;
        }
        if (numActs >= 200) numActs = 0;
        */
    }
    public void addGreepers()
    {
        getSpace().addObject(new Greepers2(), getX(), getY()+getImage().getHeight() / 2);
        getSpace().addObject(new Greepers(1000), getX(), getY() + getImage().getHeight() / 2);
        getSpace().addObject(new FastGreeper(1000), getX(), getY() + getImage().getHeight() / 2);
        getSpace().addEnemy();
        getSpace().addEnemy();
        getSpace().addEnemy();
    }
    public void shootRayGun()
    {
        EB7 b = new EB7( turnToShipInt(), 80, false, this);
        getWorld().addObject(b, getX(), getY());
        b.move();
    }
    public void AAS()
    {
        int r = getRotation();
        for (int i = 0; i < 360; i++)
        {
            EB4 b = new EB4(r, 80, false, this);
            getWorld().addObject(b, getX(), getY());
            b.move();
            
            r += 10;
        }
        Greenfoot.playSound("aas.wav");
    }
}
