import greenfoot.*;  // (World, Actor, GreenfootImage, and Greenfoot)
import java.awt.Color;
import java.awt.Point;
import java.util.*;
import java.lang.Object.*;
import java.lang.Integer;
/**
 * ... the final frontier
 * 
 * @author Poul Henriksen
 * anthony hoang modified it.
 */
public class Space extends World
{
    private GreenfootImage a = new GreenfootImage("spaceimage.png");
    private GreenfootImage b = new GreenfootImage("spaceimage2.jpg");
    private GreenfootImage c = new GreenfootImage("sand.jpg");
    private GreenfootImage d = new GreenfootImage("spaceimage3.jpg");      
    
    private Counter scoreCounter;
    private Counter gameLevel;
    public Counter bossLife;
    
    private int startAsteroids = 2;
    private Rocket rocket;
    private Rocket rocket2;
    private RocketBooster rB1;
    private RocketBooster rB2;
    private boolean twoPlayers;
    
    private int level;
    private int maxUpgradeLevel;
    public int numGreeps;
    public int alienShipLife;
    public int greepRange;
    private int numEnemies;
    
    private int numGreepsKilled;
    private int numSpaceShipKilled;
    private int numAsteroidDestroyed;
    
    public Display keyBoardDisplay;
    public String gameLevelDataInput = "Enter Auth Code";
    //"Enter Auth Code";
    public String gameLevelDataOutput = "";
    /**
     * save and load game stuff
     */
    //private SaveGame save;
    //private SaveGame load;
    private SystemMessage sysMessage;
    private ArrayList<Actor> actors = new ArrayList<Actor>();
    private int[] spaceStats = new int[12];
    private ArrayList<Integer> xPos = new ArrayList<Integer>();
    private ArrayList<Integer> yPos = new ArrayList<Integer>();
    private int[] r1Stats = new int[10];
    private int[] r2Stats = new int[10];

    /**
     * These are the upgrade counters
     */
    
    private Counter numLife;
    private Counter gunLevel;
    private Counter numAAS;
    private Counter shieldLevel;
    private Counter numGuns;
    private Counter energyLevel;
    private Counter numMissles;
    private Counter numMGAmmo;
    
    private Counter numLife2;
    private Counter gunLevel2;
    private Counter numAAS2;
    private Counter shieldLevel2;
    private Counter numGuns2;
    private Counter energyLevel2;
    private Counter numMissles2;
    private Counter numMGAmmo2;
    
    private AudioPlayer ap;
    private int difficulty = 0;
    private boolean gameStarted = false;
    private int delay = -50;
    /**
     * Gametype 2 stuff
     */
    private int numPlayers;
    private boolean gameType2 = false;
    private Plane player1;
    private Plane player2;
    private Plane player3;
    private Plane player4;
    
    public Counter life1;
    public Counter weaponLevel1;
    public Counter special1;
    
    public Counter life2;
    public Counter weaponLevel2;
    public Counter special2;
    
    public Counter life3;
    public Counter weaponLevel3;
    public Counter special3;
    
    public Counter life4;
    public Counter weaponLevel4;
    public Counter special4;
    
    public Space() 
    {
        super(800, 615, 1);
        //setPaintOrder(Explosion.class, SmallExplosion.class, HighLighter.class, Rocket.class);
        ap = new AudioPlayer("1", true);
        addObject( ap, 780, 50);
        //loadMenu();
        addObject(new GreepMouse(), 0,0);
        loadMainMenu();
        numGreepsKilled = 0;
        numSpaceShipKilled = 0;
        numAsteroidDestroyed = 0;
        numEnemies = 0;
        setBackground(a);
    }
    public void loadMainMenu()
    {
        removeMessage();
        removeObjects(getObjects(GameMode.class));
        addObject(new Title(), getWidth()/2, 171);
        addObject(new ChooseLevel(), 423, 342);
        addObject(new LostInSpace(), 211, 505);
        addObject(new DefendEarth(), 616, 510);
    }
    public void act()
    {
        if (gameStarted)
        {
            //checkClear();
            /*
            if (delay == 0)
            {
                delay = -50;
                if (!gameType2)
                updateAllCounters();
            }
            */
          //  if (delay < 0 ) delay++;
            if (Greenfoot.isKeyDown("p"))
            {
                if (!twoPlayers)
                    addObject(new Message("pause", true), getWidth()/2, getHeight()/2);
                else
                    addObject(new Message("pause2", true), getWidth()/2, getHeight()/2);
                    
                Greenfoot.stop();
            }
       }
    }
    public void loadOnePlayerMenu()
    {
        removeObjects(getObjects(ReturnToMainMenu.class));
        removeObjects(getObjects(NumPlayers.class));
        addObject(new Easy(1), 452, 211);
        addObject(new Medium(1), 452, 276);
        addObject(new Hard(1), 452, 346);
        addObject(new ReturnToMenu(), 646, 571);
    }
    public void loadTwoPlayerMenu()
    {
        removeObjects(getObjects(ReturnToMainMenu.class));
        removeObjects(getObjects(NumPlayers.class));
        addObject(new Easy(2), 452, 211);
        addObject(new Medium(2), 452, 276);
        addObject(new Hard(2), 452, 346);
        addObject(new ReturnToMenu(), 646, 571);
    }
    public void loadMenu()
    {
        removeObjects(getObjects(MainMenu.class));
        removeMessage();
        removeGameModes();
        //removeKeyBoard();
        
        addObject(new ReturnToMainMenu(), 628, 571);
        addObject(new Message("preGame"), 180, 280);
        addObject(new LevelLoader(), 504, 404);
        addObject(new TwoPlayer(), 609, 274);
        addObject(new OnePlayer(), 419, 275);
    }
    public void loadBasic()
    {
        sysMessage = new SystemMessage("Hi there, this is the system message. Important stuff will show here.");
        
        //save = new SaveGame("save");
        //load = new SaveGame("load");
        addObject(sysMessage, 358, 12);
        //addObject(save, 771, 11);
        //addObject(load, 681, 11);
        spaceStats = new int [12];
        r1Stats = new int[10];
        r2Stats = new int[10];
        level = 1;
        gameStarted = true;
        removeMessage();
        removeGameModes();
        removeKeyBoard();
        addAsteroids(startAsteroids);
        actors = new ArrayList<Actor>();
        xPos = new ArrayList<Integer>();
        yPos = new ArrayList<Integer>();
        
    }
    public void loadHard()
    {
        difficulty = 2;
        loadBasic();
        startAsteroids = 6;
        numGreeps = 10;
        greepRange = 400;
        alienShipLife = 200;
        maxUpgradeLevel = 4;
        
        if (!twoPlayers)
        loadOnePlayer();
        else
        loadTwoPlayer();
       
        addUpgrades(4);
        
        rocket.increaseSpeed(new Vector(13, 0.1));
        if (twoPlayers) 
        rocket2.increaseSpeed(new Vector(13, 0.1));
        Explosion.initialiseImages();

    }
    public void loadEasy()
    {
        difficulty = 0;
        loadBasic();
        startAsteroids = 4;
        numGreeps = 5;
        greepRange = 300;
        alienShipLife = 100;
        maxUpgradeLevel = 4;
    
        if (!twoPlayers)
        loadOnePlayer();
        else
        loadTwoPlayer();
        
        addUpgrades(6);
        
        Explosion.initialiseImages();
        Greenfoot.stop();
    }
    public void loadMedium()
    {
        difficulty = 1;
        loadBasic();
        startAsteroids = 4;
        numGreeps = 5;
        greepRange = 300;
        alienShipLife = 150;
        maxUpgradeLevel = 4;
    
        if (!twoPlayers)
        loadOnePlayer();
        else
        loadTwoPlayer();
        
        addUpgrades(6);
        
        rocket.increaseSpeed(new Vector(13, 0.1));
        if (twoPlayers) 
        rocket2.increaseSpeed(new Vector(13, 0.1));
        Explosion.initialiseImages();
        Greenfoot.stop();
    }
    public void loadOnePlayer()
    {
        scoreCounter = new Counter("Score: ");
        addObject(scoreCounter, 58, 601);
        gameLevel = new Counter("Game Level: ", true);
        addObject(gameLevel, 78, 31);
        loadPlayerOneCounters();
        addObject(new Message("rules", true), getWidth()/2, getHeight()/2);
        rocket = new Rocket();
        addObject(rocket, getWidth()/2, getHeight()/2);
        rB1 = new RocketBooster(rocket);
        addObject(rB1, getWidth()/2, getHeight()/2);
        
        gameLevel.updateImage2(getGameLevel());
        updateAllCounters();
    }
    public void loadPlayerOneCounters()
    {
        //UPgrade counters player1
        numLife = new Counter("Lives: ", true);
        addObject(numLife, 145, 601);
        shieldLevel = new Counter("Shield: ", true);
        addObject(shieldLevel, 212, 601);
        numAAS = new Counter("AAS Shots: ", true);
        addObject(numAAS, 319, 601);
        gunLevel = new Counter("Gun Level: ", true);
        addObject(gunLevel, 423, 601);
        numGuns = new Counter("Weapons: ", true);
        addObject(numGuns, 497, 601);
    }
    public void loadPlayerTwoCounters()
    {
         //UPgrade counters player2
        numLife2 = new Counter("Lives: ", true);
        addObject(numLife2, 145, 31);
        shieldLevel2 = new Counter("Shield: ", true);
        addObject(shieldLevel2, 212, 31);
        numAAS2 = new Counter("AAS Shots: ", true);
        addObject(numAAS2, 319, 31);
        gunLevel2 = new Counter("Gun Level: ", true);
        addObject(gunLevel2, 423, 31);
        numGuns2 = new Counter("Weapons: ", true);
        addObject(numGuns2, 497, 31);
    }
    public void loadTwoPlayer()
    {
        scoreCounter = new Counter("Score: ");
        addObject(scoreCounter, 58, 301);
        gameLevel = new Counter("Game Level: ", true);
        addObject(gameLevel, 78, 331);
        
        loadPlayerOneCounters();
        loadPlayerTwoCounters();
        
        rocket = new Rocket1();
        addObject(rocket, getWidth()/2, getHeight()/2);
        rB1 = new RocketBooster(rocket);
        addObject(rB1, getWidth()/2, getHeight()/2);
        HighLighter y = new HighLighter (rocket, "blue");
        addObject(y,getWidth()/2, getHeight()/2);
        
        rocket2 = new Rocket2();
        addObject(rocket2, getWidth()/2 +10, getHeight()/2+10);
        
        rB2 = new RocketBooster(rocket2);
        addObject(rB2, getWidth()/2, getHeight()/2);
        
        HighLighter x = new HighLighter (rocket2, "red");
        addObject(x,getWidth()/2, getHeight()/2);
        addObject(new Message("rules_2", true), getWidth()/2, getHeight()/2);
        updateAllCounters();
        gameLevel.updateImage2(getGameLevel());
    }
    public void loadGameType2()
    {
        removeObjects(getObjects(MainMenu.class));
        
        addObject(new Land(), getWidth()/2, getHeight()/2);
        addRandomCloud(10);
        addRandomCloud2(10);
        loadBoarders();
        level = 1;
        gameStarted = true;
        numGreeps = 10;
        alienShipLife = 100;
        scoreCounter = new Counter("Score: ");
        addObject(scoreCounter, 58, 301);
        gameLevel = new Counter("Game Level: ", true);
        addObject(gameLevel, 78, 331);
        loadPlayerOne();
        //loadPlayerTwo();
        //loadPlayerThree();
        //loadPlayerFour();
        gameType2 = true;
        if (ap != null)
        ap.close();
        ap = new AudioPlayer("5", true);
        addObject( ap, 780, 50);
        player1 = new Type1(1);
        addObject(player1, getWidth()/2, getHeight()-20);
        startAsteroids = 5;
        addRandomGreepShip(startAsteroids);
        addObject(new Message("gametype2", true), getWidth()/2, getHeight()/2);
        Greenfoot.stop();
    }
    public void updateCountersOfPlayer(int p)
    {
        
    }
    public void loadPlayerOne()
    {
        addObject(new Tag("PLAYER 1"), 56, 527);
        life1 = new Counter("Lives: ", true);
        addObject(life1, 65, 550);
        weaponLevel1 = new Counter("Weapon Level: ", true);
        addObject(weaponLevel1, 100, 565);
        special1 = new Counter("Special: ", true);
        addObject(special1, 75, 580);
        
    }
    public void loadPlayerTwo()
    {
        addObject(new Tag("PLAYER 2"), 722, 527);
        life1 = new Counter("Lives: ");
        addObject(life1, 735, 550);
        weaponLevel1 = new Counter("Weapon Level: ", true);
        addObject(weaponLevel1, 770, 565);
        special1 = new Counter("Special: ", true);
        addObject(special1, 744, 580);
    }
    public void loadPlayerThree()
    {
        addObject(new Tag("PLAYER 3"), 56, 37);
        life1 = new Counter("Lives: ", true);
        addObject(life1, 65, 60);
        weaponLevel1 = new Counter("Weapon Level: ", true);
        addObject(weaponLevel1, 100, 75);
        special1 = new Counter("Special: ", true);
        addObject(special1, 75, 90);
    }
    public void loadPlayerFour()
    {
        addObject(new Tag("PLAYER 4"), 722, 37);
        life1 = new Counter("Lives: ", true);
        addObject(life1, 735, 60);
        weaponLevel1 = new Counter("Weapon Level: ", true);
        addObject(weaponLevel1, 770, 75);
        special1 = new Counter("Special: ", true);
        addObject(special1, 744, 90);
    }
    public void addRandomGreepShip2(int n)
    {
        for (int i = 0; i < n; i ++)
        {
            int x = Greenfoot.getRandomNumber(200)+200;
            int y = Greenfoot.getRandomNumber(200);
            addObject(new GreepShip2(numGreeps, alienShipLife), x, y);
            addEnemy();
        }
    }
    public void addRandomWeaponLevelUpgrade(int n)
    {
        for (int i = 0; i < n; i ++)
        {
            int x = Greenfoot.getRandomNumber(200)+200;
            int y = Greenfoot.getRandomNumber(615);
            addObject(new WeaponLevelUpgrade(), x, y);
        }
    }
    public void addRandomGreepHole2(int n)
    {
        for (int i = 0; i < n; i ++)
        {
            int x = Greenfoot.getRandomNumber(200)+200;
            int y = 0;
            addObject( new GreepHole2(numGreeps), x, y);
            addEnemy();
        }
    }
    public void addRandomGreepShip(int n)
    {
        for (int i = 0; i < n; i ++)
        {
            int x = Greenfoot.getRandomNumber(200)+200;
            int y = Greenfoot.getRandomNumber(200);
            addObject(new GreepShip(numGreeps, alienShipLife), x, y);
            addEnemy();
        }
    }
    public void addRandomCloud(int n)
    {
        for (int i = 0; i < n; i ++)
        {
            int x = Greenfoot.getRandomNumber(200)+200;
            int y = Greenfoot.getRandomNumber(615);
            addObject(new Cloud(), x, y);
        }
    }
    public void addRandomCloud2(int n)
    {
        for (int i = 0; i < n; i ++)
        {
            int x = Greenfoot.getRandomNumber(200)+400;
            int y = Greenfoot.getRandomNumber(615);
            addObject(new Cloud(), x, y);
        }
    }
    public void loadBoarders()
    {
        addObject(new Boarder(180), 90, getHeight()/2);
        addObject(new Boarder(190), 710, getHeight()/2);
    }
    public void updateAllCounters()
    {
        updateNumLivesP1();
        updateGunLevelP1();
        updateNumAASP1();
        updateShieldLevelP1();
        updateNumGunsP1();
        updateNumMisslesP1();
        updateEnergyLevelP1();
        updateAmmoLevelP1();
        if (twoPlayers)
        {
            updateNumLivesP2();
            updateGunLevelP2();
            updateNumAASP2();
            updateShieldLevelP2();
            updateNumGunsP2();
            updateNumMisslesP2();
            updateEnergyLevelP2();
            updateAmmoLevelP2();
        }
    }
    public void updateNumLivesP1()
    {   numLife.updateImage2(rocket.getLives());    }
    public void updateGunLevelP1()
    {   gunLevel.updateImage2(rocket.getBulletLevel()); }
    public void updateNumAASP1()
    {   numAAS.updateImage2(rocket.getAAS());   }
    public void updateShieldLevelP1()
    {    shieldLevel.updateImage2(rocket.getShieldLevel()); }
    public void updateNumGunsP1()
    {   numGuns.updateImage2(rocket.getNumWeapons());   }
    public void updateNumMisslesP1()
    {
        if (numMissles != null)
        {
            numMissles.updateImage2(rocket.getNumMissles());
        }
    }
    public void updateEnergyLevelP1()
    {
        if (energyLevel != null)
        {
            energyLevel.updateImage2(rocket.getEnergyLevel());
        }
    }
    public void updateAmmoLevelP1()
    {
        if (numMGAmmo != null)
        {
            numMGAmmo.updateImage2(rocket.getMGAmmo());
        }
    }
    /**
     * p2 counter updates
     */
    public void updateNumLivesP2()
    {
        numLife2.updateImage2(rocket2.getLives());
    }
    public void updateGunLevelP2()
    {
        gunLevel2.updateImage2(rocket2.getBulletLevel());
    }
    public void updateNumAASP2()
    {
        numAAS2.updateImage2(rocket2.getAAS());
    }
    public void updateShieldLevelP2()
    {
        shieldLevel2.updateImage2(rocket2.getShieldLevel());
    }
    public void updateNumGunsP2()
    {
        numGuns2.updateImage2(rocket2.getNumWeapons());
    }
    public void updateNumMisslesP2()
    {
        if (numMissles != null)
        {
            numMissles2.updateImage2(rocket2.getNumMissles());
        }
    }
    public void updateEnergyLevelP2()
    {
        if (energyLevel != null)
        {
            energyLevel2.updateImage2(rocket2.getEnergyLevel());
        }
    }
    public void updateAmmoLevelP2()
    {
        if (numMGAmmo != null)
        {
            numMGAmmo2.updateImage2(rocket2.getMGAmmo());
        }
    }
    
    /**
     * Check whether all enemies have been cleared away
     */
    public void checkClear() 
    {
        if (getEnemies() <= 0)
        {
            Greenfoot.playSound("hooray.wav");
            if (gameType2)
            newRound2();
            else
            newRound();
        }
    }
    public void newRound2()
    {
        System.gc();
        player1.addLife();
        level++;
        numGreeps += 2;
        greepRange += 20;
        alienShipLife += 50;
        startAsteroids +=2;
        gameLevel.updateImage2(getGameLevel());
        if (level == 15 )
        {
            addObject(new Message("win",true), getWidth()/2, getHeight()/2);
            Greenfoot.stop();
        }
        else
        addRandomGreepShip(startAsteroids);
    }
    public void newRound() 
    {
        rocket.stop();
        rocket.setLocation(getWidth()/2, getHeight()/2);
        if (twoPlayers)
        {
            rocket2.stop();
            rocket2.setLocation(getWidth()/2, getHeight()/2);
        }
        level++;
        numGreeps += 2;
        greepRange += 20;
        alienShipLife += 50;
        generateAuthCode();
        setSystemMessage("Your level auth code is: " + gameLevelDataOutput );
        if (twoPlayers)
        {
            alienShipLife += 10;
            numGreeps += 1;
            startAsteroids += 1;
        }
        if (level == 5)loadLvl5();
        else if (level == 10) loadLvl10();
        else if(level == 11) loadLvl11();
        else if (level == 15) loadLvl15();
        else if (level == 20) loadLvl20();
        else if (level == 21) loadLvl21();
        else if (level == 25) loadLvl25();
        else if (level == 30) loadLvl30();
        else if (level == 31) loadEnd();
        else
        if (level > 21 && level < 30)
        {
            startAsteroids+=1;
            addGreepHole(startAsteroids);
        }
        else
        {
            startAsteroids+=2;
            addAsteroids(startAsteroids);
        }
        gameLevel.updateImage2(getGameLevel());
        saveGame();
    }
    public void loadLvl5()
    {
        if (ap != null)
        ap.close();
        ap = new AudioPlayer("2", true);
        addObject( ap, 780, 50);
        ap.play();
        energyLevel = new Counter("Energy: ",true );
        addObject(energyLevel, 776, 584);
        if (twoPlayers)
        {
            energyLevel2 = new Counter("Energy: ", true);
            addObject(energyLevel2, 776, 31);
            for (int i = 0; i < 8; i++)
            rocket2.raiseEnergyLevel();
        }
        for (int i = 0; i < 8; i++)
        rocket.raiseEnergyLevel();
        
        addAlienShips(15);
        if (twoPlayers)
        addObject(new Message("level5_2",true), getWidth()/2, getHeight()/2);
        else
        addObject(new Message("level5",true), getWidth()/2, getHeight()/2);
        maxUpgradeLevel++;
        Greenfoot.stop();
    }
    public void loadLvl10()
    {
        bossLife = new Counter("Health: %");
        addObject( bossLife, 0, 0);
        
        numMissles = new Counter("Homing Missles: ", true);
        addObject(numMissles, 617, 601);
        if (twoPlayers)
        {
            numMissles2 = new Counter("Homing Missles: ", true);
            addObject(numMissles2, 617, 31);
            rocket2.raiseNumMissles();
        }
        rocket.raiseNumMissles();
        
        if (twoPlayers)
        addObject(new Message("level10_2",true), getWidth()/2, getHeight()/2);
        else
        addObject(new Message("level10",true), getWidth()/2, getHeight()/2);
        maxUpgradeLevel++;
        Point pos1 = getRandomStartPosition();
        addEnemy();
        addObject (new AlienShipBoss(10000, 20, 100, 70), pos1.x, pos1.y);
        Greenfoot.stop();
    }
    public void loadLvl11()
    {
        if (ap != null)
        ap.close();
        ap = new AudioPlayer("3", true);
        addObject( ap, 780, 50);
        ap.play();
        setBackground(b);
        startAsteroids-=8;
        if (twoPlayers)
        startAsteroids-=8;
        addAsteroids(startAsteroids);
        addObject(new Message("level11",true), getWidth()/2, getHeight()/2);
        numGreeps = 5;
        Greenfoot.stop();
    }
    public void loadLvl15()
    {
        bossLife = new Counter("Health: %");
        if (ap != null)
        ap.close();
        ap = new AudioPlayer("4", true);
        addObject( ap, 780, 50);
        ap.play();
        addObject( bossLife, 0, 0);
        Point pos1 = getRandomStartPosition();
        addObject (new AlienShipBoss2(20000, 10, 50, 90), pos1.x, pos1.y);
        addEnemy();
        
        numMGAmmo = new Counter ("Ammo: ", true);
        addObject(numMGAmmo, 766, 601);
        if (twoPlayers)
        {
            numMGAmmo2 = new Counter ("Ammo: ", true);
            addObject(numMGAmmo2, 766, 50);
            rocket2.raiseMGAmmo();
        }
        rocket.raiseMGAmmo();
        
        if (twoPlayers)
        addObject(new Message("level15_2",true), getWidth()/2, getHeight()/2); 
        else
        addObject(new Message("level15",true), getWidth()/2, getHeight()/2);
        maxUpgradeLevel++;
        Greenfoot.stop();
    }
    public void loadLvl20()
    {
        bossLife = new Counter("Health: %");
        addObject( bossLife, 0, 0);
        Point pos1 = getRandomStartPosition();
        addObject ( new AlienShipBoss2(40000, 10, 50, 90, true) , pos1.x, pos1.y);
        addEnemy();
        if (twoPlayers)
        addObject(new Message("level20_2",true), getWidth()/2, getHeight()/2); 
        else
        addObject(new Message("level20",true), getWidth()/2, getHeight()/2);
        Greenfoot.stop();
    }
    public void loadLvl21()
    {
        addUpgrades(15);
        if (ap != null)
        ap.close();
        ap = new AudioPlayer("5", true);
        addObject( ap, 780, 50);
        ap.play();
        addObject(new Message("level21",true), getWidth()/2, getHeight()/2);
        setBackground(c);
        if (twoPlayers)
        startAsteroids-=10;
        numGreeps -= 4;
        startAsteroids-=16;
        addGreepHole(startAsteroids);
        Greenfoot.stop();
    }
    public void loadLvl25()
    {
        addUpgrades(15);
        if (twoPlayers)
        addObject(new Message("level25_2",true), getWidth()/2, getHeight()/2);
        else
        addObject(new Message("level25",true), getWidth()/2, getHeight()/2);
        addGreepHole(startAsteroids);
        Greenfoot.stop();
    }
    public void loadLvl30()
    {
        if (ap != null)
        ap.close();
        ap = new AudioPlayer("6", true);
        addObject( ap, 780, 50);
        ap.play();
        setBackground(d);
        bossLife = new Counter("Health: %");
        addObject( bossLife, 0, 0);
        Point pos1 = getRandomStartPosition();
        addObject ( new AlienShipBoss3(100000) , 201, 105);
        addEnemy();
        addObject(new Message("level30",true), getWidth()/2, getHeight()/2);
        addUpgrades(15);
        numGreeps -= 30;
        alienShipLife -= 1000;
        Greenfoot.stop();
    }
    public void loadEnd()
    {
        if (ap != null)
        ap.close();
        gameStarted = false;
        wait(20);
        setBackground(a);
        //resetSpace();
        ap = new AudioPlayer("7", true);
        addObject( ap, 780, 50);
        ap.play();
        addObject(new TheEnd(), getWidth()/2, getHeight()/2);
        
    }
    public void reloadLevel()
    {
        removeObjects(getObjects(Enemy.class));
        removeObjects(getObjects(Rocket.class));
        removeObjects(getObjects(HighLighter.class));
        removeObjects(getObjects(RocketBooster.class));
        removeObjects(getObjects(Asteroid.class));
        removeObjects(getObjects(EnemyBullet.class));
        removeObjects(getObjects(Bullet.class));
        removeObjects(getObjects(Continue.class));
        removeObjects(getObjects(ScoreBoard.class));
        startAsteroids = spaceStats[0];
        level = spaceStats[1];
        maxUpgradeLevel = spaceStats[2];
        numGreeps = spaceStats[3];
        alienShipLife = spaceStats[4];
        greepRange = spaceStats[5];
        // numEnemies = spaceStats[6];
        numEnemies = 0;
        scoreCounter.setTarget(spaceStats[7]);
        gameLevel.setTarget(spaceStats[8]);
        numGreepsKilled = spaceStats[9];
        numSpaceShipKilled = spaceStats[10];
        numAsteroidDestroyed = spaceStats[11];
        if ( !twoPlayers)
        {
            rocket = new Rocket();
            rocket.setAllRocketStats(r1Stats);
            addObject(rocket, getWidth()/2, getHeight()/2);
            rB1 = new RocketBooster(rocket);
            addObject(rB1, getWidth()/2, getHeight()/2);
        }
        else
        {
            rocket2 = new Rocket2();
            rocket2.setAllRocketStats(r2Stats);
            addObject(rocket2, getWidth()/2, getHeight()/2);
            rB2 = new RocketBooster(rocket2);
            addObject(rB2, getWidth()/2, getHeight()/2);
            HighLighter x = new HighLighter (rocket2, "red");
            addObject(x, getWidth()/2, getHeight()/2);
            
            rocket = new Rocket1();
            rocket.setAllRocketStats(r1Stats);
            addObject(rocket, getWidth()/2, getHeight()/2);
            rB1 = new RocketBooster(rocket);
            addObject(rB1, getWidth()/2, getHeight()/2);
            HighLighter y = new HighLighter (rocket, "blue");
            addObject(y, getWidth()/2, getHeight()/2);
        }
        if (level == 5)
        {
            addAlienShips(15);
            if (twoPlayers)
            addObject(new Message("level5_2",true), getWidth()/2, getHeight()/2);
            else
            addObject(new Message("level5",true), getWidth()/2, getHeight()/2);
            Greenfoot.stop();
        }
        else if (level == 10) 
        {
        
            if (twoPlayers)
            addObject(new Message("level10_2",true), getWidth()/2, getHeight()/2);
            else
            addObject(new Message("level10",true), getWidth()/2, getHeight()/2);
            Point pos1 = getRandomStartPosition();
            addEnemy();
            addObject (new AlienShipBoss(10000, 20, 100, 70), pos1.x, pos1.y);
            Greenfoot.stop();
        }
        else if(level == 11) 
        {
            addAsteroids(startAsteroids);
            addObject(new Message("level11",true), getWidth()/2, getHeight()/2);
            Greenfoot.stop();
        }
        else if (level == 15) 
        {
            
        
            Point pos1 = getRandomStartPosition();
            addObject (new AlienShipBoss2(20000, 10, 50, 90), pos1.x, pos1.y);
            addEnemy();
            if (twoPlayers)
            addObject(new Message("level15_2",true), getWidth()/2, getHeight()/2); 
            else
            addObject(new Message("level15",true), getWidth()/2, getHeight()/2);
            Greenfoot.stop();
        }
        else if (level == 20) 
        {
            Point pos1 = getRandomStartPosition();
            addObject ( new AlienShipBoss2(40000, 10, 50, 90, true) , pos1.x, pos1.y);
            addEnemy();
            if (twoPlayers)
            addObject(new Message("level20_2",true), getWidth()/2, getHeight()/2); 
            else
            addObject(new Message("level20",true), getWidth()/2, getHeight()/2);
            Greenfoot.stop();
        }
        else if (level == 21) 
        {
            addUpgrades(15);
            addObject(new Message("level21",true), getWidth()/2, getHeight()/2);
            addGreepHole(startAsteroids);
            Greenfoot.stop();
        }
        else if (level == 25) loadLvl25();
        else if (level == 30)
        {
            Point pos1 = getRandomStartPosition();
            addObject ( new AlienShipBoss3(200000) , 201, 105);
            addEnemy();
            addObject(new Message("level30",true), getWidth()/2, getHeight()/2);
            addUpgrades(15);
            Greenfoot.stop();
        }
        else if (level == 31) loadEnd();
        else
        if (level > 21 && level < 30)
        {
            addGreepHole(startAsteroids);
        }
        else
        {
            addAsteroids(startAsteroids);
        }
        gameLevel.updateImage2(getGameLevel());
        updateAllCounters();
        System.gc();
    }
    /**
     * Save/load game methods
     */
    public void saveGame()
    {
        xPos.clear();
        yPos.clear();
        actors.clear();
        r1Stats = new int[10];
        r2Stats = new int[10];
        List temp = getObjects(Actor.class);
        
        for (int i = 0; i < temp.size(); i++)
        {
            xPos.add( ((Actor)temp.get(i)).getX());
            yPos.add( ((Actor)temp.get(i)).getY());
            actors.add( (Actor)temp.get(i) );
        }
        spaceStats[0] = startAsteroids;
        spaceStats[1] = level;
        spaceStats[2] = maxUpgradeLevel;
        spaceStats[3] = numGreeps;
        spaceStats[4] = alienShipLife;
        spaceStats[5] = greepRange;
        spaceStats[6] = numEnemies;
        spaceStats[7] = scoreCounter.getTarget();
        spaceStats[8] = gameLevel.getTarget();
        spaceStats[9] = numGreepsKilled;
        spaceStats[10] = numSpaceShipKilled;
        spaceStats[11] = numAsteroidDestroyed;
        
        r1Stats = (int[])rocket.getAllRocketStats().clone();
        if (twoPlayers)
        r2Stats = (int[])rocket2.getAllRocketStats().clone();
        
    }
    // return true if there is a saved game
    public boolean loadSavedGame()
    {
        if (actors.size() > 0)
        {
            resetSpace();
            startAsteroids = spaceStats[0];
            level = spaceStats[1];
            maxUpgradeLevel = spaceStats[2];
            numGreeps = spaceStats[3];
            alienShipLife = spaceStats[4];
            greepRange = spaceStats[5];
            numEnemies = spaceStats[6];
            scoreCounter.setTarget(spaceStats[7]);
            gameLevel.setTarget(spaceStats[8]);
            numGreepsKilled = spaceStats[9];
            numSpaceShipKilled = spaceStats[10];
            numAsteroidDestroyed = spaceStats[11];
            
            for (int i = 0; i < actors.size(); i++)
            {   
                Actor a = actors.get(i);
                if (! (a instanceof Rocket) && !(a instanceof RocketBooster) && !( a instanceof HighLighter) )
                addObject(actors.get(i), xPos.get(i).intValue() , yPos.get(i).intValue());
                else
                if ( actors.get(i) instanceof Rocket1)
                {
                    rocket = new Rocket1();
                    rocket.setAllRocketStats(r1Stats);
                    addObject(rocket, xPos.get(i).intValue() , yPos.get(i).intValue());
                    rB1 = new RocketBooster(rocket);
                    addObject(rB1, xPos.get(i).intValue() , yPos.get(i).intValue());
                    HighLighter y = new HighLighter (rocket, "blue");
                    addObject(y,xPos.get(i).intValue(), yPos.get(i).intValue());
                }
                else
                if (actors.get(i) instanceof Rocket2)
                {
                    rocket2 = new Rocket2();
                    rocket2.setAllRocketStats(r2Stats);
                    addObject(rocket2, xPos.get(i).intValue() , yPos.get(i).intValue());
                    rB2 = new RocketBooster(rocket2);
                    addObject(rB2, xPos.get(i).intValue() , yPos.get(i).intValue());
                    
                    HighLighter x = new HighLighter (rocket2, "red");
                    addObject(x, xPos.get(i).intValue(), yPos.get(i).intValue());
                }
                else
                if ( actors.get(i) instanceof Rocket)
                {
                    rocket = new Rocket();
                    rocket.setAllRocketStats(r1Stats);
                    addObject(rocket, xPos.get(i).intValue() , yPos.get(i).intValue());
                    rB1 = new RocketBooster(rocket);
                    addObject(rB1, xPos.get(i).intValue() , yPos.get(i).intValue());
                }
            }
            
            gameLevel.updateImage2(getGameLevel());
            updateAllCounters();
            return true;
        }
        return false;
    }
    public void addGreepBlood(int x, int y)
    {
        addObject(new GreepBlood(), x, y);
    }
    public void addSmallExplosion(int x, int y)
    {
        addObject(new SmallExplosion(), x, y);
        Greenfoot.playSound("Explosion.wav");
    }
    public void addExplosion(int x, int y)
    {
        addObject(new Explosion(), x, y);
        Greenfoot.playSound("Explosion.wav");
    }
    /**
     * makes a explosion when the rocket is hit
     */
    public void rocketHit(Rocket r) 
    {
        if ( r instanceof Rocket1)
        addSmallExplosion( rocket.getX(), rocket.getY());
        else
        if ( r instanceof Rocket2)
        addSmallExplosion( rocket2.getX(), rocket2.getY());
        else
        addSmallExplosion(rocket.getX(), rocket.getY());
    }
    /**
     * game over - show scoreboard
     */
    public void showScoreBoard()
    {
        addObject(new ScoreBoard(scoreCounter.getValue(), numGreepsKilled, numAsteroidDestroyed, numSpaceShipKilled), getWidth()/2, getHeight()/2);
    }
    public void gameOver() 
    {
        if (twoPlayers && rocket2.isDead() && rocket.isDead() )
        {
            addObject(new ScoreBoard(scoreCounter.getValue(), numGreepsKilled, numAsteroidDestroyed, numSpaceShipKilled), getWidth()/2, getHeight()/2);
            addObject(new Continue(), 600, 500);
        }
        else
        if (rocket.isDead() && !twoPlayers)
        {
            addObject(new ScoreBoard(scoreCounter.getValue(), numGreepsKilled, numAsteroidDestroyed, numSpaceShipKilled), getWidth()/2, getHeight()/2);
            addObject(new Continue(), 600, 500);
        }
    }
    public void gameOver2() 
    {
        if (player1.isDead())
        {
            addObject(new ScoreBoard(scoreCounter.getValue(), numGreepsKilled, numAsteroidDestroyed, numSpaceShipKilled), getWidth()/2, getHeight()/2);
            //addObject(new Continue(), 600, 500);
        }
    }
    /**
     * adds asteroids/greephole/alienship/upgrade
     */
    private void addAsteroids(int count) 
    {
        for(int i = 0; i < count; i++) 
        {
            Point pos = getRandomStartPosition();
            Asteroid a = new Asteroid();
            //a.setVector(new Vector(Greenfoot.getRandomNumber(360), 2));
            addObject(a, pos.x, pos.y);
            addEnemy();
        }
    }
    private void addGreepHole(int count) 
    {
        for(int i = 0; i < count; i++) 
        {
            Point pos = getRandomStartPosition();
            addObject(new greepHole(numGreeps, alienShipLife), pos.x, pos.y);
            addEnemy();
        }
    }
    public void addUpgrades(int num)
    {
        for (int i=0; i <num; i++)
        {
            Point pos = getRandomStartPosition();
            int r = Greenfoot.getRandomNumber(maxUpgradeLevel);
            if (r == 5)
            {
                addObject (new EnergyUpgrade(5), pos.x, pos.y); 
            }
            else
            if (r == 7) 
            {
                addObject (new AmmoUpgrade(7), pos.x, pos.y);
            }
            else
            {
                addObject (new Upgrades(r), pos.x, pos.y);
            }
            if (level >= 5 && randomChance(70))
            {
                Point pos2 = getRandomStartPosition();
                addObject (new EnergyUpgrade(5), pos2.x, pos2.y); 
            }
            if (level >= 15 && randomChance(70))
            {
                Point pos3 = getRandomStartPosition();
                addObject (new AmmoUpgrade(7), pos3.x, pos3.y);
            }
        }
    }
    public void addAlienShips(int n)
    {
        for (int i = 0; i<n; i++)
        {
            Point pos = getRandomStartPosition();
            addEnemy();
            addObject (new AlienShip(numGreeps, alienShipLife), pos.x, pos.y);
            if (level > 10 && randomChance(40) )
            {
                Point pos2 = getRandomStartPosition();
                addEnemy();
                addObject (new AlienShip2(alienShipLife/2, 2, 10), pos2.x, pos2.y);
            }
        }
    }
    /**
     * makes a random point
     */
    private Point getRandomStartPosition() 
    {
        int side = Greenfoot.getRandomNumber(4);
        Point pt = new Point();
        switch (side) {
            case 0: pt.x = Greenfoot.getRandomNumber(getWidth());
                    pt.y = Greenfoot.getRandomNumber(30);
                    break;
            case 1: pt.x = getWidth() - Greenfoot.getRandomNumber(30);
                    pt.y = Greenfoot.getRandomNumber(getHeight());
                    break;
            case 2: pt.x = Greenfoot.getRandomNumber(getWidth());
                    pt.y = getHeight() - Greenfoot.getRandomNumber(30);
                    break;
            case 3: pt.x = Greenfoot.getRandomNumber(30);
                    pt.y = Greenfoot.getRandomNumber(getHeight());
                    break;
        }
        return pt;
    }
    
    /**
     * Removes the big gray message board
     */
    public void removeMessage()
    {
        removeObjects(getObjects(Message.class));
    }
    
    public void addKeyBoard()
    {
        keyBoardDisplay = new Display();
        keyBoardDisplay.setCurText(gameLevelDataInput);
        addObject(keyBoardDisplay, 397, 157);
        
        addObject(new Key("0"), 40, 220);
        addObject(new Key("1"), 80, 220);
        addObject(new Key("2"), 120, 220);
        addObject(new Key("3"), 160, 220);
        addObject(new Key("4"), 200, 220);
        addObject(new Key("5"), 240, 220);
        addObject(new Key("6"), 280, 220);
        addObject(new Key("7"), 320, 220);
        addObject(new Key("8"), 360, 220);
        addObject(new Key("9"), 400, 220);
        
        addObject(new Key("q"), 80, 260);
        addObject(new Key("w"), 120, 260);
        addObject(new Key("e"), 160, 260);
        addObject(new Key("r"), 200, 260);
        addObject(new Key("t"), 240, 260);
        addObject(new Key("y"), 280, 260);
        addObject(new Key("u"), 320, 260);
        addObject(new Key("i"), 360, 260);
        addObject(new Key("o"), 400, 260);
        addObject(new Key("p"), 440, 260);
        addObject(new BackSpace(), 600, 220);
        
        addObject(new Key("a"), 120, 300);
        addObject(new Key("s"), 160, 300);
        addObject(new Key("d"), 200, 300);
        addObject(new Key("f"), 240, 300);
        addObject(new Key("g"), 280, 300);
        addObject(new Key("h"), 320, 300);
        addObject(new Key("j"), 360, 300);
        addObject(new Key("k"), 400, 300);
        addObject(new Key("l"), 440, 300);
        
        addObject(new Key("z"), 160, 340);
        addObject(new Key("x"), 200, 340);
        addObject(new Key("c"), 240, 340);
        addObject(new Key("v"), 280, 340);
        addObject(new Key("b"), 320, 340);
        addObject(new Key("n"), 360, 340);
        addObject(new Key("m"), 400, 340);
        
        addObject(new SpaceKey(), 385, 382);
        addObject(new Caps(), 600, 272);
        addObject(new Enter(), 600, 314);
        addObject(new ReturnToMenu(), 646, 571);
        addObject(new Clear(), 599, 354);
    }
    
    public void loadAuthCode()
    {
        String a = gameLevelDataInput;
        if (a.substring(0,1).equals("E"))
        difficulty = 0;
        if (a.substring(0,1).equals("M"))
        difficulty = 1;
        if (a.substring(0,1).equals("H"))
        difficulty = 2;
        
        if (a.substring(1,2).equals("T"))
        twoPlayers = true;
        else twoPlayers = false;
        
        int index = 3;
        int i = 3;
        while ( i < a.length() && Character.isDigit(a.charAt(i)) )
            i++;
        String temp = a.substring(index,i); 
        maxUpgradeLevel = Integer.valueOf(temp).intValue();
        index = i+1;
        i = index;
        while ( i < a.length() && Character.isDigit(a.charAt(i)) )
            i++;
        temp = a.substring(index,i);
        level = Integer.valueOf(temp).intValue();
       
        if (difficulty == 2)
        {
            startAsteroids = 4;
            numGreeps = 8;
            greepRange = 180;
            alienShipLife = 150;
        }
        else
        {
            startAsteroids = 2;
            numGreeps = 3;
            greepRange = 80;
            alienShipLife = 50;
        }
        numGreeps += 2*level;
        greepRange += 20*level;
        alienShipLife += 50*level;
        startAsteroids +=2*level;
        
        if (difficulty == 0) addUpgrades(6);
        else addUpgrades(4);
        
        addUpgrades((level-1)*2);
        if (twoPlayers)
        {
            alienShipLife += 10*level;
            numGreeps += 1*level;
            startAsteroids += 1*level;
        }
        
        if (level > 11)
        {
            startAsteroids-=8;
            if (twoPlayers)
            startAsteroids-=8;
        }
        if (level > 20)
        {
            if (twoPlayers)
            startAsteroids-=10;
            numGreeps -= 4;
            startAsteroids-=16;
        }
        
        loadAuthCodeHelper();
        if (level > 10 ) 
            setBackground(b);
        if (level > 20)
            setBackground(c);
        if (level >30) setBackground(d);
        if (level > 10) 
        {
            numMissles = new Counter("Homing Missles: ", true);
            addObject(numMissles, 617, 601);
            rocket.raiseNumMissles();
            if (twoPlayers)
            {
                numMissles2 = new Counter("Homing Missles: ", true);
                addObject(numMissles2, 617, 31);
                rocket2.raiseNumMissles();
            }
        }
        if (level > 15) 
        {
            numMGAmmo = new Counter ("Ammo: ", true);
            addObject(numMGAmmo, 766, 601);
            rocket.raiseMGAmmo();
            if (twoPlayers)
            {
                numMGAmmo2 = new Counter ("Ammo: ", true);
                addObject(numMGAmmo2, 766, 50);
                rocket2.raiseMGAmmo();
            }
        }
        if (level > 5)
        {
            energyLevel = new Counter("Energy: ", true);
            addObject(energyLevel, 776, 584);
            for (int x = 0; x < 8; x++)
            rocket.raiseEnergyLevel();
            if (twoPlayers)
            {
                energyLevel2 = new Counter("Energy: ", true);
                addObject(energyLevel2, 776, 31);
                for (int x = 0; x < 8; x++)
                rocket2.raiseEnergyLevel();
            }
        }

        gameStarted = true;
        updateAllCounters();
        if (level > 10) addUpgrades(7);
        if (level > 15) addUpgrades(7);
        if (level > 20) addUpgrades(7);
        if (level > 21) addUpgrades(10);
        
        if (level == 5) loadLvl5();
        else if (level == 10) loadLvl10();
        else if(level == 11) loadLvl11();
        else if (level == 15) loadLvl15();
        else if (level == 20) loadLvl20();
        else if (level == 21) loadLvl21();
        else if (level == 25) loadLvl25();
        else if (level == 30) loadLvl30();
        else
        if (level > 20 && level < 30)
        {
            startAsteroids+=1*(level-10);
            addGreepHole(startAsteroids);
        }
        else addAsteroids(startAsteroids);
        
        removeKeyBoard();
    }
    public void loadAuthCodeHelper()
    {
        sysMessage = new SystemMessage("Hi there, this is the system message. Important stuff will show here.");
        //save = new SaveGame("save");
        //load = new SaveGame("load");
        addObject(sysMessage, 358, 12);
        //addObject(save, 771, 11);
        //addObject(load, 681, 11);
        spaceStats = new int [12];
        r1Stats = new int[10];
        r2Stats = new int[10];
        actors = new ArrayList<Actor>();
        xPos = new ArrayList<Integer>();
        yPos = new ArrayList<Integer>();
        if (!twoPlayers)
        {
            scoreCounter = new Counter("Score: ");
            addObject(scoreCounter, 58, 601);
            gameLevel = new Counter("Game Level: ", true);
            addObject(gameLevel, 78, 31);
            loadPlayerOneCounters();
            rocket = new Rocket();
            addObject(rocket, getWidth()/2, getHeight()/2);
            rB1 = new RocketBooster(rocket);
            addObject(rB1, getWidth()/2, getHeight()/2);
        }
        else
        {
            scoreCounter = new Counter("Score: ");
            addObject(scoreCounter, 58, 301);
            gameLevel = new Counter("Game Level: ", true);
            addObject(gameLevel, 78, 331);
        
            loadPlayerOneCounters();
            loadPlayerTwoCounters();
        
            rocket = new Rocket1();
            addObject(rocket, getWidth()/2, getHeight()/2);
            rB1 = new RocketBooster(rocket);
            addObject(rB1, getWidth()/2, getHeight()/2);
            HighLighter y = new HighLighter (rocket, "blue");
            addObject(y,getWidth()/2, getHeight()/2);
        
            rocket2 = new Rocket2();
            addObject(rocket2, getWidth()/2 +10, getHeight()/2+10);
        
            rB2 = new RocketBooster(rocket2);
            addObject(rB2, getWidth()/2, getHeight()/2);
        
            HighLighter x = new HighLighter (rocket2, "red");
            addObject(x,getWidth()/2, getHeight()/2);
            //addObject(new Message("rules_2", true), getWidth()/2, getHeight()/2);
        }
        gameLevel.updateImage2(getGameLevel());
        updateAllCounters();
    }
    public void generateAuthCode()
    {
        String a = "";
        if (difficulty == 0)
        a+= "E";
        if (difficulty == 1)
        a+= "M";
        if (difficulty == 2)
        a+= "H";
        
        if (twoPlayers)
        a += "T";
        else
        a += "F";
        
        a += "E";
        a += maxUpgradeLevel;
        a += "E";
        a += level;
        a += "E";
        gameLevelDataOutput = a;
    }
    public boolean authCodeValid()
    {
        String a = keyBoardDisplay.curText;
        if (a.length() <= 3) return false;
        boolean isValid = true;
        isValid = isValid && ( (a.substring(0,1).equals("E") || a.substring(0,1).equals("M") || a.substring(0,1).equals("H"))
            && (a.substring(1,2).equals("T") 
            || a.substring(1,2).equals("F")) && a.substring(2,3).equals("E"));
            
        int index = 3;
        int i = 3;
        while ( i < a.length() && Character.isDigit(a.charAt(i)) )
            i++;
        String temp = a.substring(index,i); 
        char[] carray = temp.toCharArray();
        for (int x = 0; x < carray.length; x++)
            isValid = isValid && Character.isDigit(carray[x]);
        index = i+1;
        i = index;
        while ( i < a.length() && Character.isDigit(a.charAt(i)) )
            i++;
        temp = a.substring(index,i);
        carray = temp.toCharArray();
        for (int x = 0; x < carray.length; x++)
            isValid = isValid && Character.isDigit(carray[x]);
        
        return isValid;
    }
    /**
     *   accessor/modifier methods
     */
    public int getNumGreeps()
    {   return numGreeps;   }
    public int getGameLevel()
    {   return level;   }
    public void addEnemy()
    {   numEnemies++;   }
    public int getEnemies()
    {   return numEnemies;  }
    public void removeEnemy()
    {   numEnemies--;   }
    public void removeRocket1()
    {   removeObject(rB1);  }
    public void removeRB2()
    {   removeObject(rB2);  }
    public Rocket getRocket()
    {   return rocket;  }
    public void setSystemMessage(String str)
    {   sysMessage.display(str, "SYS: ");   }
    public void set2playerMode()
    {   twoPlayers = true;  }
    public int getLevel()
    {   return level;   }
    public boolean twoP()
    {   return twoPlayers;  }
    public void removeGameModes()
    {   removeObjects(getObjects(GameMode.class));  }
    public boolean isEasy()
    {   return difficulty == 0;    }
    public int numberOfAsteroids() 
    {   return getObjects(Asteroid.class).size();   }
    public int numberOfAlienShips() 
    {   return getObjects(AlienShip.class).size();  }
    public int numberOfBossShips() 
    {   return getObjects(AlienShipBoss.class).size();  }
    public int numberOfAlienShipBoss2()
    {   return getObjects(AlienShipBoss2.class).size(); }
    public int getGreepRange()
    {   return greepRange;  }
    public int getNumGreepsKilled()
    {   return numGreepsKilled; }
    public int getNumSpaceShipsKilled()
    {   return numSpaceShipKilled;  }
    public int getNumAsteroidDestroyed()
    {   return numAsteroidDestroyed;    }
    public void addGreepsKilled()
    {   numGreepsKilled++;  }
    public void addSpaceShipKilled()
    {   numSpaceShipKilled++;   }
    public void addAsteroidDestroyed()
    {   numAsteroidDestroyed++; }
    public void removeKeyBoard()
    {   removeObjects(getObjects(Keyboard.class));  }
    protected boolean randomChance(int percent)
    {   return Greenfoot.getRandomNumber(100) < percent;    }
    public int rocketLocX()
    {   return rocket.getX();   }
    public int rocketLocY()
    {   return rocket.getY();    }
    //removes all actors from space
    public void resetSpace()
    {   removeObjects(getObjects(Actor.class));     }
    /**
     * adds newScore to the scorecounter
     */
    public void score(int newScore) 
    {   scoreCounter.add(newScore); }
    public int difficulty()
    {   return difficulty;  }
   private void wait(int length) 
    {
        for(int i = 0; i < length; i++) 
            Greenfoot.delay(1);
    }        
    
}