import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.awt.Color;
import java.awt.Font;
/**
 * Write a description of class BackSpace here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Enter extends Keyboard
{
    private GreenfootImage image;
    private int acts = 0;
    private int delay = 20;
    
    public Enter()
    {
        image = new GreenfootImage(200, 50);
        image.setColor(new Color(255,255,255, 128));
        image.fillRect(0, 0, 200, 50);
        image.setColor(new Color(0, 0, 0, 128));
        image.fillRect(5, 5, 190, 40);
        Font font = new Font("Courier", image.getFont().getStyle(), image.getFont().getSize()) ;
        font = font.deriveFont(50f);
        image.setFont(font);
        image.setColor(Color.WHITE);
        image.drawString("Enter", 30, 40);
        setImage(image);
    }
    public void act() 
    {
        if (delay > 0) 
        {
            delay--;
            return;
        }
        if (Greenfoot.mouseMoved(this))
        {
            image.setColor(Color.RED);
            image.drawString("Enter", 30, 40);
        }
        else
        {
            image.setColor(Color.WHITE);
            image.drawString("Enter", 30, 40);
        }
        if ( (Greenfoot.mouseClicked(this)|| Greenfoot.isKeyDown("enter")) && acts ==0 )
        {
            Greenfoot.playSound("click.wav");
            acts = -10;
            image.setColor(Color.RED);
            image.drawString("Enter", 30, 40);
            getLand().charName = getLand().d.curText;
            getLand().newGame();
            getLand().removeKeyBoard();
        }
        if (acts != 0)
        acts++;
        setImage(image);
    }    
}
