import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class ScrollActor here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class ScrollActor  extends Actor
{
    private int realX, realY;
    
    public ScrollActor(int realX, int realY)
    {
        this.realX = realX;
        this.realY = realY;
    }
    
    public void act() 
    {
        setLocation(realX, realY);
    }    
    
    public void setRealLocation(int x, int y)
    {
        realX = x;
        realY = y;
    }
    
    public void setLocation(int x, int y)
    {
        super.setLocation(x - getWorld().getSX(), y - getWorld().getSY());
    }
    
    public int getRealY()
    {
        return realY;
    }
    
    public int getRealX()
    {
        return realX;
    }
    
    public ScrollWorld getWorld()
    {
        return (ScrollWorld) super.getWorld();
    }
}
