import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.awt.Color;
import java.awt.Font;
/**
 * Write a description of class SkyeStats here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class SkyeStats extends Stats
{
    private GreenfootImage SkyePic = new GreenfootImage("skyepic.jpg");
    private GreenfootImage image = new GreenfootImage(200,50);
    
    private Good good;
    private String name;
    public SkyeStats(String name, Good g)
    {
        good = g;
        this.name = name;
        image.setColor(new Color(121,73,34, 128));
        image.fillRect(0, 0, 200, 50);
        image.setColor(new Color(136, 100, 70, 128));
        image.fillRect(3, 3, 200-6, 50-6);
        Font font = image.getFont();
        font = font.deriveFont(16f);
        image.setFont(font);
        image.setColor(Color.WHITE);
        image.drawString(name, 35 , 20);
        image.drawImage(SkyePic, 5, 5);
        setImage(image);
        font = font.deriveFont(13f);
        image.setFont(font);
    }
    public void act() 
    {
        reloadImage();
        String hp = "HP: "+good.getCurHP()+"/"+good.getTotalHP();
        String mana = "Mana: "+good.getCurMana()+"/"+good.getTotalMana();
        String mp = "MP: "+good.getCurMP()+"/"+good.getTotalMP();
        image.drawString(hp, 100 , 15);
        if (getLand().canUseMagic)
        image.drawString(mana, 100 , 30);
        image.drawString(mp, 100, 45);
        setImage(image);
    }    
    public void reloadImage()
    {
        image.setColor(new Color(121,73,34, 128));
        image.fillRect(0, 0, 200, 50);
        image.setColor(new Color(136, 100, 70, 128));
        image.fillRect(3, 3, 200-6, 50-6);
        Font font = image.getFont();
        font = font.deriveFont(16f);
        image.setFont(font);
        image.setColor(Color.WHITE);
        image.drawString(name, 35 , 20);
        image.drawImage(SkyePic, 5, 5);
        setImage(image);
        font = font.deriveFont(13f);
        image.setFont(font);
    }
}
