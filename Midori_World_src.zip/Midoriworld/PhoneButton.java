import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class PhoneButton here.
 * 
 * @author Anthony Hoang
 * @version (v1)
 */
public class PhoneButton  extends PhoneHolos
{
    private boolean decrease = true;
    private boolean firstInitialize = true;
    private int t = 0;
    public PhoneButton()
    {
        setImage(new GreenfootImage("cellphonesymbol.png"));
        getImage().setTransparency(0);
        Greenfoot.playSound("phonebeeping.wav");
    }
    public void act() 
    {
        if (getMWorld().gamePause) return;
        if (Greenfoot.mouseClicked(this) && !remove)
        {
            remove();
            getMWorld().eventCount++;
            Greenfoot.playSound("holoopenbeep.wav");
        }
        if (remove)
        super.act();
        else
        if (firstInitialize)
        {
            t = getImage().getTransparency()+5;
            if (t > 200)
            {
                firstInitialize = false;
            }
            else
            getImage().setTransparency(t);
        }
        else
        if (decrease)
        {
            t -= 2;
            if (t < 80)
            {
                decrease = false;
                Greenfoot.playSound("phonebeeping.wav");
            }
            getImage().setTransparency(t);
        }
        else
        {
            t += 2;
            if (t > 210)
            {
                decrease = true;
            }
            getImage().setTransparency(t);
        }
    }    
}
