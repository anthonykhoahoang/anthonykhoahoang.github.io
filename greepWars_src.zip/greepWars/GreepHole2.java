import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Releases fast greeps
 * 
 * @author Anthony Hoang
 * @version 1.2
 */
public class GreepHole2 extends Enemy2
{
    private int totalPassengers; 
    private int stepCount = 0;
    private int passengersReleased;
    private int releaseDelay;
    
    public GreepHole2(int numGreeps)
    {
        super (9999, 100);
        GreenfootImage image = new GreenfootImage(32,32);
        totalPassengers = numGreeps;
        getImage().clear();
    }
    public void act() 
    {
        if(!isEmpty() && releaseDelay >= 0) 
        releasePassenger();
        else 
        releaseDelay++;
        if (isEmpty())
        {
            getSpace().removeEnemy();
            getSpace().removeObject(this);
        }
    }    
     /**
     * True if all passengers are out.
     */
    public boolean isEmpty()
    {
        return passengersReleased == totalPassengers;
    }
    
    /**
     * Possibly: Let one of the passengers out. Passengers appear at intervals, 
     * so this may or may not release the passenger.
     */
    private void releasePassenger()
    {
        if(passengersReleased < totalPassengers) 
        {
            stepCount++;
            if(stepCount == 5) 
            {
                getSpace().addEnemy();
                getSpace().addObject(new Greep(), getX(), getY() + 30);
                passengersReleased++;
                stepCount = 0;
            }
        }
    }
}
