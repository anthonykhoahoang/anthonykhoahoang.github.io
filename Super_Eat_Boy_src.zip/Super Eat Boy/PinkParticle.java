import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class PinkParticle here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class PinkParticle  extends Particle
{
    private static GreenfootImage img;
    private int transparency = 200;
    private int transReduce = 5;
    private boolean firstInitialize = true;
    private int r;
    private Vector v = new Vector();
    private int curImage = 0;
    private static GreenfootImage[] images;
        
    public PinkParticle(int r, int realX, int realY)
    {
        super(realX, realY);
        this.r = r;
        if (img == null)
        {
            img = new GreenfootImage("images/particle/pink.png");
            //img.scale(img.getWidth()/2, img.getHeight()/2);
        }
        if (images == null)
        {
            images = new GreenfootImage[40];
            int n = 0;
            for (int i = 0; i < images.length; i++)
            {
                images[i] = new GreenfootImage(img);
                images[i].setTransparency(transparency-n);
                n += transReduce;
            }
        }
        setImage(images[curImage]);
    }
    
    public void act() 
    {
        super.act();
        if (firstInitialize)
        {
            firstInitialize = false;
        }
        else
        {
            curImage++;
            if (curImage == 40)
            getWorld().removeObject(this);
            else
            {
                setImage(images[curImage]);
                random();
                move();
            }
            /*
            transparency-=transReduce;
            if (transparency <= 0)
            {
                getWorld().removeObject(this);
            }
            else
            {
                getImage().setTransparency(transparency);
                random();
                move();
            }
            */
        }
    }    
    public void random()
    {
        v.add(new Vector((int)(Math.random()*360),Math.random()*.3));
        v.add(new Vector(270, .04));
    }
    public void move()
    {
        v.add(new Vector(r, .05));
        double x = getRealX() + v.getX();
        double y = getRealY() + v.getY();
        setRealLocation((int)x,(int)y);
    } 
}
