import greenfoot.*;  // (World, Actor, GreenfootImage, and Greenfoot)
import java.awt.Color;
import java.awt.Font;
import java.io.IOException;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URL;
import java.util.StringTokenizer;
import java.util.ArrayList;
//import java.awt.GraphicsEnvironment;
//import java.awt.GraphicsDevice;
/**
 * Reads an input text file 
 * @author Anthony Hoang
 * @version 3.0
 */
public class CharacterText extends Actor
{
    public float FONT_SIZE;
    public int WIDTH;
    public int HEIGHT;
    private String curString;
    
    private int index;
    private int pos;
    private int hPos;
    
    private String nxtFile;
    private String curFile;
    private boolean closing;
    
    private ArrayList<String> words;
    public GreenfootImage image;
    public String name;
    public boolean firstInitialize = true;
    public int talkLength;
    private int delay = 0;
    public CharacterText() 
    {
    }
    public CharacterText(String text, String name)
    {
        this.name = name;
        initialize(text);
    }
    public void initialize(String text)
    {
        if (!text.endsWith(".txt"))
        text+= ".txt";
        closing = false;
        words = new ArrayList<String>();
        curFile = text;
        Font font;
        font = new Font("Lucida Console",getImage().getFont().getStyle(), getImage().getFont().getSize());
        if (!font.getFontName().equals("Lucida Console"))
        font = new Font("Monospaced",getImage().getFont().getStyle(), getImage().getFont().getSize());
        font = font.deriveFont(16f); 
        FONT_SIZE = font.getSize();
        WIDTH = 370;
        String temp = "data/text/"+name+"/"+text;
        curString = getTextFile(temp);
        talkLength = curString.length();
        readStringToArray(curString);
        HEIGHT = calcHeight(curString);
        
        index = 0;
        pos = (int)(FONT_SIZE)+60;
        hPos = (int)(FONT_SIZE)+60;
        
    }
    public void act()
    {
        if (getMWorld().gamePause) return;
        showText();
    }
    public void drawImage(){ }
    public void addNextText(String nxt) {}
    public void showText()
    {
        if (closing)
        {
            int t = getImage().getTransparency()-10;
            if (t < 10)
            getWorld().removeObject(this);
            else
            getImage().setTransparency(t);
            return;
        }
        if (delay > 0) delay--;
        ///****
        if (words.size() == 0 && delay == 0
        && (Greenfoot.mouseClicked(this) || 
        Greenfoot.isKeyDown("enter") && Greenfoot.isKeyDown("enter")))
        {
            if (nxtFile != null && !curFile.equals(nxtFile))
            {
                //initialize(nxtFile);
                //firstInitialize = true;
                //drawImage();
                addNextText(nxtFile);
                closing = true;
            }
            else
            closing = true;
        }
        if (words.size() == 0) 
            return;
        if (words.size() != 0 && (Greenfoot.mouseClicked(this) || 
        Greenfoot.isKeyDown("enter") && Greenfoot.isKeyDown("enter")) 
        && delay == 0)
        {
            instantText();
            delay = 20;
        }
        
        words.set(0,checkForKeys(words.get(0)));
        if (words.get(0).equals("@@"))
        {
            words.remove(0);
            nxtFile = words.remove(0);
            
            if (!nxtFile.endsWith(".txt"))
            nxtFile+= ".txt";
        }
        else if (pos > WIDTH-FONT_SIZE/2*words.get(0).length()-(int)FONT_SIZE && index == 0 )
        {
            pos = (int)FONT_SIZE+60;
            //pos = getImage().getFont().getSize()+50;
            hPos += (int)FONT_SIZE*2-FONT_SIZE/1.3;
            
            //hPos += (int)FONT_SIZE*2-FONT_SIZE/1.5;
        }
        else
        {
            String temp = words.get(0).substring(index, index + 1);
            image.drawString(temp, pos, hPos);
            index += temp.length();
            pos += (int)FONT_SIZE/2;
            //pos += getImage().getFont().getSize()/2;
            setImage(image);
            if (index >= words.get(0).length())
            {
                words.remove(0);
                index = 0;
                pos+= FONT_SIZE/2;
                //pos += getImage().getFont().getSize()/2;
            }
        }
    }
    public void close()
    {
        closing = true;
    }
    public void instantText()
    {
        while (words.size() > 2)
        {
            words.set(0,checkForKeys(words.get(0)));
            if (words.get(0).equals("@@"))
            {
                words.remove(0);
                nxtFile = words.remove(0);
                if (!nxtFile.endsWith(".txt"))
                nxtFile+= ".txt";
            }
            else if (pos > WIDTH-FONT_SIZE/2*words.get(0).length()-(int)FONT_SIZE && index == 0 )
            {
                pos = (int)FONT_SIZE+60;
                hPos += (int)FONT_SIZE*2-FONT_SIZE/1.3;
            }
            else
            {
                String temp = words.get(0).substring(index, index + 1);
                image.drawString(temp, pos, hPos);
                index += temp.length();
                pos += (int)FONT_SIZE/2;
                setImage(image);
                if (index >= words.get(0).length())
                {
                    words.remove(0);
                    index = 0;
                    pos+= FONT_SIZE/2;
                }
            }
        }
    }
    public String getTextFile(String textFileName)
    {
        String str = "";
        StringBuffer sb = new StringBuffer();
        try{
            URL url = getClass().getClassLoader().getResource(textFileName);
            if(url == null)
            throw new IOException("File not found: " + textFileName);
            InputStream is = url.openStream();
            BufferedReader br = new BufferedReader(new InputStreamReader(is));
            String line = br.readLine();
            while(line != null)
            {
                if (line != null)
                {
                    str += " "+line;
                }
                line = br.readLine();
            }
            is.close();
            br.close();
        }
        catch(Exception ex)
        { 
        }
        return str;
    } 
    public String checkForKeys(String s)
    {
        if (s == null) return s;
        if (s.equals("%left")) return getMWorld().left.toUpperCase();
        if (s.equals("%left2")) return getMWorld().left2.toUpperCase();
        if (s.equals("%right")) return getMWorld().right.toUpperCase();
        if (s.equals("%right2")) return getMWorld().right2.toUpperCase();
        if (s.equals("%jump")) return getMWorld().jump.toUpperCase();
        if (s.equals("%jump2")) return getMWorld().jump2.toUpperCase();
        if (s.equals("%crouch")) return getMWorld().crouch.toUpperCase();
        if (s.equals("%crouch2")) return getMWorld().crouch2.toUpperCase();
        if (s.equals("%use")) return getMWorld().use.toUpperCase();
        if (s.equals("%suitpower")) return getMWorld().suitpower.toUpperCase();
        return s;
    }
    public void readStringToArray(String str)
    {
        StringTokenizer st = new StringTokenizer(str);
        while (st.hasMoreTokens())
        {
            String t = ""+st.nextToken();
           // t = checkForKeys(t);
            words.add(t);
        }
    }
    public int calcHeight(String str)
    {
        int wordPos = (int)FONT_SIZE+60;
        int numrows = (int)(FONT_SIZE)+60;
        for (int i = 0; i < words.size(); i++)
        {
            wordPos += words.get(i).length()*(int)FONT_SIZE/2;
            wordPos += FONT_SIZE/2;
            if (wordPos > WIDTH-FONT_SIZE)
            {
                wordPos = (int)FONT_SIZE+60;
                wordPos += words.get(i).length()*(int)FONT_SIZE/2;
                numrows += (int)FONT_SIZE*2-FONT_SIZE/1.3;
            }
        }
        return numrows+(int)(FONT_SIZE);
        /*
        //int numRow = (str.length()*(int)FONT_SIZE)/(WIDTH-2*(int)FONT_SIZE);
        int numRow = str.length()*(int)FONT_SIZE/WIDTH;
        if (numRow == 0)
        numRow = 1;
        //return numRow*(int)FONT_SIZE;
        return numRow*(int)FONT_SIZE+3*(int)FONT_SIZE;
        */
    }
    public Midori getMWorld()
    {
        return (Midori) getWorld();
    }
}