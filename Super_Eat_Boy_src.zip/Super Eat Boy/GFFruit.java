import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.util.List;
/**
 * Write a description of class GFFruit here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class GFFruit  extends GoodFood
{
    private static GreenfootImage img;
    
    public GFFruit(int realX, int realY)
    {
        super(realX, realY);
        if (img == null)
            img = new GreenfootImage("images/goodfood/apple.png");
        setImage(img);
    }
    public void act() 
    {
        super.act();
    }      
    public void die()
    {
        List<Hud> listHud = getWorld().getObjects(Hud.class);
        for (Hud h : listHud)
            h.addCarb();
        getWorld().removeObject(this);
    } 
}
