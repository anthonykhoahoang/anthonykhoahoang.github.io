import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.util.List;
/**
 * Write a description of class EricCharacter here.
 * 
 * @author Anthony Hoang
 * @version (v1)
 */
public class EricCharacter  extends Character
{
    public EricCharacter()
    {
        setImage(new GreenfootImage("eric/eric.png"));
    }
    public void act() 
    {
        super.act();
    }   
    public void blinkEyes()
    {
        List<EricEyes> listEyes = getMWorld().getObjects(EricEyes.class);
        if (listEyes.size() == 0 ) return;
        EricEyes eyes = listEyes.get(0);
        eyesBlinkCount--;
        if (eyesBlinkCount == 0)
        {
            eyes.readyToBlink();
            eyesBlinkCount = 200 + ((int)Math.random()*5)*100;
        }
    } 
    public void placeMouthEyes()
    {
        List<EricEyes> listEyes = getMWorld().getObjects(EricEyes.class);
        List<EricMouth> listMouth = getMWorld().getObjects(EricMouth.class);
        if (listEyes.size() == 0 || listMouth.size() == 0) return;
        
        EricEyes eyes = listEyes.get(0);
        EricMouth mouth = listMouth.get(0);
        
        if (mouth.getY() != getY()-157)
        mouth.setLocation(getX()+11, getY()-157);
        
        if (eyes.getX() != getX()+10 && eyes.getY() != getY()-214)
        eyes.setLocation(getX()+10, getY()-214);
    } 
}
