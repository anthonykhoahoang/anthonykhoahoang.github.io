import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class GreepMouse here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class GreepMouse extends Misc
{
    private GreenfootImage image;
    private GreenfootImage clear;
    public GreepMouse()
    {
        setImage(new GreenfootImage(1,1));
        //image = getImage();
       // clear = new GreenfootImage(1,1);
        setRotation(-135);
    }
    public void act() 
    {
        if (Greenfoot.getMouseInfo() != null)
        {
            //setImage(image);
            setLocation( Greenfoot.getMouseInfo().getX() +12, Greenfoot.getMouseInfo().getY() +20);
            getSpace().addGreepBlood(getX(), getY());
        }
        //else
        //setImage(clear);
    }    

}
