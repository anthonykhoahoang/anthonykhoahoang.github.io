import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.awt.Color;
import java.awt.Font;

/**
 * shows current typed text
 * 
 * @author Anthony Hoang
 * @version 2.1
 */
public class Display extends Keyboard
{
    private boolean isUpperCase;
    public String curText;
    private int acts = 0;
    private GreenfootImage image;
    
    public Display()
    {
        
        curText = "";
        isUpperCase = true;
        
        image = new GreenfootImage(700, 30);
        image.setColor(new Color(255,255,255, 128));
        image.fillRect(0, 0, 700, 30);
        image.setColor(new Color(0, 0, 0, 128));
        image.fillRect(5, 5, 690, 20);
        Font font = new Font("Courier", image.getFont().getStyle(), image.getFont().getSize()) ;
        font = font.deriveFont(30f);
        image.setFont(font);
        image.setColor(Color.WHITE);
        image.drawString(curText, 10, 20);
        setImage(image);
    }
    public void act() 
    {
        if (acts ==0)
        {
            image.clear();
            image = new GreenfootImage(700, 30);
            image.setColor(new Color(255,255,255, 128));
            image.fillRect(0, 0, 700, 30);
            image.setColor(new Color(0, 0, 0, 128));
            image.fillRect(5, 5, 690, 20);
            image.setColor(Color.WHITE);
            image.drawString(curText, 10, 20);
            setImage(image);
            acts = -5;
        }
        if (acts != 0)
        acts++;
    }    
    public void add(String str)
    {
        curText += str;
    }
    
    public boolean isUpperCase()
    {
        return isUpperCase;
    }
    public boolean setIsUpperCase(boolean b)
    {
        return isUpperCase = b;
    }
    public void deleteLastLetter()
    {
        if (curText.length() > 0)
        curText = curText.substring(0,curText.length()-1);
    }
    public void setCurText(String str)
    {
        curText = str;
    }
}
