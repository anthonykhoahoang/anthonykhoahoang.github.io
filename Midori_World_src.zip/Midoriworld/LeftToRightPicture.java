import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Moving picture that moves from left to right
 * 
 * @author Anthony Hoang
 * @version (v1)
 */
public class LeftToRightPicture extends MovingPicture
{
    private int delay;
    private int count = 0;
    public LeftToRightPicture(int d, String img)
    {
        setImage(new GreenfootImage(img));
        delay = d;
    }
    public void act() 
    {
        if (getMWorld().gamePause) return;
        if (count == delay)
        {
            count = 0;
            int x = getX()+1;
            if (x > 0)
            setLocation(x,getY());
        }
        else
        count++;
    }    
}
