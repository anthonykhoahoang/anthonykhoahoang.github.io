import greenfoot.*;  // (World, Actor, GreenfootImage, and Greenfoot)
import java.util.*;
/**
 * A rocket that can be controlled by the arrowkeys: up, left, right.
 * The gun is fired by hitting the 'space' key.
 * 
 * i'll add the credits later...
 * Reimplemented by anthony
 */
public class Rocket extends MovingThing
{
    public static GreenfootImage rocket = new GreenfootImage("rocket/rocket.png");    
    public static GreenfootImage rocketWithShield = new GreenfootImage("rocket/rocketWithShield.png");    
    public static GreenfootImage rocketWithShield2 = new GreenfootImage("rocket/rocketWithShield2.png");    
    public static GreenfootImage rocketWithShield3 = new GreenfootImage("rocket/rocketWithShield3.png");    
    public static GreenfootImage rocketWithShield4 = new GreenfootImage("rocket/rocketWithShield4.png");    
       
    
    /** The minimum delay between firing the gun. */
    public int minGunFireDelay;    
    /** How long ago we fired the gun the last time. */
    public int gunFireDelay = 0;    
    /** How fast the rocket is */  
    private Vector acceleration = new Vector(0,0.3);
    
    private int numActs;
    
    /** Speed of Rocket in easy mode */
    private int SPEED;
    
    /** Delay time for AAS attack */
    public int aasDelay;
    
    /** Delay time for EMP */
    public int empDelay;
    
    /**Missle firing delay */
    public int missleDelay;
    
    /** Ship squad fire delay*/
    public  boolean isDead = false;
     /** 
     * Upgrade 0 is bullet level +
     * Upgrade 1 is 100+ shield level
     * Upgrade 2 is number of weapons
     * Upgrade 3 is number "ALL Around Fire" (AAS) attack left
     * Upgrade 4 is number of lives
     * UPgrade 5 is energy level
     * Upgrade 6 is number of homing missles
     * Upgrade 7 is Ammo - Ammo can be used for machine gun
     * Upgrade 8 is number of ship squadrens left
     * Upgrade 9 is energy shot
     */
    
    private int invincible = 40;
    public int[] upgrades;
    
    public Rocket()
    {
        upgrades = new int[10];
        empDelay = 0;
        upgrades[0] = 0;
        upgrades[1] = 100;
        upgrades[2] = 1;
        upgrades[3] = 5;
        upgrades[4] = 1;
        aasDelay = 0;
        SPEED = 10;
        numActs = 0;
        minGunFireDelay = 5;
        if (getShieldLevel() <= 0)
        setImage(rocket);   
        else
        if (getShieldLevel() > 0 && getShieldLevel() < 300)
        setImage(rocketWithShield);
        else
        if (getShieldLevel() >= 300 && getShieldLevel() < 600)
        setImage(rocketWithShield2);
        else
        if (getShieldLevel() >= 600 && getShieldLevel() < 900)
        setImage(rocketWithShield3);
        else
        if (getShieldLevel() > 900)
        setImage(rocketWithShield4);
        isDead = false;
        
    }
    public void act()
    {
        if (! isDead)
        {
            if (getSpace().difficulty() != 0 )
            move();
            
            if (getShieldLevel() < 0)
            upgrades[1] = 0;
            gunFireDelay++;
            checkKeys();
            if (getInvincible() > 0)
            {
                if (getInvincible()%2 == 0)
                checkShields();
                else
                setImage(new GreenfootImage(1,1));
                setInvincible(getInvincible()-1);
            }
            else
            checkCollision();
        }
    }
    public boolean isDead()
    {
        return isDead;
    }
    public int getaasDelay()
    {
        return aasDelay;
    }
    public int getempDelay()
    {
        return empDelay;
    }
    public int getMissleDelay()
    {
        return missleDelay;
    }
    public boolean hitSomething()
    {
        Asteroid a = (Asteroid) getOneIntersectingObject(Asteroid.class);
        Enemy c = (Enemy) getOneIntersectingObject(Enemy.class);
        EnemyBullet e = (EnemyBullet) getOneIntersectingObject(EnemyBullet.class);
        return (a!=null || c!=null || e != null);
    }
    public void checkCollision() 
    {
        Asteroid a = (Asteroid) getOneIntersectingObject(Asteroid.class);
        Enemy c = (Enemy) getOneIntersectingObject(Enemy.class);
        EnemyBullet e = (EnemyBullet) getOneIntersectingObject(EnemyBullet.class);
        Upgrades f = (Upgrades) getOneIntersectingObject(Upgrades.class);
        if(a != null) 
        {
            getSpace().rocketHit(this);
            a.hit(40);
            if ( upgrades[1] > 0)
                upgrades[1] -= 25;
            else
            {
                if (getLives() > 0)
                    loseLife();
                else
                {
                    isDead = true;
                    ((Space) getWorld()).gameOver();
                }
            }
        }
        else 
        if (c != null )
        {
            getSpace().rocketHit(this);
            c.hit(100);
            if ( upgrades[1] > 0)
                upgrades[1] -= 75;
            else
            {
                if (getLives() > 0)
                    loseLife();
                else
                {
                    isDead = true;
                    ((Space) getWorld()).gameOver();
                }
            }
        }
        else 
        if (e != null)
        {
            getSpace().rocketHit(this);
            if ( upgrades[1] > 0)
                upgrades[1] -= e.getDamage();
            else
            {
                if (getLives() > 0)
                    loseLife();
                else
                {
                    isDead = true;
                    ((Space) getWorld()).gameOver();
                }
            }
            e.hit();
        }
        else 
        if (f != null)
        {
            f.hit(5, this);
        }
        checkShields();
    }
    private void checkKeys() 
    {
        if (Greenfoot.isKeyDown("t") && Greenfoot.isKeyDown("h")&& Greenfoot.isKeyDown("o") )
        {
            if (aasDelay == 0)
            {
                activateCheatCode();
                aasDelay = 30;
            }
        }
        if (Greenfoot.isKeyDown("up") || Greenfoot.isKeyDown("w"))
        ignite(true);
        else
        reverse(Greenfoot.isKeyDown("down") || Greenfoot.isKeyDown("s") );
        if(Greenfoot.isKeyDown("left") || Greenfoot.isKeyDown("a"))
        setRotation(getRotation() - 5);
        if(Greenfoot.isKeyDown("right") || Greenfoot.isKeyDown("d")) 
        setRotation(getRotation() + 5);
        
        if (Greenfoot.isKeyDown("e") && getSpace().difficulty() != 0 )
        {
            stop();
        }
        if(Greenfoot.isKeyDown("space")) 
        {
            fire();
        }
        if(Greenfoot.isKeyDown("c"))
        {
            if (missleDelay == 0)
            {
                shootMissle();
                missleDelay = 15;
            }
        }
        if(Greenfoot.isKeyDown("z")) 
        {
            if (aasDelay == 0)
            {
                fireAAS();
                aasDelay = 30;
            }
        }
        if(Greenfoot.isKeyDown("x")) 
        {
            if (empDelay == 0)
            {
                fireEMP();
                empDelay = 20;
            }
        }
        if (Greenfoot.isKeyDown("v"))
        shootMG();
        if (Greenfoot.isKeyDown("n")&& getSpace().getGameLevel() >= 25) fireFlameThrower();
        if (getSpace().getGameLevel() >= 20)
        if (Greenfoot.isKeyDown("b"))
        {
            chargeEnergyShot();
        }
        else
        {
            if (upgrades[9] != 0)
            shootEnergyShot();
        }
        if (aasDelay > 0)
        aasDelay--;
        if (empDelay > 0)
        empDelay--;
        if (missleDelay > 0)
        missleDelay--;
           
    }
    /**
     * cheat code!
     */
    public void activateCheatCode()
    {
        for (int i = 0; i < 360; i+=20)
        {
            EnergyBullet b = new EnergyBullet(getSpeed().copy(), i, 999, this, true);
            getWorld().addObject(b, getX(), getY());
            b.move();
        }
    }
    
    /**
     * Go forward or back w/ rocket
     */
    public void ignite(boolean b)
    {
        if(b) 
             if (getSpace().difficulty() != 0)
             {
                 acceleration.setDirection(getRotation());
                 increaseSpeed(acceleration);
             }
             //super.move2();
             else move2();
    }
    public void reverse(boolean b)
    {
        if(b) 
           if (getSpace().difficulty() != 0)
           {
               acceleration.setDirection(getRotation()+180);
               increaseSpeed(acceleration);
           }
           else moveReverse();
    }
    public void moveReverse()
    {
        double angle = Math.toRadians( getRotation() +180 );
        int x = (int) Math.round(getX() + Math.cos(angle) * 5);
        int y = (int) Math.round(getY() + Math.sin(angle) * 5);
        if(x >= getWorld().getWidth()) 
        {
            x = 0;
        }
        if(x < 0) {
            x = getWorld().getWidth() - 1;
        }
        if(y >= getWorld().getHeight()) {
            y = 0;
        }
        if(y < 0) {
            y = getWorld().getHeight() - 1;
        }
        setLocation(x, y);
    }
    public void move2()
    {
        double angle = Math.toRadians( getRotation() );
        int x = (int) Math.round(getX() + Math.cos(angle) * SPEED);
        int y = (int) Math.round(getY() + Math.sin(angle) * SPEED);
        if(x >= getWorld().getWidth()) 
        {
            x = 0;
        }
        if(x < 0) {
            x = getWorld().getWidth() - 1;
        }
        if(y >= getWorld().getHeight()) {
            y = 0;
        }
        if(y < 0) {
            y = getWorld().getHeight() - 1;
        }
        setLocation(x, y);
    }
    
    /**
     * Fire a bullet if the gun is ready and tells which type of bullet to fire
     */
    public void fireBullet(int rotation, boolean sounds)
    {
        int n = upgrades[0];
        Bullet b = null;
        if (n == 0)
        {
            b = new Bullet(getSpeed().copy(), rotation, 10, sounds, this);
        }
        else
        if ( n == 1)
        {
            b = new Bullet1(getSpeed().copy(), rotation, 10, sounds, this);
        }
        else
        if ( n == 2)
        {
            b = new Bullet2(getSpeed().copy(), rotation, 10, sounds, this);
        }
        else
        if ( n == 3)
        {
            b = new Bullet3(getSpeed().copy(), rotation, 10, sounds, this);
        }
        else
        if ( n == 4)
        {
            b = new Bullet4(getSpeed().copy(), rotation, 10, sounds, this);
        }
        else
        if ( n == 5)
        {
            b = new Bullet5(getSpeed().copy(), rotation, 10, sounds, this);
        }
        else
        if ( n == 6)
        {
            b = new Bullet6(getSpeed().copy(), rotation, 10, sounds, this);
        }
        else
        if ( n == 7)
        {
            b = new Bullet7(getSpeed().copy(), rotation, 10, sounds, this);
        }
        else
        if ( n == 8)
        {
            b = new Bullet8(getSpeed().copy(), rotation, 10, sounds, this);
        }
        else
        if ( n == 9)
        {
            b = new Bullet9(getSpeed().copy(), rotation, 10, sounds, this);
        }
        getWorld().addObject(b,getX(), getY());
        b.setVector(getSpeed().copy());
        b.setRotation(rotation);
        b.increaseSpeed(new Vector(rotation, 15));
        b.move();
        
    }
    public void fire() 
    {     
        if(gunFireDelay >= minGunFireDelay) 
        {
            if (getNumWeapons() == 1)
            {
                fireBullet(getRotation(), true);
            }
            else
            if (getNumWeapons() == 2)
            {
                fireBullet(getRotation()-1, true);
                fireBullet(getRotation()+1, false);
            
            }
            else
            if (getNumWeapons() == 3)
            {
                fireBullet(getRotation(), true);
                fireBullet(getRotation()-5, false);
                fireBullet(getRotation()+5, false);
            }
            else
            if (getNumWeapons() == 4)
            {
                fireBullet(getRotation()+1, true);
                fireBullet(getRotation()-1, false);
                fireBullet(getRotation()+3, false);
                fireBullet(getRotation()-3, false);
            }
            gunFireDelay = 0;
            getSpace().score(-2);
        }
    }
    /**
     * returns stats of the rockets and sets them accordingly
     */
    public int[] getAllRocketStats()
    {
        return upgrades;
    }
    public void setAllRocketStats(int[] x)
    {
        for (int i = 0; i < x.length; i ++)
        upgrades[i] = x[i];
        
    }
    /**
     * returns number of enemies
     */
    public int getEnemies()
    {
        return ((Space)getWorld()).getEnemies();
    }
    /**
     * These are upgrade methods below
     */
    
    /**
     * Bullet methods
     */
    public void raiseBulletLevel()
    {
        if (upgrades[0] < 9 )
        {
            upgrades[0]++;
            getSpace().updateGunLevelP1();
        }
    }
    public int getBulletLevel()
    {
        return upgrades[0];
    }
    
    /**
     * Shield Methods
     */
    public int getShieldLevel()
    {
        return upgrades[1];
    }
    
    public void raiseShieldLevel()
    {
        if (upgrades[1] >=2000)
        raiseBulletLevel();
        else
        upgrades[1] += 100;
        if (upgrades[1] > 2000)
        upgrades[1] = 2000;
        checkShields();
    }

    public void checkShields()
    {
        if (getShieldLevel() <= 0)
        {
            setImage(rocket);   
            upgrades[1] = 0;
        }
        else
        if (getShieldLevel() > 0 && getShieldLevel() < 300 )
        setImage(rocketWithShield);
        else
        if (getShieldLevel() >= 300 && getShieldLevel() < 600 )
        setImage(rocketWithShield2);
        else
        if (getShieldLevel() >= 600 && getShieldLevel() < 900 )
        setImage(rocketWithShield3);
        else
        if (getShieldLevel() > 900 && !getImage().equals(rocketWithShield4))
        setImage(rocketWithShield4);
        getSpace().updateShieldLevelP1();
    }

    
    /**
     * Number of weapons methods, 3 max
     */
    public void raiseNumWeapons()
    {
        if (upgrades[2] < 4)
        {
            upgrades[2]++;
            getSpace().updateNumGunsP1();
        }
        else
        raiseShieldLevel();
    }
    public int getNumWeapons()
    {
        return upgrades[2];
    }
    
    /**
     * "ALL Around Shot" attack methods
     */
    public void raiseAAS()
    {
        if (upgrades[3] < 10)
        upgrades[3]++;
        else
        raiseNumWeapons();
        getSpace().updateNumAASP1();
    }
    public int getAAS()
    {
        return upgrades[3];
    }
    public void fireAAS()
    {
        if (getAAS() > 0)
        {
            int r = 0;
            for (int i = 0; i < 360; i++)
            {
                Bullet b = new Bullet(getSpeed().copy(), r, 10, false, this);
                
                getWorld().addObject(b, getX(), getY());
                b.setVector(getSpeed().copy());
                b.setRotation(getRotation()+r);
                b.increaseSpeed(new Vector(getRotation()+r, 15));
                b.move();
                r += 2;
            }
            Greenfoot.playSound("aas.wav");
            upgrades[3]--;
            getSpace().updateNumAASP1();
        }
    }
    /**
     * Number of lives methods
     */
    public void raiseLife()
    {
      if (upgrades[4] < 10)
        upgrades[4]++;
      else
      raiseAAS();
      getSpace().updateNumLivesP1();
    }
    public int getLives()
    {
        return upgrades[4];
    }
    public void loseLife()
    {
        upgrades[4]--;
        upgrades[1] = 100;
        setLocation(getSpace().getWidth()/2, getSpace().getHeight()/2);
        invincible = 40;
        stop();
        getSpace().updateNumLivesP1();
    }
    
    /**
     * EMP Methods
     */
    public void fireEMP()
    {
        if (upgrades[5] >= 100)
        {
            int r = 0;
            for (int i = 0; i < 360; i++)
            {
                EMPBullet b = new EMPBullet(getSpeed().copy(), getRotation()+r, this);
                
                getWorld().addObject(b, getX(), getY());
                b.setVector(getSpeed().copy());
                b.setRotation(getRotation()+r);
                b.increaseSpeed(new Vector(getRotation()+r, 15));
                b.move();
                r+=2;
            }
            upgrades[5] -= 100;
            Greenfoot.playSound("emp.wav");
            getSpace().updateEnergyLevelP1();
        }
    }
    public int getEnergyLevel()
    {
        return upgrades[5];
    }
    public void raiseEnergyLevel()
    {
      if (upgrades[5] == 3000)
        raiseLife();
      if (upgrades[5] <= 3000)
        upgrades[5] += 50;
      if (upgrades[5] > 3000)
        upgrades[5] = 3000;
      getSpace().updateEnergyLevelP1();
    }
    
    /**
     * Homing Missle Methods
     */
    public void raiseNumMissles()
    {
        upgrades[6]+=5;
        getSpace().updateNumMisslesP1();
    }
    public int getNumMissles()
    {
        return upgrades[6];
    }
    public void loseOneMissle()
    {
        if (upgrades[6] > 0)
        upgrades[6]--;
        getSpace().updateNumMisslesP1();
    }
    
    public void shootMissle()
    {
        if (getNumMissles() > 0)
        {
            HomingMissles b = new HomingMissles(getRotation(), this);
            getWorld().addObject(b, getX(), getY());
            loseOneMissle();
            
        }
      //  getSpace().updateNumMissles();
    }
    
    /**
     *  Machine gun fire methods
     */
    public void raiseMGAmmo()
    {
        upgrades[7] += 100;
        getSpace().updateAmmoLevelP1();
    }
    public int getMGAmmo()
    {
        return upgrades[7];
    }
    public void shootMG()
    {
        if (getMGAmmo() > 0)
        {
                        
            Bullet2 b = new Bullet2(getSpeed().copy(), getRotation()+5, 30, false, this);
            getWorld().addObject(b, getX(), getY());
            b.setVector(getSpeed().copy());
            b.setRotation(getRotation());
            b.increaseSpeed(new Vector(getRotation(), 15));
            b.move();
        
            Bullet2 a = new Bullet2(getSpeed().copy(), getRotation(), 30, true, this);
            getWorld().addObject(a, getX(), getY());
            a.setVector(getSpeed().copy());
            a.setRotation(getRotation()+5);
            a.increaseSpeed(new Vector(getRotation()+5, 15));
            a.move();

            Bullet2 c = new Bullet2(getSpeed().copy(), getRotation()-5, 30, false, this);
            getWorld().addObject(c, getX(), getY());
            c.setVector(getSpeed().copy());
            c.setRotation(getRotation()-5);
            c.increaseSpeed(new Vector(getRotation()-5, 15));
            c.move();
            
            upgrades[7] -= 3;
            getSpace().updateAmmoLevelP1();
            
            Greenfoot.playSound("bullet2.wav");
        }
       // getSpace().updateAmmoLevel();
    }
    /**
     * Energy shot methods
     */
    public void shootEnergyShot()
    {
        if (upgrades[9] != 0)
        {
            EnergyBullet b = new EnergyBullet(getSpeed().copy(), getRotation(), upgrades[9]/3, this, true);
            getWorld().addObject(b, getX(), getY());
            b.move();
            upgrades[9] = 0;
        }
    }
    public void chargeEnergyShot()
    {
        if (upgrades[5] != 0)
        {
            EnergyBullet b = new EnergyBullet(getSpeed().copy(), getRotation(), 1, this, false);
            getWorld().addObject(b, getX(), getY());
            b.move();
            upgrades[5] -= 10;
            upgrades[9] += 10;
            getSpace().updateEnergyLevelP1();
        }
        else
        shootEnergyShot();
        //getSpace().updateEnergyLevel();
    }
    /**
     *  flame thrower methods
     */
    public void fireFlameThrower()
    {
        if (getMGAmmo() > 0)
        {
            Flame a = new Flame(getSpeed().copy(), getRotation(), 5, false, this);
            getWorld().addObject(a, getX(), getY());
            a.move();
            upgrades[7] -= 1;
            getSpace().updateAmmoLevelP1();
        }
        //getSpace().updateAmmoLevel();
    }
    public void setInvincible(int n)
    {   invincible = n; }
    public int getInvincible()
    {   return invincible;  }
}