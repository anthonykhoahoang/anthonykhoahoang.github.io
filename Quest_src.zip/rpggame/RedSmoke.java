import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class RedSmoke here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class RedSmoke extends Smoke
{
    private GreenfootImage smoke = new GreenfootImage("Battle/redsmoke.png");
    
    public RedSmoke()
    {
        setImage(smoke);
    }
    public void act() 
    {
        super.act();
    }    
}
