import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class GameOver here.
 * 
 * @author Anthony Hoang
 * @version (v1)
 */
public class GameOver  extends Title
{
    
    public GameOver()
    {
        setImage(new GreenfootImage("gameover.png"));
    }
    public void act() 
    {
        super.act();
        if (Greenfoot.mouseClicked(this))
        {
            close();
            if (getWorld().getObjects(EatBoy.class).size() == 0)
            {
                getWorld().addObject(new EatBoy(100, 200), 800, 800);
                getWorld().removeObjects(getWorld().getObjects(HudObject.class));
                getWorld().addObject(new Hud(), 138, 41);
                getWorld().addObject(new FoodBar("Green", -45), 42, 38);
                getWorld().addObject(new FoodBar("Blue", -10), 12, 51);
                getWorld().addObject(new FoodBar("Red", -85), 52, 11);
                getWorld().addObject(new InsulinBar(), 123, 34);
                getWorld().addObject(new WaterBar(), 266, 36);
                getWorld().addObject(new BloodSugarBar(), 177, 13);
            }
        }
    }    
}
