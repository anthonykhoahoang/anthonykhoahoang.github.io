import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Rocket2 here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Rocket2 extends Rocket
{
    public Rocket2()
    {
        super();
    }
    public void act() 
    {
        if (! isDead)
        {
            if (!getSpace().isEasy())
            move();
            if (getShieldLevel() < 0)
            upgrades[1] = 0;
            gunFireDelay++;
            checkKeys();
            if (getInvincible() > 0)
            {
                if (getInvincible()%2 == 0)
                checkShields();
                else
                setImage(new GreenfootImage(1,1));
                setInvincible(getInvincible()-1);
            }
            else
            checkCollision();
        }
        else setImage(new GreenfootImage(1,1));
    }    
     private void checkKeys()
    {
        if(Greenfoot.isKeyDown("w"))
            ignite(true);
        else
            reverse(Greenfoot.isKeyDown("s"));
        if(Greenfoot.isKeyDown("a"))
            setRotation(getRotation() - 5);
        if(Greenfoot.isKeyDown("d"))
            setRotation(getRotation() + 5);
        if(Greenfoot.isKeyDown("F1"))
            fire();
        if (Greenfoot.isKeyDown("e") && !getSpace().isEasy() )
            stop();
        if(Greenfoot.isKeyDown("F5"))
            shootMG();
        if(Greenfoot.isKeyDown("F4") && getMissleDelay() == 0)
        {
            shootMissle();
            missleDelay = 5;
        }
        if(Greenfoot.isKeyDown("F2") && getaasDelay() == 0)
        {
            fireAAS();
            aasDelay = 30;
        }
        if(Greenfoot.isKeyDown("F3") && getempDelay() == 0)
        {
            fireEMP();
            empDelay = 20;
        }
        if (getSpace().getGameLevel() >= 20)
        if (Greenfoot.isKeyDown("F6"))
        {
            chargeEnergyShot();
        }
        else
        {
            if (upgrades[9] != 0)
            shootEnergyShot();
        }
        if (Greenfoot.isKeyDown("F7")&& getSpace().getGameLevel() >= 25) fireFlameThrower();
        if(aasDelay > 0)
            aasDelay--;
        if(empDelay > 0)
            empDelay--;
        if(missleDelay > 0)
            missleDelay--;
    }
    /**
     * These are upgrade methods below
     */
    
    /**
     * Bullet methods
     */
    public void raiseBulletLevel()
    {
        if (upgrades[0] < 9 )
        {
            upgrades[0]++;
            getSpace().updateGunLevelP2();
        }
    }
    
    /**
     * Shield Methods
     */
    
    public void checkShields()
    {
        if (getShieldLevel() <= 0)
        {
            setImage(rocket);   
            upgrades[1] = 0;
        }
        else
        if (getShieldLevel() > 0 && getShieldLevel() < 300 )
        setImage(rocketWithShield);
        else
        if (getShieldLevel() >= 300 && getShieldLevel() < 600 )
        setImage(rocketWithShield2);
        else
        if (getShieldLevel() >= 600 && getShieldLevel() < 900 )
        setImage(rocketWithShield3);
        else
        if (getShieldLevel() > 900 && !getImage().equals(rocketWithShield4))
        setImage(rocketWithShield4);
        getSpace().updateShieldLevelP2();
    }

    
    /**
     * Number of weapons methods, 3 max
     */
    public void raiseNumWeapons()
    {
        if (upgrades[2] < 4)
        {
            upgrades[2]++;
            getSpace().updateNumGunsP2();
        }
        else
        raiseShieldLevel();
    }
    /**
     * "ALL Around Shot" attack methods
     */
    public void raiseAAS()
    {
        if (upgrades[3] < 10)
        upgrades[3]++;
        else
        raiseNumWeapons();
        getSpace().updateNumAASP2();
    }
    public void fireAAS()
    {
        if (getAAS() > 0)
        {
            int r = 0;
            for (int i = 0; i < 360; i++)
            {
                Bullet b = new Bullet(getSpeed().copy(), r, 10, false, this);
                
                getWorld().addObject(b, getX(), getY());
                b.setVector(getSpeed().copy());
                b.setRotation(getRotation()+r);
                b.increaseSpeed(new Vector(getRotation()+r, 15));
                b.move();
                r += 2;
            }
            Greenfoot.playSound("aas.wav");
            upgrades[3]--;
            getSpace().updateNumAASP2();
        }
    }
    
    /**
     * Number of lives methods
     */
    public void raiseLife()
    {
      if (upgrades[4] < 10)
        upgrades[4]++;
      else
      raiseAAS();
      getSpace().updateNumLivesP2();
    }
    public void loseLife()
    {
        upgrades[4]--;
        upgrades[1] = 100;
        setLocation(getSpace().getWidth()/2, getSpace().getHeight()/2);
        setInvincible(40);
        stop();
        getSpace().updateNumLivesP2();
    }
    /**
     * EMP Methods
     */
    public void fireEMP()
    {
        if (upgrades[5] >= 100)
        {
            int r = 0;
            for (int i = 0; i < 360; i++)
            {
                EMPBullet b = new EMPBullet(getSpeed().copy(), getRotation()+r, this);
                
                getWorld().addObject(b, getX(), getY());
                b.setVector(getSpeed().copy());
                b.setRotation(getRotation()+r);
                b.increaseSpeed(new Vector(getRotation()+r, 15));
                b.move();
                r+=2;
            }
            upgrades[5] -= 100;
            Greenfoot.playSound("emp.wav");
            getSpace().updateEnergyLevelP2();
        }
    }
    public void raiseEnergyLevel()
    {
      if (upgrades[5] == 3000)
        raiseLife();
      if (upgrades[5] <= 3000)
        upgrades[5] += 50;
      if (upgrades[5] > 3000)
        upgrades[5] = 3000;
      getSpace().updateEnergyLevelP2();
    }
    
    /**
     * Homing Missle Methods
     */
    public void raiseNumMissles()
    {
        upgrades[6]+=5;
        getSpace().updateNumMisslesP2();
    }
    public void loseOneMissle()
    {
        if (upgrades[6] > 0)
        upgrades[6]--;
        getSpace().updateNumMisslesP2();
    }
    
    /**
     *  Machine gun fire methods
     */
    public void raiseMGAmmo()
    {
        upgrades[7] += 100;
        getSpace().updateAmmoLevelP2();
    }
    public void shootMG()
    {
        if (getMGAmmo() > 0)
        {
            Bullet2 b = new Bullet2(getSpeed().copy(), getRotation()+5, 30, false, this);
            getWorld().addObject(b, getX(), getY());
            b.setVector(getSpeed().copy());
            b.setRotation(getRotation());
            b.increaseSpeed(new Vector(getRotation(), 15));
            b.move();
                    
            Bullet2 a = new Bullet2(getSpeed().copy(), getRotation(), 30, true, this);
            getWorld().addObject(a, getX(), getY());
            a.setVector(getSpeed().copy());
            a.setRotation(getRotation()+5);
            a.increaseSpeed(new Vector(getRotation()+5, 15));
            a.move();

            Bullet2 c = new Bullet2(getSpeed().copy(), getRotation()-5, 30, false, this);
            getWorld().addObject(c, getX(), getY());
            c.setVector(getSpeed().copy());
            c.setRotation(getRotation()-5);
            c.increaseSpeed(new Vector(getRotation()-5, 15));
            c.move();

            upgrades[7] -= 3;
            getSpace().updateAmmoLevelP2();
            Greenfoot.playSound("bullet2.wav");
        }
    }
    /**
     * Energy shot methods
     */
    public void chargeEnergyShot()
    {
        if (upgrades[5] != 0)
        {
            EnergyBullet b = new EnergyBullet(getSpeed().copy(), getRotation(), 1, this, false);
            getWorld().addObject(b, getX(), getY());
            b.move();
            upgrades[5] -= 10;
            upgrades[9] += 10;
            getSpace().updateEnergyLevelP2();
        }
        else
        shootEnergyShot();
        //getSpace().updateEnergyLevel();
    }
    /**
     *  flame thrower methods
     */
    public void fireFlameThrower()
    {
        if (getMGAmmo() > 0)
        {
            Flame a = new Flame(getSpeed().copy(), getRotation(), 5, false, this);
            getWorld().addObject(a, getX(), getY());
            a.move();
            upgrades[7] -= 1;
            getSpace().updateAmmoLevelP2();
        }
        //getSpace().updateAmmoLevel();
    }

}
