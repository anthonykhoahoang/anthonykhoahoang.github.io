import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Menu here.
 * 
 * @author Anthony Hoang
 * @version (v1)
 */
public class Menu  extends Actor
{
    private boolean isOn = false;
    public boolean closing = false;
    public void act() 
    {
        // Add your action code here.
    }   
    public void close()
    {
        closing = true;
    } 
    public boolean mouseOverThis()
    {
        MouseInfo m = Greenfoot.getMouseInfo();
        if (m == null)
        {
            if (isOn) return true;
            return false;
        }
        else
        {
            Actor actor = m.getActor();
            
            if (actor != null && actor.equals(this))
            {
                isOn = true;
                return true;
            }
            else
            {
                isOn = false;
                return false;
            }
        }
    }
    public ScrollWorld getWorld()
    {
        return (ScrollWorld) super.getWorld();
    }
}
