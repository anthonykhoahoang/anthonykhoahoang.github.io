import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Bullet4 - level 4 of the bullet the rocket can shoot.
 * 
 * @author (Anthony Hoang) 
 * @version (2.0)
 */
public class Bullet4 extends Bullet
{
    public Bullet4 (Vector speed, int rotation, int dmg, boolean sounds, Rocket rocket)
    {
        super(speed, rotation, dmg+20, false, rocket);
        if (sounds)
        Greenfoot.playSound("bullet4.wav");
    }
    public void act() 
    {
        super.act();
    }    
}
