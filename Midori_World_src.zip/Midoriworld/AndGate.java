import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class AndGate here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class AndGate  extends LGGates
{   
    private static GreenfootImage img;
    public AndGate()
    {
        super("AND");
        if (img == null)
        img = new GreenfootImage("logicgates/and.png");
        setImage(img);
    }
    public void act() 
    {
        super.act();
    }    
}
