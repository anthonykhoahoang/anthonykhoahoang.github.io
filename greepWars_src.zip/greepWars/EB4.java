import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class EB4 here.
 * 
 * @author Anthony Hoang
 * @version 2.1
 */
public class EB4 extends EnemyBullet
{
    public EB4(int rotation, int life, boolean sounds, Enemy e)
    {
        super(rotation, life, 20, false, e);
        if (sounds)
        Greenfoot.playSound("bullet4.wav");
    }
}
