import greenfoot.*;  // (World, Actor, GreenfootImage, and Greenfoot)

/**
 * A bullet that can hit asteroids.
 * 
 * @author Poul Henriksen
 * redesigned and reimplemented by  Anthony Hoang
 */
public class Bullet extends MovingThing
{
    /** A bullet looses one life each act, and will disappear when life = 0 */
    private int life;
    /** The damage this bullet will deal */
    private int damage;
    public Rocket r;
    private int shrink = 0;
    private int numActs = 0;
    private int SPEED = 15;
    
    public Bullet()
    {
    }
    public Bullet(Vector speed, int rotation, int dmg, boolean sound, Rocket rocket)
    {
        super(speed);
        r = rocket;
        damage = dmg;
        life = 40;
        //calcShrink(life*2);
        setRotation(rotation);
        increaseSpeed(new Vector(rotation, 15));
        if (sound)
        Greenfoot.playSound("startBullet.wav");
    }
    /**
     * The bullet will damage asteroids if it hits them.
     */
    public void calcShrink(int life)
    {
        int w = getImage().getWidth();
        int h = getImage().getHeight();
        if (w < h)
        {
            shrink = life/w; 
        }
        else shrink = life/h;
    }
    public int getLife()
    {
        return life;
    }
    public void setLife(int num)
    {
        life = num;
    }
    public void lowerLife()
    {
        life--;
    }
    public void act()
    {
        
        if(life <= 0) 
        {
            reset();
            getWorld().removeObject(this);
        }
        else 
        {
            move();
            Asteroid asteroid = (Asteroid) getOneIntersectingObject(Asteroid.class);
            Upgrades upgrade = (Upgrades) getOneIntersectingObject(Upgrades.class);
            Enemy enemy = (Enemy) getOneIntersectingObject(Enemy.class);
            if(asteroid != null)
            {
                asteroid.hit(damage);
                reset();
                getWorld().removeObject(this);
            }
            else
            if (enemy != null)
            {
                enemy.hit(damage);
                reset();
                getWorld().removeObject(this);
            }
            else
            if (upgrade != null)
            {
                upgrade.hit(damage, r);
                reset();
                getWorld().removeObject(this);
            }
        }
        life--;
        /*
        if (numActs!= 0 && numActs%shrink == 0 
        && getImage().getWidth() != 1 && getImage().getHeight() != 1)
        getImage().scale(getImage().getWidth()-1, getImage().getHeight()-1);
        numActs++;
        */
    }
    /*
    public void move()
    {
        double angle = Math.toRadians( getRotation() );
        int x = (int) Math.round(getX() + Math.cos(angle) * SPEED);
        int y = (int) Math.round(getY() + Math.sin(angle) * SPEED);
        if(x >= getWorld().getWidth()) 
        {
            x = 0;
        }
        if(x < 0) {
            x = getWorld().getWidth() - 1;
        }
        if(y >= getWorld().getHeight()) {
            y = 0;
        }
        if(y < 0) {
            y = getWorld().getHeight() - 1;
        }
        setLocation(x, y);
    }
    */
    public void reset()
    {
        //setVector(r.getSpeed().copy());
        life = 40;
    }
}