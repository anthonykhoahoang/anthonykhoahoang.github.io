import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * AlienShip releases Greeps and can hurt you if it contacts you.
 * 
 * @author (Anthony Hoang) 
 * @version (2.0)
 */
public class AlienShip extends Enemy
{
    private int totalPassengers;     // Total number of passengers in this ship.
    private int stepCount = 0;
    private int passengersReleased;
    private int empDelay;
    
    private int releaseDelay;
    
    /**
     * Create a space ship. The parameter specifies at what height to land.
     */
    public AlienShip(int numGreeps, int life)
    {
        super (life, 100);
        totalPassengers = numGreeps;
        empDelay = 0;
        releaseDelay = -20;
    }

    /**
     * Let the ship act: move or release greeps.
     */
    public void act()
    {
        if (getEmpDelay() >= 0)
        { 
            if(!isEmpty() && releaseDelay >= 0) 
            releasePassenger();
            else 
            releaseDelay++;
            move2();
            /*
            if (randomChance(2))
            turn(10);
            */
           if (atWorldEdge())
           setRotation(getRotation() + 45);
        }
        else
        super.act();
    }
    public void resetStats()
    {
        super.resetStats();
        totalPassengers = getSpace().numGreeps;
        passengersReleased = 0;
        empDelay = 0;
        releaseDelay = -20;
    }
    /**
     * True if all passengers are out.
     */
    public boolean isEmpty()
    {
        return passengersReleased == totalPassengers;
    }
    
    /**
     * Possibly: Let one of the passengers out. Passengers appear at intervals, 
     * so this may or may not release the passenger.
     */
    private void releasePassenger()
    {
        if(passengersReleased < totalPassengers) 
        {
            stepCount++;
            if(stepCount == 5) 
            {
                getSpace().addEnemy();
                getSpace().addObject(new Greepers(getSpace().getGreepRange()), getX(), getY() + 30);
                passengersReleased++;
                stepCount = 0;
            }
        }
    }
}