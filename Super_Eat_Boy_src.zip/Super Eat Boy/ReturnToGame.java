import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.awt.Color;
import java.awt.Font;
import java.util.List;
/**
 * Write a description of class ReturnToLoginMenu here.
 * 
 * @author Anthony Hoang
 * @version (v1)
 */
public class ReturnToGame  extends Menu
{
    private int WIDTH = 220;
    private int HEIGHT= 50;
    private GreenfootImage image;
    private GreenfootImage image2;
    private boolean redraw = true;
    private boolean firstInitialize = true;
    public ReturnToGame()
    {
        image = new GreenfootImage(WIDTH, HEIGHT);
        image2 = new GreenfootImage(WIDTH, HEIGHT);
        drawOne();
        drawTwo();
        setImage(image2);
        image.setTransparency(0);
        image2.setTransparency(0);
    }
    public void act() 
    {
        if (firstInitialize)
        {
            int t = getImage().getTransparency()+5;
            if (t > 255)
            firstInitialize = false;
            else
            {
                image.setTransparency(t);
                image2.setTransparency(t);
            }
        }
        if (closing)
        {
            int t = getImage().getTransparency()-10;
            if (t < 0)
            {
                getWorld().gamePause = false;
                getWorld().removeObject(this);
            }
            else
            {
                image.setTransparency(t);
                image2.setTransparency(t);
            }
            return;
        }
        if (mouseOverThis() )
        {
            if (getImage().equals(image2))
            setImage(image);
        }
        else if (getImage().equals(image))
        setImage(image2);
        if (Greenfoot.mouseClicked(this))
        {
            List<HowToPlayText> listPH = getWorld().getObjects(HowToPlayText.class);
            for (HowToPlayText p : listPH)
                p.close();
            List<CreditsText> listCT =  getWorld().getObjects(CreditsText.class);
            for (CreditsText p : listCT)
                p.close();
            getWorld().gamePause = false;
            close();
            //getWorld().addEventScript("returnToGame");
        }
    }    
    public void drawOne()
    {
        image.setColor(Color.GRAY);
        image.fill();
        image.setColor(new Color(5, 5, 75 ,150));
        image.fillRect(5, 5, WIDTH-10, HEIGHT-10);
        Font font = image.getFont();
        font = font.deriveFont(25f);
        image.setFont(font);
        image.setColor(Color.WHITE);
        image.drawString("Return to Menu", 19, 32);
        setImage(image);
    }
    public void drawTwo()
    {
        image2.setColor(new Color(5, 5, 50 ,150));
        image2.fillRect(5, 5, WIDTH-10, HEIGHT-10);
        Font font = image.getFont();
        font = font.deriveFont(25f);
        image2.setFont(font);
        image2.setColor(Color.WHITE);
        image2.drawString("Return to Menu", 19, 32);
        setImage(image2);
    }
}
