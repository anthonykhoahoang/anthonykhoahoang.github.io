import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.util.List;
/**
 * Alienship2 releases greepers2 and can shoot out bullets
 * 
 * @author Anthony Hoang
 * @version 2.1
 */
public class AlienShip2 extends Enemy
{
    private int totalPassengers = 10;     // Total number of passengers in this ship.
    private int stepCount = 0;
    private int passengersReleased;
    private int greepRange;
    private int minGunFireDelay;    
    private int gunFireDelay = 0;    
    private int numActs;
    private int coolDown;
    private int numActsMax;
    private int damage;
    private int coolDownDelay;
    private int empDelay = 0;
    /**
     * Create a space ship. The parameter specifies at what height to land.
     */
    public AlienShip2(int life, int maxActs, int bulletDamage)
    {
        super(life, 200);
        minGunFireDelay = 5;
        gunFireDelay = 0;
        numActs = 0;
        coolDown = 0;
        numActsMax = maxActs;
        damage = bulletDamage;
    }

    /**
     * Let the ship act: move or release greeps.
     */
    public void act()
    {
            if(numActs < numActsMax && numActs > 0)
            {
                shootRayGun();
            }
            if (numActs > numActsMax)
            numActs= -50;
            numActs++;
            
                gunFireDelay++;
            move();
            
            if (randomChance(2))
            turn(10);
        
        releasePassenger();
    }
    public void resetStats()
    {
        super.resetStats();
        totalPassengers = getSpace().numGreeps;
        passengersReleased = 0;
    }
    /**
     * release greepers2
     */
    private void releasePassenger()
    {
        if(passengersReleased < totalPassengers) 
        {
            stepCount++;
            if(stepCount == 15) 
            {
                getSpace().addObject(new Greepers2(), getX(), getY());
                getSpace().addEnemy();
                passengersReleased++;
                stepCount = 0;
            }
        }
    }
    /**
     * shoots it's weapon
     */
    public void shootRayGun()
    {
        if(gunFireDelay >= minGunFireDelay) 
        {
            EB4 b = new EB4( turnToShipInt(), 70, true, this);
            getWorld().addObject(b, getX(), getY());
            b.move();
            gunFireDelay = 0;
        }         
    }
}
