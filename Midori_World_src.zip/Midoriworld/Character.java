import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.util.List;
/**
 * Write a description of class Character here.
 * 
 * @author Anthony Hoang
 * @version (v1)
 */
public class Character  extends Actor
{
    public int eyesBlinkCount = 200;
    
    private int position; //0 center, 1 right, 2 left
    private boolean moving = false;
    private boolean movingToPosition0 = false;
    private boolean movingToPosition1 = false;
    private boolean movingToPosition2 = false;
    private int MOVESPEED = 3;
    private int nextX;
    
    public Character()
    {
        //setImage(new GreenfootImage("mido/mido.png"));
    }
    public void act() 
    {
        //movementChecks();
        placeMouthEyes();
        if (getMWorld().gamePause) return;
        blinkEyes();
    }    
    public void moveToX()
    {
        if (Math.abs(nextX-getX()) <= 3)
        moving = true;
        else
        {
            if (getX() > nextX)
            setLocation(getX()-MOVESPEED,getY());
            else
            setLocation(getX()+MOVESPEED,getY());
        }
    }
    public void moveX(int x)
    {
        moving = true;
        nextX = x;
    }
    public void movementChecks()
    {
        if (movingToPosition0) gotoPosition0();
        else
        if (movingToPosition1) gotoPosition1();
        else
        if (movingToPosition2) gotoPosition2();
    }
    
    public void gotoPosition0()
    {
        if (getX()-MOVESPEED > 310)
        setLocation(getX()-MOVESPEED, getY());
        else
        if (getX()+MOVESPEED < 310)
        setLocation(getX()+MOVESPEED, getY());
        else 
        {
            position = 0;
            movingToPosition0 = false;
        }
    }
    public void gotoPosition1()
    {
        if (getX() > 140)
        setLocation(getX()-MOVESPEED, getY());
        else
        {
            position = 1;
            movingToPosition1 = false;
        }
    }
    public void gotoPosition2()
    {
        if (getX() < 750)
        setLocation(getX()+MOVESPEED, getY());
        else
        {
            position = 2;
            movingToPosition2 = false;
        }
    }
    public void blinkEyes()
    {
        /*
        List<Eyes> listEyes = getMWorld().getObjects(Eyes.class);
        if (listEyes.size() == 0 ) return;
        Eyes eyes = listEyes.get(0);
        eyesBlinkCount--;
        if (eyesBlinkCount == 0)
        {
            eyes.readyToBlink();
            eyesBlinkCount = 200 + ((int)Math.random()*5)*100;
        }
        */
    }
    public void placeMouthEyes()
    {
        /*
        List<Eyes> listEyes = getMWorld().getObjects(Eyes.class);
        List<Mouth> listMouth = getMWorld().getObjects(Mouth.class);
        if (listEyes.size() == 0 || listMouth.size() == 0) return;
        
        Eyes eyes = listEyes.get(0);
        Mouth mouth = listMouth.get(0);
        
        if (mouth.getY() != getY()-91)
        mouth.setLocation(getX(), getY()-91);
        
        if (eyes.getX() != getX()-1 && eyes.getY() != getY()-128)
        eyes.setLocation(getX()-1, getY()-128);
        */
    }
    public void setMovingToPosition0(boolean b)
    {   movingToPosition0 = true;   }
    public void setMovingToPosition1(boolean b)
    {   movingToPosition1 = true;   }
    public void setMovingToPosition2(boolean b)
    {   movingToPosition2 = true;   }
    public Midori getMWorld()
    {
        return (Midori) getWorld();
    }
}
