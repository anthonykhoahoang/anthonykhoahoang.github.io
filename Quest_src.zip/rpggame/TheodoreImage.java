import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class TheodoreImage here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class TheodoreImage extends Keyboard
{
    public TheodoreImage()
    {
        getImage().scale(getImage().getWidth()+20, getImage().getHeight()+20);
    }
    public void act() 
    {
        // Add your action code here.
    }    
}
