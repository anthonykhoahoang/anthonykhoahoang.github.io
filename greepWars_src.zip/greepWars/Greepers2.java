import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Original Author of the greeps: Michael Kolling
 * Reimplemented by Anthony Hoang
 * These Greeps shoot at you and can destroy your rocket. 
 */
public class Greepers2 extends Greepers
{
    private int delay;
    private int numActs;
    public Greepers2()
    {
        super(0);
        setRange(999);
    }
    public void act()
    {
        if (numActs == 0)
        {
            turnToShip();
            numActs++;
        }
        if (delay == 0)
        {
            EB3 b = new EB3(getRotation(), 30, false, this);
            getWorld().addObject(b, getX(), getY());
            
            b.move();
            b.move();
            b.move();
            delay = 30;
        }
        else
        delay--;
    }
}
