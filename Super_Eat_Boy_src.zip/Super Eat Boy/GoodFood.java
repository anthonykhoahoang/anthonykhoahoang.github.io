import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class GoodFood here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class GoodFood  extends ScrollActor
{
    //Fall variables
    private static GreenfootImage fallImg;
    private static double fallSpeedIncrement = 0.2;
    private double fallSpeed = 0.0;
    private boolean isFalling = false;
    
    public GoodFood(int realX, int realY)
    {
        super(realX, realY);
    }
    
    public void act() 
    {
        checkFall();
        super.act();
    }    
    
    public void die()
    {
    }
    private void checkFall()
    {
        int imgHeight = getImage().getHeight();
        int imgWidth = getImage().getWidth();
        isFalling = !isGroundBelow();
        
        if (isFalling)
        {
            fallSpeed += fallSpeedIncrement;
            int oldRealY = getRealY();
            while (!isGroundBelow() && getRealY() - oldRealY < fallSpeed)
                setRealLocation(getRealX(), getRealY() + 1);
        }
        else
        {
            fallSpeed = 0;
        }
    }
    
    private boolean isGroundBelow()
    {
        int imgHeight = getImage().getHeight();
        int imgWidth = getImage().getWidth();
        return getWorld().isBlackAt(getRealX(), getRealY() + imgHeight/2)
        || getWorld().isBlackAt(getRealX() + imgWidth/4, getRealY() + imgHeight/2) 
        || getWorld().isBlackAt(getRealX() - imgWidth/4, getRealY() + imgHeight/2);        
    }
}
