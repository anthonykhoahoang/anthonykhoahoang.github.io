import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.awt.Color;
/**
 * Write a description of class CrouchKey here.
 * 
 * @author Anthony Hoang
 * @version (v1)
 */
public class CrouchKey  extends Keys
{
    public CrouchKey()
    {
        super("s");
    }
    public void act() 
    {
        super.act();
    }    
    public void doChange()
    {
        String key = Greenfoot.getKey();
        if (key!=null)
        {
            getMWorld().crouch = ""+key;
            super.doChange();
            redraw = true;
        }
        else
        if (redraw)
        {
            getImage().clear();
            getImage().setColor(Color.BLUE);
            getImage().drawRect(0,0,getImage().getWidth(),getImage().getHeight());
            getImage().setColor(Color.RED);
            getImage().drawString(getMWorld().crouch, 2, 25);
            redraw = false;
        }
    }
    public void doNoChange()
    {
        if (redraw)
        {
            getImage().clear();
            getImage().setColor(Color.BLUE);
            getImage().drawRect(0,0,getImage().getWidth(),getImage().getHeight());
            getImage().setColor(Color.WHITE);
            getImage().drawString(getMWorld().crouch, 2, 25);   
            redraw = false;
        }
    }
}
