import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class MenuMapLoader here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class MenuMapLoader  extends Menu
{
    private String[] maps;
    private int count;
    private int COUNTLIMIT;
    private int previous;
    public MenuMapLoader()
    {
        getImage().clear();
        COUNTLIMIT = 1000;
        count = 0;
        initialize();
        previous = (int)(Math.random()*maps.length);
    }
    public void act() 
    {
        if (closing)
        {
            getMWorld().removeObject(this);
            return;
        }
        if (count <= 0)
        {
            count = COUNTLIMIT;
            int n = previous;
            while (n == previous)
            n =(int)( Math.random()*maps.length);
            getMWorld().addEventScript(maps[n]);
            previous = n;
        }
        else
        if (count > 0) count--;
    }    
    public void initialize()
    {
        maps = new String[] {"menumaps/a0","menumaps/a1",
            "menumaps/a2","menumaps/a3",
            "menumaps/a4","menumaps/a5",
            "menumaps/a6","menumaps/a7",
            "menumaps/a8","menumaps/a9",
            "menumaps/a10","menumaps/b1",
            "menumaps/b2", "menumaps/b3",
            "menumaps/b4", "menumaps/b5",
            "menumaps/b6", "menumaps/b7",
            "menumaps/b8",};
    }
}
