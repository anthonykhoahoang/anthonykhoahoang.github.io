import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.awt.Color;
import java.awt.Font;

/**
 * Write a description of class Items here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Item extends Actor
{
    private int HEIGHT = 30;
    private int WIDTH = 250;
    private GreenfootImage image;   
    private int amount = 0;
    private String type;
    private boolean isShowTooltip = false;
    private boolean forEnemy = false;
    public Item(String type)
    {
        this.type = type;
        image = new GreenfootImage(WIDTH, HEIGHT);
        image.setColor(new Color(0, 27, 164, 50));
        image.fillRect(0, 0, WIDTH, HEIGHT);
        image.setColor(new Color(55, 88, 255, 50));
        image.fillRect(3, 3, WIDTH-6, HEIGHT-6);
        Font font = new Font("Courier", image.getFont().getStyle(), image.getFont().getSize()) ;
        font = font.deriveFont(15f);
        image.setFont(font);
        image.setColor(Color.WHITE);
        image.drawString(toString(), 15, 20);
        setImage(image);
    }
    public Item(String type, int n, boolean forBad)
    {
        amount = n;
        forEnemy = forBad;
        this.type = type;
        image = new GreenfootImage(WIDTH, HEIGHT);
        image.setColor(new Color(0, 27, 164, 50));
        image.fillRect(0, 0, WIDTH, HEIGHT);
        image.setColor(new Color(55, 88, 255, 50));
        image.fillRect(3, 3, WIDTH-6, HEIGHT-6);
        Font font = new Font("Courier", image.getFont().getStyle(), image.getFont().getSize()) ;
        font = font.deriveFont(15f);
        image.setFont(font);
        image.setColor(Color.WHITE);
        image.drawString(toString(), 15, 20);
        setImage(image);
    }
    public void act() 
    {
        redraw();
    }    
    public void redraw()
    {
        image.clear();
        image.setColor(new Color(0, 27, 164, 50));
        image.fillRect(0, 0, WIDTH, HEIGHT);
        image.setColor(new Color(55, 88, 255, 50));
        image.fillRect(3, 3, WIDTH-6, HEIGHT-6);
        Font font = new Font("Courier", image.getFont().getStyle(), image.getFont().getSize()) ;
        font = font.deriveFont(15f);
        image.setFont(font);
        
        Pointer p = (Pointer)getOneIntersectingObject(Pointer.class);
        Pointer2 p2 = (Pointer2)getOneIntersectingObject(Pointer2.class);
        if (p != null || p2 != null) 
        {
            image.setColor(Color.RED);
            if (!isShowTooltip)
            {
                if (p != null)
                ((Land)getWorld()).addObject(new Tooltip(getType()), p.getX()+90, p.getY()+20);
                else
                ((Land)getWorld()).addObject(new Tooltip(getType()), p2.getX()+90, p2.getY()+20);
                isShowTooltip = true;
            }
            
        }
        else 
        {
            image.setColor(Color.WHITE);
            isShowTooltip = false;
        }
        
        image.drawString(toString(), 15, 20);
        setImage(image);
    }
    public boolean isForEnemy()
    {
        return forEnemy;
    }
    public String getType()
    {
        return type;
    }
    public int getAmount()
    {
        return amount;
    }
    public void setAmount(int n)
    {
        amount = n;
    }
    public String toString()
    {
        return getAmount()+"x " + getType();
    }
    public void useItem(Bad b)
    {
        amount--;
        if (type.equals("Small Thunder Shard") )
        {
            b.addSpark();
            b.hit(20);
        }
        if (type.equals("Small Fire Shard") )
        {
            b.addFire();
            b.hit(20);
        }
        
    }
    public Land getLand()
    {
        return (Land)getWorld();
    }
    public void useItem(Good g)
    {
        amount--;
        if (type.equals("Minor Healing Potion")) 
        {
            int n = (int)(g.getTotalHP()*.10);
            g.heal(n);
        }
        if (type.equals("Healing Potion"))
        {
            int n = (int)(g.getTotalHP()*.15);
            g.heal(n);
        }
        if (type.equals("Potion"))
        {
            int n = (int)(g.getTotalHP()*.20);
            g.heal(n);
        }
    }
    
}
