import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Smoke here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Smoke extends Battle
{
    private GreenfootImage smoke = new GreenfootImage("Battle/smoke.png");
    private int delay = 0;
    public Smoke()
    {
        setImage(smoke);
    }
    public void act() 
    {
        if (delay < 0)
        delay++;
        if (getImage().getWidth() <= 2)
        getLand().removeObject(this);
        else
        {
            getImage().scale(getImage().getWidth()-1, getImage().getHeight()-1);
            setLocation(getX()+1, getY()-1);
        }
        
    }    
}
