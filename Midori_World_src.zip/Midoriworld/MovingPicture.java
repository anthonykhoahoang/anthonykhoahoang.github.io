import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Moving pictures
 * 
 * @author Anthony Hoang
 * @version (v1)
 */
public class MovingPicture  extends InGameObjects
{
    /**
     * Act - do whatever the MovingPicture wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
        // Add your action code here.
    }    
}
