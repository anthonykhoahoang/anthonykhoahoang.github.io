import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * AlienShip releases Greeps and can hurt you if it contacts you.
 * 
 * @author (Anthony Hoang) 
 * @version (2.0)
 */
public class GreepShip2 extends GreepShip
{
    private int totalPassengers;     // Total number of passengers in this ship.
    private int stepCount = 0;
    private int passengersReleased;
    private boolean isLeft = false;
    private int releaseDelay;
    private int delay;
    private int aasDelay = 300;
    
    /**
     * Create a space ship. The parameter specifies at what height to land.
     */
    public GreepShip2(int numGreeps, int life)
    {
        super (life, 100);
        totalPassengers = numGreeps*2;
        releaseDelay = -5;
    }

    /**
     * Let the ship act: move or release greeps.
     */
    public void act()
    {
        if(!isEmpty() && releaseDelay >= 0) 
            releasePassenger();
            else 
            releaseDelay++;
            if (isLeft)
            {
                moveLeft();
                if (delay == 10)
                {
                    isLeft = false;
                    delay = 0;
                }
            }
            else
            {
                moveRight();
                if (delay == 10)
                {
                    isLeft = true;
                    delay = 0;
                }
            }
            delay++;
            aasDelay--;
            if (aasDelay <= 0)
            {
                AAS();
                aasDelay = 400;
            }
            if (atLeftEdge()) isLeft = false;
            if (atRightEdge()) isLeft = true;
            /*
            if (randomChance(2))
            turn(10);
            */
    }
    public void AAS()
    {
        for (int i = 0; i < 360; i++)
        {
            EB2 b = new EB2(getRotation(), 100, false, this);
            getWorld().addObject(b, getX(), getY());
            b.move();
            setRotation(getRotation() + 20);
        }
        Greenfoot.playSound("aas.wav");
    }
    /**
     * True if all passengers are out.
     */
    public boolean isEmpty()
    {
        return passengersReleased == totalPassengers;
    }
    
    /**
     * Possibly: Let one of the passengers out. Passengers appear at intervals, 
     * so this may or may not release the passenger.
     */
    private void releasePassenger()
    {
        if(passengersReleased < totalPassengers) 
        {
            stepCount++;
            if(stepCount == 10) 
            {
                getSpace().addObject(new EB4_2(90, true), getX(), getY() + 30);
                passengersReleased++;
                stepCount = 0;
            }
        }
    }
}