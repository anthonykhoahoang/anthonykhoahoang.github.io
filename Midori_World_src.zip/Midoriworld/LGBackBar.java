import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class LGBackBar here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class LGBackBar  extends LogicGate
{
    public LGBackBar()
    {
        setImage(new GreenfootImage("bar.png"));
    }
    public void act() 
    {
        // Add your action code here.
    }    
}
