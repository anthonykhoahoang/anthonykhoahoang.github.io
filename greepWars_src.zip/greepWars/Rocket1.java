import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class rocket1 here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Rocket1 extends Rocket
{
    public Rocket1()
    {
        super();
    }
    public void act() 
    {
        if (! isDead)
        {
            if (!getSpace().isEasy())
            move();
            if (getShieldLevel() < 0)
            upgrades[1] = 0;
            gunFireDelay++;
            checkKeys();
            if (getInvincible() > 0)
            {
                if (getInvincible()%2 == 0)
                checkShields();
                else
                setImage(new GreenfootImage(1,1));
                setInvincible(getInvincible()-1);
            }
            else
            checkCollision();
        }
        else setImage(new GreenfootImage(1,1));
    }    
     private void checkKeys()
    {
        
        if (Greenfoot.isKeyDown("t") && Greenfoot.isKeyDown("h")&& Greenfoot.isKeyDown("o") )
        {
            if (aasDelay == 0)
            {
                activateCheatCode();
                aasDelay = 30;
            }
        }
        if(Greenfoot.isKeyDown("up"))
            ignite(true);
        else
            reverse(Greenfoot.isKeyDown("down"));
        if(Greenfoot.isKeyDown("left"))
            setRotation(getRotation() - 5);
        if(Greenfoot.isKeyDown("right"))
            setRotation(getRotation() + 5);
        if(Greenfoot.isKeyDown("n"))
            fire();
        if (Greenfoot.isKeyDown("b") && !getSpace().isEasy() )
            stop();
        if(Greenfoot.isKeyDown(".") && missleDelay == 0)
        {
            shootMissle();
            missleDelay = 5;
        }
        if(Greenfoot.isKeyDown("m") && aasDelay == 0)
        {
            fireAAS();
            aasDelay = 30;
        }
        if(Greenfoot.isKeyDown(",") && empDelay == 0)
        {
            fireEMP();
            empDelay = 20;
        }
        if (getSpace().getGameLevel() >= 20)
        if (Greenfoot.isKeyDown("j"))
        {
            chargeEnergyShot();
        }
        else
        {
            if (upgrades[9] != 0)
            shootEnergyShot();
        }
        if (Greenfoot.isKeyDown("k")&& getSpace().getGameLevel() >= 25) fireFlameThrower();
        if(Greenfoot.isKeyDown("/"))
            shootMG();
            
            
        if(aasDelay > 0)
            aasDelay--;
        if(empDelay > 0)
            empDelay--;
        if(missleDelay > 0)
            missleDelay--;
    }

}
