import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.awt.Color;
/**
 * Write a description of class FallPlatform here.
 * 
 * @author Anthony Hoang
 * @version v1
 */
public class FallPlatform  extends Platform
{
    private int count;
    private int threshold=30;
    private boolean firstInitialize = true;
    private int y1;
    private int speed = 5;
    private boolean willFall = false;
    public FallPlatform()
    {
        super();
        setImage(new GreenfootImage(platform2));
    }
    public FallPlatform(int thres, int width)
    {
        this();
        getImage().scale(width, getImage().getHeight());
        threshold = thres;
    }
    public void act() 
    {
        if (getMWorld().esPause) return;
        if (firstInitialize)
        {
            y1 = getY();
            firstInitialize = false;
        }
        if (isAbove())
        {
            willFall = true;
            moveChar();
        }
        if (willFall) count++;
        if (count > threshold)
        fall();
        else if (getY() != y1)
        {
            goBackToStart();
        }
        
    }    
    public void fall()
    {
        if (!blackBetweenY(getY()+getImage().getHeight()/2+speed))
            setLocation(getX(), getY()+speed);
        else 
        {
            count = 0; 
            willFall = false;
            Greenfoot.playSound("platformhit.wav");
        }
    }
    public void goBackToStart()
    {
            setLocation(getX(), getY()-1);
    }
    public void moveChar()
    {
        Actor a = getOneIntersectingObject(InGameCharacter.class);
        if (a != null) 
        {
            a.setLocation(a.getX(), getY()-getImage().getHeight()/2-a.getImage().getHeight()/2);
        }
    }
}
