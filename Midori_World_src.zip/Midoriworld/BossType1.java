import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class BossType1 here.
 * 
 * @author Anthony Hoang
 * @version (v1)
 */
public class BossType1  extends Boss
{
    private double downDelayMax;
    private double downDelay;
    private double rechargeRate;
    private boolean firstInitialize = true;
    public BossType1(int hp, String file, double down, double recharge)
    {
        super(hp,file);
        downDelayMax = down;
        downDelay = down;
        rechargeRate = recharge;
        isPaused = true;
        setImage("bosses/bosstype1.png");
        getImage().setTransparency(0);
    }
    public void act() 
    {
        if (getMWorld().esPause) return;
        if (firstInitialize)
        {
            if (getImage().getTransparency() == 0)
            getMWorld().addObject(new BossEnergy(),855,247);
            int t = getImage().getTransparency()+10;
            if (t > 230) 
            firstInitialize = false;
            else
            getImage().setTransparency(t);
            
        }
        checkDownDelay();
        super.act();
    }    
    public double getRechargeRate()
    {
        return rechargeRate;
    }
    public double getDownDelay()
    {
        return downDelay;
    }
    public double getDownDelayMax()
    {
        return downDelayMax;
    }
    public void checkDownDelay()
    {
        if (downDelay >= downDelayMax && isPaused)
        isPaused = false;
        else if (downDelay > 0 && !isPaused)
        downDelay--;
        if (downDelay <= 0 && !isPaused)
        isPaused = true;
        if (isPaused && downDelay < downDelayMax)
        downDelay+=rechargeRate;
    }
    public void moveTo()
    {
        super.moveTo();
        for (int i = 0; i < 2; i++)
        {
            getMWorld().addObject(new SmokeParticle((int)(Math.random()*360)),getX(),getY());
        }
    }
}
