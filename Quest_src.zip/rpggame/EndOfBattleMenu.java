import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.awt.Color;
import java.awt.Font;

/**
 * Write a description of class EndOfBattleMenu here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class EndOfBattleMenu extends Actor
{
    private int HEIGHT = 500;
    private int WIDTH = 724;
    private GreenfootImage SkyePic = new GreenfootImage("skyepic.jpg");
    private GreenfootImage image;
    private String name = "";
    private int level=1;
    private String exp ="";
    public EndOfBattleMenu()
    {
    }
    public EndOfBattleMenu(String skye, int level, String exp)
    {
        name = skye;
        this.level = level;
        this.exp = exp;
        image = new GreenfootImage(WIDTH, HEIGHT);
        image.setColor(new Color(0, 27, 164, 50));
        image.fillRect(0, 0, WIDTH, HEIGHT);
        image.setColor(new Color(55, 88, 255, 50));
        image.fillRect(3, 3, WIDTH-6, HEIGHT-6);
        Font font = new Font("Courier", image.getFont().getStyle(), image.getFont().getSize()) ;
        font = font.deriveFont(20f);
        image.setFont(font);
        image.setColor(Color.WHITE);
        image.drawString(exp, 400, 50);
        loadSkye();
        setImage(image);
    }
    public void act() 
    {
        
    }    
    public void loadSkye()
    {
        SkyePic.scale (SkyePic.getWidth()+10, SkyePic.getHeight()+10);
        String l = "Level "+level;
        image.drawString(name, 450, 85);
        image.drawString(l, 450, 105);
        image.drawImage(SkyePic, 400, 70);
    }
    public Land getLand()
    {
        return (Land)getWorld();
    }
}
