import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.awt.Color;
import java.awt.Font;
/**
 * Write a description of class Title here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Title extends Menu
{
    public static final float FONT_SIZE = 45.0f;
    public static final int WIDTH = 100;
    public static final int HEIGHT = 50;
    private GreenfootImage image = new GreenfootImage("title.png");
    public Title()
    {
        image.scale(500,300);
        setImage(image);
    }
    public void act() 
    {
    }    
}
