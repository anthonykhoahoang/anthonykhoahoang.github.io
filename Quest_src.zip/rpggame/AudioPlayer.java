import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import javax.sound.midi.*;
import java.net.URL;
import java.net.MalformedURLException;
import java.io.IOException;
import java.io.InputStream;
/**
 * Write a description of class AudioPlayer here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class AudioPlayer extends Actor
{
    private Sequencer sequencer;
    private String file;
    private int numActs = 0;
    private boolean isOn;
    private boolean repeat;
    public AudioPlayer(String fileName, boolean r)
    {
        setImage(new GreenfootImage(1,1));
        file = "music/"+fileName+".mid";
        load(file, true);
        repeat = r;
    }
    public void act() 
    {
        if (sequencer.getTickPosition() == sequencer.getTickLength())
        {
            if(repeat)
            {
                sequencer.setTickPosition(0);
                sequencer.start();
            }
            else close();
        }
    }    
    public void close()
    {
        sequencer.stop();
        //( (Land)getWorld()).removeObject(this);
    }
    public void play()
    {
        sequencer.start();
    }
    public void stop()
    {
        sequencer.stop();
    }
    public void load(String fileName, boolean loop)
    {
        try 
        {
            URL url = getClass().getClassLoader().getResource(fileName);
            if(url == null)
            throw new IOException("File not found: " + fileName);
            Sequence sequence = MidiSystem.getSequence(url);
            
            // Create a sequencer for the sequence
            sequencer = MidiSystem.getSequencer();
            sequencer.open();
            sequencer.setSequence(sequence);
           // play();
        } 
        catch (MalformedURLException e) {
        } catch (IOException e) {
        } catch (MidiUnavailableException e) {
         } catch (InvalidMidiDataException e) {
            } 
    }

}

