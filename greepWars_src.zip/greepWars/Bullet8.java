import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Bullet8 - level 8 of the bullet the rocket can shoot.
 * 
 * @author (Anthony Hoang) 
 * @version (2.0)
 */
public class Bullet8 extends Bullet
{
   public Bullet8 (Vector speed, int rotation, int dmg, boolean sounds, Rocket rocket)
    {
        super(speed, rotation, dmg+40, false, rocket);
        if (sounds)
        Greenfoot.playSound("bullet8.wav");
    }
    public void act() 
    {
        super.act();
    }    
}
