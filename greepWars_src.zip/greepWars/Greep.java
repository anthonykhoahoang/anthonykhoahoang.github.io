import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Greep here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Greep extends Enemy2
{
    public Greep()
    {
        super(10, 5);
        setRotation(90);
    }
    public void act() 
    {
        move();
    }    
}
