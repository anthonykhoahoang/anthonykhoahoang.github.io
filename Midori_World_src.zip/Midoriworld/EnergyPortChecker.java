import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.util.List;
/**
 * checks if all energy ports are powered up
 * if they are, add evencount
 * 
 * @author Anthony Hoang
 * @version (v1)
 */
public class EnergyPortChecker  extends EnergyPort
{
    private boolean isDone = false;
    public EnergyPortChecker()
    {
        getImage().clear();
    }
    public void act() 
    {
        if (getMWorld().gamePause) return;
        if (allPortsPoweredUp() && !isDone)
        {
            isDone = true;
            getMWorld().eventCount++;
        }
    }    
    public boolean allPortsPoweredUp()
    {
        List<EnergyInPort> list = getMWorld().getObjects(EnergyInPort.class);
        if (list.size() == 0) return false;
        for(EnergyInPort e : list)
            if (!e.hasHadEnergy())
            return false;
        return true;
    }
}
