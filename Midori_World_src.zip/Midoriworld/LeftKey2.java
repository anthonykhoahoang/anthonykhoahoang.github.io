import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.awt.Color;
/**
 * Write a description of class LeftKey2 here.
 * 
 * @author Anthony Hoang
 * @version (v1)
 */
public class LeftKey2  extends Keys
{
    public LeftKey2()
    {
        super("left");
    }
    public void act() 
    {
        super.act();
    }    
    public void doChange()
    {
        String key = Greenfoot.getKey();
        if (key!=null)
        {
            getMWorld().left2 = ""+key;
            super.doChange();
            redraw = true;
        }
        else
        if (redraw)
        {
            getImage().clear();
            getImage().setColor(Color.BLUE);
            getImage().drawRect(0,0,getImage().getWidth(),getImage().getHeight());
            getImage().setColor(Color.RED);
            getImage().drawString(getMWorld().left2, 2, 25);
            redraw = false;
        }
    }
    public void doNoChange()
    {
        if (redraw)
        {
            getImage().clear();
            getImage().setColor(Color.BLUE);
            getImage().drawRect(0,0,getImage().getWidth(),getImage().getHeight());
            getImage().setColor(Color.WHITE);
            getImage().drawString(getMWorld().left2, 2, 25);   
            redraw = false;
        }
    }
}
