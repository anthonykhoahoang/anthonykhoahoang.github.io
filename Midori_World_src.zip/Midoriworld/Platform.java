import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Platform here.
 * 
 * @author Anthony Hoang
 * @version (v1)
 */
public class Platform  extends InGameObjects
{
    public static GreenfootImage platform1;
    public static GreenfootImage platform2;
    
    public Platform()
    {
        initialize();
    }
    public void initialize()
    {
        if (platform1 == null)
        platform1 = new GreenfootImage("platform1.png");
        if (platform2 == null)
        platform2 = new GreenfootImage("platform2.png");
    }
    public void act() 
    {
    }
    public boolean isAbove()
    {
        Actor a = getOneIntersectingObject(InGameCharacter.class);
        if (a != null) 
        {
            int w = a.getImage().getWidth()/2;
            int h = a.getImage().getHeight()/2;
            int thisW = getImage().getWidth()/2;
            if (a.getY()+h-8 <= getY()-getImage().getHeight()/2
            && a.getX() <= getX()+thisW
            && a.getX() >= getX()-thisW)
            {
                return true;
            }
        }
        return false;
    }
    public boolean blackBetweenX(int x2)
    {
        int x1 = getX();
        if (x1 < x2)
        return blackBetweenXRight(x2);
        return blackBetweenXLeft(x2);
    }
    public boolean blackBetweenXRight(int x2)
    {
        int x1 = getX()+getImage().getWidth()/2;
        int y1 = getY();
        while (x1 < x2)
        {
            if (isBlackAt(x1, y1))
            return true;
            x1++;
        }
        return false;
    }
    public boolean blackBetweenXLeft(int x2)
    {
        int x1 = getX()-getImage().getWidth()/2;
        int y1 = getY();
        while (x1 > x2)
        {
            if (isBlackAt(x1, y1))
            return true;
            x1--;
        }
        return false;
    }
    public boolean blackBetweenY( int y2)
    {
        int y1 = getY();
        if (y1 < y2)
        return blackBetweenYDown(y2);
        return blackBetweenYUp(y2);
    }
    public boolean blackBetweenYDown(int y2)
    {
        int y1 = getY();
        while (y1 < y2)
        {
            if (isBlackAt(getX(),y1))
            return true;
            y1++;
        }
        return false;
    }
    public boolean blackBetweenYUp(int y2)
    {
        int y1 = getY();
        while (y1 > y2)
        {
            if (isBlackAt(getX(),y1))
            return true;
            y1--;
        }
        return false;
    }
    public void moveX(int dX2)
    {
        int dX = getX();
        int width = getImage().getWidth()/2;
        int dY = getY();
        if (dX > dX2)//moveleft
        while (dX > dX2 && !isBlackAt(dX-width, dY))
        {
            dX--;
        }
        else//moveright
        while (dX < dX2 && !isBlackAt(dX+width, dY))
        {
            dX++;
        }
        setLocation(dX, dY);
    }
}
