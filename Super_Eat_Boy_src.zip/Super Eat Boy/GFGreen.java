import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.util.List;
/**
 * Write a description of class GFGreens here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class GFGreen  extends GoodFood
{
    private static GreenfootImage img;
    
    public GFGreen(int realX, int realY)
    {
        super(realX, realY);
        if (img == null)
            img = new GreenfootImage("images/goodfood/brocolli.png");
        setImage(img);
    }
    public void act() 
    {
        super.act();
    }   
    public void die()
    {
        List<Hud> listHud = getWorld().getObjects(Hud.class);
        for (Hud h : listHud)
            h.setVeggie(1 + h.getVeggie());
        getWorld().removeObject(this);
    } 
}
