import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class SkyeImage here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class SkyeImage extends Keyboard
{
    
    public SkyeImage()
    {
        getImage().scale(getImage().getWidth()+20, getImage().getHeight()+20);
    }
    public void act() 
    {
        // Add your action code here.
    }    
}
