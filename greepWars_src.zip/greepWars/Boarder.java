import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.awt.Color;

/**
 * Write a description of class Boarder here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Boarder extends Misc
{
    
    public Boarder(int w)
    {
        GreenfootImage a = new GreenfootImage(w, 615);
        a.setColor(Color.BLACK);
        a.fill();
        setImage(a);
    }
    public void act() 
    {
        // Add your action code here.
    }    
}
