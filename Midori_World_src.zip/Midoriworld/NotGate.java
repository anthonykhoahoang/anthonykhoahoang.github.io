import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class NotGate here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class NotGate  extends LGGates
{
    private static GreenfootImage img;
    public NotGate()
    {
        super("NOT");
        if (img == null)
        img = new GreenfootImage("logicgates/not.png");
        setImage(img);
    }
    public void act() 
    {
        super.act();
    }    
}
