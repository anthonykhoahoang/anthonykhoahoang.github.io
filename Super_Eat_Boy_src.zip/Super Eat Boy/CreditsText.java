import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class CreditsText here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class CreditsText  extends Menu
{
    private boolean firstInitialize = true;
    
    public CreditsText()
    {
        setImage(new GreenfootImage("credits.png"));
        getImage().setTransparency(0);
    }
    public void act() 
    {
        if (firstInitialize)
        {
            int t = getImage().getTransparency()+5;
            if (t > 230)
            firstInitialize = false;
            else
            getImage().setTransparency(t);
        }
        if (closing)
        {
            int t = getImage().getTransparency()-10;
            if (t < 0)
            getWorld().removeObject(this);
            else
            getImage().setTransparency(t);
            return;
        }
    }    
}
