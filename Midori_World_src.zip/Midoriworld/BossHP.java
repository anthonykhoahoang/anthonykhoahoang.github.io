import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.awt.Color;
import java.awt.Font;
/**
 * Display current health of boss
 * 
 * @author Anthony Hoang
 * @version (v1)
 */
public class BossHP  extends BossCounter
{
    private int tHealth = 0;
    private GreenfootImage image;
    private boolean firstInitialize = true;
    private int delay = 2;
    public BossHP()
    {
        image = new GreenfootImage(15, 400);
        getImage().clear();
    }
    public void act() 
    {
        if (getMWorld().gamePause) return;
        if (firstInitialize)
        {
            firstInitialize = false;
            Font font = image.getFont();
            font = font.deriveFont(11f);
            image.setColor(Color.WHITE);
            image.drawString("HP", 5, 100);
            setImage(image);
        }
        updateHP();
    }    
    public void updateHP()
    {
        if (getBoss() == null) return;
        double percent = (double)getBoss().getHP()/(double)getBoss().getHPMax();
        int hp = (int)(getImage().getHeight()*percent);
        if (hp == tHealth) return;
        if (hp > tHealth)
        tHealth += 2;
        else if (hp < tHealth)
        tHealth -= 2;
        image.clear();
        image.setColor(new Color(50,105,250,210));
        image.fillRect(0,400-tHealth,20,400);
        Font font = image.getFont();
        font = font.deriveFont(11f);
        image.setFont(font);
        image.setColor(Color.WHITE);
        image.drawString("HP", 2, 200);
        setImage(image);
    }
}
