import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class HoloMap here.
 * 
 * @author Anthony Hoang
 * @version (v1)
 */
public class HoloMap  extends PhoneHolos
{
    private GreenfootImage image;
    private int curAction = 0;
    public HoloMap()
    {
        image = new GreenfootImage("map.png");
        image.scale(587, 329);
        setImage(new GreenfootImage(image));
        getImage().scale(getImage().getWidth()/2,getImage().getHeight()/2);
        getImage().setTransparency(0);
    }
    public void act() 
    {
        if (getMWorld().gamePause) return;
        if (curAction == 0)
        {
            int t = getImage().getTransparency()+5;
            int w = getImage().getWidth()+15;
            int h = getImage().getHeight()+15;
            if (t > 254 || w > image.getWidth() || h > image.getHeight())
            curAction++;
            else
            {
                getImage().scale(w,h);
                getImage().setTransparency(t);
            }
        }
        if (curAction == 1)
        {
            image.setTransparency(150);
            setImage(image);
            curAction++;
        }
        super.act();
    }    
}
