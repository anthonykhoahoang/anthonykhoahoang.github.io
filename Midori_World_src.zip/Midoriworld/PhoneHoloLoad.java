import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.awt.Color;
import java.awt.Font;
/**
 * Write a description of class PhoneHoloLoad here.
 * 
 * @author Anthony Hoang
 * @version (v1)
 */
public class PhoneHoloLoad  extends PhoneHolos
{
    private GreenfootImage image;
    private int curAction = 0;
    private int barWidth = 1;
    private int curText = 0;
    private int delay = 5;
    private int actCount = 0;
    public PhoneHoloLoad()
    {
        image = new GreenfootImage(200,200);
        image.setTransparency(200);
        setImage(image);
    }
    public void act() 
    {
        if (getMWorld().gamePause) return;
        if (remove)
        super.act();
        else
        if (curAction == 0)
        {
            image.clear();
            image.setColor(new Color(50,25,150,150));
            image.fillRect(0,100,barWidth,50);
            Font font = image.getFont();
            font = font.deriveFont(16f);
            image.setFont(font);
            image.setColor(Color.WHITE);
            if (curText == 0)
            {
                image.drawString("Rendering hologram....", 0, 80);
                if (actCount > delay)
                {
                    curText++;
                    actCount = 0;
                }
                else actCount++;
            }
            else if (curText == 1)
            {
                image.drawString("Rendering hologram...", 0, 80);
                if (actCount > delay)
                {
                    curText++;
                    actCount = 0;
                }
                else actCount++;
            }
            else if (curText == 2)
            {
                image.drawString("Rendering hologram..", 0, 80);
                if (actCount > delay)
                {
                    curText++;
                    actCount = 0;
                }
                else actCount++;
            }
            else if (curText == 3)
            {
                image.drawString("Rendering hologram.", 0, 80);
                if (actCount > delay)
                {
                    curText=0;
                    actCount = 0;
                }
                else actCount++;
            }
            image.drawString(""+(barWidth/2)+"%", 80, 130);
            barWidth++;
            if (barWidth > 200)
            curAction = 1;
        }
        else if (curAction == 1)
        {
            image.clear();
            image.setColor(new Color(50,25,150,150));
            image.fillRect(0,100,barWidth,50);
            Font font = image.getFont();
            font = font.deriveFont(16f);
            image.setFont(font);
            image.setColor(Color.WHITE);
            image.drawString("Rendering Complete!", 0, 80);
            curAction++;
            actCount = 0;
        }
        else if (curAction == 2)
        {
            if (actCount > delay)
            {
                curAction = 3;
            }
            else actCount++;
        }
        else if (curAction == 3)
        {
            int w = getImage().getWidth()-20;
            int h = getImage().getHeight()-20;
            if (w <= 0 || h <= 0)
            getMWorld().removeObject(this);
            else
            getImage().scale(w,h);
        }
    }    
}
