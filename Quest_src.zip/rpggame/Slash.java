import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Slash here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Slash extends Battle
{
    private GreenfootImage slash = new GreenfootImage("Battle/Slash.png");
    public Slash()
    {
        setImage(slash);
    }
    public void act() 
    {
        if (getImage().getWidth() <= 10 || getImage().getHeight() <= 10)
        getLand().removeObject(this);
        else
        getImage().scale(getImage().getWidth()-10, getImage().getHeight()-10);
    }    
}
