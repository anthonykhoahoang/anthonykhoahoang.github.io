import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.awt.Color;
/**
 * Write a description of class FoodBar here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class FoodBar  extends HudObject
{
    private static GreenfootImage bar;
    private double percent = 0.0;
    private Color color;
    private String sColor;
    
    public FoodBar(String color, int rotation)
    {
        sColor = color;
        if (bar == null)
            bar = new GreenfootImage("images/hud/foodbartemplate.png");
        //setImage(new GreenfootImage(bar));
        if (color.equals("Red"))
            this.color = Color.RED;
        else if (color.equals("Green"))
            this.color = Color.GREEN;
        else
            this.color = Color.BLUE;
        fill();
        setRotation(rotation);
    }
    
    public void act() 
    {
        // Add your action code here.
    }    
    
    public void fill()
    {
        double height = bar.getHeight()*percent;
        int iWidth = bar.getWidth();
        GreenfootImage image = new GreenfootImage(bar);
        image.clear();
        for (int y = 0; y < height; y++)
        {
            for (int x = 0; x < iWidth; x++)
            {
                if (bar.getColorAt(x, y).equals(Color.GREEN))
                    image.setColorAt(x, y, color);
            }
        }
        setImage(image);
    }
    
    public void setPercent(double percent)
    {
        this.percent = percent;
        if (this.percent > 1.0)
            this.percent = 1.0;
    }
    
    public String getColor()
    {
        return sColor;
    }
}
