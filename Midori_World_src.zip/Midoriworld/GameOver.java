import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class GameOver here.
 * 
 * @author Anthony Hoang
 * @version (v1)
 */
public class GameOver  extends Title
{
    
    public GameOver()
    {
        setImage(new GreenfootImage("gameover.png"));
    }
    public void act() 
    {
        super.act();
        if (Greenfoot.mouseClicked(this))
        getMWorld().eventCount = 1;
    }    
}
