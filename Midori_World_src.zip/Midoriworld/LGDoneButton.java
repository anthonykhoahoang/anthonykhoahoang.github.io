import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.awt.Color;
import java.awt.Font;
import java.util.List;
/**
 * Write a description of class NewAccountMenu here.
 * 
 * @author Anthony Hoang
 * @version (v1)
 */
public class LGDoneButton extends LogicGate
{
    private int WIDTH = 100;
    private int HEIGHT= 50;
    private GreenfootImage image;
    private GreenfootImage image2;
    private boolean firstInitialize = true;
    private boolean isOn = false;
    public LGDoneButton()
    {
        image = new GreenfootImage(WIDTH, HEIGHT);
        image2 = new GreenfootImage(WIDTH, HEIGHT);
        drawOne();
        image.setTransparency(0);
        image2.setTransparency(0);
        setImage(image2);
    }
    public void act() 
    {
        if (getMWorld().esPause) return;
        if (firstInitialize)
        {
            int t = getImage().getTransparency()+5;
            if (t > 255)
            firstInitialize = false;
            else
            {
                image.setTransparency(t);
                image2.setTransparency(t);
            }
        }
        if (mouseOverThis() )
        {
            if (getImage().equals(image2))
            setImage(image);
        }
        else 
        if (getImage().equals(image))
        setImage(image2);
        if (Greenfoot.mouseClicked(this))
        {
            List<LGFiller> list = getMWorld().getObjects(LGFiller.class);
            for (LGFiller lg : list)
            lg.rapidFill();
        }
    }    
    public void drawOne()
    {
        image.setColor(Color.GRAY);
        image.fill();
        image.setColor(new Color(5, 5, 75 ,150));
        image.fillRect(5, 5, WIDTH-10, HEIGHT-10);
        Font font = image.getFont();
        font = font.deriveFont(25f);
        image.setFont(font);
        image.setColor(Color.WHITE);
        image.drawString("Done", 19, 32);
        image2.setColor(new Color(5, 5, 50 ,150));
        image2.fillRect(5, 5, WIDTH-10, HEIGHT-10);
        font = image.getFont();
        font = font.deriveFont(25f);
        image2.setFont(font);
        image2.setColor(Color.WHITE);
        image2.drawString("Done", 19, 32);
    }
    public boolean mouseOverThis()
    {
        MouseInfo m = Greenfoot.getMouseInfo();
        if (m == null)
        {
            if (isOn) return true;
            return false;
        }
        else
        {
            Actor actor = m.getActor();
            
            if (actor != null && actor.equals(this))
            {
                isOn = true;
                return true;
            }
            else
            {
                isOn = false;
                return false;
            }
        }
    }
}
