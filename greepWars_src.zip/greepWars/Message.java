import greenfoot.*;  // (World, Actor, GreenfootImage, and Greenfoot)
import java.awt.Color;
import java.awt.Font;
import java.io.BufferedReader;
import java.io.IOException; 
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URL;
/**
 * Reads an input text file 
 * @author Anthony Hoang
 * @version 2.1
 */
public class Message extends Actor
{
    private static final float FONT_SIZE = 12.0f;
    private static final int WIDTH = 600;
    private static final int HEIGHT = 500;

    private int acts = 0;
    private GreenfootImage image;
    private boolean autoClose= false;

    public Message(String text)
    {
        image = new GreenfootImage(WIDTH, HEIGHT);
        image.setColor(new Color(255,255,255, 128));
        image.fillRect(0, 0, WIDTH, HEIGHT);
        image.setColor(new Color(0, 0, 0, 128));
        image.fillRect(5, 5, WIDTH-10, HEIGHT-10);
        Font font = image.getFont();
        font = font.deriveFont(FONT_SIZE);
        image.setFont(font);
        image.setColor(Color.WHITE);
        if (text.equals("preGame") )
        showDifficulty();
        else
        showTextFile("textFiles/"+text + ".txt");
    }
    public Message(String text, boolean b)
    {
        this(text);
        autoClose = b;
    }
    public void act()
    {
        if (autoClose && acts == 1) 
        ((Space)getWorld()).removeObject(this);
        if (acts < 1 )acts++;
    }
    public InputStream openFile(String fileName) throws IOException
    {
        URL url = getClass().getClassLoader().getResource(fileName);
        if(url == null)
        throw new IOException("File not found: " + fileName);
        return url.openStream();
    } 
    private void showDifficulty()
    {
        GreenfootImage image = new GreenfootImage(250, 200);
        image.setColor(new Color(255,255,255, 128));
        image.fillRect(0, 0, 250, 200);
        image.setColor(new Color(0, 0, 0, 128));
        image.fillRect(5, 5, 250-10, 200-10);
        Font font = image.getFont();
        font = font.deriveFont(FONT_SIZE);
        image.setFont(font);
        image.setColor(Color.WHITE);
        
        image.drawString("Easy - No Drift", 40, 40);
        image.drawString("Medium - Drift ", 40, 60);
        image.drawString("Hard - Drift + stronger enemies", 40, 80);
        image.drawString("------", 100, 100);
        image.drawString("Level loader lets you jump to", 40, 120);
        image.drawString("a level with the correct code", 40, 140);
        image.drawString("------", 100, 160);
        setImage(image);
    }
    public void showTextFile(String textFileName)
    {
        int height = 40;
        StringBuffer sb = new StringBuffer();
        try{
            InputStream is = openFile(textFileName);
             BufferedReader d = new BufferedReader(new InputStreamReader(is));
            String line = d.readLine();
            while(line != null)
            {
                image.drawString(line, 40, height);
                height+= 20;
                line = d.readLine();
            }
        }
        catch(Exception ex){
            return;}
        setImage(image);
    } 
}