import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.util.List;
/**
 * Write a description of class MidoCharacter here.
 * 
 * @author Anthony Hoang
 * @version (v1)
 */
public class MidoCharacter  extends Character
{
    public MidoCharacter()
    {
        setImage(new GreenfootImage("mido/mido.png"));
    }
    public void act() 
    {
        super.act();
    }   
    public void blinkEyes()
    {
        List<MidoEyes> listEyes = getMWorld().getObjects(MidoEyes.class);
        if (listEyes.size() == 0 ) return;
        MidoEyes eyes = listEyes.get(0);
        eyesBlinkCount--;
        if (eyesBlinkCount == 0)
        {
            eyes.readyToBlink();
            eyesBlinkCount = 200 + ((int)Math.random()*5)*100;
        }
    } 
    public void placeMouthEyes()
    {
        List<MidoEyes> listEyes = getMWorld().getObjects(MidoEyes.class);
        List<MidoMouth> listMouth = getMWorld().getObjects(MidoMouth.class);
        if (listEyes.size() == 0 || listMouth.size() == 0) return;
        
        MidoEyes eyes = listEyes.get(0);
        MidoMouth mouth = listMouth.get(0);
        
        if (mouth.getY() != getY()-91)
        mouth.setLocation(getX(), getY()-91);
        
        if (eyes.getX() != getX()-1 && eyes.getY() != getY()-128)
        eyes.setLocation(getX()-1, getY()-128);
    }
}
