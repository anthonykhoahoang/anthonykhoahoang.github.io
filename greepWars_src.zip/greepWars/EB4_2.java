import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class EB4_2 here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class EB4_2 extends EB4
{
    
    public EB4_2 (int rot, boolean sounds)
    {
        super(rot, 9999, sounds, null);
    }
    public void act() 
    {
        if (atWorldEdge2())
        getWorld().removeObject(this);
        else
        move();
    }    
}
