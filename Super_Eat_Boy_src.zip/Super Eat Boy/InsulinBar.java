import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.awt.Color;
/**
 * Write a description of class InsulinBar here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class InsulinBar  extends HudObject
{
    private int percent = 50;
    private GreenfootImage bar = new GreenfootImage("images/hud/insulinbar.png");
    
    public InsulinBar()
    {
        fill();
    }
    
    public void act() 
    {
        // Add your action code here.
    }    
    
    public void fill()
    {
        int curW = bar.getWidth();
        double width = bar.getWidth()*percent/100.0;
        int height = bar.getHeight();
        GreenfootImage image = new GreenfootImage(bar);
        for (int x = (int)width; x < curW; x++)
            for (int y = 0; y < height; y++)
                image.setColorAt(x, y, new Color(0,0,0,0));
        setImage(image);
    }
    
    public void setPercent(int percent)
    {
        this.percent = percent;
    }
}
