import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
/**
 * Write a description of class LeftRightPlatform here.
 * 
 * @author Anthony Hoang 
 * @version 1
 */
public class LeftRightPlatform  extends Platform
{
    private boolean left = true;
    private int speed;
    private boolean charWasAbove = false;
    private int prevX = 0;
    public LeftRightPlatform() //default
    {
        super();
        setImage(new GreenfootImage(platform1));
        speed = 1;
    }
    public LeftRightPlatform(int s, int width)
    {
        this();
        getImage().scale(width, getImage().getHeight());
        speed = s;
    }
    public void act() 
    {
        if (getMWorld().esPause) return;
        charWasAbove = isAbove();
        prevX = getX();
        move();
        if (charWasAbove)
        moveChar();
    }    
    public void move()
    {
        if (left)
        {
            if (!blackBetweenX(getX()+getImage().getWidth()/2+speed))
            moveX(getX()+speed);
            else
            {
                left = false;
                Greenfoot.playSound("platformhit.wav");
            }
        }
        else
        {
            if (!blackBetweenX(getX()-getImage().getWidth()/2-speed))
            moveX(getX()-speed);
            else
            {
                left = true;
                Greenfoot.playSound("platformhit.wav");
            }
        }
    }
    public void moveChar()
    {
        Actor a = getOneIntersectingObject(InGameCharacter.class);
        if (a != null) 
        {
            int xa = a.getX()-prevX;
            a.setLocation( getX()+xa, getY()-getImage().getHeight()/2-a.getImage().getHeight()/2);
        }
    }
}
