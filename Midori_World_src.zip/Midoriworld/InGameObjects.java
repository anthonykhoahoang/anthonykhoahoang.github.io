import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class InGameObjects here.
 * 
 * @author Anthony Hoang
 * @version (v1)
 */
public class InGameObjects  extends Actor
{
    public void act() 
    {
    }    
    
    public boolean isBlackAt(int x, int y)
    {
        return getMWorld().isBlackAt(x,y);
    }
    public boolean isGreenAt(int x, int y)
    {
        return getMWorld().isGreenAt(x,y);
    }
    public Midori getMWorld()
    {
        return (Midori) getWorld();
    }
}
