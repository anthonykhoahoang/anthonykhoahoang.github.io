import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class DeadHit here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class GreepBlood extends Misc
{
    private static GreenfootImage[] images = new GreenfootImage[25];
    private int imageNo = 0;
    public GreepBlood()
    {initialiseImages();
    }
    public void initialiseImages()
    {
        for (int i = 0; i < 25; i++)
        {
            images[i] = new GreenfootImage(getImage());
            images[i].scale(getImage().getWidth()-i,getImage().getHeight()-i);
        }
    }
    public void act() 
    {
        /*
        if (getWidth() <= 1 || getHeight() <= 1)
        getSpace().removeObject(this);
        else
        getImage().scale(getWidth()-1, getHeight()-1);
        */
       if (imageNo == 24)
       {
           imageNo = 0;
           getSpace().removeObject(this);
       }
       else
       {
           setImage(images[imageNo]);
           imageNo++;
       }
    }    
}
