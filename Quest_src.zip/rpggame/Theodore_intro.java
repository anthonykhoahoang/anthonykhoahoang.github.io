import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Theodore here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Theodore_intro extends WorldObjects
{
    /**
     * 
     *
     * Act - do whatever the Theodore wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
   
    private int acts = 0;
    public void act() 
    {
        if (acts == -1)
        {
            if (getOneIntersectingObject(InGameChar.class) != null)
            {
                if (getImage().getWidth() > 5 && getImage().getHeight() > 5)
                getImage().scale(getImage().getWidth()-5,getImage().getHeight()-5);
                else
                getLand().removeObject(this);
                return;
            }
            else
            {
                turnTo();
                move();
                setRotation(0);
            }
        }
        if (!getLand().isBattle && getObjectsInRange(400, Battle.class).size() == 0 )
        {
            if (getObjectsInRange(600, Text.class).size() == 0 && acts == 0)
            {
                getLand().theodoreInParty = true;
                getLand().addObject(new AutoText("Theodore/thanks", 200, 12f), getX(), getY()-100);
                acts++;
            }
            else
            {
                if(getObjectsInRange(600, Keyboard.class).size() == 0 && getObjectsInRange(600, Text.class).size() == 0 && acts ==1)
                {
                    getLand().addKeyBoard2();
                    acts++;
                }
                else
                if(getObjectsInRange(600, Keyboard.class).size() == 0 && acts ==2)
                {
                    getLand().addObject(new AutoText("Theodore/thanks_2", 200, 12f), getX(), getY()-100);
                    acts++;
                }
                else
                if(getObjectsInRange(600, Text.class).size() == 0 && acts == 3 )
                {
                    getLand().addObject(new AutoText("Skye/introTheodore", 200, 12f), getLand().skye.getX(), getLand().skye.getY()-100);
                    acts++;
                }
                else
                if(getObjectsInRange(600, Text.class).size() == 0 && acts ==4)
                {
                    getLand().addObject(new AutoText("Theodore/thanks_3", 200, 12f), getX(), getY()-100);
                    acts++;
                }
                else
                if(getObjectsInRange(600, Text.class).size() == 0 && acts == 5 )
                {
                    getLand().addObject(new AutoText("Skye/introTheodore_2", 200, 12f), getLand().skye.getX(), getLand().skye.getY()-100);
                    acts++;
                }
                else
                if(getObjectsInRange(600, Text.class).size() == 0 && acts ==6)
                {
                    getLand().addObject(new AutoText("Theodore/thanks_4", 200, 12f), getX(), getY()-100);
                    acts++;
                }
                else
                if(getObjectsInRange(600, Text.class).size() == 0 && acts == 7 )
                {
                    getLand().addObject(new AutoText("Skye/introTheodore_3", 200, 12f), getLand().skye.getX(), getLand().skye.getY()-100);
                    acts++;
                }
                else
                if(getObjectsInRange(600,Text.class).size() == 0 && acts ==8)
                {
                    getLand().addObject(new AutoText("Theodore/thanks_5", 200, 12f), getX(), getY()-100);
                    acts++;
                }
                else
                if(getObjectsInRange(600, Text.class).size() == 0 && acts == 9 )
                {
                    getLand().addObject(new AutoText("Skye/introTheodore_4", 200, 12f), getLand().skye.getX(), getLand().skye.getY()-100);
                    acts++;
                }
                else
                if(getObjectsInRange(600, Text.class).size() == 0 && acts ==10)
                {
                    getLand().addObject(new AutoText("Theodore/thanks_6", 200, 12f), getX(), getY()-100);
                    acts++;
                }
                else
                if(getObjectsInRange(600, Text.class).size() == 0 && acts ==11)
                {
                    getLand().addObject(new Tuturial("basics3"), getLand().getWidth()/2, getLand().getHeight()/2);
                    acts++;
                }
                else
                if (getObjectsInRange(600, Tuturial.class).size() == 0 && acts == 12)
                {
                    getLand().addObject(new AutoText("Theodore/thanks_7", 200, 12f), getX(), getY()-100);
                    acts++;
                }
                else
                if (getObjectsInRange(600, Text.class).size() == 0 && acts == 13)
                {
                    acts = -1;
                }
            }
        }
    }    
    public void turnTo()
    {
        Actor a = (Actor)getLand().getObjects(InGameChar.class).get(0);
        int deltaX = (a.getX() - getX());
        int deltaY = (a.getY() - getY());
        setRotation((int) (180 * Math.atan2(deltaY, deltaX) / Math.PI));
    }
    public void move()
    {
        double angle = Math.toRadians( getRotation() );
        int x = (int) Math.round(getX() + Math.cos(angle) * getImage().getWidth()/3);
        int y = (int) Math.round(getY() + Math.sin(angle) * getImage().getWidth()/3);
        setLocation(x, y);
    }
}
