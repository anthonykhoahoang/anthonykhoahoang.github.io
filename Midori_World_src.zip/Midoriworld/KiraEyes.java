import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Eyes blink
 * 
 * @author Anthony Hoang 
 * @version 1
 */
public class KiraEyes extends KiraFaceParts
{
    private GreenfootImage[] img = new GreenfootImage[5];
    int n = 0;
    int part = 1;
    private int count = 0;
    private boolean blinking = false;
    public KiraEyes()
    {
        img[0] = new GreenfootImage("kira/eyes/eyes1.png");
        img[1] = new GreenfootImage("kira/eyes/eyes2.png");
        img[2] = new GreenfootImage("kira/eyes/eyes3.png");
        img[3] = new GreenfootImage("kira/eyes/eyes4.png");
        img[4] = new GreenfootImage("kira/eyes/eyes5.png");
        setImage(img[0]);
    }
    public void act() 
    {
        if (getMWorld().gamePause) return;
        if (Greenfoot.mouseClicked(this)) 
        { blinking = true;}
        if (blinking) blink();
        
    }
    public void blink()
    {
        if (count > 0) count=0;
        else
        count++;
        if (count > 0){return;}
        setImage(img[n]);
        if (n < 4 && part == 1)
            n++;
        else
        if (n == 4 && part == 1)
            part = 2;
      
        if (n > 0 && part == 2)
            n--;
        else if (n == 0 && part == 2)
        {
            part = 1;
            blinking = false;
        }
    }
    public void readyToBlink()
    {
        blinking = true;
    }
}
