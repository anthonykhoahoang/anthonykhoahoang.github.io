import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Theodore2Soldiers here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Theodore2Soldiers extends Enemy
{
    /**
     * Act - do whatever the Theodore2Soldiers wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    private int numActs = 0;
    public void act() 
    {
        if (getObjectsInRange(400, InGameChar.class).size() != 0)
        {
            
                getLand().addObject(new InstantText("Theodore/helpme", 200, 12f), getX(), getY()-100);
                Greenfoot.delay(50);
                int n = getLand().charLevel;
                getLand().loadBattleType1();
                int delay = 500 - n*10;
                if (delay < 100) delay = 100;
                getLand().addObject(new BattleSoldier(n*10-5*(n-1), 0, delay-Greenfoot.getRandomNumber(20), 3*n - 2*(n-1)), 700, 400);
                getLand().addObject(new BattleSoldier(n*10-5*(n-1), 0, delay-Greenfoot.getRandomNumber(20), 3*n - 2*(n-1)), 700, 300);
                //getLand().curEXP += 10;
                getLand().addObject(new Theodore_intro(), getX(),getY());
                getLand().removeObject(this);
        }      
    }
}
