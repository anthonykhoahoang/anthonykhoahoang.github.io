import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class TwoSoldiers here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class TwoSoldiers extends Enemy
{
    private int numActs = 0;
    private boolean willAttack;
    public TwoSoldiers()
    {
    }
    public void act() 
    {
        if (getObjectsInRange(200, InGameChar.class).size() != 0)
        willAttack = true;
        if (willAttack)
        {
            getLand().addObject(new InstantText("soldier/halt", 200, 12f), getX(), getY()-100);
            Greenfoot.delay(50);
            int n = getLand().charLevel;
            getLand().loadBattleType1();
            int delay = 500 - n*10;
            if (delay < 100) delay = 100;
            getLand().addObject(new Potion(), getX(), getY());
            getLand().addObject(new BattleSoldier(n*10-5*(n-1), 0, delay-Greenfoot.getRandomNumber(20), 3*n - 2*(n-1)), 700, 400);
            getLand().addObject(new BattleSoldier(n*10-5*(n-1), 0, delay-Greenfoot.getRandomNumber(20), 3*n - 2*(n-1)), 700, 300);
            //getLand().curEXP += 10;
            getLand().removeObject(this);
            
            
        }
    }    
}
