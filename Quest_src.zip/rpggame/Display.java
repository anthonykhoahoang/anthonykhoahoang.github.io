import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.awt.Color;
import java.awt.Font;

/**
 * Write a description of class Display here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Display extends Keyboard
{
    private boolean isUpperCase;
    public String curText;
    private int acts = 0;
    private GreenfootImage image;
    
    public Display()
    {
        
        curText = "";
        isUpperCase = true;
        
        image = new GreenfootImage(700, 50);
        image.setColor(new Color(255,255,255, 128));
        image.fillRect(0, 0, 700, 50);
        image.setColor(new Color(0, 0, 0, 128));
        image.fillRect(5, 5, 690, 40);
        Font font = new Font("Courier", image.getFont().getStyle(), image.getFont().getSize()) ;
        font = font.deriveFont(50f);
        image.setFont(font);
        image.setColor(Color.WHITE);
        image.drawString(curText, 10, 40);
        setImage(image);
    }
    public void act() 
    {
        if (acts ==0)
        {
            image.clear();
            image = new GreenfootImage(700, 50);
            image.setColor(new Color(255,255,255, 128));
            image.fillRect(0, 0, 700, 50);
            image.setColor(new Color(0, 0, 0, 128));
            image.fillRect(5, 5, 690, 40);
            Font font = new Font("Courier", image.getFont().getStyle(), image.getFont().getSize()) ;
            font = font.deriveFont(50f);
            image.setFont(font);
            image.setColor(Color.WHITE);
            image.drawString(curText, 10, 40);
            acts = -5;
            setImage(image);
        }
        if (acts != 0)
        acts++;
    }    
    public void add(String str)
    {
        curText += str;
    }
    
    public boolean isUpperCase()
    {
        return isUpperCase;
    }
    public boolean setIsUpperCase(boolean b)
    {
        return isUpperCase = b;
    }
    public void deleteLastLetter()
    {
        if (curText.length() > 0)
        curText = curText.substring(0,curText.length()-1);
    }
    public void setCurText(String str)
    {
        curText = str;
    }
    public void clear()
    {
        curText = "";
    }
}
