import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.awt.Color;
/**
 * Write a description of class PhoneGrayScreen here.
 * 
 * @author Anthony Hoang
 * @version (v1)
 */
public class PhoneGrayScreen  extends PhoneHolos
{
    private GreenfootImage img;
    public PhoneGrayScreen()
    {
        img = new GreenfootImage(880, 494);
        img.setColor(Color.BLACK);
        img.fill();
        img.setTransparency(0);
        setImage(img);
    }
    public void act() 
    {
        if (getMWorld().gamePause) return;
        if (remove)
        super.act();
        else
        if (img.getTransparency() < 160)
        {
            img.setTransparency(img.getTransparency()+2);
            setImage(img);
        }
    }    
}
