import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.awt.Color;
import java.awt.Font;
/**
 * Write a description of class Easy here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Hard extends Level
{
    public static final float FONT_SIZE = 25.0f;
    public static final int WIDTH = 100;
    public static final int HEIGHT = 50;
    private GreenfootImage image;
    private int players = 1;
    
    public Hard(int numPlayers)
    {
        players = numPlayers;
        image = new GreenfootImage(WIDTH, HEIGHT);
        image.setColor(new Color(200, 50, 10, 128));
        image.fillRect(0, 0, WIDTH, HEIGHT);
        Font font = image.getFont();
        font = font.deriveFont(FONT_SIZE);
        image.setFont(font);
        image.setColor(Color.WHITE);
        image.drawString("HARD", 15 , 35);
        setImage(image);
    }
    public void act() 
    {
        image.clear();
        if (Greenfoot.mouseMoved(this))
        {
            image.setColor(new Color(255, 255, 10, 128));
            image.fillRect(0, 0, WIDTH, HEIGHT);
            image.setColor(Color.WHITE);
            image.drawString("HARD", 15 , 35);
        }
        else
        {
            image.setColor(new Color(200, 50, 10, 128));
            image.fillRect(0, 0, WIDTH, HEIGHT);
            image.setColor(Color.WHITE);
            image.drawString("HARD", 15 , 35);
        }
        if (Greenfoot.mousePressed(this))
        {
            if (players == 2) getSpace().set2playerMode();
            getSpace().loadHard();
        }
        setImage(image);
    }
}
