import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.awt.Color;
/**
 * Write a description of class RightKey2 here.
 * 
 * @author Anthony Hoang
 * @version (v1)
 */
public class RightKey2  extends Keys
{
    public RightKey2()
    {
        super("right");
    }
    public void act() 
    {
        super.act();
    }    
    public void doChange()
    {
        String key = Greenfoot.getKey();
        if (key!=null)
        {
            getMWorld().right2 = ""+key;
            super.doChange();
            redraw = true;
        }
        else
        if (redraw)
        {
            getImage().clear();
            getImage().setColor(Color.BLUE);
            getImage().drawRect(0,0,getImage().getWidth(),getImage().getHeight());
            getImage().setColor(Color.RED);
            getImage().drawString(getMWorld().right2, 2, 25);
            redraw = false;
        }
    }
    public void doNoChange()
    {
        if (redraw)
        {
            getImage().clear();
            getImage().setColor(Color.BLUE);
            getImage().drawRect(0,0,getImage().getWidth(),getImage().getHeight());
            getImage().setColor(Color.WHITE);
            getImage().drawString(getMWorld().right2, 2, 25);   
            redraw = false;
        }
    }
}
