import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class InGameHostile here.
 * 
 * @author Anthony Hoang
 * @version (v1)
 */
public class InGameHostile  extends InGameObjects
{
    /**
     * Act - do whatever the InGameHostile wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
        // Add your action code here.
    } 
    public boolean blackBetweenY( int y2)
    {
        int y1 = getY();
        if (y1 < y2)
        return blackBetweenYDown(y2);
        return blackBetweenYUp(y2);
    }
    public boolean blackBetweenYDown(int y2)
    {
        int y1 = getY();
        while (y1 < y2)
        {
            if (isBlackAt(getX(),y1))
            return true;
            y1++;
        }
        return false;
    }
    public boolean blackBetweenYUp(int y2)
    {
        int y1 = getY();
        while (y1 > y2)
        {
            if (isBlackAt(getX(),y1))
            return true;
            y1--;
        }
        return false;
    }
    public void gotoNextBlackY(int y2)
    {
        int y1 = getY();
        if (y1 < y2)
        gotoNextBlackYDown(y2);
        else
        gotoNextBlackYUp(y2);
    }
    public void gotoNextBlackYDown(int y2)
    {
        int y1 = getY();
        while (y1 < y2)
        {
            if (isBlackAt(getX(),y1))
            {                 
                setLocation(getX(), y1-getImage().getHeight()/2);
                return;
            }
            y1++;
        }
        setLocation(getX(), y1-getImage().getHeight()/2);
    }
    public void gotoNextBlackYUp(int y2)
    {
        int y1 = getY();
        while (y1 > y2)
        {
            if (isBlackAt(getX(),y1))
            {
                setLocation(getX(), y1+getImage().getHeight()/2);
                return;
            }
            y1--;
        }
        setLocation(getX(), y1+getImage().getHeight()/2);
    }
    public boolean blackBetweenX(int x2)
    {
        int x1 = getX();
        if (x1 < x2)
        return blackBetweenXRight(x2);
        return blackBetweenXLeft(x2);
    }
    public boolean blackBetweenXRight(int x2)
    {
        int x1 = getX();
        int y1 = getY();
        while (x1 < x2)
        {
            if (isBlackAt(x1, y1))
            return true;
            x1++;
        }
        return false;
    }
    public boolean blackBetweenXLeft(int x2)
    {
        int x1 = getX();
        int y1 = getY();
        while (x1 > x2)
        {
            if (isBlackAt(x1, y1))
            return true;
            x1--;
        }
        return false;
    }   
}
