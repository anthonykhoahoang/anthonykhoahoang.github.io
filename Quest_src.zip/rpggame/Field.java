import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Field here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Field extends Battle
{
    public void act() 
    {
        // Add your action code here.
    }    
    public void setBackground(GreenfootImage image)
    {   setImage(image);    }
}
