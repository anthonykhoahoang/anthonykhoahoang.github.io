import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Land here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Land extends Misc
{
    public void act() 
    {
        moveDown();
    }    
    public void moveDown()
    {
        setLocation(getX(), getY()+1);
        if (atBottomEdge())
        setLocation(getX(), 5);
        
    }
    public boolean atBottomEdge()
    {
        if (getY() >= getWorld().getHeight()-1)
            return true;
        return false;
    }
}
