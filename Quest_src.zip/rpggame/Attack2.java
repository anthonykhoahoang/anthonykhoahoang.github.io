import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.awt.Color;
import java.awt.Font;
/**
 * Write a description of class Attack here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Attack2 extends BattleMenu2
{
    private GreenfootImage image;
    private float FONT_SIZE = 15f;
    private int WIDTH = 200;
    private int HEIGHT = 20;
    public boolean special = false;
    public Attack2()
    {
        image = new GreenfootImage(WIDTH, HEIGHT);
        Font font = image.getFont();
        font = font.deriveFont(FONT_SIZE);
        image.setFont(font);
        image.setColor(Color.WHITE);
        image.drawString("Attack", 15 , 18);
        setImage(image);
    }
    public void act() 
    {
        image.clear();
        if (getOneIntersectingObject(Pointer2.class) != null)
        {
            if (getLand().battletheodore.getCurMP() != getLand().battletheodore.getTotalMP() )
            {
                image.setColor(Color.RED);
                image.clear();
                image.drawString("Attack", 15 , 18);
            }
            else
            {
                image.setColor(Color.ORANGE);
                image.drawString("Attack >>", 15 , 18);
            }
        }
        else
        {
            image.setColor(Color.WHITE);
            image.drawString("Attack", 15 , 18);
       
        }
        if (special) special();
        setImage(image);
    }    
    public void special()
    {
        image.clear();
        special = true;
        if (getOneIntersectingObject(Pointer2.class) != null)
        image.setColor(Color.ORANGE);
        else image.setColor(Color.WHITE);
        
        image.drawString("Special", 15 , 18);
    }
}
