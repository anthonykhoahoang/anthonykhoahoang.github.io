import greenfoot.*;  // (World, Actor, GreenfootImage, and Greenfoot)
/**
 * game mode class
 * 
 * @author Anthony Hoang
 * @version 1.5
 */
public class GameMode extends Actor
{
    public GameMode()
    {

    }
    public void act() 
    {
    }   
    public Space getSpace() 
    {
        return (Space)getWorld();
    }
}
