import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class LGGates here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class LGGates  extends LogicGate
{
    private String type;
    private boolean isPressed = true;
    private boolean remove = false;
    public LGGates (String type)
    {
        this.type = type;
    }
    public void act() 
    {
        if (getMWorld().esPause) return;
        if (remove)
        {
            int t = getImage().getTransparency()-50;
            if (t < 0)
            {
                getMWorld().removeObject(this);
                return;
            }
            else
            getImage().setTransparency(t);
        }
        checkMovement();
        checkForGateChecker();
    }
    public boolean isPressed()
    {
        return isPressed;
    }
    public void checkForGateChecker()
    {
        if (isPressed) return;
        Actor gc = getOneIntersectingObject(LGGateChecker.class);
        Actor lgGate = getOneIntersectingObject(LGGates.class);
        if (gc != null && lgGate == null)
        setLocation(gc.getX(),gc.getY());
        else
        if (gc == null)
        {
            remove = true;
            setImage(new GreenfootImage(getImage()));
        }
        else 
        if (lgGate != null && gc.getX() != getX() && gc.getY()!=getY())
        {
            remove = true;
            setImage(new GreenfootImage(getImage()));
        }
    }
    public void checkMovement()
    {
        if (Greenfoot.mouseClicked(this))
        isPressed = !isPressed;
        MouseInfo m = Greenfoot.getMouseInfo();
        if (m==null) return;
        
        if (isPressed)
        setLocation(m.getX(),m.getY());
        
    }
    public String getType()
    {
        return type;
    }
}
