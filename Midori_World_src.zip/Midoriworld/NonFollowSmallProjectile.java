import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.util.List;
/**
 * Write a description of class FollowHostile here.
 * 
 * @author Anthony Hoang
 * @version (v1)
 */
public class NonFollowSmallProjectile  extends HostileProjectile
{
    private static GreenfootImage img;
    private Vector v = new Vector();
    private double x=0, y=0;
    private int x2,y2;
    private boolean firstInitialize = true;
    private int r;
    private int checkDelay = 0;
    public NonFollowSmallProjectile(int r)
    {
        if (img == null)
        {img = new GreenfootImage("greenStuff.png");
        img.scale(img.getWidth()/2, img.getHeight()/2);}
        setImage(new GreenfootImage(img));
        this.r = r;
    }
    public void act() 
    {
        if (getMWorld().esPause) return;
        super.act();
        if (firstInitialize)
        {
            x = getX();
            y = getY();
            firstInitialize = false;
        }
        else
        if (!hasHit)
        move();
        else
        explode();
    }    
    public void explode()
    {
        for (int i = 0; i < 10; i++)
        getMWorld().addObject(new SmallSmudgeParticle((int)(Math.random()*360)),getX(),getY());

        int w = getImage().getWidth();
        int h = getImage().getHeight();
        if (w <= 5 || h <= 5)
        getMWorld().removeObject(this);
        else
        getImage().scale(w-5, h-5);
    }
    public void move()
    {
        getMWorld().addObject(new SmallSmudgeParticle(r),getX(),getY());
        v.add(new Vector(r, Math.random()*.5 ));
        setRotation(r);
        x+=v.getX();
        y+=v.getY();
        if (blackBetweenX((int)x)||blackBetweenY((int)y))
        hasHit = true;
        if (x > getWorld().getWidth()) x = getWorld().getWidth();
        if (x < 0) x = 0;
        if (y > getWorld().getHeight()) y = getWorld().getHeight();
        if (y < 0) y = 0;
        setLocation((int)x,(int)y);
    }
    private int getAngleTo(double x, double y)
    {
        double deltaX = x - getX();
        double deltaY = y - getY();
        return (int)(180 * Math.atan2(deltaY, deltaX) / Math.PI);
    }
}
