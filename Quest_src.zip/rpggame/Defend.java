import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.awt.Color;
import java.awt.Font;
/**
 * Write a description of class Attack here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Defend extends BattleMenu
{
    private GreenfootImage image;
    private float FONT_SIZE = 15f;
    private int WIDTH = 200;
    private int HEIGHT = 20;
    
    public boolean isDefendTeam = false;
    public boolean isReturningToNormalPos = false;
    public Defend()
    {
        image = new GreenfootImage(WIDTH, HEIGHT);
        Font font = image.getFont();
        font = font.deriveFont(FONT_SIZE);
        image.setFont(font);
        image.setColor(Color.WHITE);
        image.drawString("Defend", 15 , 18);
        setImage(image);
    }
    public void act() 
    {
        if (!isDefendTeam && !isReturningToNormalPos)
        {
            image.clear();
            setLocation( 180, 123);
        }
        if (getOneIntersectingObject(Pointer.class) != null)
        {
            if (getLand().getObjects(Good.class).size() > 1)
            {
                image.setColor(Color.ORANGE);
                image.drawString("Defend >>", 15 , 18);
            }
            else
            {
                image.setColor(Color.RED);
                image.clear();
                image.drawString("Defend", 15 , 18);
            }
        }
        else
        {
            image.setColor(Color.WHITE);
            image.drawString("Defend", 15 , 18);
       
        }
        setImage(image);
        if (isDefendTeam) defendTeam();
        if (isReturningToNormalPos) returnToNormalPos();
    }    
    public void defendTeam()
    {
        image.clear();
        isDefendTeam = true;
        isReturningToNormalPos = false;
        if (getOneIntersectingObject(Pointer.class) != null)
        image.setColor(Color.ORANGE);
        else image.setColor(Color.WHITE);
        
        setLocation(158, 123);
        image.drawString("<< Defend Teammate >>", 15 , 18);
    }
    public void returnToNormalPos()
    {
        
        image.clear();
        isDefendTeam = false;
        isReturningToNormalPos = true;
        if (getOneIntersectingObject(Pointer.class) != null)
        image.setColor(Color.ORANGE);
        else image.setColor(Color.WHITE);
        
        setLocation(156, 123);
        image.drawString("<< Return to Prev. Pos.", 15 , 18);
    }
}
