import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class MovePlatform here.
 * 
 * @author Anthony Hoang
 * @version (v1)
 */
public class MovePlatform  extends Platform
{
    private int x[];
    private int y[];                   
    private int curPos;  
    private int moveSpeed;
    private boolean charWasAbove = false;
    private int prevX = 0;
    private boolean goingBack;
    public MovePlatform(int speed, int[] x, int[] y)
    {
        this.x = x;
        this.y = y;
        curPos = 0;
        goingBack = false;
        moveSpeed = speed;
    }
    public void act() 
    {
        if (getMWorld().esPause) return;
        charWasAbove = isAbove();
        prevX = 0;
        move();
        if (charWasAbove)
        moveChar();
    }    
    public void move()
    {
        int nx = x[curPos], ny = y[curPos];
        if (goingBack && curPos <= 0)
        goingBack = false;
        else if (!goingBack && curPos >= x.length)
        goingBack = true;
        if (Math.abs(nx-getX()) < moveSpeed && Math.abs(ny-getY()) < moveSpeed)
        {
            if(!goingBack) curPos++;
            else curPos--;
        }
        else
        {
            if (nx > x[curPos])
            nx-=moveSpeed;
            else if (nx < x[curPos])
            nx+=moveSpeed;
            if (ny > y[curPos])
            ny-=moveSpeed;
            else if (ny < y[curPos])
            ny+=moveSpeed;
            setLocation(nx,ny);
        }
    }
    public void moveChar()
    {
        Actor a = getOneIntersectingObject(InGameCharacter.class);
        if (a != null) 
        {
            int xa = a.getX()-prevX;
            a.setLocation( getX()+xa, getY()-getImage().getHeight()/2-a.getImage().getHeight()/2);
        }
    }
}
