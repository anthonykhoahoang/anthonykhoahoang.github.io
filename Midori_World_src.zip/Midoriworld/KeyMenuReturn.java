import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.awt.Color;
import java.awt.Font;
import java.util.List;
/**
 * Write a description of class ReturnToLoginMenu here.
 * 
 * @author Anthony Hoang
 * @version (v1)
 */
public class KeyMenuReturn  extends Keys
{
    private int WIDTH = 220;
    private int HEIGHT= 50;
    private GreenfootImage image;
    private GreenfootImage image2;
    private boolean redraw = true;
    public KeyMenuReturn()
    {
        image = new GreenfootImage(WIDTH, HEIGHT);
        image2 = new GreenfootImage(WIDTH, HEIGHT);
        drawOne();
        drawTwo();
        setImage(image2);
        getImage().setTransparency(0);
    }
    public void act() 
    {
        if (mouseOverThis() )
        {
            if (getImage().equals(image2))
            setImage(image);
        }
        else if (getImage().equals(image))
        setImage(image2);
        if (Greenfoot.mouseClicked(this))
        {
            List<Keys> list = getMWorld().getObjects(Keys.class);
            for (Keys k : list)
            k.close();
            List<Typer> list2 = getMWorld().getObjects(Typer.class);
            for (Typer t : list2)
            t.close();
            List<TyperBackground> list3 = getMWorld().getObjects(TyperBackground.class);
            for (TyperBackground t : list3)
            t.close();
        }
        super.act();
    }    
    public void drawOne()
    {
        image.setColor(Color.GRAY);
        image.fill();
        image.setColor(new Color(5, 5, 75 ,150));
        image.fillRect(5, 5, WIDTH-10, HEIGHT-10);
        Font font = image.getFont();
        font = font.deriveFont(25f);
        image.setFont(font);
        image.setColor(Color.WHITE);
        image.drawString("Return to Menu", 19, 32);
        setImage(image);
    }
    public void drawTwo()
    {
        image2.setColor(new Color(5, 5, 50 ,150));
        image2.fillRect(5, 5, WIDTH-10, HEIGHT-10);
        Font font = image.getFont();
        font = font.deriveFont(25f);
        image2.setFont(font);
        image2.setColor(Color.WHITE);
        image2.drawString("Return to Menu", 19, 32);
        setImage(image2);
    }
}
