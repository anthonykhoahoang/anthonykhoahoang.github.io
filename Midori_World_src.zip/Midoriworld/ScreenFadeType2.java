import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Can overlay ingame objects, but not menu classes, phone, text
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class ScreenFadeType2  extends ScreenFade
{
    public ScreenFadeType2()
    {
        super();
    }
    public void act() 
    {
        super.act();
    }    
}
