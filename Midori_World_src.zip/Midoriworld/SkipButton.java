import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.awt.Color;
import java.awt.Font;
/**
 * Performs skip command of the eventscript.
 * 
 * @author Anthony Hoang
 * @version (v1)
 */
public class SkipButton extends InGameObjects
{
    private int WIDTH = 90;
    private int HEIGHT = 50;
    private GreenfootImage image;
    private GreenfootImage image2;
    private String user;
    private String pass;
    private boolean firstInitialize = true;
    private boolean isOn = false;
    public boolean closing = false;
    private EventScript es;
    
    public SkipButton(EventScript es)
    {
        image = new GreenfootImage(WIDTH, HEIGHT);
        image2 = new GreenfootImage(WIDTH, HEIGHT);
        drawOne();
        image.setTransparency(0);
        image2.setTransparency(0);
        setImage(image2);
        this.es = es;
    }
    public void close()
    {
        closing = true;
    } 
    public boolean mouseOverThis()
    {
        MouseInfo m = Greenfoot.getMouseInfo();
        if (m == null)
        {
            if (isOn) return true;
            return false;
        }
        else
        {
            Actor actor = m.getActor();
            
            if (actor != null && actor.equals(this))
            {
                isOn = true;
                return true;
            }
            else
            {
                isOn = false;
                return false;
            }
        }
    }
    public void act() 
    {
        if (firstInitialize)
        {
            int t = getImage().getTransparency()+10;
            if (t > 255)
            firstInitialize = false;
            else
            {
                image.setTransparency(t);
                image2.setTransparency(t);
            }
        }
        if (closing)
        {
            int t = getImage().getTransparency()-10;
            if (t < 0)
            getMWorld().removeObject(this);
            else
            {
                image.setTransparency(t);
                image2.setTransparency(t);
            }
            return;
        }
        
        String key = ""+Greenfoot.getKey();
        if (mouseOverThis() )
        {
            if (getImage().equals(image2))
            setImage(image);
        }
        else 
        if (getImage().equals(image))
        setImage(image2);
        if (Greenfoot.mouseClicked(this))
        {
            es.skip();
        }
    }    
    public void drawOne()
    {
        image.setColor(Color.GRAY);
        image.fill();
        image.setColor(new Color(5, 5, 75 ,150));
        image.fillRect(5, 5, WIDTH-10, HEIGHT-10);
        Font font = image.getFont();
        font = font.deriveFont(25f);
        image.setFont(font);
        image.setColor(Color.WHITE);
        image.drawString("Skip", 19, 32);
        image2.setColor(new Color(5, 5, 50 ,150));
        image2.fillRect(5, 5, WIDTH-10, HEIGHT-10);
        font = image.getFont();
        font = font.deriveFont(25f);
        image2.setFont(font);
        image2.setColor(Color.WHITE);
        image2.drawString("Skip", 19, 32);
    }
}
