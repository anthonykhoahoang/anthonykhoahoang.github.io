import greenfoot.*;  // (World, Actor, GreenfootImage, and Greenfoot)
import java.awt.Color;
import java.awt.Font;
import java.io.BufferedReader;
import java.io.IOException; 
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URL;
/**
 * Reads an input text file 
 * @author Anthony Hoang
 * @version 2.0
 */
public class Text extends Actor
{
    public float FONT_SIZE;
    public int WIDTH;
    public int HEIGHT;
    public String curString;
    
    private int index;
    private int pos;
    private int hPos;
    
    private int acts = -2;
    
    public String nxtFile;
    public String curFile;
    public boolean reachedEnd;
    public boolean closing = false;
    public int delay = 10;
    

    public GreenfootImage image;

    public Text(String text, int width, float fSize)
    {
        curFile = text;
        setImage(new GreenfootImage(1,1));
        FONT_SIZE = fSize;
        WIDTH = width;
        String temp = "text/"+text+".txt";
        curString = getTextFile(temp);
        
        reachedEnd = false;
        HEIGHT = calcHeight(curString);
        
        index = 0;
        pos = (int)(FONT_SIZE);
        hPos = (int)(FONT_SIZE*1.3);
        
        image = new GreenfootImage(WIDTH, HEIGHT);
        image.setColor(new Color(255,255,255, 128));
        image.fillRect(0, 0, WIDTH, HEIGHT);
        image.setColor(new Color(0, 0, 0, 128));
        image.fillRect(3, 3, WIDTH-6, HEIGHT-6);
        Font font = new Font("Courier", image.getFont().getStyle(), image.getFont().getSize()) ;
        font = font.deriveFont(FONT_SIZE);
        image.setFont(font);
        image.setColor(Color.WHITE);
    }
    public void act()
    {
        if (closing)
        {
            if (getImage().getWidth() > 300 && getImage().getHeight() > 30)
            getImage().scale(getImage().getWidth()-30, getImage().getHeight()-30);
            else
            getLand().removeObject(this);
            return;
        }
        if (index < curString.length() && acts == 0)
        {
            int nxtIndex = index+1;
            while (nxtIndex < curString.length() && !curString.substring(nxtIndex, nxtIndex+1).equals(" ") )
            {
                
                nxtIndex++;
                String temp3 = curString.substring(index, nxtIndex);
                if (temp3.equals("##"))
                {
                    while (nxtIndex < curString.length() && !curString.substring(nxtIndex, nxtIndex+1).equals(" ") )
                    {
                        nxtIndex++;
                    }
                    temp3 = curString.substring(index+2, nxtIndex);
                    getLand().loadLevel(temp3);
                    index += temp3.length()+2;
                    acts = -4;
                    return;
                }
                String temp2 = curString.substring(index, nxtIndex);
                if (temp2.equals("%Name%") )
                {
                    temp2 = getLand().charName();
                    int n = nxtIndex;
                    while (!curString.substring(n, n+1).equals(" ") )
                    n++;
                    String t = curString.substring(nxtIndex, n);
                    temp2 = temp2 + t;
                    if (pos > WIDTH-FONT_SIZE*temp2.length() )
                    {
                        pos = (int)FONT_SIZE;
                        hPos += (int)FONT_SIZE*2-FONT_SIZE/1.5;
                    }   
                    image.drawString(temp2, pos, hPos);
                    index += 6 + t.length();
                    pos += (int)FONT_SIZE*temp2.length()/1.8 + (int)FONT_SIZE/2 ;
                    setImage(image);
                    acts = -4;
                    //index+= 1;
                    return;
                }
                if (temp2.equals("%Name2%") )
                {
                    temp2 = getLand().charName2();
                    int n = nxtIndex;
                    while (!curString.substring(n, n+1).equals(" ") )
                    n++;
                    String t = curString.substring(nxtIndex, n);
                    temp2 = temp2 + t;
                    if (pos > WIDTH-FONT_SIZE*temp2.length() )
                    {
                        pos = (int)FONT_SIZE;
                        hPos += (int)FONT_SIZE*2-FONT_SIZE/1.5;
                    }   
                    image.drawString(temp2, pos, hPos);
                    index += 7 + t.length();
                    pos += (int)FONT_SIZE*temp2.length()/1.8 + (int)FONT_SIZE/2 ;
                    setImage(image);
                    acts = -4;
                    //index+= 1;
                    return;
                }
                if (temp2.equals(" **close**"))
                {  // getLand().removeObject(this); 
                    closing = true;
                    return;
                }
            }
            
            if (nxtIndex < curString.length()-1)
            nxtIndex += 1;
            String temp = curString.substring(index, nxtIndex);
            if (temp.equals("@@ ") )
            {
                nxtFile = curString.substring(nxtIndex, curString.length());
                //System.out.println(nxtFile);
                index = curString.length();
                return;
            }
            
            if (pos > WIDTH-FONT_SIZE*temp.length() )
            {
                pos = (int)FONT_SIZE;
                hPos += (int)FONT_SIZE*2-FONT_SIZE/1.5;
            }
            image.drawString(temp, pos, hPos);
            index += temp.length();
            pos += (int)FONT_SIZE*temp.length()/1.8 + (int)FONT_SIZE/2 ;
            setImage(image);
            acts = -4;
        }
        if (index >= curString.length())
        reachedEnd = true;
        
        if (acts != 0)
        acts++;
        
        if (reachedEnd && (Greenfoot.mouseClicked(this)|| Greenfoot.isKeyDown("enter"))  )
        {
            if (delay >= 10)
            {
                if (nxtFile != null && !curFile.equals(nxtFile))
                {
                    delay = 0;
                    loadNext(nxtFile);
                }
                else
                closing = true;
            }
            //getLand().removeObject(this);
        }
        
        if (Greenfoot.isKeyDown("enter") || (Greenfoot.mouseClicked(this) && !reachedEnd))
        {
            if (delay >= 10 )
            {
                delay = 0;
                instantText();
            }
        }
        if (delay < 10 ) delay++;
        
    }
    public void instantText()
    {
        while (index < curString.length())
        {
            int nxtIndex = index+1;
            while (nxtIndex < curString.length() && !curString.substring(nxtIndex, nxtIndex+1).equals(" ") )
            {
                
                nxtIndex++;
                String temp3 = curString.substring(index, nxtIndex);
                if (temp3.equals("##"))
                {
                    while (nxtIndex < curString.length() && !curString.substring(nxtIndex, nxtIndex+1).equals(" ") )
                    {
                        nxtIndex++;
                    }
                    temp3 = curString.substring(index+2, nxtIndex);
                    getLand().loadLevel(temp3);
                    index += temp3.length()+2;
                    acts = -4;
                    //return;
                }
                
                String temp2 = curString.substring(index, nxtIndex);
                if (temp2.equals("%Name%") )
                {
                    temp2 = getLand().charName();
                    int n = nxtIndex;
                    while (!curString.substring(n, n+1).equals(" ") )
                    n++;
                    String t = curString.substring(nxtIndex, n);
                    temp2 = temp2 + t;
                    if (pos > WIDTH-FONT_SIZE*temp2.length() )
                    {
                        pos = (int)FONT_SIZE;
                        hPos += (int)FONT_SIZE*2-FONT_SIZE/1.5;
                    }   
                    image.drawString(temp2, pos, hPos);
                    index += 6 + t.length();
                    pos += (int)FONT_SIZE*temp2.length()/1.8 + (int)FONT_SIZE/2 ;
                    setImage(image);
                    acts = -4;
                    //index+= 1;
                    return;
                }
                if (temp2.equals("%Name2%") )
                {
                    temp2 = getLand().charName2();
                    int n = nxtIndex;
                    while (!curString.substring(n, n+1).equals(" ") )
                    n++;
                    String t = curString.substring(nxtIndex, n);
                    temp2 = temp2 + t;
                    if (pos > WIDTH-FONT_SIZE*temp2.length() )
                    {
                        pos = (int)FONT_SIZE;
                        hPos += (int)FONT_SIZE*2-FONT_SIZE/1.5;
                    }   
                    image.drawString(temp2, pos, hPos);
                    index += 7 + t.length();
                    pos += (int)FONT_SIZE*temp2.length()/1.8 + (int)FONT_SIZE/2 ;
                    setImage(image);
                    acts = -4;
                    //index+= 1;
                    return;
                }
                if (temp2.equals(" **close**"))
                {  // getLand().removeObject(this); 
                    closing = true;
                    return;
                }
                
                
            }
            if (nxtIndex < curString.length()-1)
            nxtIndex += 1;
            String temp = curString.substring(index, nxtIndex);
            String temp2 = curString.substring(index, nxtIndex-1);
            String temp3 = curString.substring(index, nxtIndex-2);
            
            if (temp.equals("@@ ") )
            {
                nxtFile = curString.substring(nxtIndex, curString.length());
                //System.out.println(nxtFile);
                index = curString.length();
                return;
            }
            
            if (pos > WIDTH-FONT_SIZE*temp.length() )
            {
                pos = (int)FONT_SIZE;
                hPos += (int)FONT_SIZE*2-FONT_SIZE/1.5;
            }
            image.drawString(temp, pos, hPos);
            index += temp.length();
            pos += (int)FONT_SIZE*temp.length()/1.8 + (int)FONT_SIZE/2 ;
            setImage(image);
        }
        
    }
    public void loadNext(String text)
    {
        //nxtFile = "";
        curFile = text;
        //setImage(new GreenfootImage(1,1));
        String temp = "text/"+text+".txt";
        curString = getTextFile(temp);
        HEIGHT = calcHeight(curString);
        reachedEnd = false;
        index = 0;
         pos = (int)(FONT_SIZE);
        hPos = (int)(FONT_SIZE*1.3);
        
        acts = -2;
        image = new GreenfootImage(WIDTH, HEIGHT);
        image.setColor(new Color(255,255,255, 128));
        image.fillRect(0, 0, WIDTH, HEIGHT);
        image.setColor(new Color(0, 0, 0, 128));
        image.fillRect(3, 3, WIDTH-6, HEIGHT-6);
        Font font = new Font("Courier", image.getFont().getStyle(), image.getFont().getSize()) ;
        font = font.deriveFont(FONT_SIZE);
        image.setFont(font);
        image.setColor(Color.WHITE);
    }
    public InputStream openFile(String fileName) throws IOException
    {
        URL url = getClass().getClassLoader().getResource(fileName);
        if(url == null)
        throw new IOException("File not found: " + fileName);
        return url.openStream();
    } 
    public String getTextFile(String textFileName)
    {
        String str = "";
        StringBuffer sb = new StringBuffer();
        try{
            InputStream is = openFile(textFileName);
             BufferedReader d = new BufferedReader(new InputStreamReader(is));
            String line = d.readLine();
            while(line != null)
            {
                line = d.readLine();
                if (line != null)
                str += line;
            }
        }
        catch(Exception ex)
        { return str; }
        return str;
    } 
    public int calcHeight(String str)
    {
        int numRow = (str.length()*(int)FONT_SIZE)/(WIDTH-2*(int)FONT_SIZE);
        if (numRow == 0)
        numRow = (int)FONT_SIZE;
        return numRow*(int)FONT_SIZE+3*(int)FONT_SIZE;
    }
    public Land getLand()
    {
        return (Land)getWorld();
    }
}