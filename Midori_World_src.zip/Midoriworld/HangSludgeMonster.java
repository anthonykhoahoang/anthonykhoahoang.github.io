import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.util.List;
/**
 * Write a description of class HangSludgeMonster here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class HangSludgeMonster  extends HostileEnemy
{
    private static GreenfootImage[] img;
    private int delay = 2;
    private int index = 0;
    private boolean b = false;
    private int range = 200;
    private int attackDelay = 50;
    
    private boolean left = false;
    private int speed;
    private int moveDelay = 0;
    private int MOVEDELAYLIMIT;
    
    public HangSludgeMonster()
    {
        if (img == null)
        {
            img = new GreenfootImage[2];
            img[0] = new GreenfootImage("monsters/hangmonster1.png");
            img[1] = new GreenfootImage("monsters/hangmonster2.png");
        }
        setImage(img[0]);
        speed = 1;
        MOVEDELAYLIMIT =2;
        attackDelay = (int)(attackDelay*Math.random())+30;
    }
    public HangSludgeMonster(int r)
    {
        this();
        range = r;
    }
    public void act() 
    {
        if (getMWorld().esPause) return;
        if (delay == 0 && !hasHit())
        { setImage(); delay = 30;}
        delay--;
        if (attackDelay < 0 && !hasHit)
        {
            attack();
            attackDelay = 50;
        }
        else
        attackDelay--;
        if (moveDelay > MOVEDELAYLIMIT)
        moveDelay++;
        else
        {
            if (!hasHit)
            move();
            moveDelay = 0;
        }
        super.act();
    }    
    public void move()
    {
        if (isBlackAt(getX(),getY()))
        {hasHit = true;
        return;}
        if (left)
        {
            if (!blackBetweenX(getX()+getImage().getWidth()+speed))
            setLocation(getX()+speed, getY());
            else
            left = false;
        }
        else
        {
            if (!blackBetweenX(getX()-getImage().getWidth()-speed))
            setLocation(getX()-speed, getY());
            else
            left = true;
        }
    }
    public void setImage()
    {
        if(getImage().equals(img[1]))
        setImage(img[0]);
        else
        setImage(img[1]);
    }
    public void attack()
    {
        List<InGameCharacter> l1 = getObjectsInRange(range,InGameCharacter.class);
        if (l1.size()==0) l1 = getObjectsInRange(range,HelperBot.class);
        if (l1.size()!=0)
        {
            Greenfoot.playSound("spit.wav");
            getMWorld().addObject(new FollowSmallProjectile(),getX(),getY());
        }
    }
}
