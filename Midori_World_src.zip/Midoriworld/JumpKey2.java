import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.awt.Color;
/**
 * Write a description of class JumpKey2 here.
 * 
 * @author Anthony Hoang
 * @version (v1)
 */
public class JumpKey2  extends Keys
{
    public JumpKey2()
    {
        super("up");
    }
    public void act() 
    {
        super.act();
    }    
    public void doChange()
    {
        String key = Greenfoot.getKey();
        if (key!=null)
        {
            getMWorld().jump2 = ""+key;
            super.doChange();
            redraw = true;
        }
        else
        if (redraw)
        {
            getImage().clear();
            getImage().setColor(Color.BLUE);
            getImage().drawRect(0,0,getImage().getWidth(),getImage().getHeight());
            getImage().setColor(Color.RED);
            getImage().drawString(getMWorld().jump2, 2, 25);
            redraw = false;
        }
    }
    public void doNoChange()
    {
        if (redraw)
        {
            getImage().clear();
            getImage().setColor(Color.BLUE);
            getImage().drawRect(0,0,getImage().getWidth(),getImage().getHeight());
            getImage().setColor(Color.WHITE);
            getImage().drawString(getMWorld().jump2, 2, 25);   
            redraw = false;
        }
    }
}
