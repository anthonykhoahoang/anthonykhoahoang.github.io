import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.util.List;
/**
 * takes in energy spike when close enough
 * 
 * @author Anthony Hoang
 * @version (v1)
 */
public class EnergyInPort  extends EnergyPort
{
    public boolean hasHadEnergy = false;
    private int rotation;
    private GreenfootImage image1;
    private GreenfootImage image2;
    private int delay = 50;
    public EnergyInPort(int r)
    {
        rotation = r;
        image1 = new GreenfootImage("energyinport.png");
        image2 = new GreenfootImage("energyinport2.png");
        setImage(image1);
        setRotation(r);
    }
    public void act() 
    {
        if (getMWorld().gamePause) return;
        checkForEnergySpike();
        if (hasHadEnergy && delay >= 0)
        delay --;
        if (delay == 0)
        setImage(image2);
    }    
    public void checkForEnergySpike()
    {
        List<EnergySpike> list = getObjectsInRange(50,EnergySpike.class);
        for (EnergySpike e : list)
        {
            e.stopAct();
            setEnergySpikeLoc(e);
            if (!hasHadEnergy)
            {
                hasHadEnergy = true;
                //getMWorld().eventCount++;
            }
        }
    }
    public boolean hasHadEnergy()
    {
        return hasHadEnergy;
    }
    public void setEnergySpikeLoc(EnergySpike e)
    {
        int x = e.getX();
        int y = e.getY();
        if (x > getX())
        x--;
        if (x < getX())
        x++;
        if (y > getY())
        y--;
        if (y < getY())
        y++;
        e.setLocation(x,y);
    }
}
