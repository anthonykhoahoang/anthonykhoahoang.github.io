import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.awt.Color;
import java.util.List;
/**
 * Write a description of class HoloCircle here.
 * 
 * @author Anthony Hoang
 * @version (v1)
 */
public class KiraCapsule  extends InGameObjects
{
    private GreenfootImage image;
    private boolean onTarget = false;
    private int x, y;
    private boolean done = false;
    public KiraCapsule(int x, int y)
    {
        this.x = x; 
        this.y = y;
        image = new GreenfootImage("kira/kirapod.png");
        setImage(image);
    }
    public void act() 
    {
        if (getMWorld().gamePause) return;
        
        if (!onTarget)
        {
            setRotation(getRotation()+20);
            for (int i = 0; i < 4; i++)
            getMWorld().addObject(new SmokeParticle((int)(Math.random()*360)),getX(),getY()+(int)(Math.random()*10));
            int y2 = getY(), x2 = getX();
            if (y2 < y)
            y2+=5;
            else if (y2 > y)
            y2-=5;
            if (x2 < x)
            x2+=5;
            else if (x2 > x)
            x2-=5;
            setLocation(x2,y2);
            if (Math.abs(y-y2) < 10 && Math.abs(x-x2) < 10)
            {
                onTarget = true;
                for (int i = 0; i < 14; i++)
                getMWorld().addObject(new SmokeParticle((int)(Math.random()*360)),getX(),getY()+(int)(Math.random()*10));
                
            }
        }
        else if (!done)
        {
            List<Actor> list = getObjectsInRange(100,InGameCharacter.class);
            if (list.size() !=0)
            {
                done = true;
                getMWorld().eventCount++;
            }
        }
    }    
}
