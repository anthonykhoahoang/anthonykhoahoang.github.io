import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.awt.Color;
import java.awt.Font;

/**
 * basic key input
 * 
 * @author Anthony Hoang
 * @version 2.1
 */
public class Key extends Keyboard
{
    private String letter;
    private String orgLetter;
    private GreenfootImage image;
    private int acts = 0;
    
    public Key(String key)
    {
        letter = key;
        orgLetter = key;
        image = new GreenfootImage(30, 30);
        image.setColor(new Color(255,255,255, 128));
        image.fillRect(0, 0, 30, 30);
        image.setColor(new Color(0, 0, 0, 128));
        image.fillRect(5, 5, 20, 20);
        Font font = new Font("Courier", image.getFont().getStyle(), image.getFont().getSize()) ;
        font = font.deriveFont(30f);
        image.setFont(font);
        image.setColor(Color.WHITE);
        image.drawString(letter, 5, 25);
        //setUpperOrLower();
        setImage(image);
    }
    public void act() 
    {
        if (Greenfoot.mouseMoved(this))
        {
            image.setColor(Color.RED);
            image.drawString(letter, 5, 25);
        }
        else
        {
            image.setColor(Color.WHITE);
            image.drawString(letter, 5, 25);
        }
        setUpperOrLower();
        if ( (Greenfoot.mouseClicked(this) || Greenfoot.isKeyDown(orgLetter)) && acts ==0 )
        {
            acts = -5;
            image.setColor(Color.RED);
            image.drawString(letter, 5, 25);
            getSpace().keyBoardDisplay.add(letter);
        }
        if (acts != 0)
        acts++;
        setImage(image);
    }    
    public void setUpperOrLower()
    {
        if (getSpace().keyBoardDisplay.isUpperCase())
        {
            if (Character.isLowerCase(letter.charAt(0)) )
            {
                char a = Character.toUpperCase(letter.charAt(0));
                letter = ""+a;
                image.clear();
                image.setColor(new Color(255,255,255, 128));
                image.fillRect(0, 0, 30, 30);
                image.setColor(new Color(0, 0, 0, 128));
                image.fillRect(5, 5, 20, 20);   
                Font font = new Font("Courier", image.getFont().getStyle(), image.getFont().getSize()) ;
                font = font.deriveFont(30f);
                image.setFont(font);
                image.setColor(Color.WHITE);
                image.drawString(letter, 5, 25);
            }
        }
        else
        {
            if (Character.isUpperCase(letter.charAt(0)) )
            {
                char a = Character.toLowerCase(letter.charAt(0));
                letter = ""+a;
                image.clear();
                image.setColor(new Color(255,255,255, 128));
                image.fillRect(0, 0, 30, 30);
                image.setColor(new Color(0, 0, 0, 128));
                image.fillRect(5, 5, 20, 20);  
                Font font = new Font("Courier", image.getFont().getStyle(), image.getFont().getSize()) ;
                font = font.deriveFont(30f);
                image.setFont(font);
                image.setColor(Color.WHITE);
                image.drawString(letter, 5, 25);
            }
        }
    }
    
}
