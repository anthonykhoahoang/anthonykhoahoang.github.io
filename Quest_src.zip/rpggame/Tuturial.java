import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.util.*;
import java.awt.Color;
import java.awt.Font;
import java.io.BufferedReader;
import java.io.IOException; 
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URL;

/**
 * Write a description of class Tuturial here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Tuturial extends Actor
{
    private ArrayList<GreenfootImage> images = new ArrayList<GreenfootImage>();
    private ArrayList<String> strArray = new ArrayList<String>();
    private String file;
    private int numSlides =0;
    private int curSlide = 0;
    
    public Tuturial(String f)
    {
        file = "data/TutorialData/"+f+".txt";
        loadFileToArray(file);
        loadImages();
        setImage(images.get(curSlide));
        curSlide = 1;
    }
    public void act() 
    {
        if (Greenfoot.mouseClicked(this) || ( Greenfoot.isKeyDown("enter") && Greenfoot.getKey().equals("enter") ) ) next();
    }    
    public InputStream openFile(String fileName) throws IOException
    {
        URL url = getClass().getClassLoader().getResource(fileName);
        if(url == null)
        throw new IOException("File not found: " + fileName);
        return url.openStream();
    } 
    public void loadFileToArray(String textFileName)
    {
        StringBuffer sb = new StringBuffer();
        try{
            InputStream is = openFile(textFileName);
            BufferedReader d = new BufferedReader(new InputStreamReader(is));
            String line = d.readLine();
            while(line != null)
            {
                strArray.add(line);
                line = d.readLine();
            }
        }
        catch(Exception ex)
        { return ; }
    } 
    public void loadImages()
    {
        for (int i = 0; i < strArray.size(); i++)
        {
            String a = strArray.get(i);
            GreenfootImage temp = new GreenfootImage(a);
            images.add(temp);
        }
    }
    public void next()
    {
        if (curSlide >= images.size())
        getLand().removeObject(this);
        else
        {
            setImage(images.get(curSlide));
            curSlide++;
        }
    }
    public Land getLand()
    {
        return (Land)getWorld();
    }
    
}
