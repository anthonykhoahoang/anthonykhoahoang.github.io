import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.util.*;
/**
 * Write a description of class Pointer here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Pointer extends Battle
{
    private GreenfootImage pointer = new GreenfootImage("Battle/pointer.png");
    private int delay = 0;
    private List<Bad> badGuys;
    private List<Good> goodGuys;
    private int curBadGuy = 0;
    private int curGoodGuy = 0;
    private boolean special = false;
    private boolean pressed = false;
    private boolean targetEnemy = false;
    private boolean normalMenu = true;
    private boolean itemMenu = false;
    private boolean defendTeamMate = false;
    private int curItem = 0;
    private Item item;
    
    public Pointer()
    {
        pointer.scale(35,25);
        setRotation(20);
        setImage(pointer);
    }
    public void act() 
    {
        if (getLand().battleEnemiesDead())
        return;
        if (Greenfoot.isKeyDown("2"))
        {
            if (getLand().theodoreMenuOpen)
            {
                getLand().loadTheodoreBattleMenu();
                getLand().addObject(getLand().gamePointer2, 430, 87);
                getLand().gamePointer2.reset();
                getLand().removeObject(this);
            }
            else    
            {
                getLand().loadSkyeBattleMenu();
            }
        }
        if (delay < 0) delay++;
        if (targetEnemy) pickEnemy();
        if (normalMenu) scrollNormalMenu();
        if (itemMenu) scrollItemMenu();
        if (defendTeamMate) scrollTeamMateDefend();
        if (Greenfoot.isKeyDown("escape") && delay == 0)
        {
            reset();
            getLand().removeObjects(getLand().getObjects(BattleMenu.class));
            getLand().removeItemMenu();
            if (getLand().skyeMenuOpen)
            {
                getLand().loadSkyeBattleMenu();
                setLocation( 180, 87);
                reset();
            }
           //if (getLand().theodoreMenuOpen)
            //getLand().loadTheodoreBattleMenu();
        }
    }    
    
    /**
     * normal menu method
     */
    public void scrollNormalMenu()
    {
        if (Greenfoot.isKeyDown("down") && delay == 0)
        {
            delay = -10;
            down();
        }
        else
        if (Greenfoot.isKeyDown("up") && delay == 0)
        {
            delay = -10;
            up();
        }
        else
        if (Greenfoot.isKeyDown("enter") && delay == 0)
        {
            delay = -10;
            enter();
        }
        if (Greenfoot.isKeyDown("right") && delay == 0 )
        {
            delay = -10;
            
            if ( getOneIntersectingObject(Attack.class) != null && getLand().battleskye.getCurMP() == getLand().battleskye.getTotalMP())
            {
                Attack a = (Attack)getOneIntersectingObject(Attack.class);
                a.special();
            }
            if (getOneIntersectingObject(Defend.class) != null && getLand().getObjects(Good.class).size() > 1 )
            {
                Defend d = (Defend) getOneIntersectingObject(Defend.class);
                if (!d.isDefendTeam && !d.isReturningToNormalPos)
                {
                    d.defendTeam();
                    setLocation(getX()+50, getY());
                }
                else
                if (d.isDefendTeam && !d.isReturningToNormalPos)
                {
                    d.returnToNormalPos();
                }
            }
        }
        if (Greenfoot.isKeyDown("left") && delay == 0 )
        {
            delay = -10;
            
            if ( getOneIntersectingObject(Attack.class) != null )
            {
                Attack a = (Attack)getOneIntersectingObject(Attack.class);
                a.special = false;
            }
            if (getOneIntersectingObject(Defend.class) != null)
            {
                Defend d = (Defend) getOneIntersectingObject(Defend.class);
                if (!d.isDefendTeam && d.isReturningToNormalPos)
                {
                    d.defendTeam();
                }
                else
                if (d.isDefendTeam && !d.isReturningToNormalPos)
                {
                    d.isDefendTeam = false;
                    setLocation(getX()-50, getY());
                }
            }
        }
    }
    
    public void enter()
    {
        if (getOneIntersectingObject(Attack.class) != null)
        {
            if ( ((Attack)getOneIntersectingObject(Attack.class)).special)
            special = true;
            targetEnemy = true;
            badGuys = getLand().getObjects(Bad.class);
            while (curBadGuy >= badGuys.size()) curBadGuy--;
            setLocation(badGuys.get(curBadGuy).getX(),badGuys.get(curBadGuy).getY());
        }
        else if (getOneIntersectingObject(Defend.class) != null)
        {
            goodGuys = getLand().getObjects(Good.class);
            Defend d = (Defend) getOneIntersectingObject(Defend.class);
            if (d.isDefendTeam)
            {
                defendTeamMate = true;
                normalMenu = false;
                curGoodGuy = 1;
                setLocation(goodGuys.get(curGoodGuy).getX(), goodGuys.get(curGoodGuy).getY());
                return;
            }
            else
            if (d.isReturningToNormalPos) getLand().battleskye.returnToNormalPosition();
            else getLand().battleskye.defend();
            //getLand().battleskye.defend();
            getLand().skyeMenuOpen = false;
            getLand().removeObjects(getLand().getObjects(BattleMenu.class));
            removeSelfAndCheck();
        }
        else if (getOneIntersectingObject(MenuItem.class) != null)
        {
            itemMenu = true;
            curItem = 0;
            normalMenu = false;
            getLand().addItemMenu();
        }
        else if (getOneIntersectingObject(MenuMagic.class) != null)
        {
        }
        else if (getOneIntersectingObject(Bad.class) != null)
        {
        }
        else if (getOneIntersectingObject(Good.class) != null)
        {
        }
    }
    public void down()
    {
        if(getY() == 87)
            setLocation(getX(), 123);
        else
        if(getY() == 123)
            setLocation(getX(), 158);
        else
        if(getY() == 158)
            setLocation(getX(), 193);
        else
        if(getY() == 193)
            setLocation(getX(), 87);
    }
    public void up()
    {
        if(getY() == 87)
            setLocation(getX(), 193);
        else
        if(getY() == 123)
            setLocation(getX(), 87);
        else
        if(getY() == 158)
            setLocation(getX(), 123);
        else
        if(getY() == 193)
            setLocation(getX(), 158);
    }

    public void reset()
    {
        delay = -10;
        targetEnemy = false;
        curBadGuy = 0;
        curItem = 0;
        special = false;
        normalMenu = true;
        itemMenu = false;
        defendTeamMate = false;
    }
    public void attackSpecial()
    {
    }
    /**
     * pointer badguy method
     */
    public void attackBadGuy()
    {
        targetEnemy = false;
        if (!special)
        getLand().battleskye.attack((Bad)badGuys.get(curBadGuy));
        else
        {
            getLand().battleskye.attackSpecial((Bad)badGuys.get(curBadGuy));
            getLand().battleskye.setCurMP(0);
        }
        special = false;
        getLand().removeObjects(getLand().getObjects(BattleMenu.class));
        removeSelfAndCheck();
    }
    public void upBadGuy()
    {
        curBadGuy +=1;
        if (curBadGuy == badGuys.size())
        curBadGuy = 0;
        setLocation(badGuys.get(curBadGuy).getX(),badGuys.get(curBadGuy).getY());
    }
    public void downBadGuy()
    {
        curBadGuy -=1;
        if (curBadGuy == -1)
        curBadGuy = badGuys.size()-1;
        setLocation(badGuys.get(curBadGuy).getX(),badGuys.get(curBadGuy).getY());
    }
    public void pickEnemy()
    {
        if (badGuys.size() == 0) return;
        if (badGuys.get(curBadGuy).getCurHP() <= 0)
        {
            badGuys = getLand().getObjects(Bad.class);
            if (badGuys.size() == 0) return;
            curBadGuy = 0;
        }
        setLocation(badGuys.get(curBadGuy).getX(), badGuys.get(curBadGuy).getY());
        if (Greenfoot.isKeyDown("down") && delay == 0)
        {
            delay = -10;
            downBadGuy();
        }
        if (Greenfoot.isKeyDown("up") && delay == 0)
        {
            delay = -10;
            upBadGuy();
        }
        if (Greenfoot.isKeyDown("enter") && delay ==0)
        {
            delay = -10;
            attackBadGuy();
        }
    }
    /**
     * menu item method
     */
    public void scrollItemMenu()
    {
        if (getLand().items.size() == 0) return;
        if (Greenfoot.isKeyDown("down") && delay == 0)
        {
            delay = -10;
            if (getOneIntersectingObject(Item.class) != null)
            itemDown();
            else
            if (getOneIntersectingObject(Bad.class) != null)
            downBadGuy();
            else
            downGoodGuy();
        }
        else
        if (Greenfoot.isKeyDown("up") && delay == 0)
        {
            delay = -10;
            if (getOneIntersectingObject(Item.class) != null)
            itemUp();
            else
            if (getOneIntersectingObject(Bad.class) != null)
            upBadGuy();
            else
            upGoodGuy();
        }
        else
        if (Greenfoot.isKeyDown("enter") && delay == 0)
        {
            delay = -10;
            useItem();
        }
    }
    public void itemDown()
    {
        if (getOneIntersectingObject(Tooltip.class) != null)
        getLand().removeObject(getOneIntersectingObject(Tooltip.class));
        curItem ++;
        if (curItem == getLand().items.size())
        curItem = 0;
        setLocation(getLand().items.get(curItem).getX()+125, getLand().items.get(curItem).getY() );
    }
    public void itemUp()
    {
        if (getOneIntersectingObject(Tooltip.class) != null)
        getLand().removeObject(getOneIntersectingObject(Tooltip.class));
        curItem--;
        if (curItem == -1)
        curItem = getLand().items.size()-1;
        setLocation(getLand().items.get(curItem).getX()+125, getLand().items.get(curItem).getY() );
    }
    public void useItem()
    {
        item = getLand().items.get(curItem);
        if (item.isForEnemy())
        {
            if (getOneIntersectingObject(Item.class) != null)
            {
                badGuys = getLand().getObjects(Bad.class);
                while (curBadGuy >= badGuys.size()) curBadGuy--;
                setLocation(badGuys.get(curBadGuy).getX(),badGuys.get(curBadGuy).getY());
                getLand().removeItemMenu();
            }
            else
            {
                item.useItem(badGuys.get(curBadGuy));
                getLand().skyeMenuOpen = false;
                getLand().removeObjects(getLand().getObjects(BattleMenu.class));
                removeSelfAndCheck();
            }
        }
        else
        {
            if (getOneIntersectingObject(Item.class) != null)
            {
                goodGuys = getLand().getObjects(Good.class);
                while (curGoodGuy >= goodGuys.size()) curGoodGuy--;
                setLocation(goodGuys.get(curGoodGuy).getX(),goodGuys.get(curGoodGuy).getY());
                getLand().removeItemMenu();
            }
            else
            {
                getLand().items.get(curItem).useItem((Good)goodGuys.get(curGoodGuy));
                getLand().skyeMenuOpen = false;
                getLand().removeObjects(getLand().getObjects(BattleMenu.class));
                removeSelfAndCheck();
            }
        }
    }
    public void upGoodGuy()
    {
        curGoodGuy +=1;
        if (curGoodGuy == goodGuys.size())
        curGoodGuy = 0;
        setLocation(goodGuys.get(curGoodGuy).getX(), goodGuys.get(curGoodGuy).getY());
    }
    public void downGoodGuy()
    {
        curGoodGuy -=1;
        if (curGoodGuy == -1)
        curGoodGuy = goodGuys.size()-1;
        setLocation(goodGuys.get(curGoodGuy).getX(),goodGuys.get(curGoodGuy).getY());
    }
    /**
     * 
     * Defend teammate
     */
    public void scrollTeamMateDefend()
    {
        if (Greenfoot.isKeyDown("down") && delay == 0)
        {
            delay = -10;
            downGoodGuy();
        }
        else
        if (Greenfoot.isKeyDown("up") && delay == 0)
        {
            delay = -10;
            upGoodGuy();
        }
        else
        if (Greenfoot.isKeyDown("enter") && delay == 0)
        {
            delay = -10;
            getLand().battleskye.defendTeamMate(goodGuys.get(curGoodGuy) );
                getLand().skyeMenuOpen = false;
                getLand().removeObjects(getLand().getObjects(BattleMenu.class));
                removeSelfAndCheck();
        }
    }
    public void removeSelfAndCheck()
    {
        if (getLand().theodoreMenuOpen)
        {
            getLand().loadTheodoreBattleMenu();
            getLand().addObject(getLand().gamePointer2, 430, 87);
            getLand().gamePointer2.reset();
        }
        getLand().removeObject(this);
    }
}
