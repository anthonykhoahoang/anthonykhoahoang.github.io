import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class DefendEarth here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class DefendEarth extends MainMenu
{
    
    public void act() 
    {
       
        if (Greenfoot.mouseClicked(this))
        getSpace().loadGameType2();
    }    
}
