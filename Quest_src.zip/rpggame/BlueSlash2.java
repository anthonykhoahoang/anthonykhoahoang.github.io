import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class BlueSlash2 here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class BlueSlash2 extends Slash
{
    private GreenfootImage slash = new GreenfootImage("Battle/BlueSlash2.png");
    public BlueSlash2()
    {
        setImage(slash);
    }
    public void act() 
    {
        super.act();
    }    
}
