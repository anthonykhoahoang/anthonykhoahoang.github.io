import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.util.*;
/**
 * Write a description of class EatBoy here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class EatBoy  extends ScrollActor
{
    private int imgWidth, imgHeight;
    //Direction facing: 0 = west, 1 = east
    private int direction = 1;
    
    //Animation state - 0=standing, 1=running, 2 = falling, 3 = hurt
    private int animState = 0;
    
    //Stand animation variables
    private static GreenfootImage[] standImg;
    private int maxStandDelay = 12;
    private int standCur = 0;
    private int standDelay = maxStandDelay;    
    
    //Fall variables
    private static GreenfootImage fallImg;
    private static double fallSpeedIncrement = 0.2;
    private double fallSpeed = 0.0;
    private boolean isFalling = false;
    
    //Run variables
    private static int runSpeed = 4;
    private int runSpeedDefault = 4;
    
    //Run animation variables
    private static GreenfootImage[] runImg;
    private int maxRunDelay = 6;
    private int runCur = 0;
    private int runDelay = maxRunDelay;
    
    //Jump variables
    private int maxJumpSpeed = 10;
    private boolean isJumping = false;
    private double jumpSpeed = 0.0;
    private int jumpDelay = 0;
    private int maxJumpDelay = 8;
    private int jumpTimer = 0;
    private int jumpTimerMax = 80;
    
    //Hurt animation variables
    private static GreenfootImage[] hurtImg;
    private int maxHurtDelay = 4;
    private int hurtCur = 0;
    private int hurtDelay = maxHurtDelay;
    private boolean isHurt = false;
    private boolean isDead = false;
    
    //Immune duration variables
    private Timer immuneTimer;
    
    
    public EatBoy(int realX, int realY)
    {
        super(realX, realY);
        loadImages();
        imgWidth = standImg[0].getWidth();
        imgHeight = standImg[0].getHeight();
    }
    
    public void loadImages()
    {
        fallImg = new GreenfootImage("images/supereatboy/fall1.png");
        
        standImg = new GreenfootImage[22];
        standImg[0] = new GreenfootImage("images/supereatboy/stand1.png");
        standImg[1] = new GreenfootImage("images/supereatboy/stand2.png");
        standImg[2] = new GreenfootImage("images/supereatboy/stand3.png");
        standImg[3] = new GreenfootImage("images/supereatboy/stand4.png");
        standImg[4] = new GreenfootImage("images/supereatboy/stand5.png");
        standImg[5] = new GreenfootImage("images/supereatboy/stand6.png");
        standImg[6] = new GreenfootImage("images/supereatboy/stand7.png");
        standImg[7] = new GreenfootImage("images/supereatboy/stand8.png");
        standImg[8] = new GreenfootImage("images/supereatboy/stand9.png");
        standImg[9] = new GreenfootImage("images/supereatboy/stand10.png");
        standImg[10] = new GreenfootImage("images/supereatboy/stand11.png");
        standImg[11] = new GreenfootImage("images/supereatboy/stand12.png");
        standImg[12] = new GreenfootImage("images/supereatboy/stand13.png");
        standImg[13] = new GreenfootImage("images/supereatboy/stand14.png");
        standImg[14] = new GreenfootImage("images/supereatboy/stand15.png");
        standImg[15] = new GreenfootImage("images/supereatboy/stand16.png");
        standImg[16] = new GreenfootImage("images/supereatboy/stand17.png");
        standImg[17] = new GreenfootImage("images/supereatboy/stand18.png");
        standImg[18] = new GreenfootImage("images/supereatboy/stand19.png");
        standImg[19] = new GreenfootImage("images/supereatboy/stand20.png");
        standImg[20] = new GreenfootImage("images/supereatboy/stand21.png");
        standImg[21] = new GreenfootImage("images/supereatboy/stand22.png");
        
        runImg = new GreenfootImage[8];
        runImg[0] = new GreenfootImage("images/supereatboy/run1.png");
        runImg[1] = new GreenfootImage("images/supereatboy/run2.png");
        runImg[2] = new GreenfootImage("images/supereatboy/run3.png");
        runImg[3] = new GreenfootImage("images/supereatboy/run4.png");
        runImg[4] = new GreenfootImage("images/supereatboy/run5.png");
        runImg[5] = new GreenfootImage("images/supereatboy/run6.png");
        runImg[6] = new GreenfootImage("images/supereatboy/run7.png");
        runImg[7] = new GreenfootImage("images/supereatboy/run8.png");
        
        hurtImg = new GreenfootImage[2];
        hurtImg[0] = new GreenfootImage("images/supereatboy/hurt1.png");
        hurtImg[1] = new GreenfootImage("images/supereatboy/hurt2.png");
    }
    
    public void act() 
    {       
        checkCollision();
        checkImmuneCounter();
        checkRun();
        if (!isJumping)
            checkFall();
        checkJump();
        animate();
        super.act();
        if (isDead)
            getWorld().removeObject(this);
    }
    
    private void checkJump()
    {
        if (!isFalling)
        {
            if (Greenfoot.isKeyDown("up") || Greenfoot.isKeyDown("space"))
            {
                if (jumpDelay <= 0)
                {
                    if (!isJumping)
                    {
                        jumpSpeed = maxJumpSpeed;
                        jumpDelay = maxJumpDelay;
                        Greenfoot.playSound("sounds/Jump.wav");
                        for (int j = 0; j < 4; j++)
                        {
                            getWorld().addObject(new DustParticle(180, 
                            getRealX() - getImage().getWidth()/4,
                            getRealY() + getImage().getHeight()/2), 0, 0);
                            getWorld().addObject(new DustParticle(0,
                            getRealX()+getImage().getWidth()/4, getRealY()+getImage().getHeight()/2), 0, 0);
                        }
                    }
                    isJumping = true;
                }
                else if (jumpSpeed-fallSpeed < 1 && jumpTimer < jumpTimerMax)//flying
                {
                    jumpSpeed += fallSpeed + fallSpeedIncrement/2;
                }
                if (jumpTimer < jumpTimerMax)
                    jumpTimer++;
                else
                {
                    isJumping = false;
                    isFalling = true;
                    jumpTimer = 0;
                }
            }
            if (isJumping)
            {
                if (jumpSpeed-fallSpeed > 1)
                    fallSpeed += fallSpeedIncrement/2;
                jumpSpeed -= fallSpeed;
                
                int oldRealY = getRealY();
                while ((!isWallAbove() || !isWallWayAbove())&& Math.abs(getRealY() - oldRealY) < jumpSpeed)
                    setRealLocation(getRealX(), getRealY() - 1);
                
                //setRealLocation(getRealX(), (int)(getRealY() - jumpSpeed));
                if (jumpSpeed <= 0)
                {
                    isJumping = false;
                    isFalling = true;
                    //fallSpeed = 0;
                }
            }
            else 
            if (jumpDelay > 0)
                jumpDelay--;
        }
    }
    
    private void animate()
    {
        if (isHurt)
            animState = 3;
        else if (isFalling || isJumping)
            animState = 2;
        if (animState == 0)
            animateStand();
        else if (animState == 1)
            animateRun();
        else if (animState == 2)
            animateFall();
        else if (animState == 3)        
            animateHurt();
    }
    
    public void hit()
    {
        isHurt = true;
    }
    
    public void checkCollision()
    {
        if (isHurt)
            return;
        List<BadFood> listBadFood = getIntersectingObjects(BadFood.class);
        for (BadFood bf : listBadFood)
        {
            int bfHeight = bf.getImage().getHeight();
            if (bf.getRealY() - bfHeight/2 <= getRealY())
            {
                isHurt = true;
                immuneTimer = new Timer(0.023, true);          
                List<Hud> listHud = getWorld().getObjects(Hud.class);
                for (Hud hd : listHud)
                {
                    hd.eatBoyHurtCalculation();
                    if (hd.isDead())
                    {
                        die();
                        return;
                    }
                    else                    
                        Greenfoot.playSound("sounds/Super Eat Boy Getting Hit Sound.wav");
                }
                return;
            }
            else if (bf.isActive())
            {
                bf.die();
                Greenfoot.playSound("sounds/Chomp1.wav");
                jumpSpeed = maxJumpSpeed;
                jumpDelay = maxJumpDelay;
                isFalling = false;
                isJumping = true;
                fallSpeed = 0.0;
                for (int j = 0; j < 4; j++)
                        {
                            getWorld().addObject(new DustParticle(180, 
                            getRealX() - getImage().getWidth()/4,
                            getRealY() + getImage().getHeight()/2), 0, 0);
                            getWorld().addObject(new DustParticle(0,
                            getRealX()+getImage().getWidth()/4, getRealY()+getImage().getHeight()/2), 0, 0);
                        }
            }
        }
        List<GoodFood> listGoodFood = getIntersectingObjects(GoodFood.class);
        for (GoodFood gf : listGoodFood)
        {
            gf.die();
            if ( (int)(Math.random()*2) == 1)
                Greenfoot.playSound("sounds/Chomp2.wav");
            else
                Greenfoot.playSound("sounds/Chomp3.wav");            
        }
    }
    
    private void runLowerBloodSugar()
    {
        List<Hud> listHud = getWorld().getObjects(Hud.class);
        for (Hud hd : listHud)
        {
            hd.eatBoyRunCalculation();
            if (hd.isDead())
            {
                die();
                return;
            }
        }
        return;
    }
    
    private void checkImmuneCounter()
    {
        if (isHurt && immuneTimer != null)
        {
            immuneTimer.updateTime();
            if (immuneTimer.toString().equals("00:00"))
                isHurt = false;
        }
    }
    
    private void animateHurt()
    {
        if (hurtDelay >= maxHurtDelay)
        {
            if (hurtCur >= hurtImg.length)
                hurtCur = 0;
            setImage(new GreenfootImage(hurtImg[hurtCur]));
            if (direction == 0)
                getImage().mirrorHorizontally();
            hurtCur++;            
            hurtDelay = 0;
        }
        else
            hurtDelay++;
    }
    
    private boolean isWallToEast()
    {
        return getWorld().isBlackAt(getRealX() + imgWidth/2, getRealY())
        || getWorld().isBlackAt(getRealX() + imgWidth/2, getRealY() - imgHeight/4);
    }
    
    private boolean isWallToWest()
    {
        return getWorld().isBlackAt(getRealX() - imgWidth/2, getRealY())
        || getWorld().isBlackAt(getRealX() - imgWidth/2, getRealY() - imgHeight/4);
    }
    
    private boolean isWallAbove()
    {
        return getWorld().isBlackAt(getRealX() + imgWidth/2, getRealY() - imgHeight/2)
        || getWorld().isBlackAt(getRealX() - imgWidth/2, getRealY() - imgHeight/2);
    }
    
    private boolean isWallWayAbove()
    {
        return getWorld().isBlackAt(getRealX() + imgWidth/2, getRealY() - 2*imgHeight)
        || getWorld().isBlackAt(getRealX() - imgWidth/2, getRealY() - 2*imgHeight);
    }
    
    private void animateFall()
    {
        setImage(new GreenfootImage(fallImg));
        if (direction == 0)
            getImage().mirrorHorizontally();        
    }
    
    private void animateRun()
    {
        if (runDelay >= maxRunDelay)
        {
            if (runCur >= runImg.length)
                runCur = 0;
            setImage(new GreenfootImage(runImg[runCur]));
            if (direction == 0)
                getImage().mirrorHorizontally();
            runCur++;            
            runDelay = 0;
        }
        else
            runDelay++;
    }
    
    private void checkRun()
    {
        if (Greenfoot.isKeyDown("right") || Greenfoot.isKeyDown("d"))
        {              
            runLowerBloodSugar();
            if (isHurt)
                runSpeed = 2;
            else
                runSpeed = runSpeedDefault;
            if (direction == 0)     
            {
                for (int j = 0; j < 4; j++)
                {
                    getWorld().addObject(new DustParticle(180, 
                    getRealX() - getImage().getWidth()/4,
                    getRealY() + getImage().getHeight()/2), 0, 0);
                }
            }
            animState = 1;
            direction = 1;
            int oldRealX = getRealX();
            while (!isWallToEast() && getRealX() - oldRealX < runSpeed)
            {
                setRealLocation(getRealX() + 1, getRealY());
                if (!isFalling && !isJumping)
                {
                    while (isGroundBelow())
                        setRealLocation(getRealX(), getRealY() - 1);
                    if (!isGroundBelow())
                            setRealLocation(getRealX(), getRealY() + 1);
                    if (!isFalling && !isJumping)
                    {
                        int oldRealY = getRealY();
                        //int imgHeight = getImage().getHeight();
                        while (!isGroundBelow() && getRealY() - oldRealY < imgHeight/16)
                            setRealLocation(getRealX(), getRealY() + 1);
                    }
                }
                    /*
                int oldRealY = getRealY();
                int imgHeight = getImage().getHeight();
                while (!isGroundBelow() && Math.abs(getRealY() - oldRealY) < imgHeight/4)
                    setRealLocation(getRealX(), getRealY() + 1);
                    */
            }
        }
        else if (Greenfoot.isKeyDown("left") || Greenfoot.isKeyDown("a"))
        { 
            runLowerBloodSugar();
            if (isHurt)
                runSpeed = 2;
            else
                runSpeed = runSpeedDefault;
            if (direction == 1)     
            {
                for (int j = 0; j < 4; j++)
                {
                    getWorld().addObject(new DustParticle(0, 
                    getRealX() - getImage().getWidth()/4,
                    getRealY() + getImage().getHeight()/2), 0, 0);
                }
            }
            animState = 1;
            direction = 0;
            int oldRealX = getRealX();
            while (!isWallToWest() && Math.abs(getRealX() - oldRealX) < runSpeed)
            {
                setRealLocation(getRealX() - 1, getRealY());
                if (!isFalling && !isJumping)
                {
                    while (isGroundBelow())
                        setRealLocation(getRealX(), getRealY() - 1);
                    if (!isGroundBelow())
                            setRealLocation(getRealX(), getRealY() + 1);
                    if (!isFalling && !isJumping)
                    {
                        int oldRealY = getRealY();
                        //int imgHeight = getImage().getHeight();
                        while (!isGroundBelow() && getRealY() - oldRealY < imgHeight/16)
                            setRealLocation(getRealX(), getRealY() + 1);
                    }
                }
            }
        }
        else
        {
            animState = 0;
            runCur = 0;
            runDelay = maxRunDelay;
        }
    }
    
    private void checkFall()
    {
        //int imgHeight = getImage().getHeight();
        //int imgWidth = getImage().getWidth();
        isFalling = !isGroundBelow();
        
        if (isFalling)
        {
            fallSpeed += fallSpeedIncrement;
            int oldRealY = getRealY();
            while (!isGroundBelow() && getRealY() - oldRealY < fallSpeed)
                setRealLocation(getRealX(), getRealY() + 1);
            if (isGroundBelow())
            {
                standDelay = maxStandDelay;
                for (int j = 0; j < 4; j++)
                {
                    getWorld().addObject(new DustParticle(180, 
                    getRealX() - getImage().getWidth()/4,
                    getRealY() + getImage().getHeight()/2), 0, 0);
                    getWorld().addObject(new DustParticle(0,
                    getRealX()+getImage().getWidth()/4, getRealY()+getImage().getHeight()/2), 0, 0);
                }
            }
        }
        else
        {
            fallSpeed = 0;
        }
    }
    
    private boolean isGroundBelow()
    {
        //int imgHeight = getImage().getHeight();
        //int imgWidth = getImage().getWidth();
        return getWorld().isBlackAt(getRealX(), getRealY() + imgHeight/2)
        || getWorld().isBlackAt(getRealX() + imgWidth/4, getRealY() + imgHeight/2) 
        || getWorld().isBlackAt(getRealX() - imgWidth/4, getRealY() + imgHeight/2);        
    }
    
    private void animateStand()
    {
        if (standDelay >= maxStandDelay)
        {
            if (standCur >= standImg.length)
                standCur = 0;
            setImage(new GreenfootImage(standImg[standCur]));
            if (direction == 0)
                getImage().mirrorHorizontally();
            standCur++;
            standDelay = 0;
        }
        else
            standDelay++;
    }
    
    public void die()
    {
        for (int i = 0; i < 360; i+=10)
            getWorld().addObject(new YellowParticle(i, getRealX(), getRealY()+10), 0, 0);
        getWorld().addObject(new DeadEatBoy(getRealX(), getRealY()), 0, 0);    
        isDead = true;
        Greenfoot.playSound("sounds/Explosion.wav");
    }
}
