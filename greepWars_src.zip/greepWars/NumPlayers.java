import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * allows user to choose 1/2 player mode
 * 
 * @author Anthony Hoang
 * @version 2.1
 */
public class NumPlayers extends GameMode
{
    /**
     * Act - do whatever the NumPlayers wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
        // Add your action code here.
    }    
}
