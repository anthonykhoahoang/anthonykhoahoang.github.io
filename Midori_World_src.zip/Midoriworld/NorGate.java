import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Nor here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class NorGate  extends LGGates
{
    private static GreenfootImage img;
    public NorGate()
    {
        super("NOR");
        if (img == null)
        img = new GreenfootImage("logicgates/nor.png");
        setImage(img);
    }
    public void act() 
    {
        super.act();
    }    
}
