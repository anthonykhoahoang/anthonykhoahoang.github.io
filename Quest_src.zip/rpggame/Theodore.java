import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Theodore here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Theodore extends InGameChar
{
    private boolean returnToSkye = false;
    public Theodore (double scale)
    {
        getImage().scale((int)(getImage().getWidth()*scale), (int)(getImage().getHeight()*scale));
    }
    public void act() 
    {
        if (returnToSkye)
        {
            if (getOneIntersectingObject(InGameChar.class) != null)
            {
                if (getImage().getWidth() > 5 && getImage().getHeight() > 5)
                getImage().scale(getImage().getWidth()-5,getImage().getHeight()-5);
                else
                getLand().removeObject(this);
                return;
            }
            else
            {
                turnTo();
                move();
                setRotation(0);
            }
        }
        if (getObjectsInRange(400, Text.class).size() == 0)
        returnToSkye = true;
        
    }    
    public void turnTo()
    {
        Actor a = (Actor)getLand().getObjects(InGameChar.class).get(0);
        int deltaX = (a.getX() - getX());
        int deltaY = (a.getY() - getY());
        setRotation((int) (180 * Math.atan2(deltaY, deltaX) / Math.PI));
    }
    public void move()
    {
        double angle = Math.toRadians( getRotation() );
        int x = (int) Math.round(getX() + Math.cos(angle) * getImage().getWidth()/3);
        int y = (int) Math.round(getY() + Math.sin(angle) * getImage().getWidth()/3);
        setLocation(x, y);
    }
}
