import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Bullet2 - level 2 of the bullet the rocket can shoot.
 * 
 * @author (Anthony Hoang) 
 * @version (2.0)
 */
public class Bullet2 extends Bullet
{
    public Bullet2 (Vector speed, int rotation, int dmg, boolean sounds, Rocket rocket)
    {
        super(speed, rotation, dmg+10, false, rocket);
        if (sounds)
        Greenfoot.playSound("bullet2.wav");
    }
    public void act() 
    {
        super.act();
    }    
}
