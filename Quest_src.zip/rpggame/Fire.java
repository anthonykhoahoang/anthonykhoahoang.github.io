import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Fire here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Fire extends BattleEffects
{
    private GreenfootImage image = new GreenfootImage("Battle/fire.png");
    private int acts = 0;
    public Fire()
    {
        Greenfoot.playSound("thunder.wav");
        setImage(image);
    }
    public void act() 
    {
        if (acts < 10)
        {
            getImage().scale(getImage().getWidth()+3, getImage().getHeight()+3);
            acts++;
        }
        if (acts == 10)
        acts = 20;
        
        if (acts == 20)
        {
            if (getImage().getHeight() <= 10 || getImage().getWidth() <= 10)
            getLand().removeObject(this);
            else
            getImage().scale(getImage().getWidth()-10, getImage().getHeight()-10);
            
        }
    }    
}
