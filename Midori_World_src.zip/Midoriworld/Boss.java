import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Boss here.
 * 
 * @author Anthony Hoang
 * @version (v1)
 */
public class Boss  extends HostileEnemy
{
    private int hpMax;
    private int hp;
    private boolean movingTo = false;
    private int moveSpeed = 3;
    private int[] coord = new int[2];
    private ActionScript actionScript;
    private String actionScriptFile;
    private boolean firstInitialize = true;
    public boolean isPaused = false;
    
    public Boss()
    {
    }
    public Boss(int hp, String aSFile)
    {
        actionScriptFile = aSFile;
        hpMax = hp;
        this.hp = hp;
    }
    public void act() 
    {
        if (getMWorld().esPause) return;
        if (firstInitialize)
        {
            firstInitialize = false;
            actionScript = new ActionScript(actionScriptFile,this);
            getMWorld().addObject(actionScript,0,0);
            getMWorld().addObject(new BossHP(),866,247);
        }
        if (isPaused) 
        {
            for (int i = 0; i < 4; i++)
            getMWorld().addObject(new SmokeParticle((int)(Math.random()*360)),getX(),getY());
            return;
        }
        if (movingTo)
        moveTo();
        super.act();
    }   
    public boolean isPaused()
    {
        return isPaused;
    }
    public void setMoveSpeed(int s)
    {
        moveSpeed = s;
    }
    public void setMoveTo(int x, int y)
    {
        movingTo = true;
        coord[0] = x;
        coord[1] = y;
    } 
    public void moveTo()
    {
        int y2 = getY(), x2 = getX();
        int x = coord[0], y = coord[1];

        if (y2 < y)
        y2+=moveSpeed;
        if (y2 > y)
        y2-=moveSpeed;
        if (x2 < x)
        x2+=moveSpeed;
        if (x2 > x)
        x2-=moveSpeed;
        

        setLocation(x2,y2);
        if (Math.abs(y-y2) < moveSpeed && Math.abs(x-x2) < moveSpeed)
        movingTo = false;
    }
    public int getHP()
    {
        return hp;
    }
    public int getHPMax()
    {
        return hpMax;
    }
    public void fireRed()
    {
        getMWorld().addObject(new FollowProjectileRed(),getX(),getY());
    }
    public void fireRed(int r) // no follow
    {
        getMWorld().addObject(new NonFollowProjectileRed(r),getX(),getY());
    }
    public void fireSmallRed()
    {
        getMWorld().addObject(new FollowSmallProjectileRed(),getX(),getY());
    }
    public void fireSmallRed(int r) // no follow
    {
        getMWorld().addObject(new NonFollowSmallProjectileRed(r),getX(),getY());
    }
    public void redExplosion()
    {
        for (int i = 0; i < 36; i++)
        fireRed(i*10);
    }
    public void redExplosion(int amount)
    {
        for (int i = 0; i < amount; i++)
        fireRed(i*10);
    }
    public void redExplosionRandom()
    {
        for (int i = 0; i < 36; i++)
        fireRed((int)(Math.random()*360));
    }
    public void redExplosionRandom(int amount)
    {
        for (int i = 0; i < amount; i++)
        fireRed((int)(Math.random()*360));
    }
    public void smallRedExplosion()
    {
        for (int i = 0; i < 36; i++)
        fireSmallRed(i*10);
    }
    public void smallRedExplosion(int amount)
    {
        for (int i = 0; i < amount; i++)
        fireSmallRed(i*10);
    }
    public void smallRedExplosionRandom()
    {
        for (int i = 0; i < 36; i++)
        fireSmallRed((int)(Math.random()*360));
    }
    public void smallRedExplosionRandom(int amount)
    {
        for (int i = 0; i < amount; i++)
        fireSmallRed((int)(Math.random()*360));
    }
    public void fireEnergySpike(int r)
    {
        getMWorld().addObject(new EnergyDrainSpike(r),getX(),getY());
    }
    public void energyDrainExplosion()
    {
        for (int i = 0; i < 36; i++)
        fireEnergySpike(i*10);
    }
    public void energyDrainExplosion(int amount)
    {
        for (int i = 0; i < amount; i++)
        fireEnergySpike(i*10);
    }
    public void energyDrainExplosionRandom()
    {
        for (int i = 0; i < 36; i++)
        fireEnergySpike((int)(Math.random()*360));
    }
    public void energyDrainExplosionRandom(int amount)
    {
        for (int i = 0; i < amount; i++)
        fireEnergySpike((int)(Math.random()*360));
    }
    public void hit()
    {
        hp -= 10;
        if (hp < 0) hp = 0;
        //if (hp <= 0)
        //hasHit = true;
    }
    public void die()
    {
        for (int i = 0; i < 2; i++)
        {
            getMWorld().addObject(new SmokeParticle((int)(Math.random()*360)),getX(),getY());
            getMWorld().addObject(new SmallYellowParticle((int)(Math.random()*360)), getX(), getY());
        }
        GreenfootImage img = new GreenfootImage(getImage());
        int w = img.getWidth()-1;
        int h = img.getHeight()-1;
        if (w < 1 || h < 1) 
        {
            for (int i = 0; i < 30; i++)
            {
                int r = (int)(Math.random()*10);
                getMWorld().addObject(new SmokeParticle((int)(Math.random()*360)),getX()+r,getY()+r);
                getMWorld().addObject(new SmokeParticle((int)(Math.random()*360)),getX()-r,getY()-r);
                getMWorld().addObject(new SmokeParticle((int)(Math.random()*360)),getX(),getY());
                getMWorld().addObject(new SmokeParticle((int)(Math.random()*360)),getX()-r,getY()+r);
                getMWorld().addObject(new SmokeParticle((int)(Math.random()*360)),getX()+r,getY()-r);
                getMWorld().addObject(new SmallYellowParticle((int)(Math.random()*360)), getX(), getY());
            }
            getMWorld().removeObject(this);
            return;
        }
        else
        img.scale(w,h);
        setImage(img);
    }
    public void setHasHit(boolean b)
    {
        hasHit = b;
    }
}
