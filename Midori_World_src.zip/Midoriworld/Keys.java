import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.util.List;
import java.awt.Color;
import java.awt.Font;
/**
 * Write a description of class Keys here.
 * 
 * @author Anthony Hoang
 * @version (v1)
 */
public class Keys  extends Menu
{
    public boolean isSelected = false;
    private boolean firstInitialize = true;
    public boolean redraw = true;
    public Keys()
    {
    }
    public Keys(String s)
    {
        setImage(new GreenfootImage(100, 50));
        Font font = getImage().getFont();
        font = font.deriveFont(25f);
        getImage().setFont(font);
        getImage().setColor(Color.WHITE);
        getImage().drawString(s, 2, 25);
        getImage().setTransparency(0);
    }
    public void act() 
    {
        if (firstInitialize)
        {
            int t = getImage().getTransparency()+10;
            if (t >200)
            firstInitialize = false;
            else
            getImage().setTransparency(t);
            return;
        }
        if (closing)
        {
            int t = getImage().getTransparency()-10;
            if (t < 0)
            getMWorld().removeObject(this);
            else
            getImage().setTransparency(t);
            return;
        }
        if (Greenfoot.mouseClicked(this))
        select();
        if (isSelected)
        {
            doChange();
        }
        else
        doNoChange();
    }   
    public void redraw()
    {
        redraw = true;
    }
    public void doNoChange(){}
    public void doChange()
    {
        isSelected = false;
    }
    public void deselect()
    {
        redraw();
        isSelected = false;
    }
    public void select()
    {
        List<Keys> list = getMWorld().getObjects(Keys.class);
        for (Keys k : list)
        k.deselect();
        isSelected = true;
        redraw = true;
    }
}
