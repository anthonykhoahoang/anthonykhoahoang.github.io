import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.awt.Color;
/**
 * Write a description of class HoloCircle here.
 * 
 * @author Anthony Hoang
 * @version (v1)
 */
public class HoloCircle  extends PhoneHolos
{
    private GreenfootImage image;
    private boolean onTarget = false;
    private int x, y;
    private boolean firstInitialize = true;
    public HoloCircle(int x, int y)
    {
        this.x = x; 
        this.y = y;
        image = new GreenfootImage("holosquare.png");
        image.setTransparency(0);
        setImage(image);
    }
    public void act() 
    {
        if (getMWorld().gamePause) return;
        setRotation(getRotation()+1);
        if (firstInitialize)
        {
            int t = getImage().getTransparency()+4;
            if (t > 200)
            firstInitialize = false;
            else
            getImage().setTransparency(t);
        }
        if (!onTarget)
        {
            int y2 = getY(), x2 = getX();
            if (getY() < y)
            y2+=4;
            if (x2 < x)
            x2+=4;
            setLocation(x2,y2);
            if (Math.abs(y-y2) < 4 && Math.abs(x-x2) < 4)
            onTarget = true;
        }
        super.act();
    }    
}
