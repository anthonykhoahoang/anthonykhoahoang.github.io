import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class BT2 here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class BT2 extends BulletType2
{
    public int acts = 15;
    public BT2( int dmg, boolean sound, Type1 p, int rot)
    {
        super(dmg, false, p, rot);
        if (sound)
        Greenfoot.playSound("bullet1.wav");
    }
    public void act() 
    {
        acts--;
        if (acts <= 15 && acts > 7)
        {
            moveRight();
        }
        else
        if (acts<= 7 && acts >0)
        moveLeft();
        super.act();
    }    
    public void addToPlane()
    {
        acts= 15;
        super.addToPlane();
    }
    public void superAct()
    {
        super.act();
    }
}
