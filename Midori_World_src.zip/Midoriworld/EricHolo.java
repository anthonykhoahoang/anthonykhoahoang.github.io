import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
/**
 * Write a description of class EricHolo here.
 * 
 * @author Anthony Hoang
 * @version (v1)
 */
public class EricHolo  extends PhoneHolos
{
    
    private int delay = 1;
    private int acts = 0;
    private boolean firstInitialize = true;
    
    private boolean dec = true;
    private int t = 200;
    public EricHolo()
    {
        setImage(new GreenfootImage("eric/holo/ericholo.png"));
        getImage().setTransparency(4);
    }
    public void act() 
    {
        if (getMWorld().gamePause) return;
        if (remove)
        super.act();
        else
        if (firstInitialize)
        {
            int t = getImage().getTransparency()+2;
            if (t > 200)
            firstInitialize = false;
            else
            getImage().setTransparency(t);
        }
        else
        if (acts > delay)
        {
            acts = 0;
            if (dec)
            {
                t -= 2;
                if (t < 110)
                dec = false;
            }
            else
            {
                t += 2;
                if (t > 200)
                dec = true;
            }
            getImage().setTransparency(t);
        }
        else acts++;
    }    
}
