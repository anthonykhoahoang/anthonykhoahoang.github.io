import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class DeadEatBoy here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class DeadEatBoy  extends DeadFood
{
    private static GreenfootImage img;
    private int acts = 0;
    
    public DeadEatBoy(int realX, int realY)
    {
        super(realX, realY);
        if (img == null)
            img = new GreenfootImage(1, 1);
        setImage(img);
    }
    
    public void act() 
    {
        setRotation(getRotation() + 10);
        setRealLocation(getRealX(), getRealY() - 1);
        for (int i = 0; i < 360; i+=10)
            getWorld().addObject(new YellowParticle(i, getRealX(), getRealY()+10), 0, 0);
        super.act();
        acts++;
        if (acts > 10)
        {
            getWorld().addObject(new GameOver(), 405, 244);
            getWorld().removeObject(this);
        }
    }    
}
