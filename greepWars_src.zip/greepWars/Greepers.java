import greenfoot.*;  
/**
 * Original Author of the greeps: Michael Kolling
 * Reimplemented by Anthony Hoang
 * These Greeps carry tomatoes as bombs and will blow up on contact with your rocket.
 */
public class Greepers extends Enemy
{
    private int acts = 0;
    public Greepers(int range)
    {
        super(10, 10);
        setRange(range);
        setRotation(Greenfoot.getRandomNumber(360));
    }
    public void act()
    {
        if (acts == 0)
        {
            turnToShip();
            acts = -20;
        }
        else
        acts++;
        if (atWorldEdge())
        turn(45);
        move2();
    }
}