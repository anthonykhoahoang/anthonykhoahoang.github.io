import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.awt.Color;
import java.awt.Font;
/**
 * Write a description of class KeyBackground here.
 * 
 * @author Anthony Hoang
 * @version (v1)
 */
public class MenuBackground  extends Menu
{
    private GreenfootImage img;
    private boolean firstInitialize = true;
    public MenuBackground()
    {
        img = new GreenfootImage(880,494);
        img.setTransparency(0);
        img.setColor(Color.BLACK);
        img.fill();
        setImage(img);
        img.setColor(Color.WHITE);
    }
    public void act() 
    {
        if (firstInitialize)
        {
            img.drawString("LOAD GAME CODE: "+getMWorld().curLoadGameCode, 20,20);
            int t = getImage().getTransparency()+5;
            if (t >120)
            firstInitialize = false;
            else
            getImage().setTransparency(t);
            return;
        }
        if (closing)
        {
            int t = getImage().getTransparency()-10;
            if (t < 0)
            getMWorld().removeObject(this);
            else
            getImage().setTransparency(t);
            return;
        }
    }    
    public void close()
    {
        closing = true;
    }
}
