import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.awt.Color;

/**
 * Write a description of class GameBoarder here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class GameBoarder extends WorldObjects
{
    public GameBoarder(int w, int h)
    {
        setImage(new GreenfootImage(w, h));
    }
    public GameBoarder(int w, int h, boolean canSee)
    {
        GreenfootImage i = new GreenfootImage(w,h);
        if (canSee)
        {
            i.setColor(Color.GREEN);
            i.fill();
        }
        setImage(i);
        
    }
    public void act() 
    {
        // Add your action code here.
    }    
}
