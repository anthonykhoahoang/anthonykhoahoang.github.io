import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.awt.Color;
import java.awt.Point;
import java.util.*;
/**
 * Write a description of class Land here.
 * 
 * @author Anthony Hoang
 * @version 1.0
 */
public class Land extends World
{
    public boolean isPause;
    public Display d;
    public String charName = "Skye";
    public int act = 0;
    public AudioPlayer stream0;
    public AudioPlayer stream1;
    public AudioPlayer stream2;
    public AudioPlayer stream3;
    public AudioPlayer stream4;
    public Skye skye = new Skye();
    public BattleSkye battleskye = new BattleSkye(50, 0, 100, 5);
    public BattleTheodore battletheodore = new BattleTheodore(70, 0, 150, 10);
    private Field f;
    public boolean theodoreMenuOpen = false;
    public boolean theodoreInParty = false;
    public String charName2 = "Theodore";
    
    public Pointer gamePointer = new Pointer();
    public Pointer2 gamePointer2 = new Pointer2();
    
    public boolean skyeMenuOpen = false;
    public boolean isBattle = false;
    public boolean canUseMagic = false;
    
    public int charLevel = 1;
    public int curEXP = 0;
    public int EXP = 20;
    private int battleEndDelay = -50;
    
    public ArrayList<Item> items;
    
    public Land()
    {    
        super(1024, 600, 1);
        setPaintOrder (FadeIn.class, GameOver.class, Tuturial.class, Item.class, Text.class, 
        EndOfBattleMenu.class, Pointer.class, Pointer2.class, 
        Battle.class, InGameChar.class);
        getBackground().setColor(Color.WHITE);
        getBackground().fill();
        //addObject(new Text("help", 400, 15), 512, 500);
        setBackground("storybackground.jpg");
        loadMenu();
        items = new ArrayList<Item>();
        addItem( new Item("Minor Healing Potion", 2, false));
        addItem( new Item("Minor Healing Potion", 10, false));
        addItem( new Item("Healing Potion", 5, false));
        
        addItem( new Item("Minor Healing Potion", 3, false));
        
        addItem( new Item("Potion", 4, false));
        addItem( new Item("Small Thunder Shard", 4, true));
        
        addItem( new Item("Minor Healing Potion", 2, false));
        
        stream0 = new AudioPlayer("intro", true);
        addObject(stream0, 0, 0);
        stream0.play();
        Greenfoot.start();
        
    }
    public String charName2()
    {
        return charName2;
    }
    public String charName()
    {
        return charName;
    }
    public void addItemMenu()
    {
        addObject(new ItemMenu(), this.getWidth()/2, this.getHeight()/2);
        showItems();
        removeObject(gamePointer);
        if (items.size() > 0)
        addObject(gamePointer, items.get(0).getX()+125, items.get(0).getY());
        else
        addObject(gamePointer, this.getWidth()/2, this.getHeight()/2);
    }
    public void addItemMenu2()
    {
        addObject(new ItemMenu(), this.getWidth()/2, this.getHeight()/2);
        showItems();
        removeObject(gamePointer2);
        if (items.size() > 0)
        addObject(gamePointer2, items.get(0).getX()+125, items.get(0).getY());
        else
        addObject(gamePointer2, this.getWidth()/2, this.getHeight()/2);
    }
    public void removeItemMenu()
    {
        removeObjects(getObjects(ItemMenu.class));
        removeObjects(getObjects(Item.class));
    }
    public void showItems()
    {
        removeUsedItems();
        int x = 162;
        int y = 92;
        for (int i = 0; i < items.size(); i++)
        {
            addObject(items.get(i), x, i*30+y);
        }
    }
    public void removeUsedItems()
    {
        for (int i = 0; i < items.size(); i++)
        {
            if (items.get(i).getAmount() <= 0)
            items.remove(i);
        }
    }
    public void addItem(Item a)
    {
        for (int i = 0; i < items.size(); i++)
        {
            Item t = items.get(i);
            if (t.getType().equals(a.getType()))
            {
                t.setAmount(t.getAmount()+a.getAmount());
                return;
            }
        }
        items.add(a);
    }
    public void removeKeyBoard()
    {
        removeObjects(getObjects(Keyboard.class));
        act++;
    }
    public void loadMenu()
    {
        removeMenuObjects();
        addObject(new Title(), 512, 142);
        addObject(new NewGame(), 512, 354 );
        addObject(new TutorialMenu(), 512, 417);
        addObject(new FadeOut(), this.getWidth()/2,this.getHeight()/2);
    }
    public void loadTutorialMenu()
    {
        removeMenuObjects();
        addObject(new fightbasics(), 144, 81);
        addObject(new fightbasics2(), 144, 160);
        addObject(new partydefendbasics(), 144, 233);
        addObject(new ReturnToMenu(), 866, 548);
    }
    public void removeMenuObjects()
    {
        removeObjects(getObjects(Menu.class));
    }
    public void act()
    {
        /*
        if (act == 1)
        {
            addObject(new FadeIn(), getWidth()/2, getHeight()/2);
            addObject(new Text("intro_1", 600, 20), 512, 400);
            stream0 = new AudioPlayer("intro", true);
            addObject(stream0, 0, 0);
            stream0.play();
            addObject(new LevelLoader("level1"), 571, 652);
            act++;
        }
        */
        if (isBattle) checkBattle();
    }
    public void newGame()
    {
        addObject(new FadeOut(), getWidth()/2, getHeight()/2);
        addObject(new Text("intro_1", 600, 20), getWidth()/2, getHeight()/2);
        
        addObject(new LevelLoader("level1"), 571, 569);
    }
    public void loadLevel(String str)
    {
        if (str.equals("lvl0")) loadLevel0();
    }
    public void loadLevel0()
    {
        setBackground("skyeRoom.jpg");
        addObject(skye, this.getWidth()/2,199);
        skye.scaleImages(2.2);
        addObject (new GameBoarder(1024, 50, false), 517, 0);
        addObject (new GameBoarder(500, 300, false), 185, 66);
        addObject (new GameBoarder(500, 300, false), 930, 59);
        //addObject (new GameBoarder(1024, 100, true), 508, 48);
        addObject (new GameBoarder(150, 500, false), 32, 446);
        addObject (new InfoLoader("howtonavigate"), 570, 372);
        addItem(new Item("Minor Healing Potion", 2, false));
    }
    public void loadSkyeBattleMenu()
    {
        if (!skyeMenuOpen) return;
        removeObjects(getObjects(BattleMenu.class));
        skyeMenuOpen = true;
        addObject(new BattleMenu(charName), 128, 128);
        addObject(new Attack(), 180, 87);
        addObject(new Defend(), 180, 123);
        addObject(new MenuItem(), 180, 158);
        if (canUseMagic)
        addObject(new MenuMagic(), 180, 193); 
        
        if (!theodoreMenuOpen)
        {
            addObject(gamePointer, 180, 87);
            gamePointer.reset();
            //removeObject(gamePointer2);
        }
    }
    public void loadTheodoreBattleMenu()
    {
        if (!theodoreMenuOpen) return;
        removeObjects(getObjects(BattleMenu2.class));
        theodoreMenuOpen = true;
        addObject(new BattleMenu2(charName2), 378, 128);
        addObject(new Attack2(), 430, 87);
        addObject(new Defend2(), 430, 123);
        addObject(new MenuItem2(), 430, 158);
        
        if (!skyeMenuOpen)
        {
            addObject(gamePointer2, 430, 87);
            gamePointer2.reset();
            //removeObject(gamePointer);
        }
    }
    public void removeSkyeBattleMenu()
    {
        removeObjects(getObjects(BattleMenu.class));
        removeObject(gamePointer);
        skyeMenuOpen = false;
        
        if (theodoreMenuOpen)
        loadTheodoreBattleMenu();
    }
    public void removeTheodoreBattleMenu()
    {
        removeObjects(getObjects(BattleMenu2.class));
        removeObject(gamePointer2);
        theodoreMenuOpen = false;
        
        if (skyeMenuOpen)
        loadSkyeBattleMenu();
    }
    public void exampleLoad()
    {
        isBattle = true;
        loadSkyeBattleMenu();
        addObject(new SkyeStats(charName, battleskye), 118, 761);
        addObject(battleskye, 300, 500);
        addObject(new BattleSoldier(10, 0, 500, 3), 700, 500);
        addObject(new BattleSoldier(10, 0, 450, 3), 700, 200);
        addObject(new BattleSoldier(10, 0, 480, 3), 700, 660);
        addObject(new BattleSoldier(10, 0, 510, 3), 700, 300);
    }
    public void loadBattleType1()
    {
        removeObjects(getObjects(Text.class));
        addObject(new FadeOut(), 512, 300);
        if (stream0 != null)
        stream0.stop();
        stream1 = new AudioPlayer("swamp_battle_theme", true);
        addObject(stream1, 0,0);
        stream1.play();
        f = new Field();
        f.setBackground(this.getBackground());
        addObject(f, 512, 300);
        isBattle = true;
        loadSkyeBattleMenu();
        addObject(battleskye, 300, 400);
        addObject(new SkyeStats(charName, battleskye), 124, 567);
        battleskye.setNormalPos(300,400);
        if (theodoreInParty)
        {
            loadTheodoreBattleMenu();
            addObject(battletheodore, 300, 300);
            addObject(new TheodoreStats(charName2, battletheodore), 348, 567);
            battletheodore.setNormalPos(300, 300);
        }
    }
    public void loadBattleType2()
    {
        removeObjects(getObjects(Text.class));
        addObject(new FadeOut(), 512, 300);
        if (stream0 != null)
        stream0.stop();
        stream1 = new AudioPlayer("FF11_37_Battle_in_the_Dungeon_2", true);
        addObject(stream1, 0,0);
        stream1.play();
        f = new Field();
        f.setBackground(new GreenfootImage("yalta_ground.jpg"));
        addObject(f, 512, 300);
        isBattle = true;
        loadSkyeBattleMenu();
        addObject(battleskye, 300, 400);
        addObject(new SkyeStats(charName, battleskye), 124, 567);
        battleskye.setNormalPos(300,400);
        if (theodoreInParty)
        {
            loadTheodoreBattleMenu();
            addObject(battletheodore, 300, 300);
            addObject(new TheodoreStats(charName2, battletheodore), 348, 567);
            battletheodore.setNormalPos(300, 300);
        }
    }
    public void gameOver()
    {
        List<Good> g = getObjects(Good.class);
        boolean isDead = true;
        for ( Good a : g)
        {
            isDead = isDead && a.getCurHP() <= 0;
        }
        if (isDead)
        {
            if (battleEndDelay < 0)
            {
                battleEndDelay++;
                return;
            }
            stream1.close();
            stream1 = new AudioPlayer("The_Loser", false);
            addObject(stream1, 0, 0);
            stream1.play();
            getBackground().setColor(Color.WHITE);
            getBackground().fill();
            //addObject(new FadeOut(), 512, 300);
            addObject(new GameOver(), 512, 300);
            Greenfoot.stop();
        }
    }
    public boolean checkIfLevelUp()
    {
        if (curEXP >= EXP)
        {
            curEXP -= EXP;
            charLevel++;
            EXP += 10;
            battleskye.setTotalHP(battleskye.getTotalHP()+battleskye.getTotalHP()/2);
            battleskye.setCurHP(battleskye.getTotalHP());
            battleskye.setDmg(battleskye.getDmg()+battleskye.getDmg()/2+1);
            battleskye.setFightDelay(battleskye.getFightDelay() -1);
            
            battletheodore.setTotalHP(battletheodore.getTotalHP()+battletheodore.getTotalHP()/2);
            battletheodore.setCurHP(battletheodore.getTotalHP());
            battletheodore.setDmg(battletheodore.getDmg()+battletheodore.getDmg()/2);
            battletheodore.setFightDelay(battletheodore.getFightDelay() -1);
            return true;
        }
        return false;
        
    }
    public boolean battleEnemiesDead()
    {
        return getObjects(Bad.class).size() == 0 ;
    }
    public void checkBattle()
    {
        gameOver(); // did u lose?
        if (battleEnemiesDead())
        {
            if (battleEndDelay < 0)
            {
                battleEndDelay++;
                return;
            }
            isBattle = false;
            stream1.close();
            stream1 = new AudioPlayer("The_Winner", false);
            addObject(stream1, 0,0);
            stream1.play();
            if (checkIfLevelUp() ) 
            {
                addObject(new EndOfBattleMenu(charName, charLevel, "LEVEL UP! EXP: "+curEXP+"/"+EXP), 512, 300);
                if (theodoreInParty)
                    addObject(new Char2EndOfBattleMenu(charName2, charLevel, "LEVEL UP! EXP: "+curEXP+"/"+EXP), 512, 406);
                addObject(new EndOfBattleMenuButton(), 738, 497);
            }
            else 
            {
                addObject(new EndOfBattleMenu(charName, charLevel, "EXP: "+curEXP+"/"+EXP), 512, 300);
                if (theodoreInParty)
                    addObject(new Char2EndOfBattleMenu(charName2, charLevel, "EXP: "+curEXP+"/"+EXP), 512, 406);
                addObject(new EndOfBattleMenuButton(), 738, 497);
            }
            battleEndDelay = -50;
            //removeObjects(getObjects(Battle.class));
        }
    }
    
    public void addKeyBoard()
    {
        d = new Display();
        d.setCurText(charName);
        addObject(d, 512, 118);
        
        loadKeys();
        
        addObject(new Enter(), 810, 390);
        addObject(new SkyeImage(), 117, 119);
    }
    public void addKeyBoard2()
    {
        d = new Display();
        d.setCurText(charName2);
        addObject(d, 512, 118);
        
        loadKeys();
        
        addObject(new Enter2(), 810, 390);
        addObject(new TheodoreImage(), 117, 119);
    }
    public void loadKeys()
    {
        
        addObject(new Key("0"), 100, 250);
        addObject(new Key("1"), 160, 250);
        addObject(new Key("2"), 220, 250);
        addObject(new Key("3"), 280, 250);
        addObject(new Key("4"), 340, 250);
        addObject(new Key("5"), 400, 250);
        addObject(new Key("6"), 460, 250);
        addObject(new Key("7"), 520, 250);
        addObject(new Key("8"), 580, 250);
        addObject(new Key("9"), 640, 250);
        
        addObject(new Key("q"), 100, 320);
        addObject(new Key("w"), 160, 320);
        addObject(new Key("e"), 220, 320);
        addObject(new Key("r"), 280, 320);
        addObject(new Key("t"), 340, 320);
        addObject(new Key("y"), 400, 320);
        addObject(new Key("u"), 460, 320);
        addObject(new Key("i"), 520, 320);
        addObject(new Key("o"), 580, 320);
        addObject(new Key("p"), 640, 320);
        
        addObject(new Key("a"), 160, 390);
        addObject(new Key("s"), 220, 390);
        addObject(new Key("d"), 280, 390);
        addObject(new Key("f"), 340, 390);
        addObject(new Key("g"), 400, 390);
        addObject(new Key("h"), 460, 390);
        addObject(new Key("j"), 520, 390);
        addObject(new Key("k"), 580, 390);
        addObject(new Key("l"), 640, 390);
        
        addObject(new Key("z"), 220, 460);
        addObject(new Key("x"), 280, 460);
        addObject(new Key("c"), 340, 460);
        addObject(new Key("v"), 400, 460);
        addObject(new Key("b"), 460, 460);
        addObject(new Key("n"), 520, 460);
        addObject(new Key("m"), 580, 460);
        
        addObject(new BackSpace(), 853, 250);
        addObject(new Space(), 500, 530);
        addObject(new Caps(), 810, 320);
        addObject(new Clear(), 811, 451);
    }
}
