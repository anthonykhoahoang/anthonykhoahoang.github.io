import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class WaterBar here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class WaterBar  extends HudObject
{
    private GreenfootImage water, emptyWater;
    private int numOrbs = 2, maxOrbs = 7;
    
    public WaterBar()
    {
        water = new GreenfootImage("images/hud/waterorb.png");
        emptyWater = new GreenfootImage("images/hud/emptywaterorb.png");
        setImage(new GreenfootImage(190, 18));
        fill();
    }
    
    public void act() 
    {
    }   
    
    public void fill()
    {
        getImage().clear();
        int pos = 0;
        for (int i = 0; i < numOrbs; i++)
        {
            getImage().drawImage(water, pos, 0);
            pos += 20;
        }
        for (int i = numOrbs; i < maxOrbs; i++)
        {
            getImage().drawImage(emptyWater, pos, 0);
            pos += 20;
        }
    }
    
    public void setOrbAmount(int amount)
    {
        numOrbs = amount;
    }
}
