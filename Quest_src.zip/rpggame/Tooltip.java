import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Tooltip here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Tooltip extends InstantText
{
    public Tooltip(String text)
    {
        super("tooltip/"+text, 150, 11f);
    }
    public void act() 
    {
        if (getOneIntersectingObject(Pointer.class) == null 
            &&getOneIntersectingObject(Pointer2.class)==null)
        getLand().removeObject(this);
    }    
}
