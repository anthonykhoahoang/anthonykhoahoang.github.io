import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class EB2 here.
 * 
 * @author Anthony Hoang
 * @version 2.1
 */
public class EB2 extends EnemyBullet
{
    public EB2(int rotation, int life, boolean sounds, Enemy e)
    {
        super(rotation, life, 10, false,e);
        if (sounds)
        Greenfoot.playSound("bullet2.wav");
    }
}
