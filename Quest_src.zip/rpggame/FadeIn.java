import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.awt.Color;


/**
 * Write a description of class FadeIn here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class FadeIn extends Actor
{
    public static final float FONT_SIZE = 25.0f;
    public static final int WIDTH = 1024;
    public static final int HEIGHT = 600;
    private int t;
    
    private GreenfootImage image;
    
    public FadeIn()
    {
        t = 0;
        image = new GreenfootImage(WIDTH, HEIGHT);
        image.setColor(new Color(0, 0, 0, 0));
        image.fillRect(0, 0, WIDTH, HEIGHT);
        setImage(image);
    }
    public void act() 
    {
        getLand().isPause = true;
        t +=10;
        if (t <255)
        image.setColor(new Color(0, 0, 0, t ));
        image.fillRect(0, 0, WIDTH, HEIGHT);
        setImage(image);
        if (t >= 255)
        {
            getLand().addObject(new FadeOut(), getLand().getWidth()/2, getLand().getHeight()/2);
            getLand().removeObject(this);
        }
            
    }    
    public Land getLand()
    {
        return (Land)getWorld();
    }
}
