import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.awt.Color;
/**
 * Write a description of class Particle here.
 * 
 * @author Anthony Hoang
 * @version v1
 */
public class Particle  extends InGameObjects
{
    Vector v;
    private double transparency = 100;
    private double transReduce = 4;
    private boolean firstInitialize = true;
    private double x;
    private double y;
    public Particle()
    {
    }
    public Particle(int r)
    {
        v = new Vector(r, 1);
    }
    public void act() 
    {
        if (getMWorld().esPause) return;
        if (firstInitialize)
        {
            x = getX();
            y = getY();
            firstInitialize = false;
        }
        else
        {
            /*
            transparency-=transReduce;
            if (transparency <= 0)
            {
                getWorld().removeObject(this);
            }
            else
            {
                getImage().setTransparency((int)transparency);
                up();
                random();
                
                move();
            }
            */
           move();
           down();
        }
    }    
    public void random()
    {
        v.add(new Vector((int)(Math.random()*360),Math.random()*1));
    }
    public void move()
    {
        x+=v.getX();
        y+=v.getY();
        setLocation((int)x,(int)y);
    }
    public void up()
    {
        v.add(new Vector(90,.1));
    }
    public void down()
    {
        v.add(new Vector(270,.1));
    }
}
