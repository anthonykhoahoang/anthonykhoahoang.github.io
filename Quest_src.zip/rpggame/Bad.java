import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Bad here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Bad extends Battle
{
    private int totalHP;
    private int curHP;
    private int totalMana;
    private int curMana;
    private int smokeDelay = 0;
    
    public Bad()
    {
    }
    public Bad(int hp, int mana)
    {
        totalHP = hp;
        curHP = hp;
        totalMana = mana;
        curMana = mana;
    }
    public void act() 
    {
        if (curHP <= 0)
        {
            getLand().addObject(new DeadHit(), getX(),getY());
            addEXP();
            getLand().removeObject(this);
        }
    }    
    public void addEXP()
    {
        if (this instanceof BattleSoldier)
        getLand().curEXP += 5;
        if (this instanceof Spector)
        getLand().curEXP += 7;
        if (this instanceof Zombie)
        getLand().curEXP += 7;
        if (this instanceof SkeletonWarrior)
        getLand().curEXP += 10;
        if (this instanceof SkeletonMage)
        getLand().curEXP += 10;
    }
    public void makeRunSmoke()
    {
        if (smokeDelay ==0)
        {
            getLand().addObject(new Smoke(), getX()-5,getY()+15);
            smokeDelay = -2;
        }
        if (smokeDelay < 0) smokeDelay++;
    }
    public void hit(int hp)
    {
        curHP -= hp;
        if (curHP < 0)
        curHP = 0;
    }
    public void heal(int hp)
    {
        curHP += hp;
        if (curHP > totalHP)
        curHP = totalHP;
    }
    public void loseMana(int amount)
    {
        curMana -= amount;
        if (curMana < 0)
        curMana = 0;
    }
    public void regenMana(int amount)
    {
        curMana += amount;
        if (curMana > totalMana)
        curMana = totalMana;
    }
    public void setTotalHP(int n)
    {
        totalHP = n;
    }
    public void setCurHP(int n)
    {
        curHP = n;
    }
    public void setTotalMana(int n)
    {
        totalMana = n;
    }
    public void setCurMana (int n)
    {
        curMana = n;
    }
    public int getCurHP()
    {   return curHP;   }
    public void addSpark()
    {
        getLand().addObject(new Spark(), getX(), getY());
    }
    public void addFire()
    {
        getLand().addObject(new Fire(), getX(), getY());
    }
}
