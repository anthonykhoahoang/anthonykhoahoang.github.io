import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class BlueSmoke here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class BlueSmoke extends Smoke
{
    private GreenfootImage smoke = new GreenfootImage("Battle/bluesmoke.png");
    
    public BlueSmoke()
    {
        setImage(smoke);
    }
    public void act() 
    {
        super.act();
    }    
}
