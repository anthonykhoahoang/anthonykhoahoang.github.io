import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * A flashing, spinning red light
 * that comes into the world by enlarging
 * 
 * @author Anthony Hoang
 * @version (v1)
 */
public class RedLightFlasher  extends InGameObjects
{
    private static GreenfootImage img;
    public RedLightFlasher()
    {
        if (img == null)
        {
            img = new GreenfootImage("redlightflasher.png");
        }
        setImage(new GreenfootImage(1,1));
    }
    public void act() 
    {
        if (getMWorld().esPause) return;
        enlarge();
        spin();
    }    
    public void enlarge()
    {
        if (getImage().equals(img)) return;
        int w = getImage().getWidth();
        int h = getImage().getHeight();
        if (w < img.getWidth())
        w+=2;
        if (h < img.getHeight())
        h+=1;
        if (w > img.getWidth() && h > img.getHeight())
        setImage(img);
        else
        {
            setImage(new GreenfootImage(img));
            getImage().scale(w,h);
        }
        
    }
    public void spin()
    {
        setRotation(getRotation()+5);
    }
}
