import greenfoot.*;  // (World, Actor, GreenfootImage, and Greenfoot)

/**
 * A bullet that can hit asteroids.
 * 
 * @author Poul Henriksen
 * redesigned and reimplemented by  Anthony Hoang
 */
public class BulletType2 extends MovingThing
{
    /** A bullet looses one life each act, and will disappear when life = 0 */
    private int life;
    /** The damage this bullet will deal */
    private int damage;
    public Type1 plane;
    private int SPEED = 12;
    
    public BulletType2()
    {    }
    public BulletType2( int dmg, boolean sound, Type1 p, int rot)
    {
        setRotation(rot);
        plane = p;
        damage = dmg;
        if (sound)
        Greenfoot.playSound("startBullet.wav");
    }
    public void act()
    {
        if(atTopEdge()) 
        {
            addToPlane();
            getWorld().removeObject(this);
        }
        else 
        {
            move();
            checkCollision();
        }
    }
    public void addToPlane()
    {
        plane.addBullet(this);
    }
    public void checkCollision()
    {
        Enemy2 a =(Enemy2) getOneIntersectingObject(Enemy2.class);
        if (a!= null)
        {
            a.hit(damage);
            addToPlane();
            getSpace().removeObject(this);
        }
        
    }
    public boolean atTopEdge()
    {
        if (getY() < 10)
        return true;
        return false;
    }
    public void move()
    {
        double angle = Math.toRadians( getRotation() );
        int x = (int) Math.round(getX() + Math.cos(angle) * SPEED);
        int y = (int) Math.round(getY() + Math.sin(angle) * SPEED);
        setLocation(x, y);
    }
    public boolean atWorldEdge()
    {
        if(getX() < 180 || getX() > getWorld().getWidth() - 180)
            return true;
        if(getY() < 10 || getY() > getWorld().getHeight()-10)
            return true;
        else
            return false;
    }
    public void moveForward()
    {
        setLocation(getX(), getY()-SPEED);
    }
    public void moveLeft()
    {
        setLocation(getX()-SPEED, getY());
    }
    public void moveRight()
    {
        setLocation(getX()+SPEED, getY());
    }
}