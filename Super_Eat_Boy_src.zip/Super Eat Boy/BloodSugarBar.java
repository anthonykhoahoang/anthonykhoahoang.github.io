import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class BloodSugarBar here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class BloodSugarBar  extends HudObject
{
    public BloodSugarBar()
    {
        setImage(new GreenfootImage("images/hud/bloodsugarbar.png"));
    }
    
    public void act() 
    {
        // Add your action code here.
    }    
}
