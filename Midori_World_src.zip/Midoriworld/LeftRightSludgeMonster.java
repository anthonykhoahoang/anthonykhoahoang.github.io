import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.util.List;
/**
 * Write a description of class LeftRightSludgeMonster here.
 * 
 * @author Anthony Hoang
 * @version (v1)
 */
public class LeftRightSludgeMonster  extends LeftRightGroundHostile
{
    private static GreenfootImage[] img;
    private int delay = 2;
    private int index = 0;
    private boolean b = false;
    private int range = 200;
    private int attackDelay = 50;
    public LeftRightSludgeMonster()
    {
        if (img == null)
        {
            img = new GreenfootImage[5];
            img[0] = new GreenfootImage("sludgemonstersmall/sludgemonster1.png");
            img[1] = new GreenfootImage("sludgemonstersmall/sludgemonster2.png");
            img[2] = new GreenfootImage("sludgemonstersmall/sludgemonster3.png");
            img[3] = new GreenfootImage("sludgemonstersmall/sludgemonster4.png");
            img[4] = new GreenfootImage("sludgemonstersmall/sludgemonster5.png");
        }
        setImage(img[0]);
        attackDelay = (int)(attackDelay*Math.random())+30;
    }
    public LeftRightSludgeMonster(int r)
    {
        this();
        range = r;
    }
    public void act() 
    {
        if (getMWorld().esPause) return;
        if (delay == 0 && !hasHit())
        { setImage(); delay = 10;}
        delay--;
        if (attackDelay < 0 && !hasHit)
        {
            attack();
            attackDelay = 50;
        }
        else
        attackDelay--;
        super.act();
    }    
    public void setImage()
    {
        if (index >= 4) {
            b = true;
        }
        if (index <=0)  { b = false;}
        if (b) index--;
        else index++;
        setImage(img[index]);
    }
    public void attack()
    {
        List<InGameCharacter> l1 = getObjectsInRange(range,InGameCharacter.class);
        if (l1.size()==0) l1 = getObjectsInRange(range,HelperBot.class);
        if (l1.size()!=0)
        {
            Greenfoot.playSound("spit.wav");
            getMWorld().addObject(new FollowSmallProjectile(),getX(),getY());
        }
    }
}
