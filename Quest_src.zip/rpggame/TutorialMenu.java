import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.awt.Color;
import java.awt.Font;
/**
 * Write a description of class Turtorial here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class TutorialMenu extends Menu
{
    public static final float FONT_SIZE = 25.0f;
    public static final int WIDTH = 125;
    public static final int HEIGHT = 40;
    private GreenfootImage image;
    public TutorialMenu()
    {
        image = new GreenfootImage(WIDTH, HEIGHT);
        image.setColor(new Color(149, 105, 0, 50));
        image.fillRect(0, 0, WIDTH, HEIGHT);
        Font font = image.getFont();
        font = font.deriveFont(FONT_SIZE);
        image.setFont(font);
        image.setColor(Color.WHITE);
        image.drawString("Tutorials", 15 , 30);
        setImage(image);
    }
    public void act() 
    {
        if (Greenfoot.mouseMoved(this))
        {
            image.setColor(Color.RED);
            image.drawString("Tutorials", 15 , 30);
        }
        else
        {
            image.setColor(Color.WHITE);
            image.drawString("Tutorials", 15 , 30);
        }
        if (Greenfoot.mousePressed(this))
        {
            Greenfoot.playSound("click.wav");
            getLand().addObject(new FadeOut(), getLand().getWidth()/2, getLand().getHeight()/2);
            getLand().loadTutorialMenu();
            //getLand().removeObject(this);
        }
        setImage(image);
    }    
}
