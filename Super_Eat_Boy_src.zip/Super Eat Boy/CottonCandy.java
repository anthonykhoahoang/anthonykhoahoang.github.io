import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class CottonCandy here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class CottonCandy  extends BadFood
{
    private static GreenfootImage[] images;
        
    //Animation variables
    private int maxAnimDelay = 6;
    private int curAnim = 0;
    private int curAnimDelay = maxAnimDelay;
    
    //Death animation variables
    private int curImgHeight;
    private int squishSpeed = 10;
    
    public CottonCandy(int realX, int realY)
    {
        super(realX, realY, "BackAndForth", 2);
        if (images == null)
            loadImages();
    }
    
    public CottonCandy(int realX, int realY, String ai, int speed)
    {
        super(realX, realY, ai, speed);
        if (images == null)
            loadImages();
    }
    
    public void loadImages()
    {
        images = new GreenfootImage[11];
        images[0] = new GreenfootImage("images/cottoncandy/cc1.png");
        images[1] = new GreenfootImage("images/cottoncandy/cc2.png");
        images[2] = new GreenfootImage("images/cottoncandy/cc3.png");
        images[3] = new GreenfootImage("images/cottoncandy/cc4.png");
        images[4] = new GreenfootImage("images/cottoncandy/cc5.png");
        images[5] = new GreenfootImage("images/cottoncandy/cc6.png");
        images[6] = new GreenfootImage("images/cottoncandy/cc7.png");
        images[7] = new GreenfootImage("images/cottoncandy/cc8.png");
        images[8] = new GreenfootImage("images/cottoncandy/cc9.png");
        images[9] = new GreenfootImage("images/cottoncandy/cc10.png");
        images[10] = new GreenfootImage("images/cottoncandy/cc11.png");
    }
    
    public void act() 
    {
        animate();
        super.act();
    }    

    public void animate()
    {
        if (curAnimDelay >= maxAnimDelay)
        {
            if (curAnim >= images.length)
                curAnim = 0;
            setImage(new GreenfootImage(images[curAnim]));
            if (getDirection() == 0)
                getImage().mirrorHorizontally();
            curAnim++;
            curAnimDelay = 0;
        }
        else
            curAnimDelay++;
    }
    
    public void die()
    {
        for (int i = 0; i < 360; i+=10)
            getWorld().addObject(new PinkParticle(i, getRealX(), getRealY()+10), 0, 0);
        getWorld().addObject(new DeadCottonCandy(getRealX(), getRealY()), 0, 0);
        getWorld().removeObject(this);
    }    
}
