import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class ScrollBackroundUnderlay here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class ScrollBackgroundUnderlay  extends ScrollActor
{
    private int width, height;
    private static GreenfootImage bg;
    public ScrollBackgroundUnderlay(int realX, int realY)
    {
        super(realX, realY);
        bg = new GreenfootImage("images/backgroundscroll.png");
        setImage(bg);
        width = getImage().getWidth();
        height = getImage().getHeight();
    }
    
    public void act() 
    {
        super.act();
        //getWorld().getBackground().drawImage(bg, width/2 - getWorld().getSX(), height/2 - getWorld().getSY()); 
    }    
    
    public void setLocation(int x, int y)
    {
        super.setLocation(x + width/2, y + height/2);
    }
}
