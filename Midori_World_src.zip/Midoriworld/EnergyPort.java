import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Energy port superclass
 * 
 * @author Anthony Hoang
 * @version (v1)
 */
public class EnergyPort  extends InGameObjects
{
    public void act() 
    {
    }    
}
