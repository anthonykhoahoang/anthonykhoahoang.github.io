import greenfoot.*;  // (World, Actor, GreenfootImage, and Greenfoot)

import java.awt.Color;
import java.awt.Graphics;

/**
 * Counter that displays a number with a text prefix.
 * 
 * @author Michael Kolling
 * @version 1.0.2
 */
public class Counter extends Actor
{
    private static final Color textColor = new Color(255, 180, 150);
    private boolean noUpdate = false;
    private int value = 0;
    private int target = 0;
    private String text;
    private String originalText;
    private int stringLength;

    public Counter()
    {
        this("");
    }

    public Counter(String prefix)
    {
        text = prefix;
        stringLength = (text.length() + 2) * 10;

        setImage(new GreenfootImage(stringLength, 16));
        GreenfootImage image = getImage();
        image.setColor(textColor);
        updateImage();
    }
     public Counter(String prefix, boolean noUpdate)
    {
        originalText = prefix;
        text = prefix;
        stringLength = (text.length() + 2) * 10;
        this.noUpdate = noUpdate;
        setImage(new GreenfootImage(stringLength, 16));
        GreenfootImage image = getImage();
        image.setColor(textColor);
        updateImage();
    }
    public String getCoordinates()
    {
        return getX() + " " +getY();
    }
    public void act() 
    {
        if ( !noUpdate)
        {
            if(value < target) 
            {
                value += 10;
                updateImage();
            }
            else 
            if(value > target) 
            {
                value--;
                updateImage();
            }
        }
       
    }

    public void add(int score)
    {
        target += score;
    }

    public void subtract(int score)
    {
        target -= score;
    }

    public int getValue()
    {
        return value;
    }
    public void setValue(int n)
    {
        value = n;
    }
    public int getTarget()
    {
        return target;
    }
    public void setTarget(int n)
    {
        target = n;
    }
    /**
     * Make the image
     */
    private void updateImage()
    {
        GreenfootImage image = getImage();
        image.clear();
        image.drawString(text + value, 1, 12);
    }
    public void updateImage2(int num)
    {
        GreenfootImage image = getImage();
        image.clear();
        image.drawString(text + num, 1, 12);
    }
}