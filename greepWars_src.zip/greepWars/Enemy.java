import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.util.*;

/**
 * This is the basic class of an enemy. Provides basic methods for enemies.
 * 
 * @author Anthony Hoang
 * @version (a version number or a date)
 */
public class Enemy extends Actor
{
    private int curHealth;
    private int health;
    private int scoreAmount;
    private int empDelay;
    private int range;
    public Counter lifeCounter;
    
    public Enemy(){}
    public Enemy (int h, int score)
    {
        health = h;
        curHealth = h;
        scoreAmount = score;
        range = 100;
    }
    public int getHealth()
    {
        return curHealth;
    }
    public void resetStats()
    {
        if ( this instanceof AlienShip)
        {
            health = getSpace().alienShipLife;
        }
        if ( this instanceof AlienShip2)
        {
            health = getSpace().alienShipLife/2;
        }
        curHealth = health;
        range = getSpace().greepRange;
        empDelay = 0;
    }
    public void act() 
    {
        if (empDelay < 0)
        empDelay++;
    }    
    public void hit(int damage)
    {
        curHealth -= damage;
        if(curHealth <= 0)
        {
            getSpace().removeEnemy();
            die();         
        }
    }
    public int healthPercent()
    {
        double d = (double)curHealth/(double)health*100.0;
        return (int)d;
    }
    public void heal(int amount) 
    {
        curHealth += amount;
        if (curHealth > health)
        curHealth= health;
    }
    private void die() 
    {
        Space space = getSpace();
        if (scoreAmount >= 100)
        {
            //getWorld().addObject(new Explosion(), getX(), getY());
            getSpace().addExplosion(getX(),getY());
            if (randomChance(3))
                space.addUpgrades(1);
        }
        if (this instanceof AlienShipBoss || this instanceof AlienShipBoss2)
        {
            removeEnemyBullets();
            getSpace().addUpgrades(7);
            getSpace().removeObject(getSpace().bossLife);
        }
        getSpace().score(scoreAmount);
        //Greenfoot.playSound("greepSquish.wav");
        if (this instanceof Greepers || this instanceof Greepers2)
        {
            getSpace().addGreepsKilled();
            getSpace().addGreepBlood(getX(), getY());
        }
        if (this instanceof AlienShip )
        {
            
            if (randomChance(50) && getSpace().getLevel() >25)
            space.addUpgrades(2);
            getSpace().addSpaceShipKilled();
        }
        getSpace().checkClear();
        getSpace().removeObject(this);
    }
    public void removeEnemyBullets()
    {
        List bullets = getObjectsInRange(1000, EnemyBullet.class);
        for (int i = 0; i < bullets.size(); i++)
        getSpace().removeObject((EnemyBullet) bullets.get(i));
    }
    public void setRange(int num)
    {
        range = num;
    }
    public void setEmpDelay()
    {
        empDelay = -200;
        if (this instanceof AlienShipBoss || this instanceof AlienShipBoss2)
        empDelay = -20;
    }
    public int getEmpDelay()
    {
        return empDelay;
    }
    public void move2()
    {
        double angle = Math.toRadians( getRotation() );
        int x = (int) Math.round(getX() + Math.cos(angle) * 2);
        int y = (int) Math.round(getY() + Math.sin(angle) * 2);
        setLocation(x, y);
    }
    public void moveSlow()
    {
        double angle = Math.toRadians( getRotation() );
        int x = (int) Math.round(getX() + Math.cos(angle) * 1);
        int y = (int) Math.round(getY() + Math.sin(angle) * 1);
        if(x >= getWorld().getWidth()) 
        {
            x = 0;
        }
        if(x < 0) {
            x = getWorld().getWidth() - 1;
        }
        if(y >= getWorld().getHeight()) {
            y = 0;
        }
        if(y < 0) {
            y = getWorld().getHeight() - 1;
        }
        setLocation(x, y);
    }
    public void move()
    {
        double angle = Math.toRadians( getRotation() );
        int x = (int) Math.round(getX() + Math.cos(angle) * 3);
        int y = (int) Math.round(getY() + Math.sin(angle) * 3);
        if(x >= getWorld().getWidth()) 
        {
            x = 0;
        }
        if(x < 0) {
            x = getWorld().getWidth() - 1;
        }
        if(y >= getWorld().getHeight()) {
            y = 0;
        }
        if(y < 0) {
            y = getWorld().getHeight() - 1;
        }
        setLocation(x, y);
    }
    public void turn(int angle)
    {
        setRotation(getRotation() + angle);
    }
    public void turnToShip()
    {
        List rocketL = rocketList();
        if (rocketL.size() != 0)
        {
            Rocket temp = (Rocket)rocketL.get(0);
            if (!temp.isDead )
            {
                int deltaX = (temp.getX() - getX());
                int deltaY = (temp.getY() - getY());
                setRotation((int) (180 * Math.atan2(deltaY, deltaX) / Math.PI));
            }
           else if (getSpace().twoP())
            {
                temp = (Rocket)rocketL.get(rocketL.size()-1);
            int deltaX = (temp.getX() - getX());
                int deltaY = (temp.getY() - getY());
                setRotation((int) (180 * Math.atan2(deltaY, deltaX) / Math.PI));
            }
        }
    }
    public int turnToShipInt()
    {
        List rocketL = getNeighbours(999, true, Rocket.class);
        int turn = 0;
        if (rocketL.size() > 0)
        {
            Rocket temp = (Rocket)rocketL.get(0);
            if (!temp.isDead )
            {
                int deltaX = temp.getX()-getX();
                int deltaY = temp.getY()-getY();
            
                turn = (int) (180 * Math.atan2(deltaY, deltaX) / Math.PI);
            }
            else if (getSpace().twoP())
            {
                temp = (Rocket)rocketL.get(rocketL.size()-1);
            int deltaX = (temp.getX() - getX());
                int deltaY = (temp.getY() - getY());
                setRotation((int) (180 * Math.atan2(deltaY, deltaX) / Math.PI));
            }
        }
        return turn;
    }
    public List rocketList()
    {
        List rocketL = getNeighbours(range, true, Rocket.class);
        for (int i = 0; i < rocketL.size(); i++)
        {
            Object temp = rocketL.get(i);
        }
        return rocketL;
    }
    public boolean randomChance(int percent)
    {
        return Greenfoot.getRandomNumber(100) < percent;
    }
    public Space getSpace() 
    {
        return (Space)getWorld();
    }
    public boolean atWorldEdge()
    {
        if(getX() < 3 || getX() > getWorld().getWidth() - 3)
            return true;
        if(getY() < 3 || getY() > getWorld().getHeight() - 3)
            return true;
        else
            return false;
    }
    
    public int fixRotation(int r)
    {
        while (r > 360)
        r -= 360;
        while (r < 0)
        r +=360;
        return r;
    }
}
