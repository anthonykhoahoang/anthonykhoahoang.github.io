import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.awt.Color;
import java.awt.Font;
/**
 * Write a description of class EndOfBattleMenuButton here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class EndOfBattleMenuButton extends EndOfBattleMenu
{
    
    public static final float FONT_SIZE = 38.0f;
    public static final int WIDTH = 200;
    public static final int HEIGHT = 50;
    private GreenfootImage image;
    public EndOfBattleMenuButton()
    {
        image = new GreenfootImage(WIDTH, HEIGHT);
        image.setColor(new Color(0, 0, 200, 128));
        image.fillRect(0, 0, WIDTH, HEIGHT);
        Font font = image.getFont();
        font = font.deriveFont(FONT_SIZE);
        image.setFont(font);
        image.setColor(Color.WHITE);
        image.drawString("Continue", 20 , 38);
        setImage(image);
    }
    
    public void act() 
    {
        image.clear();
        if (Greenfoot.mouseMoved(this))
        {
            image.setColor(new Color(0, 0, 200, 128));
            image.fillRect(0, 0, WIDTH, HEIGHT);
            image.setColor(Color.RED);
            image.drawString("Continue", 20 , 38);
        }
        else
        {
            image.setColor(new Color(0, 0, 200, 128));
            image.fillRect(0, 0, WIDTH, HEIGHT);
            image.setColor(Color.WHITE);
            image.drawString("Continue", 20 , 38);
        }
        if ( Greenfoot.mouseClicked(this))
        {
            getLand().addObject(new FadeOut(), 512, 300);
            if (getLand().stream1 != null)
            getLand().stream1.close();
            if (getLand().stream0 != null) 
            getLand().stream0.play();
            getLand().removeObjects(getLand().getObjects(Battle.class));
            getLand().isBattle = false;
            getLand().battleskye.endOfBattleReset();
            if (getLand().theodoreInParty)
            getLand().battletheodore.endOfBattleReset();
            getLand().removeObjects(getLand().getObjects(EndOfBattleMenu.class));
            return;
        }
        setImage(image);
        
    }
}
