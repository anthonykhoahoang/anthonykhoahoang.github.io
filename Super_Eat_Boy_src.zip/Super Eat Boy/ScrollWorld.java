import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.awt.Color;
import java.util.List;
/**
 * Write a description of class ScrollWorld here.
 * 
 * @author Team M
 * @version (a version number or a date)
 */
public class ScrollWorld  extends World
{
    private static final int SCREENWIDTH = 800, SCREENHEIGHT = 450;
    private int screenX, screenY;
    private GreenfootImage rgbMap;
    private GreenfootSound musicPlayer;
    public boolean gamePause;
    public boolean esPause;
    public int eventCount;
    
    private String eventScript;
    
    public ScrollWorld()
    {
        super(SCREENWIDTH, SCREENHEIGHT, 1, false); 
        screenX = 0;
        screenY = 0;
        gamePause = false;
        esPause = false;
        eventCount = 0;
        setBackground(new GreenfootImage("images/menubackground.jpg"));
        
        setPaintOrder(Menu.class, TimerDisplay.class, BloodSugarBar.class, Hud.class, FoodBar.class, 
        HudObject.class, Particle.class, DeadFood.class, GoodFood.class, ScrollBackground.class, EatBoy.class, ScrollActor.class, ScrollBackgroundUnderlay.class);
       /*
        setBackground(new GreenfootImage("images/background.jpg"));
        rgbMap = new GreenfootImage("images/ground_rgb.png");
        addObject(new ScrollBackground(0,0), 0, 0);
        addObject(new ScrollBackgroundUnderlay(0,0), 0, 0);
        addObject(new ScreenAdjuster(SCREENWIDTH, SCREENHEIGHT), 0, 0);
        addObject(new EatBoy(100, 200), 0, 0);
        addObject(new Hud(), 138, 41);
        addObject(new FoodBar("Green", -45), 42, 38);
        addObject(new FoodBar("Blue", -10), 12, 51);
        addObject(new FoodBar("Red", -85), 52, 11);
        addObject(new InsulinBar(), 123, 34);
        addObject(new WaterBar(), 266, 36);
        addObject(new BloodSugarBar(), 177, 13);
        addObject(new TimerDisplay(2.5), 515, 11);
        spawnCottonCandyRandom(50);
        spawnPopsicleRandom(50);
        */
        musicPlayer = new GreenfootSound("sounds/RJ Minimal MC Possible Start Menu Music.mp3");
        Greenfoot.setSpeed(50);
        loadMenu();
    }
    public void loadMenu()
    {
        addObject(new Title(), 423, 95);
        addObject(new NewGame(), 397, 238);
        addObject(new Credits(), 395, 295);
        addObject(new HowToPlay(), 398, 352);
    }
    public void newGame()
    {
        List<Menu> listMenu = getObjects(Menu.class);
        for (Menu m : listMenu)
            m.close();
        
            List<CreditsText> listPH = getObjects(CreditsText.class);
            for (CreditsText p : listPH)
                p.close();
                
        if (musicPlayer != null)
        {
            if (musicPlayer.isPlaying())
                musicPlayer.pause();
            else
                musicPlayer.stop();
        }
        musicPlayer = new GreenfootSound("sounds/RJ Super Fun Possible Start Menu Music 2.mp3");        
        if (musicPlayer != null)
            musicPlayer.playLoop();
        setBackground(new GreenfootImage("images/background.jpg"));
        rgbMap = new GreenfootImage("images/ground_rgb.png");
        addObject(new ScrollBackground(0,0), 0, 0);
        addObject(new ScrollBackgroundUnderlay(0,0), 0, 0);
        addObject(new ScreenAdjuster(SCREENWIDTH, SCREENHEIGHT), 0, 0);
        addObject(new EatBoy(100, 200), 800, 800);
        addObject(new Hud(), 138, 41);
        addObject(new FoodBar("Green", -45), 42, 38);
        addObject(new FoodBar("Blue", -10), 12, 51);
        addObject(new FoodBar("Red", -85), 52, 11);
        addObject(new InsulinBar(), 123, 34);
        addObject(new WaterBar(), 266, 36);
        addObject(new BloodSugarBar(), 177, 13);
        addObject(new TimerDisplay(2.5), 515, 11);
        spawnCottonCandyRandom(25);
        spawnPopsicleRandom(25);
        spawnWaterRandom(5);
        spawnGreenFoodRandom(10);
        spawnMeatFoodRandom(10);
        spawnFruitFoodRandom(10);
    }
    public void spawnCottonCandyRandom(int amount)
    {
        for (int i = 0; i < amount; i ++)
        {
            int x = (int)(Math.random()*rgbMap.getWidth());
            int y = (int)(Math.random()*rgbMap.getHeight());
            while (isBlackAt(x, y))
            {
                x = (int)(Math.random()*rgbMap.getWidth());
                y = (int)(Math.random()*rgbMap.getHeight());
            }            
            addObject(new CottonCandy(x, y, "BackAndForth", 1), 0, 0);
        }
    }
    
    public void spawnPopsicleRandom(int amount)
    {
        for (int i = 0; i < amount; i ++)
        {
            int x = (int)(Math.random()*rgbMap.getWidth());
            int y = (int)(Math.random()*rgbMap.getHeight());
            while (isBlackAt(x, y))
            {
                x = (int)(Math.random()*rgbMap.getWidth());
                y = (int)(Math.random()*rgbMap.getHeight());
            }            
            addObject(new Popsicle(x, y, "BackAndForth", 1), 0, 0);
        }
    }
    public void spawnWaterRandom(int amount)
    {
        for (int i = 0; i < amount; i ++)
        {
            int x = (int)(Math.random()*rgbMap.getWidth());
            int y = (int)(Math.random()*rgbMap.getHeight());
            while (isBlackAt(x, y))
            {
                x = (int)(Math.random()*rgbMap.getWidth());
                y = (int)(Math.random()*rgbMap.getHeight());
            }            
            addObject(new GFWater(x, y), 0, 0);
        }
    }
    public void spawnGreenFoodRandom(int amount)
    {
        for (int i = 0; i < amount; i ++)
        {
            int x = (int)(Math.random()*rgbMap.getWidth());
            int y = (int)(Math.random()*rgbMap.getHeight());
            while (isBlackAt(x, y))
            {
                x = (int)(Math.random()*rgbMap.getWidth());
                y = (int)(Math.random()*rgbMap.getHeight());
            }            
            addObject(new GFGreen(x, y), 0, 0);
        }
    }
    public void spawnMeatFoodRandom(int amount)
    {
        for (int i = 0; i < amount; i ++)
        {
            int x = (int)(Math.random()*rgbMap.getWidth());
            int y = (int)(Math.random()*rgbMap.getHeight());
            while (isBlackAt(x, y))
            {
                x = (int)(Math.random()*rgbMap.getWidth());
                y = (int)(Math.random()*rgbMap.getHeight());
            }            
            addObject(new GFMeat(x, y), 0, 0);
        }
    }
    public void spawnFruitFoodRandom(int amount)
    {
        for (int i = 0; i < amount; i ++)
        {
            int x = (int)(Math.random()*rgbMap.getWidth());
            int y = (int)(Math.random()*rgbMap.getHeight());
            while (isBlackAt(x, y))
            {
                x = (int)(Math.random()*rgbMap.getWidth());
                y = (int)(Math.random()*rgbMap.getHeight());
            }            
            addObject(new GFFruit(x, y), 0, 0);
        }
    }
    public void act()
    {
       // getBackground().fillRect(0, 0, SCREENWIDTH, SCREENHEIGHT);
        /*
        if (Greenfoot.isKeyDown("left"))
            screenX--;
        if (Greenfoot.isKeyDown("right"))
            screenX++;
        if (Greenfoot.isKeyDown("up"))
            screenY--;
        if (Greenfoot.isKeyDown("down"))
            screenY++;
            */
    }
    
    public void started()
    {
        if (musicPlayer != null)
        {
                musicPlayer.playLoop();
        }
    }
    
    public void stopped()
    {
        if (musicPlayer != null)
        {
            if (musicPlayer.isPlaying())
                musicPlayer.pause();
            else
                musicPlayer.stop();
        }
    }
    /*
     * Acessor Methods
     */
    public int getSX()
    {
        return screenX;
    }
    
    public int getSY()
    {
        return screenY;
    }
    
    public boolean isBlackAt(int x, int y)
    {
        if (x < 0 || y < 0)
            return true;
        if (x >= rgbMap.getWidth() || y >= rgbMap.getHeight())
            return true;
        return rgbMap.getColorAt(x, y).equals(Color.BLACK);
    }
    
    public void setScreenLocation(int x, int y)
    {
        screenX = x;
        screenY = y;
    }
    public void stopBackgroundMusic()
    {
        if (musicPlayer != null)
        {
            if (musicPlayer.isPlaying())
                musicPlayer.pause();
            else
                musicPlayer.stop();
        }
    }
}
