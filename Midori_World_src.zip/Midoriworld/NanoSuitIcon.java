import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.util.List;
/**
 * Sets and animates the suit icon to the current suit power
 * 
 * @author Anthony Hoang
 * @version (v1)
 */
public class NanoSuitIcon  extends EnergyBar
{
    private GreenfootImage[] img;
    private int transparency;
    public NanoSuitIcon()
    {
        if (img == null)
        initialize();
    }
    public void act() 
    {
        if (getMWorld().esPause) return;
        setImage();
    }    
    public void setImage()
    {
        List<NanoSuit> list = getMWorld().getObjects(NanoSuit.class);
        if (list.size()!=0)
        {
            NanoSuit nanosuit = list.get(0);
            int cur = nanosuit.getCurPower();
            if (!getImage().equals(img[cur]))
            setImage(img[cur]);
            int t = getImage().getTransparency();
            if (nanosuit.active() && t < 200)
            {
                t+=5;
                getImage().setTransparency(t);
            }
            else if (!nanosuit.active() && t > 50)
            {
                t-=5;
                getImage().setTransparency(t);
            }
        }
    }
    public void initialize()
    {
        img = new GreenfootImage[2];
        img[0] = new GreenfootImage("nanopowers/broken.png");
        img[1] = new GreenfootImage("nanopowers/sprint.png");
    }
}
