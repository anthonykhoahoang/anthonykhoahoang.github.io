import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class LGOverlay here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class LGOverlay  extends LogicGate
{
    public LGOverlay(GreenfootImage img)
    {
        setImage(img);
    }
    public void act() 
    {
    }    
}
