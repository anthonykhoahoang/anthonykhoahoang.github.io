import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class EB5 here.
 * 
 * @author Anthony Hoang
 * @version 2.1
 */
public class EB5 extends EnemyBullet
{
    public EB5(int rotation, int life, boolean sounds, Enemy e)
    {
        super(rotation, life, 25, false, e);
        if (sounds)
        Greenfoot.playSound("bullet5.wav");
    }
}
