import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Moves twice as fast as Greeper
 * 
 * @author Anthony Hoang
 * @version 1.0
 */
public class FastGreeper extends Greepers
{
    private int acts = 0;
    public FastGreeper(int range)
    {
        super(range);
        setRange(range);
        setRotation(Greenfoot.getRandomNumber(360));
    }
    public void act() 
    {
        if (acts == 0)
        {
            turnToShip();
            acts = -20;
        }
        else
        acts++;
        if (atWorldEdge())
        turn(45);
        move2();
        move2();
    }    
}
