import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
/**
 * Write a description of class BouncyPlatform here.
 * 
 * @author Anthony Hoang
 * @version v1
 */
public class SinPlatform  extends Platform
{
    private int h = 50;
    private boolean firstInitialize = true;
    private double x2;
    private double nextAdd;
    private int x1, y1;
    private int speed;
    private int distance;
    private int endX;
    private boolean right = true;
    public SinPlatform()
    {
        super();
        setImage(new GreenfootImage(platform1));
        speed = 0; 
    }
    public SinPlatform(int h, int d, int speed, int width)
    {
        this();
        getImage().scale(width, getImage().getHeight());
        this.h = h; //how high to bounce
        this.speed = speed;
        distance = d;
    }
    public void act() 
    {
        if (getMWorld().esPause) return;
        if (firstInitialize)
        {
            x2 = 0;
            x1 = getX();
            y1 = getY();
            endX = x1+distance;
            firstInitialize = false;
        }
        bounceAndMoveChar();
    }    
    public void bounceAndMoveChar()
    {
        if (x2 > 2*Math.PI)
        {   x2 = 0;
            return;
        }
        nextAdd = h*Math.sin(x2);
        if (isAbove())
        moveChar();
        if (right)
        {
            x1 += speed;
            setLocation(x1, y1+(int)nextAdd);
        }
        else
        {
            x1-=speed;
            setLocation(x1, y1+(int)nextAdd);
        }
        if (x1 >= endX)
            right = false;
        if (x1 <= endX-distance)
            right = true;
            
        x2+=.05;
    }
    public void moveChar()
    {
        Actor a = getOneIntersectingObject(InGameCharacter.class);
        if (a != null) 
        {
            int t = y1+(int)nextAdd;
            //int xa = a.getX()-x1;
            if (right)
            a.setLocation(a.getX()+speed, t-getImage().getHeight()/2-a.getImage().getHeight()/2);
            else
            a.setLocation(a.getX()-speed, t-getImage().getHeight()/2-a.getImage().getHeight()/2);
        }
    }
}
