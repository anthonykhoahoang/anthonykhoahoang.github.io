import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.awt.Color;
/**
 * Colors the rockets red/blue
 * 
 * @author Anthony Hoang
 * @version 2.1
 */
public class HighLighter extends Actor
{
    private int WIDTH = 25;
    private int HEIGHT = 20;
    private Rocket r;
    private GreenfootImage image;
    public HighLighter(Rocket rocket, String color)
    {
        r = rocket;
        if (color.equals("blue"))
        {
            image = new GreenfootImage(WIDTH, HEIGHT);
            image.setColor(new Color(22, 0, 185, 75));
            image.fillRect(0, 0, WIDTH, HEIGHT);
        }
        else
        {
            image = new GreenfootImage(WIDTH, HEIGHT);
            image.setColor(new Color(185, 33, 10, 75));
            image.fillRect(0, 0, WIDTH, HEIGHT);
        }
        setImage(image);
    }
    public void act() 
    {
        setLocation(r.getX(),r.getY());
        setRotation(r.getRotation());
        if (r.isDead)
        setImage(new GreenfootImage(1,1));
    }    
}
