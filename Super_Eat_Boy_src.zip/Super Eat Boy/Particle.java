import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.awt.Color;
/**
 * Write a description of class Particle here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Particle extends ScrollActor
{
    private Vector v;
    private double transparency = 100;
    private double transReduce = 4;
    private boolean firstInitialize = true;
    private double x;
    private double y;
    
    public Particle(int realX, int realY)
    {
        super(realX, realY);
    }
    public Particle(int r, int realX, int realY)
    {
        super(realX, realY);
        v = new Vector(r, 1);
    }
    public void act() 
    {
        super.act();
    }    
    public void random()
    {
        v.add(new Vector((int)(Math.random()*360),Math.random()*1));
    }
    public void move()
    {
        x += v.getX();
        y += v.getY();
        setRealLocation((int)x,(int)y);
    }
    public void up()
    {
        v.add(new Vector(90,.1));
    }
    public void down()
    {
        v.add(new Vector(270,.1));
    }
}
