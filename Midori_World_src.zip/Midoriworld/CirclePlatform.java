import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
/**
 * Write a description of class CircleMoveBouncyPlatform here.
 * 
 * @author Anthony Hoang
 * @version (v1)
 */
public class CirclePlatform  extends Platform
{
    private Vector v;
    private double degree;
    private double degreeAdd;
    private double length;
    private double x=400;
    private double y=200;
	private boolean firstInitialize = true;
    public CirclePlatform()
    {
        super();
        setImage(new GreenfootImage(platform1));
        v = new Vector();
        degree = 0;
        length = 2;
        degreeAdd = 3;
    }
	public CirclePlatform(double l, double d, int width)
	{
		this();
		length = l;
		degreeAdd = d;
        getImage().scale(width, getImage().getHeight());
	}
    
    public void act() 
    {
        if (getMWorld().esPause) return;
		if (firstInitialize)
		{
			x=getX();
			y=getY();
			firstInitialize = false;
		}
        //super.act();
        move();
    }   
    public void move()
    {
        v = new Vector((int)degree, length);
        degree+=degreeAdd;
        if (degree >= 360)
        degree = 0;
		if (isAbove())
		moveChar();
        x+=v.getX();
        y+=v.getY();
        setLocation((int)x, (int) y);
    }
    public void moveChar()
    {
        Actor a = getOneIntersectingObject(InGameCharacter.class);
        if (a != null) 
        {
            double xa = a.getX()-x;
            a.setLocation( (int)(x+v.getX()+xa+.5), (int)(y+v.getY() - getImage().getHeight()/2-a.getImage().getHeight()/2));
        }
    }
}
