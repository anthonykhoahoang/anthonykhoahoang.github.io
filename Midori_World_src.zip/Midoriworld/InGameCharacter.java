import greenfoot.*; 
import java.util.List;
/**
 * Write a description of class TestChar here.
 * 
 * @author Anthony Hoang
 * @version (v1)
 */
public class InGameCharacter  extends InGameObjects
{
    private static GreenfootImage[] img;
    private static GreenfootImage[] run;
    private static GreenfootImage[] crouch;
    
    private String left, left2, right, right2, jump, jump2, down, down2, use, suitpower;
    private boolean firstInitialize = true;
    
    private boolean isFalling;
    private boolean jumping;
    private boolean jumpingLeft;
    private boolean jumpingRight;
    private boolean jumpingOffWall;
    private boolean nextToWall;
    
    private int WALKSPEED;
    
    private double jumpSpeed;
    private double JUMPSPEEDMAX = 6;
    private double JUMPSPEEDMINUS = .2;
    private int jumpDelay;
    private int JUMPDELAYMAX = 40;
    private int jumpOffWallDelay;
    private int JUMPOFFWALLDELAYMAX = 20;
    private int jumpOffWallCount;
    private int JUMPOFFWALLMAX = 3;
    private int jumpingOffWallDir; // 0 right, 1 left
    
    private double fallSpeed;
    private double FALLSPEEDADD = .3;
    
    private boolean isSlidding;
    private double GROUNDSLIDESPEED;
    private double GROUNDSLIDESPEEDMAX = 3;
    private boolean goingLeft;
    private boolean goingRight;
    public boolean imgRight;
    public   boolean imgLeft;
    
    private boolean isCrouching = false;
    
    private int imageDelay = 0;  
    private int curRun = 0;
    private int acidBurnDelay = 0;
    private int sprintShadowDelay = 2;
    //private int health = 100;
    
    public InGameCharacter()
    {
        initialize();
    }
    public GreenfootImage[] getImagesImg()
    {
        return img;
    }
    public GreenfootImage[] getImagesRun()
    {
        return run;
    }
    public GreenfootImage[] getImagesCrouch()
    {
        return crouch;
    }
    public void acidBurn()
    {
        int h = getY()+getImage().getHeight()/2-3;
        if (isGreenAt(getX(),h))
        {
            jumping = true;
            jumpSpeed = JUMPSPEEDMAX+2;
            fallSpeed = 0;
            jump();
            acidBurnDelay = 10;
            Greenfoot.playSound("burn.wav");
            hit(10);
        }
        if (acidBurnDelay > 0)
        {
            getMWorld().addObject(new SmokeParticle((int)(Math.random()*90)+180),getX(),h+3);
            getMWorld().addObject(new SmallSmudgeParticle((int)(Math.random()*90)+180),getX(),h+3);
            getMWorld().addObject(new SmokeParticle((int)(Math.random()*90)+180),getX()+10,h);
            getMWorld().addObject(new SmallSmudgeParticle((int)(Math.random()*90)+180),getX()+10,h);
            acidBurnDelay--;
        }
        //if (acidBurnDelay > 0)
    }
    public void setKeys()
    {
        left = getMWorld().left; left2 = getMWorld().left2; 
        right = getMWorld().right; right2 = getMWorld().right2;
        jump = getMWorld().jump; jump2 = getMWorld().jump2;
        down = getMWorld().crouch; down2 = getMWorld().crouch2; 
        use = getMWorld().use; suitpower = getMWorld().suitpower;
    }
    public void hit(int damage)
    {
        getMWorld().health -= damage;
        if (getMWorld().health < 0)
        getMWorld().health = 0;
    }
    public void heal(int amount)
    {
        getMWorld().health += amount;
        if (getMWorld().health > 100)
        getMWorld().health = 100;
    }
    public void initialize()
    {
        if (img == null)
        {
            img = new GreenfootImage[6];
            img[0] = new GreenfootImage("midoingame/stand.png");
            img[1] = new GreenfootImage("midoingame/slide.png");
            img[2] = new GreenfootImage("midoingame/jump.png");
            for (int i = 3; i < 6; i++)
            {
                img[i] = new GreenfootImage(img[i-3]);
                img[i].mirrorHorizontally();
            }
        }
        if (run == null)
        {   
            run = new GreenfootImage[16];
            run[0] = new GreenfootImage("midoingame/run1.png");
            run[1] = new GreenfootImage("midoingame/run2.png");
            run[2] = new GreenfootImage("midoingame/run3.png");
            run[3] = new GreenfootImage("midoingame/run4.png");
            run[4] = new GreenfootImage("midoingame/run5.png");
            run[5] = new GreenfootImage("midoingame/run6.png");
            run[6] = new GreenfootImage("midoingame/run7.png");
            run[7] = new GreenfootImage("midoingame/run8.png");
            for (int i = 0; i < 8; i++)
            {
                run[i+8] = new GreenfootImage(run[i]);
                run[i+8].mirrorHorizontally();
            }
        }
        if (crouch == null)
        {
            crouch = new GreenfootImage[6];
            crouch[0] = new GreenfootImage("midoingame/crouch1.png");
            crouch[1] = new GreenfootImage("midoingame/crouch2.png");
            crouch[2] = new GreenfootImage("midoingame/crouch3.png");
            for (int i = 0; i < 3; i++)
            {
                crouch[i+3] = new GreenfootImage(crouch[i]);
                crouch[i+3].mirrorHorizontally();
            }
        }
        
        WALKSPEED = 3;
        jumping = false;
        isFalling = false;
        jumpingLeft = false;
        jumpingRight = false;
        jumpingOffWall = false;
        nextToWall = false;
        jumpingOffWallDir = 0; // 0 right, 1 left
        fallSpeed = 0;
        GROUNDSLIDESPEED = GROUNDSLIDESPEEDMAX;
        isSlidding = false;
        goingLeft = false;
        goingRight = false;
        imgRight = true;
        imgLeft = false;
        setImage(img[0]);
        jumpDelay = 0;
        jumpSpeed = JUMPSPEEDMAX;
        jumpOffWallDelay = 0;
    }
    public void setCurrentImage()
    {
        if (jumping || isFalling)  //falling/jumping
        {
            if (imgRight) 
            {
                if (!getImage().equals(img[2]))
                setImage(img[2]);
            }
            else 
            if (!getImage().equals(img[5]))
            setImage(img[5]);
        }
        else
        if (!isFalling && !jumping && !isSlidding && isCrouching) //setimage crouching
        {
            if (goingRight)
            {
                if (imageDelay<8) {imageDelay++; return;}
                if (getImage().equals(crouch[0])) setImage(crouch[1]);
                else if (getImage().equals(crouch[1])) setImage(crouch[2]);
                else setImage(crouch[0]);
                imageDelay = 0;
            }
            else
            if (goingLeft)
            {
                if (imageDelay<8) {imageDelay++; return;}
                if (getImage().equals(crouch[3])) setImage(crouch[4]);
                else if (getImage().equals(crouch[4])) setImage(crouch[5]);
                else setImage(crouch[3]);
                imageDelay = 0;
            }
            else 
            if (imgLeft)
            {
                if (!getImage().equals(crouch[3]))
                setImage(crouch[3]);
            }
            else 
            if (!getImage().equals(crouch[0]))
            setImage(crouch[0]);
        }
        else
        if (!isFalling && !jumping && !isSlidding 
        && (goingLeft||goingRight) && !isCrouching) //going left/right
        {
            if (goingRight)
            {
                if (imageDelay < 1) {imageDelay++; return;}
                setImage(run[curRun]);
                curRun++;
                if (curRun > 7)
                { curRun = 0;}
                imageDelay = 0;
            }
            else
            if (goingLeft)
            {
                if (imageDelay < 1) {imageDelay++; return;}
                setImage(run[curRun+8]);
                curRun++;
                if (curRun > 7)
                { curRun = 0;}
                imageDelay = 0;
            }
        }
        else
        if (!isFalling && !jumping && !isSlidding) 
        {
            if (getImage().equals(img[2])) setImage(crouch[0]);
            else if (getImage().equals(img[5])) setImage(crouch[3]);
            if ((getImage().equals(crouch[3]) || getImage().equals(crouch[0])) && imageDelay < 7) 
            { imageDelay++; }
            else
            { 
                imageDelay = 0;
                if (imgRight) 
                {
                    if (!getImage().equals(img[0]))
                    setImage(img[0]);
                }
                else 
                if (!getImage().equals(img[3]))
                setImage(img[3]);
            }
        }
        else
        if (isSlidding && !isFalling && !jumping) //slide
        {
            if (imgRight)
            {
                if (!getImage().equals(img[1]))
                setImage(img[1]);
            }
            else 
            if (!getImage().equals(img[4]))
            setImage(img[4]);
        }
    }
    public void slideOnGround()
    {
        if (!isSlidding) return;
        if (!goingLeft && !goingRight) { isSlidding = false;
            return;
        }
        int x2;
        if (GROUNDSLIDESPEED < 0)
        {
            isSlidding = false;
            GROUNDSLIDESPEED = GROUNDSLIDESPEEDMAX;
            goingRight = false;
            goingLeft = false;
            
        }
        if (goingRight)
        {
            x2 = getX()+getImage().getWidth()/2+(int)GROUNDSLIDESPEED;
            if (blackBetweenX(x2))
            {
                isSlidding = false;
                GROUNDSLIDESPEED = GROUNDSLIDESPEEDMAX;
                goingRight = false;
                goingLeft = false;
                gotoNextBlackX(x2);
            }
            else
            {
                if (getImage().equals(img[1]))
                for (int i = 0; i < 1; i++)
                getMWorld().addObject(new DustParticle(180),getX()+getImage().getWidth()/6,getY()+getImage().getHeight()/2);
                gotoNextBlackX(x2);
                GROUNDSLIDESPEED -= .2;
            }
        }
        if (goingLeft)
        {
            x2 = getX()-getImage().getWidth()/2-(int)GROUNDSLIDESPEED;
            if (blackBetweenX(x2))
            {
                isSlidding = false;
                GROUNDSLIDESPEED = GROUNDSLIDESPEEDMAX;
                goingRight = false;
                goingLeft = false;
                gotoNextBlackX(x2);
            }
            else
            {
                if (getImage().equals(img[4]))
                for (int i = 0; i < 1; i++)
                getMWorld().addObject(new DustParticle(0),getX()-getImage().getWidth()/6,getY()+getImage().getHeight()/2);
                gotoNextBlackX(x2);
                GROUNDSLIDESPEED-=.2;
            }
        }
    }
    public void act() 
    {
        if (firstInitialize)
        {
            setKeys();
            firstInitialize = false;
        }
        if (getMWorld().esPause) return;
        if (getMWorld().health == 0)
        {
            getMWorld().removeObjects(getMWorld().getObjects(EventScript.class));
            getMWorld().addEventScript("gameOver.txt");
            getMWorld().esPause = true;
        }
        acidBurn();
        checkKeys();
        slideOnGround();
        checkNextToWall();
        fallTest();
        jump();
        jumpOffWall();
        setCurrentImage();
    }    
    public void checkKeys()
    {
        if (jumpDelay > 0)
        jumpDelay--;
        if (jumpOffWallDelay > 0) jumpOffWallDelay--;
        if (Greenfoot.isKeyDown(jump)||Greenfoot.isKeyDown(jump2))
        {
            if (!jumping && !isFalling && jumpDelay == 0 )
            {
               if (isCrouching
                && isBlackAt(getX(), getY()-getImage().getHeight()/2+1))
               {}
               else {
                for (int i = 0; i < 2; i++)
                {
                    getMWorld().addObject(new DustParticle(0),
                    getX()+2,getY()+getImage().getHeight()/2);
                    getMWorld().addObject(new DustParticle(180),
                    getX()-2,getY()+getImage().getHeight()/2);
                }
                jumping = true;
                isFalling = true;
                if(isCrouching) jumpSpeed = JUMPSPEEDMAX+1;
                isCrouching = false;
                fallSpeed = 0;
                if (Greenfoot.isKeyDown(left)||Greenfoot.isKeyDown(left2))
                {
                    jumpingLeft = true;
                    imgRight = false;
                    imgLeft = true;
                }
                if (Greenfoot.isKeyDown(right)||Greenfoot.isKeyDown(right2))
                {
                    jumpingRight = true;
                    imgRight = true;
                    imgLeft = false;
                }
                jumpDelay = JUMPDELAYMAX;
            } 
            }
            if (isFalling && !jumping && nextToWall
            && jumpOffWallDelay == 0 && jumpOffWallCount < JUMPOFFWALLMAX)
           // && !isCrouching
              //  && !isBlackAt(getX(), getY()-getImage().getHeight()/2+1))
            {
                jumpOffWallCount++;
                fallSpeed =0;
                
                    for (int i = 0; i < 4; i++)
                    {
                        getMWorld().addObject(new DustParticle(100),
                        getX(),getY()+getImage().getHeight()/2);
                    }
                if (Greenfoot.isKeyDown(right)||Greenfoot.isKeyDown(right2))
                {
                    jumpingLeft = true;
                    jumpingRight = false;
                    imgRight = true;
                    imgLeft = false;
                }
                if (Greenfoot.isKeyDown(left)||Greenfoot.isKeyDown(left2))
                {
                    jumpingRight = true;
                    jumpingLeft = false;
                    imgRight = false;
                    imgLeft = true;
                }
                jumpingOffWall = true;
                jumpOffWallDelay = JUMPOFFWALLDELAYMAX;
            }
        }
        if (jumpingOffWall && jumpSpeed > JUMPSPEEDMAX/2) return;
        if (!isFalling && !jumping && (Greenfoot.isKeyDown(down)||Greenfoot.isKeyDown(down2)))
        {
            isCrouching = true;
            goingRight = false;
            goingLeft = false;
            if (Greenfoot.isKeyDown(left2)||Greenfoot.isKeyDown(left)) goingRight = true;
            else
            if (Greenfoot.isKeyDown(right)||Greenfoot.isKeyDown(right2)) goingLeft = true;
        }
        if (!Greenfoot.isKeyDown(down)&&!Greenfoot.isKeyDown(down2))
        {
           if( !isBlackAt(getX(), getY()-getImage().getHeight()/2-1))
           isCrouching = false;
           else
           {
               if (!Greenfoot.isKeyDown(left)&&!Greenfoot.isKeyDown(left2))
               goingLeft = false;
               if (!Greenfoot.isKeyDown(right2)&&!Greenfoot.isKeyDown(right))
               goingRight = false;
            }
        }
        if (Greenfoot.isKeyDown(left)||Greenfoot.isKeyDown(left2))
        {
            moveLeft();
            if (!goingLeft && !isFalling && !jumping && !isCrouching)
            for (int i = 0; i < 4; i++)
            {
                getMWorld().addObject(new DustParticle(0),
                getX()+getImage().getWidth()/4,getY()+getImage().getHeight()/2);
            }
            goingLeft = true;
            goingRight = false;
            isSlidding = false;
            imgRight = false;
            imgLeft = true;
        }
        else
        if (Greenfoot.isKeyDown(right2)||Greenfoot.isKeyDown(right))
        {
            moveRight();
            if (!goingRight && !isFalling && !jumping & !isCrouching)
            for (int i = 0; i < 4; i++)
            {
                getMWorld().addObject(new DustParticle(180),
                getX()-getImage().getWidth()/4,getY()+getImage().getHeight()/2);
            }
            goingRight = true;
            goingLeft = false;
            isSlidding = false;
            imgRight = true;
            imgLeft = false;
        }
        else if (!isCrouching) isSlidding = true;
        else isSlidding = false;
   
    }
    public void moveLeft()
    {
        int boost = 0;
        NanoSuit nanosuit = (NanoSuit)getOneIntersectingObject(NanoSuit.class);
        if (nanosuit != null)
        {
            if (nanosuit.getCurPower() == 1 && nanosuit.active())
            {
                if (sprintShadowDelay == 0)
                {
                    getMWorld().addObject(new CharacterPhase(),getX(),getY());
                    sprintShadowDelay = 2;
                }
                boost = 2;
                nanosuit.lowerEnergy(.5);
                if (sprintShadowDelay > 0) sprintShadowDelay--;
            }
        }
        if(isCrouching)
        moveX(getX()-WALKSPEED/2-boost);
        else
        moveX(getX()-WALKSPEED-boost);
        isSlidding = true;
    }
    public void moveRight()
    {
        int boost = 0;
        NanoSuit nanosuit = (NanoSuit)getOneIntersectingObject(NanoSuit.class);
        if (nanosuit != null)
        {
            if (nanosuit.getCurPower() == 1 && nanosuit.active())
            {
                if (sprintShadowDelay == 0)
                {
                    getMWorld().addObject(new CharacterPhase(),getX(),getY());
                    sprintShadowDelay = 2;
                }
                boost = 2;
                nanosuit.lowerEnergy(.5);
                if (sprintShadowDelay > 0) sprintShadowDelay--;
            }
        }
        if (sprintShadowDelay > 0) sprintShadowDelay--;
        if(isCrouching)
        moveX(getX()+WALKSPEED/2+boost);
        else
        moveX(getX()+WALKSPEED+boost);
        isSlidding = true;
    }
    public void checkNextToWall()
    {
        if (blackBetweenX(getX()+getImage().getWidth()/2+1))
        {
            jumpingOffWallDir = 0;
            nextToWall = true;
        }
        else if (blackBetweenX(getX()-getImage().getWidth()/2-1))
        {
            jumpingOffWallDir = 1;
            nextToWall = true;
        }
        else nextToWall = false;
    }
    public boolean noObjectsBelow()
    {
        List<Platform> list = getIntersectingObjects(Platform.class);
        List<HostileEnemy> list2 = getIntersectingObjects(HostileEnemy.class);
        //if (list.size() == 0) return true;
        //boolean bool = false;
        for (int i=0; i<list.size(); i++)
        {
            InGameObjects a = list.get(0);
            int w = a.getImage().getWidth()/2;
            int h = a.getImage().getHeight()/2;
            if (a.getY() > getY()+getImage().getHeight()/2
            && a.getX()+w >= getX() && a.getX()-w <= getX())
            {
                if (isFalling)
                for (int j = 0; j < 4; j++)
                {
                    getMWorld().addObject(new DustParticle(180),
                    getX()-getImage().getWidth()/4,getY()+getImage().getHeight()/2);
                    getMWorld().addObject(new DustParticle(0),
                    getX()+getImage().getWidth()/4,getY()+getImage().getHeight()/2);
                }
                //isFalling = false;
                return false;
            }
            //else return true;
            //return false;
        }
        for (int i=0; i<list2.size(); i++)
        {
            InGameObjects a = list2.get(0);
            int w = a.getImage().getWidth()/2;
            int h = a.getImage().getHeight()/2;
            if (a.getY() > getY()+getImage().getHeight()/2
            && a.getX()+w >= getX() && a.getX()-w <= getX())
            {
                if (isFalling)
                for (int j = 0; j < 4; j++)
                {
                    getMWorld().addObject(new DustParticle(180),
                    getX()-getImage().getWidth()/4,getY()+getImage().getHeight()/2);
                    getMWorld().addObject(new DustParticle(0),
                    getX()+getImage().getWidth()/4,getY()+getImage().getHeight()/2);
                }
                return false;
            }
        }
        return true;
    }
    public void fallTest()
    {
        if (jumpingOffWall || jumping) {
             return;}
        int y1 = getY(), y2 = getY()+getImage().getHeight()/2;
        if (!blackBetweenY(y2+1) )
        {
            isFalling = noObjectsBelow();
            
            if(isFalling)
            fallSpeed += FALLSPEEDADD;
            else // platform below
            {
                fallSpeed = 0;
                jumpOffWallCount = 0;
                gotoNextBlackY(y2);
            }
        }
        else //on ground
        {
            fallSpeed = 0;
            jumpingRight = false;
            jumpingLeft = false;
            jumpOffWallCount = 0;
            gotoNextBlackY(y2);
            if (isFalling)
            for (int i = 0; i < 4; i++)
            {
                getMWorld().addObject(new DustParticle(180),
                getX()-getImage().getWidth()/4,getY()+getImage().getHeight()/2);
                getMWorld().addObject(new DustParticle(0),
                getX()+getImage().getWidth()/4,getY()+getImage().getHeight()/2);
            }
            isFalling = false;
        }
        if (isFalling)
        {
            y2 = y1+getImage().getHeight()/2+(int)fallSpeed;
            if (nextToWall) //slide down instead
            y2 -= (int)fallSpeed/2;
            gotoNextBlackY(y2);
        }
    }
    public void jumpOffWall()
    {
        int y2;
        int x2; 
        if (!jumpingOffWall) return;
        jumpSpeed -= JUMPSPEEDMINUS;
        if (jumpSpeed < 0)
        {
            jumpingOffWall = false;
            jumpSpeed = JUMPSPEEDMAX;
            return;
        }
        if (jumpingOffWallDir == 0) //wall to right
        {
            imgLeft = true;
            imgRight = false;
            x2 = getX()-getImage().getWidth()/2-(int)jumpSpeed/2;
            y2 = getY()-getImage().getHeight()/2-(int)jumpSpeed;
            if (blackBetweenY(y2) || blackBetweenX(x2))
            {
                jumpingOffWall = false;
                gotoNextBlackY(y2);
                gotoNextBlackX(x2);
            }
            else
            {
                gotoNextBlackY(y2);
                gotoNextBlackX(x2);
            }
        }
        else //wall to left
        {
            imgRight = true;
            imgLeft = false;
            x2 = getX()+getImage().getWidth()/2+(int)jumpSpeed/2;
            y2 = getY()-getImage().getHeight()/2-(int)jumpSpeed;
            if (blackBetweenY(y2) || blackBetweenX(x2))
            {
                jumpingOffWall = false;
                gotoNextBlackX(x2);
                gotoNextBlackY(y2);
            }
            else
            {
                gotoNextBlackX(x2);
                gotoNextBlackY(y2);
            }
        }
    }
    public void jump()
    {
        if (!jumping) return;
        int y1 = getY();
        int y2 = getY()-getImage().getHeight()/2-(int)jumpSpeed;
        jumpSpeed -= JUMPSPEEDMINUS;
        if (jumpSpeed < 0)
        {
            jumping = false;
            jumpSpeed = JUMPSPEEDMAX;
        }
        else
        {
            if (blackBetweenY(y2))
            {
                jumping = false;
                jumpSpeed = JUMPSPEEDMAX;
                gotoNextBlackY(y2);
            }
            else
            {
                gotoNextBlackY(y2);
            }
        }
    }
    public void moveX(int dX2)
    {
        int dX = getX();
        int height = getImage().getHeight()/2;
        int width = getImage().getWidth()/2;
        int n = height/2;
        if (isCrouching) height -= getImage().getHeight()/2; 
        if (!isCrouching && (isFalling||jumping) 
        && (Greenfoot.isKeyDown(down)||Greenfoot.isKeyDown(down2)))
        height -= getImage().getHeight()/2; 
        if (isFalling || jumping) width-=getImage().getWidth()/8;
        else if ((!goingRight||!goingLeft)||!isCrouching) width-= getImage().getWidth()/8;
        int dY = getY();
        if (dX > dX2)//moveleft
        //while (dX > dX2 && !isBlackAt(dX-width, dY-height)
        //&& !isBlackAt(dX-width,dY))
        while (dX > dX2 &&
        !isBlackBetweenY_X(dY-height,dY+getImage().getHeight()/10,dX-width))
        {
            dX--;
            //while (isBlackAt(dX+width, dY+height))
            while(isBlackBetweenX_Y(dX-width/4,dX+width/4,dY+height))
            dY--;
        }
        else//moveright
        while (dX < dX2 //&& !isBlackAt(dX+width, dY-height)
        && !isBlackBetweenY_X(dY-height,dY+getImage().getHeight()/10,dX+width))
        //&& !isBlackAt(dX+width,dY))
        {
            dX++;
            //while (isBlackAt(dX-width, dY+height))
            while(isBlackBetweenX_Y(dX-width/4,dX+width/4,dY+height))
            dY--;
        }
        if (getY()-dY > getImage().getHeight()) return;
        if (isFalling || jumping)
        setLocation(dX, getY());
        else
        setLocation(dX, dY);
        
        if (isFalling || jumping) return;
        int y2 = getY()+getImage().getHeight();
        if (blackBetweenY(getY()+getImage().getHeight()))
        {
            //isFalling = false;
            gotoNextBlackY(y2);
        }
    }
    public boolean greenBetweenX(int x2)
    {
        int x1 = getX();
        if (x1 < x2)
        return greenBetweenXRight(x2);
        return greenBetweenXLeft(x2);
    }
    public boolean greenBetweenXRight(int x2)
    {
        int x1 = getX();
        int y1 = getY();
        if (!isCrouching)
        y1 -= getImage().getHeight()/2;
        while (x1 < x2)
        {
            if (isGreenAt(x1, y1))
            return true;
            x1++;
        }
        return false;
    }
    public boolean greenBetweenXLeft(int x2)
    {
        int x1 = getX();
        int y1 = getY();
        if (!isCrouching)
        y1 -= getImage().getHeight()/2;
        while (x1 > x2)
        {
            if (isGreenAt(x1, y1))
            return true;
            x1--;
        }
        return false;
    }
    public boolean blackBetweenX(int x2)
    {
        int x1 = getX();
        if (x1 < x2)
        return blackBetweenXRight(x2);
        return blackBetweenXLeft(x2);
    }
    public boolean blackBetweenXRight(int x2)
    {
        int x1 = getX();
        int y1 = getY();
        if (!isCrouching && !isFalling)
        y1 -= getImage().getHeight()/2;
        while (x1 < x2)
        {
            if (isBlackAt(x1, y1))
            return true;
            x1++;
        }
        return false;
    }
    public boolean blackBetweenXLeft(int x2)
    {
        int x1 = getX();
        int y1 = getY();
        if (!isCrouching&& !isFalling)
        y1 -= getImage().getHeight()/2;
        while (x1 > x2)
        {
            if (isBlackAt(x1, y1))
            return true;
            x1--;
        }
        return false;
    }
    public void gotoNextGreenX(int x2)
    {
        int x1 = getX();
        if (x1 < x2)
        gotoNextGreenXRight(x2);
        else
        gotoNextGreenXLeft(x2);
    }
    public void gotoNextGreenXRight(int x2)
    {
        int x1 = getX();
        while (x1 < x2)
        {
            if (isGreenAt(x1,getY()))
            {                 
                setLocation(x1-getImage().getWidth()/2, getY());
                return;
            }
            x1++;
        }
        if (x1 == getX()) return;
        setLocation(x1-getImage().getWidth()/2, getY());
    }
    public void gotoNextGreenXLeft(int x2)
    {
        int x1 = getX();
        while (x1 > x2)
        {
            if (isGreenAt(x1,getY()))
            {                 
                setLocation(x1+getImage().getWidth()/2, getY());
                return;
            }
            x1--;
        }        
        if (x1 == getX()) return;
        setLocation(x1+getImage().getWidth()/2, getY());
    }
    public void gotoNextBlackX(int x2)
    {
        int x1 = getX();
        if (x1 < x2)
        gotoNextBlackXRight(x2);
        else
        gotoNextBlackXLeft(x2);
    }
    public void gotoNextBlackXRight(int x2)
    {
        int x1 = getX();
        while (x1 < x2)
        {
            if (isBlackAt(x1,getY()))
            {                 
                setLocation(x1-getImage().getWidth()/2, getY());
                return;
            }
            x1++;
        }
        if (x1 == getX()) return;
        setLocation(x1-getImage().getWidth()/2, getY());
    }
    public void gotoNextBlackXLeft(int x2)
    {
        int x1 = getX();
        while (x1 > x2)
        {
            if (isBlackAt(x1,getY()))
            {                 
                setLocation(x1+getImage().getWidth()/2, getY());
                return;
            }
            x1--;
        }        
        if (x1 == getX()) return;
        setLocation(x1+getImage().getWidth()/2, getY());
    }
    public boolean blackBetweenY( int y2)
    {
        int y1 = getY();
        if (y1 < y2)
        return blackBetweenYDown(y2);
        return blackBetweenYUp(y2);
    }
    public boolean blackBetweenYDown(int y2)
    {
        int y1 = getY();
        while (y1 < y2)
        {
            if (isBlackBetweenX_Y(getX()-getImage().getWidth()/7,getX()+getImage().getWidth()/7,y1))
            return true;
            y1++;
        }
        return false;
    }
    public boolean blackBetweenYUp(int y2)
    {
        int y1 = getY();
        while (y1 > y2)
        {
            if (isBlackBetweenX_Y(getX()-getImage().getWidth()/7,getX()+getImage().getWidth()/7,y1))
            return true;
            y1--;
        }
        return false;
    }
    public void gotoNextBlackY(int y2)
    {
        int y1 = getY();
        if (y1 < y2)
        gotoNextBlackYDown(y2);
        else
        gotoNextBlackYUp(y2);
    }
    public void gotoNextBlackYDown(int y2)
    {
        int y1 = getY();
        while (y1 < y2)
        {

            if (isBlackBetweenX_Y(getX()-getImage().getWidth()/7,getX()+getImage().getWidth()/7,y1))
            {                
                setLocation(getX(), y1-getImage().getHeight()/2);
                return;
            }
            y1++;
            setLocation(getX(), y1-getImage().getHeight()/2);
            List<Platform> list = getIntersectingObjects(Platform.class);
            for (int i=0; i<list.size(); i++)
            {
                InGameObjects a = list.get(0);
                int w = a.getImage().getWidth()/2;
                int h = a.getImage().getHeight()/2;
                if (a.getY()-h >= getY()+getImage().getHeight()/2
                && a.getX()+w >= getX() && a.getX()-w <= getX())
                {
                    fallSpeed = 0;
                    jumpOffWallCount = 0;
                    //setLocation(getX(), y1-getImage().getHeight()/2);
                    if (isFalling)
                    for (int j = 0; j < 4; j++)
                    {
                        getMWorld().addObject(new DustParticle(180),
                        getX()-getImage().getWidth()/4,getY()+getImage().getHeight()/2);
                        getMWorld().addObject(new DustParticle(0),
                        getX()+getImage().getWidth()/4,getY()+getImage().getHeight()/2);
                    }
                    isFalling = false;
                    setLocation(getX(),a.getY()-h-getImage().getWidth()/2);
                    return;
                }
            }
            List<HostileEnemy> list2 = getIntersectingObjects(HostileEnemy.class);
            for (int i=0; i<list2.size(); i++)
            {
                InGameObjects a = list2.get(0);
                int w = a.getImage().getWidth()/2;
                int h = a.getImage().getHeight()/2;
                if (a.getY()-h >= getY()+getImage().getHeight()/2
                && a.getX()+w >= getX() && a.getX()-w <= getX())
                {
                    fallSpeed = 0;
                    jumpOffWallCount = 0;
                    //setLocation(getX(), y1-getImage().getHeight()/2);
                    if (isFalling)
                    for (int j = 0; j < 4; j++)
                    {
                        getMWorld().addObject(new DustParticle(180),
                        getX()-getImage().getWidth()/4,getY()+getImage().getHeight()/2);
                        getMWorld().addObject(new DustParticle(0),
                        getX()+getImage().getWidth()/4,getY()+getImage().getHeight()/2);
                    }
                    isFalling = false;
                    setLocation(getX(),a.getY()-h-getImage().getWidth()/2);
                    return;
                }
            }
        }
        //setLocation(getX(), y1-getImage().getHeight()/2);
    }
    public void gotoNextBlackYUp(int y2)
    {
        int y1 = getY();
        while (y1 > y2)
        {
            if (isBlackBetweenX_Y(getX()-getImage().getWidth()/7,getX()+getImage().getWidth()/7,y1))
            {
                setLocation(getX(), y1+getImage().getHeight()/2);
                return;
            }
            y1--;
        }
        setLocation(getX(), y1+getImage().getHeight()/2);
    }
    public boolean isBlackBetweenX_Y(int x1, int x2, int y1)
    {
        while(x1 < x2)
        {
            if (isBlackAt(x1,y1))
            return true;
            x1++;
        }
        return false;
    }
    public boolean isBlackBetweenY_X(int y1, int y2, int x1)
    {
        while(y1 < y2)
        {
            if (isBlackAt(x1,y1))
            return true;
            y1++;
        }
        return false;
    }
}
