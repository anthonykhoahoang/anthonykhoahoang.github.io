import greenfoot.*;  // (World, Actor, GreenfootImage, and Greenfoot)
import java.util.List;

/**
 * A space ship boss. It comes from space and will attack you
 * Author: Anthony Hoang
 */
public class AlienShipBoss extends Enemy
{
    private int minGunFireDelay;    
    /** How long ago we fired the gun the last time. */
    private int gunFireDelay = 0;    
    
    private int numActs;
    private int coolDown;
    
    /** Delay time for AAS attack */
    private int aasDelay = 400;
     
    private int numActsMax;
    private int damage;
    private int coolDownDelay;
    private int empDelay = 0;
    
    public AlienShipBoss(int life, int maxActs, int bulletDamage, int coolDelay)
    {
        super(life, 500);
        setImage("enemyShip/spaceshipBoss.png");
        minGunFireDelay = 2;
        gunFireDelay = 0;
        numActs = 0;
        coolDown = 0;
        numActsMax = maxActs;
        damage = bulletDamage;
        coolDownDelay = coolDelay;
    }

    /**
     * Let the ship act: move or release greeps.
     */
    public void act()
    {
        getSpace().bossLife.setLocation(this.getX(), this.getY() + getImage().getWidth() / 2);
        getSpace().bossLife.updateImage2(this.healthPercent());
        if (getEmpDelay() >= 0)
        {
            if(numActs > numActsMax)
            {
                shootRayGun();
                gunFireDelay++;
            }
        
            if (numActs > numActsMax+10)
            numActs = 0;
            numActs++;
            if (numActs > 0)
            {
                coolDown++;
                setImage("enemyShip/spaceshipBoss.png");
            }
            else
            setImage("enemyShip/spaceshipBossCoolDown.png");
            if (coolDown == coolDownDelay)
            {
                numActs = -80;
                coolDown = 0;
            }
            aasDelay--;
            if (aasDelay <= 0)
            {
                AAS();
                aasDelay = 400;
            }
            move();
            
            if (randomChance(10))
            turn(10);
        }
        else
        super.act();
    }
    public void shootRayGun()
    {
            if(gunFireDelay >= minGunFireDelay) 
            {
                EB5 b = new EB5( turnToShipInt(), 900, true, this);
                getWorld().addObject(b, getX(), getY());
                b.move();
                gunFireDelay = 0;
           }         
    }
    
    public void AAS()
    {
        int r = getRotation();
        for (int i = 0; i < 360; i++)
        {
            EB2 b = new EB2(r, 900, false, this);
            getWorld().addObject(b, getX(), getY());
            b.move();
            r += 10;
        }
        Greenfoot.playSound("aas.wav");
    }
}