import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class InfoLoader here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class InfoLoader extends Actor
{
    private String file;
    private boolean hasClicked=false;
    public InfoLoader (String File)
    {
        file = File;
    }
    public void act() 
    {
        if ( (!hasClicked 
            || (Greenfoot.isKeyDown("e")&& getOneIntersectingObject(Text.class) == null) ) && getOneIntersectingObject(InGameChar.class) != null)
        {
            ((Land)getWorld()).addObject(new AutoText(file, 200, 12f), getX(),getY());
            hasClicked = true;
        }
        if (Greenfoot.isKeyDown("1") && getOneIntersectingObject(Tuturial.class) == null && getOneIntersectingObject(InGameChar.class) != null) 
        {
            Greenfoot.playSound("click.wav");
            getLand().addObject(new FadeOut(), getLand().getWidth()/2, getLand().getHeight()/2);
            getLand().addObject(new Tuturial("basics1"), 512, 300);
        }
        
        if (Greenfoot.isKeyDown("2") && getOneIntersectingObject(Tuturial.class) == null && getOneIntersectingObject(InGameChar.class) != null) 
        {
            Greenfoot.playSound("click.wav");
            getLand().addObject(new FadeOut(), getLand().getWidth()/2, getLand().getHeight()/2);
            getLand().addObject(new Tuturial("basics2"), 512, 300);
        }
        
        setRotation(getRotation()+1);
    }  
    
    public Land getLand()
    {
        return (Land)getWorld();
    }
    
}
