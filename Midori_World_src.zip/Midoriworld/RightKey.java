import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.awt.Color;
/**
 * Write a description of class RightKey here.
 * 
 * @author Anthony Hoang
 * @version (v1)
 */
public class RightKey  extends Keys
{
    public RightKey()
    {
        super("d");
    }
    public void act() 
    {
        super.act();
    }    
    public void doChange()
    {
        String key = Greenfoot.getKey();
        if (key!=null)
        {
            getMWorld().right = ""+key;
            super.doChange();
            redraw = true;
        }
        else
        if (redraw)
        {
            getImage().clear();
            getImage().setColor(Color.BLUE);
            getImage().drawRect(0,0,getImage().getWidth(),getImage().getHeight());
            getImage().setColor(Color.RED);
            getImage().drawString(getMWorld().right, 2, 25);
            redraw = false;
        }
    }
    public void doNoChange()
    {
        if (redraw)
        {
            getImage().clear();
            getImage().setColor(Color.BLUE);
            getImage().drawRect(0,0,getImage().getWidth(),getImage().getHeight());
            getImage().setColor(Color.WHITE);
            getImage().drawString(getMWorld().right, 2, 25);   
            redraw = false;
        }
    }
}
