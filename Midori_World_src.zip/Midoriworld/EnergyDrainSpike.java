import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.util.List;
/**
 * Write a description of class EnergyDrainSpike here.
 * 
 * @author Anthony Hoang
 * @version (v1)
 */
public class EnergyDrainSpike  extends Particle
{
    private GreenfootImage img;
    private int transparency = 120;
    private int transReduce = 5;
    private boolean firstInitialize = true;
    private double x;
    private double y;
    private int r;
    private Vector v = new Vector();
    private boolean hasHit = false;
    private InGameCharacter igc;
    private int life = 50;
    
    public EnergyDrainSpike(int r)
    {
        this.r = r;
        img = new GreenfootImage("energyDrainSpike.png");
        //img.scale(img.getWidth()/2, img.getHeight()/2);
        setImage(img);
        //setImage(new GreenfootImage(img));
    }
    public void act() 
    {
        if (getMWorld().esPause) return;
        setRotation(getRotation()+10);
        if (firstInitialize)
        {
            x = getX();
            y = getY();
            firstInitialize = false;
        }
        if (!hasHit)
        {
            checkHit();
        }
        if (!hasHit)
        move();
        else
        explode();
    }   
    public void explode()
    {
        for (int i = 0; i < 5; i++)
        {
            int rand = (int)(Math.random()*4);
            int nx = getX(), ny = getY();
            if (rand == 0)
            {
                nx += (int)(Math.random()*10);
                ny += (int)(Math.random()*10);
            }
            if (rand == 1)
            {
                nx -= (int)(Math.random()*10);
                ny += (int)(Math.random()*10);
            }
            if (rand == 2)
            {
                nx -= (int)(Math.random()*10);
                ny -= (int)(Math.random()*10);
            }
            if (rand == 3)
            {
                nx += (int)(Math.random()*10);
                ny -= (int)(Math.random()*10);
            }
            getMWorld().addObject(new SmallYellowParticle((int)(Math.random()*360)),nx,ny);
        }
        if (life > 0)
        {
            life--;
            //return;
        }
        int w = getImage().getWidth();
        int h = getImage().getHeight();
        if (w <= 5 || h <= 5)
        getMWorld().removeObject(this);
        else
        getImage().scale(w-5, h-5);
    } 
    public void random()
    {
        v.add(new Vector((int)(Math.random()*360),Math.random()*.3));
        v.add(new Vector(270, .04));
    }
    public void move()
    {
        v.add(new Vector(r, .05));
        x+=v.getX();
        y+=v.getY();
        setLocation((int)x,(int)y);
    }
    public void checkHit()
    {
        List<Platform> list3 = getIntersectingObjects(Platform.class);
        if (list3.size() > 0)
        {
            hasHit = true; 
            return;
        }
        if (isBlackAt(getX(),getY()) )
        {
            hasHit = true;
            return;
        }
        List<InGameCharacter> list = getIntersectingObjects(InGameCharacter.class);
        List<HelperBot> list2 = getIntersectingObjects(HelperBot.class);
        if (list.size() > 0)
        {
            InGameCharacter c = list.get(0);
            List<NanoSuit> list4 = getMWorld().getObjects(NanoSuit.class);
            if (Math.abs(c.getX()-getX()) < 10 && Math.abs(c.getY()-getY()) <20)
            {
                hasHit = true;
                list4.get(0).lowerEnergy(100);
            }
        }
        else
        if (list2.size() > 0)
        {
            HelperBot c = list2.get(0);
            if (Math.abs(c.getX()-getX()) < 5 && Math.abs(c.getY()-getY()) < 5)
            {
                hasHit = true;
                c.hit();
            }
        }
    }
}
