import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.awt.Color;
import java.awt.Font;

/**
 * Write a description of class BattleMenu here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class BattleMenu2 extends Battle
{
    private GreenfootImage image;
    private float FONT_SIZE = 20f;
    private int WIDTH = 200;
    private int HEIGHT = 200;
    public BattleMenu2()
    {
    }

    public BattleMenu2(String name)
    {
        image = new GreenfootImage(WIDTH, HEIGHT);
        image.setColor(new Color(0, 150, 0, 128));
        image.fillRect(0, 0, WIDTH, HEIGHT);
        image.setColor(new Color(0, 100, 0, 128));
        image.fillRect(3, 3, WIDTH-3, HEIGHT-3);
        Font font = image.getFont();
        font = font.deriveFont(FONT_SIZE);
        image.setFont(font);
        image.setColor(Color.WHITE);
        image.drawString(name, 15 , 30);
        setImage(image);
    }
    public void act() 
    {
        // Add your action code here.
    }    
}
