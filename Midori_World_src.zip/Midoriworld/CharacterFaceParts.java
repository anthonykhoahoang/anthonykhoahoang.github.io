import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Character face parts
 * 
 * @author Anthony Hoang
 * @version 1
 */
public class CharacterFaceParts  extends Actor
{
    public Midori getMWorld()
    {
        return (Midori) getWorld();
    }
}
