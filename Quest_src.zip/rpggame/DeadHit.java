import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class DeadHit here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class DeadHit extends Battle
{
    private GreenfootImage dead = new GreenfootImage("Battle/Dead.png");
    public DeadHit()
    {
        setImage(dead);
    }
    public void act() 
    {
        if (getImage().getWidth() <= 1 || getImage().getHeight() <= 1)
        getLand().removeObject(this);
        else
        getImage().scale(getImage().getWidth()-1, getImage().getHeight()-1);
    }    
}
