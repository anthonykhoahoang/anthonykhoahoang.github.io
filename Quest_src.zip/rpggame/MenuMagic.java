import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.awt.Color;
import java.awt.Font;
/**
 * Write a description of class Attack here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class MenuMagic extends BattleMenu
{
    private GreenfootImage image;
    private float FONT_SIZE = 15f;
    private int WIDTH = 200;
    private int HEIGHT = 20;
    public MenuMagic()
    {
        image = new GreenfootImage(WIDTH, HEIGHT);
        Font font = image.getFont();
        font = font.deriveFont(FONT_SIZE);
        image.setFont(font);
        image.setColor(Color.WHITE);
        image.drawString("Magic", 15 , 18);
        setImage(image);
    }
    public void act() 
    {
        if (getOneIntersectingObject(Pointer.class) != null)
        {
            image.setColor(Color.RED);
            image.drawString("Magic", 15 , 18);
        }
        else
        {
            image.setColor(Color.WHITE);
            image.drawString("Magic", 15 , 18);
       
        }
        setImage(image);
    }    
}
