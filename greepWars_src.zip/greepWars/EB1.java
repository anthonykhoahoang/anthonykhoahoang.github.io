import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class EB1 here.
 * 
 * @author Anthony Hoang
 * @version 2.1
 */
public class EB1 extends EnemyBullet
{
    public EB1(int rotation, int life, boolean sounds, Enemy e)
    {
        super( rotation, life, 5, false, e);
        if (sounds)
        Greenfoot.playSound("bullet1.wav");
    }
}
