import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.awt.Color;
/**
 * The door the character must open first, and then enter. 
 * Entering adds an event count, which triggers the next event 
 * in the event script
 * 
 * @author Anthony Hoang
 * @version (v1)
 */
public class InGameDoor  extends InGameObjects
{
    private GreenfootImage image;
    private boolean open = false;
    private int h = 0;
    private boolean done = false;
    public InGameDoor()
    {
        image = new GreenfootImage(50, 70);
        image.setColor(Color.GRAY);
        image.fill();
        image.setColor(Color.BLACK);
        setImage(image);
    }
    public void open()
    {
        open = true;
        Greenfoot.playSound("doorairhiss.wav");
    }
    public void act() 
    {
        if (getMWorld().esPause) return;
        if (open && !done)
        {
            if (h < 71)
            {
                image.fillRect(0,0,50,h);
                h++;
                setImage(image);
                getMWorld().addObject(new SmokeParticle((int)(Math.random()*360)),
                getX()+getImage().getWidth()/2,
                getY()-getImage().getHeight()/2+h);
                
                getMWorld().addObject(new SmokeParticle((int)(Math.random()*360)),
                getX()-getImage().getWidth()/2,
                getY()-getImage().getHeight()/2+h);
            }
            else
            {
                Actor a = getOneIntersectingObject(InGameCharacter.class);
                if (a!=null )
                {
                    int x = Math.abs(getX()-a.getX());
                    if (x < 10 )
                    {
                        getMWorld().eventCount++;
                        done = true;
                    }
                }
            }
        }
    }    
}
