import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * drains nano suit power energy by 
 * firing out energy drain thigns
 * 
 * @author Anthony Hoang
 * @version (v1)
 */
public class EnergyDrainPort  extends EnergyPort
{
    private int acts = 500;
    private int DELAYLIM = 500;
    private static GreenfootImage img;
    public EnergyDrainPort(int acts)
    {
        if (img == null)
        {
            img = new GreenfootImage("defectiveEnergyOutPort.png");
        }
        setImage(img);
        this.acts = acts;
    }
    public void act() 
    {
        if (getMWorld().esPause) return;
        if (acts > 0)
        acts--;
        if (acts <= 0)
        acts = DELAYLIM;
        if (acts < 100)
        smoke();
        if (acts < 15)
        discharge();
        
    }    
    public void smoke()
    {
        for (int i = 0; i < 2; i++)
        {
            int rand = (int)(Math.random()*4);
            int nx = getX(), ny = getY();
            if (rand == 0)
            {
                nx += (int)(Math.random()*10);
                ny += (int)(Math.random()*10);
            }
            if (rand == 1)
            {
                nx -= (int)(Math.random()*10);
                ny += (int)(Math.random()*10);
            }
            if (rand == 2)
            {
                nx -= (int)(Math.random()*10);
                ny -= (int)(Math.random()*10);
            }
            if (rand == 3)
            {
                nx += (int)(Math.random()*10);
                ny -= (int)(Math.random()*10);
            }
            getMWorld().addObject(new SmokeParticle((int)(Math.random()*360)),nx,ny);
        }
    }
    public void discharge()
    {
        getMWorld().addObject(new EnergyDrainSpike((int)(Math.random()*360)),getX(),getY());
    }
}
