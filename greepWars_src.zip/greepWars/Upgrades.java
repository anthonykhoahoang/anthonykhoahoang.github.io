import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Upgrades provides upgrades for the rocket
 * 
 * @author Anthony Hoang
 * @version 2.0
 */
public class Upgrades extends MovingThing
{
    private int health = 1;
    
    /** 
     * Upgrade 0 is bullet level +
     * Upgrade 1 is 100+ shield level
     * Upgrade 2 is number of weapons
     * Upgrade 3 is number "ALL Around Fire" (AAS) attack left
     * Upgrade 4 is number of lives
     * UPgrade 5 is energy level +50
     * Upgrade 6 is number of homing missles
     */
    private int upgradeNum;
    public Upgrades()
    { }
    public Upgrades(int upgrade)
    {
        super(new Vector(Greenfoot.getRandomNumber(360), 2));
        upgradeNum = upgrade;
        
        /*
        if (upgradeNum != 5 && upgradeNum != 7)
        setImage("upgrades/upgrade.png");
        if (upgradeNum == 5)
        setImage("upgrades/energyUpgrade.png");
        if (upgradeNum == 7)
        setImage("upgrades/ammoUpgrade.png");
        */
    }
    public void act()
    {         
        move();
    }
    public int getUpgradeNum()
    {
        return upgradeNum;
    }
    public void setUpgradeNum(int n)
    {   upgradeNum = n; }
    public void hit(int damage, Rocket r) 
    {
        if (upgradeNum == 0)
            r.raiseBulletLevel();
        else
        if (upgradeNum == 1)
        {
            r.raiseShieldLevel();
        }
        else
        if (upgradeNum == 2)
        {
            r.raiseNumWeapons();
        }
        else
        if (upgradeNum == 3)
        {
            r.raiseAAS();
        }
        else
        if (upgradeNum == 4)
        {
            r.raiseLife();
        }
        else
        if (upgradeNum == 5)
        {
            r.raiseEnergyLevel();
        }
        else
        if (upgradeNum == 6)
        {
            r.raiseNumMissles();
        }
        else
        if (upgradeNum == 7)
        {
            r.raiseMGAmmo();
        }
        Greenfoot.playSound("pickUpgrade.wav");
        getSpace().removeObject(this);         
    }
}
