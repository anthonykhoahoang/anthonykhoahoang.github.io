import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.util.List;
/**
 * Write a description of class LGGameCheck here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class LGGameCheck  extends LogicGate
{
    private boolean done = false;
    public LGGameCheck()
    {
        setImage(new GreenfootImage("gatechecker.png"));
    }
    public void act() 
    {
        if (getMWorld().esPause) return;
        setRotation(getRotation()+1);
        if (!done)
        checkGates();
    }    
    public void checkGates()
    {
        if (!getMWorld().isBlackAt(getX(),getY()))
        {
            if (allGatesCorrect())
            {
                getMWorld().esPause = true;
                done = true;
                getMWorld().eventCount++;
            }
            else
            {
                getMWorld().removeObjects(getMWorld().getObjects(EventScript.class));
                getMWorld().addEventScript("LGTryAgain.txt");
                getMWorld().esPause = true;
                done = true;
            }
        }
    }
    public boolean allGatesCorrect()
    {
        List<LGGateChecker> list = getMWorld().getObjects(LGGateChecker.class);
        for(LGGateChecker g : list)
        {
            if (!g.isCorrect())
            return false;
        }
        return true;
            
    }
}
