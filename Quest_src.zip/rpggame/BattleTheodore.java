import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.util.List;
import java.awt.Color;
import java.awt.Font;

/**
 * Write a description of class BattleTheodore here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class BattleTheodore extends Good
{
    private GreenfootImage normal = new GreenfootImage("Battle/Theodore/normal.png");
    private GreenfootImage defend = new GreenfootImage("Battle/Theodore/defend.png");
    private GreenfootImage castMagic = new GreenfootImage("Battle/Theodore/defend.png");
    private GreenfootImage attack = new GreenfootImage("Battle/Theodore/attack.png");
    private GreenfootImage hit = new GreenfootImage("Battle/Theodore/hit.png");
    private GreenfootImage knockedout = new GreenfootImage("Battle/Theodore/knockedout.png");
    
    
    private int fightDelay;
    private int numActs =0;
    private int dmg;
    
    private boolean specialAttack = false;
    
    private int returnToPosDelay = -15;
    
    private Bad curBad;
    private boolean isAttacking = false;
    private boolean isInPos = true;
    
    private int[] prevPosition = new int[2];
    private int[] normalPosition = new int[2];
    
    public BattleTheodore(int hp, int mana, int fd, int damage)
    {
        super(hp,mana);
        dmg = damage;
        fightDelay = fd;
        setImage(normal);
    }
    public void act() 
    {
        if (!getLand().isBattle)
        return;
        if (getCurHP() > 0)
        {
            checkAttack();
            if (defending()) setImage(defend);
            if (!getLand().theodoreMenuOpen)
            {
                if (numActs >= fightDelay)
                {
                    getLand().theodoreMenuOpen = true;
                    getLand().loadTheodoreBattleMenu();
                    numActs = -fightDelay;
                }
                numActs++;
            }
        }
        else
        {
            if (getLand().theodoreMenuOpen )
            getLand().removeTheodoreBattleMenu();
            setImage(knockedout);
        }
    }  
    public void endOfBattleReset()
    {
        setDefend(false);
        setPrevPos(normalPosition[0], normalPosition[1]);
        isInPos = true;
        isAttacking = false;
        specialAttack = false;
    }
    public void checkAttack()
    {
        if (isAttacking)
        {
            getLand().theodoreMenuOpen = false;
            turnToBadGuy();
            makeRunSmoke();
            if (specialAttack)
            getLand().addObject(new GreenSmoke(), getX()-10,getY()+10);
            move();
            setRotation(0);
            setImage(attack);
            List<Bad> blist = getIntersectingObjects(Bad.class);
            for (Bad b : blist)
            {
                getLand().addObject(new Slash(), b.getX(), b.getY());
                if (specialAttack)
                {
                    getLand().addObject(new Slash2(), b.getX(), b.getY());
                    b.hit(dmg);
                }
                b.hit(dmg);
                if (specialAttack)
                getLand().addObject(new HitText(dmg*2, Color.YELLOW), b.getX()+10,b.getY()+Greenfoot.getRandomNumber(10));
                else
                getLand().addObject(new HitText(dmg, Color.RED), b.getX()+10,b.getY()+Greenfoot.getRandomNumber(10));
                Greenfoot.playSound("sword slash.wav");
                isAttacking = false;
                isInPos = false;
                setImage(hit);
                specialAttack = false;
                setCurMP(getCurMP()+5);
            }
        }
        if (!isInPos )
        {
            if (returnToPosDelay == 0)
            {
                setImage(normal);
                for (int i = 0; i < 2; i++)
                {
                    turnToStartPos();
                    move();
                    setRotation(0);
                    if ( Math.abs(prevPosition[0]-getX()) < 5 && Math.abs(prevPosition[1]-getY()) < 5)
                    {
                        i = 5;
                        isInPos = true;
                        returnToPosDelay= -15;
                        numActs = 0;
                    }
                }
            }
            else
            if (returnToPosDelay < 0 ) returnToPosDelay++;
        }
    }
    public void defend()
    {
        setDefend(true);
        setImage(defend);
    }
    public void checkIfKnockedOut()
    {
        if (getCurHP() <= 0)
        {
            setImage(knockedout);
        }
    }
    public void defendTeamMate( Good g)
    {
        defend();
        setPrevPos(g.getX()+45,g.getY());
        isInPos = false;
        getLand().theodoreMenuOpen = false;
    }
    public void returnToNormalPosition()
    {
        setPrevPos(normalPosition[0], normalPosition[1]);
        isInPos = false;
        getLand().theodoreMenuOpen = false;
    }
    public void setPrevPos(int x, int y)
    {
        prevPosition[0] = x;
        prevPosition[1] = y;
    }
    public void setNormalPos(int x, int y)
    {
        normalPosition[0] = x;
        normalPosition[1] = y;
    }
    public void move()
    {
        double angle = Math.toRadians( getRotation() );
        int x = (int) Math.round(getX() + Math.cos(angle) * getImage().getWidth()/3);
        int y = (int) Math.round(getY() + Math.sin(angle) * getImage().getWidth()/3);
        setLocation(x, y);
    }
    public void attack(Bad b)
    {
        setPrevPos(getX(),getY());
        curBad = b;
        setDefend(false);
        isAttacking = true;
    }
    public void attackSpecial(Bad b)
    {
        attack(b);
        specialAttack = true;
    }
    public void turnToBadGuy()
    {
        if (curBad == null)
        {
            List<Bad> b = getLand().getObjects(Bad.class);
            if (b.size() != 0 )
            {
                curBad = (Bad) b.get(0);
            }
            else
            {
                isAttacking = false;
                isInPos = false;
                return;
            }
        }
        int deltaX = (curBad.getX() - getX());
        int deltaY = (curBad.getY() - getY());
        setRotation((int) (180 * Math.atan2(deltaY, deltaX) / Math.PI));
    }
    public void turnToStartPos()
    {
        int deltaX = (prevPosition[0] - getX());
        int deltaY = (prevPosition[1] - getY());
        setRotation((int) (180 * Math.atan2(deltaY, deltaX) / Math.PI));
    }
    
    public void setFightDelay(int n)
    {   fightDelay = n; }
    public int getFightDelay()
    {   return fightDelay;  }
    public int getDmg()
    {   return dmg; }
    public void setDmg(int n)
    {   dmg = n;    }
}
