import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class ECAddQuestionMark here.
 * 
 * @author Anthony Hoang
 * @version (v1)
 */
public class ECAddQuestionMark  extends EventCountAdder
{
    private int imageCount;
    private static GreenfootImage image;
    private int WIDTH;
    private int curWidth;
    private int curAction = 0;
    private int delay = 2;
    private int acts = 0;
    public ECAddQuestionMark()
    {
        if (image == null)
        image = new GreenfootImage("questionmark.png");
        WIDTH = image.getWidth();
        curWidth = WIDTH;
        setImage(new GreenfootImage(image));
    }
    public void act() 
    {
        if (getMWorld().esPause) return;
        super.act();
        if (hasAdded)
        {
            int t = getImage().getTransparency()-10;
            if (t < 10)
            getMWorld().removeObject(this);
            else
            getImage().setTransparency(t);
        }
        else 
        if (acts == delay)
        {
            acts = 0;
            setImage();
        }
        else acts++;
    }    
    public void setImage()
    {
        if (curAction == 0)
        { 
            curWidth--;
            if (curWidth < 1)
            curAction = 1;
            else
            {
                GreenfootImage i = new GreenfootImage(image);
                i.scale(curWidth,image.getHeight());
                setImage(i);
            }
        }
        if (curAction == 1)
        {
            curWidth++;
            if (curWidth > WIDTH)
            curAction = 2;
            else
            {
                GreenfootImage i = new GreenfootImage(image);
                i.scale(curWidth,image.getHeight());
                i.mirrorHorizontally();
                setImage(i);
            }
        }
        if (curAction == 2)
        {
            curWidth--;
            if (curWidth < 1)
            curAction = 3;
            else
            {
                GreenfootImage i = new GreenfootImage(image);
                i.scale(curWidth,image.getHeight());
                i.mirrorHorizontally();
                setImage(i);
            }
        }
        if (curAction == 3)
        {
            curWidth++;
            if (curWidth > WIDTH)
            curAction = 0;
            else
            {
                GreenfootImage i = new GreenfootImage(image);
                i.scale(curWidth,image.getHeight());
                setImage(i);
            }
        }
    }
}
