import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class PhoneHolos here.
 * 
 * @author Anthony Hoang
 * @version (v1)
 */
public class PhoneHolos  extends Actor
{
    public boolean remove = false;
    public void remove()
    {
        remove = true;
    }
    public void act() 
    {
        if (getMWorld().gamePause) return;
        if (remove)
        {
            int w = getImage().getWidth()-20;
            int h = getImage().getHeight()-20;
            if (w <= 0 || h<=0)
            getMWorld().removeObject(this);
            else
            getImage().scale(w,h);
        }
    }    
    public Midori getMWorld()
    {
        return (Midori) getWorld();
    }
}
