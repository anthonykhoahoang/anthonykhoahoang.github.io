import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class EnergyBall here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class EnergyBall extends MagicAttacks
{
    private Battle tar;
    private int damage;
    public EnergyBall(int dmg, Battle target)
    {
        tar = target;
        damage = dmg;
    }
    public void act() 
    {
        if (tar instanceof Good)
        {
            if ( ((Good)tar).getCurHP() <= 0)
            {
                getLand().removeObject(this);
                return;
            }
        }
        else
        if (tar instanceof Bad)
        {
            if ( ((Bad)tar).getCurHP() <= 0)
            {
                getLand().removeObject(this);
                return;
            }
        }
        turnToTarget();
        move();
        setRotation(0);
        if (tar instanceof Good)
        {
            Good g = (Good)getOneIntersectingObject(Good.class);
            if (g != null && !g.isDead())
            {
                if (g.isDead()) return;
                getLand().addObject(new BlueSmoke(), g.getX(), g.getY());
                g.hit(damage);
                Greenfoot.playSound("thunder.wav");
                getLand().removeObject(this);
            }
        }
        else
        {
            Bad g = (Bad)getOneIntersectingObject(Bad.class);
            if (g != null)
            {
                getLand().addObject(new BlueSmoke(), g.getX(), g.getY());
                g.hit(damage);
                Greenfoot.playSound("thunder.wav");
                getLand().removeObject(this);
            }
        }
    }  
    public void turnToTarget()
    {
        
        int deltaX = (tar.getX() - getX());
        int deltaY = (tar.getY() - getY());
        setRotation((int) (180 * Math.atan2(deltaY, deltaX) / Math.PI));
    } 
}
