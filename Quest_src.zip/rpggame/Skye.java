import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Skye here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Skye extends InGameChar
{
    private GreenfootImage front = new GreenfootImage("Skye/faceFront.png");
    
    private GreenfootImage back = new GreenfootImage("Skye/faceBack.png");
    private GreenfootImage left = new GreenfootImage("Skye/faceLeft.png");
    private GreenfootImage right = new GreenfootImage("Skye/faceRight.png");
    
    private GreenfootImage runFront1 = new GreenfootImage("Skye/runFront1.png");
    private GreenfootImage runFront2 = new GreenfootImage("Skye/runFront2.png");
    private GreenfootImage runBack1 = new GreenfootImage("Skye/runBack1.png");
    private GreenfootImage runBack2 = new GreenfootImage("Skye/runBack2.png");
    private GreenfootImage runRight1 = new GreenfootImage("Skye/runRight1.png");
    private GreenfootImage runRight2 = new GreenfootImage("Skye/runRight2.png");
    private GreenfootImage runLeft1 = new GreenfootImage("Skye/runLeft1.png");
    private GreenfootImage runLeft2 = new GreenfootImage("Skye/runLeft2.png");
    private int acts;
    private boolean isRunning;
    private int dir;
    private int stuck = 0;
    private int walkSpeed = front.getWidth()/9;
    
    private int eDelay=0;
    
    private static int nActs = 5;
    
    public Skye()
    {
        
        //front.scale(front.getWidth()+20, front.getHeight()+20);
        setImage(front);
        dir = 90;
    }
    public void act() 
    {
        if (getOneIntersectingObject(Text.class) != null)
        {
            //setImage(front);
            return;
        }
        if (!getLand().isBattle)
        {
            LevelLoader a = (LevelLoader)getOneIntersectingObject(LevelLoader.class);
            if (a != null && (Greenfoot.isKeyDown("e")|| Greenfoot.isKeyDown("enter")) && eDelay ==0)
            {
                getLand().addObject(new FadeOut(), 512, 300);
                a.loadLevel();
                System.gc();
                eDelay =-10;
            }
            if (eDelay < 0) eDelay++;
            // fixLoc();
            walk2();
            if (!canMove()) setStandImage();
        }
    }
    public void walk2()
    {
        if (Greenfoot.isKeyDown("left"))
        {
            dir = 180;
            if (!isRunning)
            {
                setImage(left);
                isRunning = true;
            }
            else
            {
                if (canMove())
                {
                    if (Greenfoot.isKeyDown("up"))
                    setLocation(getX(), getY()-walkSpeed/2);
                    if (Greenfoot.isKeyDown("down"))
                    setLocation(getX(), getY()+walkSpeed/2);
                    
                    setLocation(getX()-walkSpeed, getY());
                }
                if (acts == 0)
                setImage(runLeft1);
                if (acts== nActs)
                {
                    setImage(runLeft2);
                    acts = -nActs;
                }
            }
            acts++;
        }
        else 
        if (Greenfoot.isKeyDown("right"))
        {
            dir = 0;
            if (!isRunning)
            {
                setImage(right);
                isRunning = true;
            }
            else
            {
                if (canMove())
                {
                    if (Greenfoot.isKeyDown("up"))
                    setLocation(getX(), getY()-walkSpeed/2);
                    if (Greenfoot.isKeyDown("down"))
                    setLocation(getX(), getY()+walkSpeed/2);
                    
                    setLocation(getX()+walkSpeed, getY());
                    
                }
                if (acts == 0)
                setImage(runRight1);
                if (acts == nActs)
                {
                    setImage(runRight2);
                    acts = -nActs;
                }
            }
            acts++;
        }
        else
        if (Greenfoot.isKeyDown("up"))
        {
            dir = 270;
            if (!isRunning)
            {
                setImage(back);
                isRunning = true;
            }
            else
            {
                if (canMove())
                setLocation(getX(), getY()-walkSpeed);
                
                if (acts == 0)
                setImage(runBack1);
                if (acts == nActs)
                {
                    setImage(runBack2);
                    acts = -nActs;
                }
            }
            acts++;
        }
        else
        if (Greenfoot.isKeyDown("down"))
        {
            dir = 90;
            if (!isRunning)
            { 
                setImage(front);
                isRunning = true;
            }
            else
            {
                if (canMove())
                setLocation(getX(), getY()+walkSpeed);
                
                if (acts == 0)
                setImage(runFront1);
                if (acts == nActs)
                {
                    setImage(runFront2);
                    acts = -nActs;
                }
            }
            acts++;
        }
        else
        {
            isRunning = false;
            setStandImage();
        }
        if (acts > 6)
        acts=0;
    }
    public void setStandImage()
    {
        if (dir == 90) setImage(front);
        else if (dir == 270) setImage(back);
        else if (dir == 0) setImage(right);
        else if (dir == 180) setImage(left);
    }
    
    public void reloadImages()
    {
        front = new GreenfootImage("Skye/faceFront.png");
        back = new GreenfootImage("Skye/faceBack.png");
        left = new GreenfootImage("Skye/faceLeft.png");
        right = new GreenfootImage("Skye/faceRight.png");
        runFront1 = new GreenfootImage("Skye/runFront1.png");
        runFront2 = new GreenfootImage("Skye/runFront2.png");
        runBack1 = new GreenfootImage("Skye/runBack1.png");
        runBack2 = new GreenfootImage("Skye/runBack2.png");
        runRight1 = new GreenfootImage("Skye/runRight1.png");
        runRight2 = new GreenfootImage("Skye/runRight2.png");
        runLeft1 = new GreenfootImage("Skye/runLeft1.png");
        runLeft2 = new GreenfootImage("Skye/runLeft2.png");
        walkSpeed = front.getWidth()/9;
    }
    public void scaleImages(double scaleFactor)
    {
        reloadImages();
        front.scale( (int)(front.getWidth()*scaleFactor), (int)(front.getHeight()*scaleFactor));
        back.scale((int)(back.getWidth()*scaleFactor), (int)(back.getHeight()*scaleFactor) );
        left.scale((int)(left.getWidth()*scaleFactor), (int)(left.getHeight()*scaleFactor));
        right.scale((int)(right.getWidth()*scaleFactor), (int)( right.getHeight()*scaleFactor) );
        runFront1.scale((int)(runFront1.getWidth()*scaleFactor), (int)(runFront1.getHeight()*scaleFactor) );
        runFront2.scale((int)(runFront2.getWidth()*scaleFactor), (int)(runFront2.getHeight()*scaleFactor) );
        runBack1.scale((int)(runBack1.getWidth()*scaleFactor), (int)(runBack1.getHeight()*scaleFactor) );
        runBack2.scale((int)(runBack2.getWidth()*scaleFactor), (int)(runBack2.getHeight()*scaleFactor) );
        runRight1.scale((int)(runRight1.getWidth()*scaleFactor), (int)(runRight1.getHeight()*scaleFactor));
        runRight2.scale((int)(runRight2.getWidth()*scaleFactor), (int)(runRight2.getHeight()*scaleFactor) );
        runLeft1.scale((int)(runLeft1.getWidth()*scaleFactor), (int)(runLeft1.getHeight()*scaleFactor) );
        runLeft2.scale((int)(runLeft2.getWidth()*scaleFactor), (int)(runLeft2.getHeight()*scaleFactor));
        
        walkSpeed = front.getWidth()/9;
    }
    public boolean canMove()
    {
        boolean isClear = true;
        if (dir == 0) setLocation(getX()+walkSpeed, getY());
        if (dir == 90) setLocation(getX(), getY()+walkSpeed);
        if (dir == 180) setLocation(getX()-walkSpeed, getY());
        if (dir == 270) setLocation(getX(), getY()-walkSpeed);
        if (getOneIntersectingObject(WorldObjects.class) != null)
        isClear = false;
        
        if (dir == 0) setLocation(getX()-walkSpeed, getY());
        if (dir == 90) setLocation(getX(), getY()-walkSpeed);
        if (dir == 180) setLocation(getX()+walkSpeed, getY());
        if (dir == 270) setLocation(getX(), getY()+walkSpeed);
        return isClear;
    }
    public void fixLoc()
    {
        if (getOneIntersectingObject(WorldObjects.class) != null)
        {
            if (dir == 0) setLocation(getX()-walkSpeed, getY());
            if (dir == 90) setLocation(getX(), getY()-walkSpeed);
            if (dir == 180) setLocation(getX()+walkSpeed, getY());
            if (dir == 270) setLocation(getX(), getY()+walkSpeed);
        }
    }
}
