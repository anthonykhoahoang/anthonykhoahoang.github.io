import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class BlueSlash here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class BlueSlash extends Slash
{
    private GreenfootImage slash = new GreenfootImage("Battle/BlueSlash.png");
    public BlueSlash()
    {
        setImage(slash);
    }
    public void act() 
    {
        super.act();
    }    
}
