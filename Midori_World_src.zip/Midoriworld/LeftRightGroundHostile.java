import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.util.List;
/**
 * Write a description of class LeftRightGroundHostile here.
 * 
 * @author Anthony Hoang
 * @version (v1)
 */
public class LeftRightGroundHostile  extends HostileEnemy
{
    private boolean left = false;
    private int speed;
    private int moveDelay = 0;
    private int MOVEDELAYLIMIT;
    private double FALLSPEED;
    private double FALLSPEEDADD = .3;
    private boolean isFalling;
    //private boolean hasHit = false;
    public LeftRightGroundHostile()
    {
        speed = 1;
        MOVEDELAYLIMIT =2;
    }
    public LeftRightGroundHostile(int s, int d)
    {
        speed = s;
        MOVEDELAYLIMIT = d;
    }
    public void act() 
    {
        if (getMWorld().esPause) return;
        if (isBlackAt(getX(),getY()))
        {
            hasHit = true;
        }
        if (!hasHit)
        fallTest();
        if (moveDelay > MOVEDELAYLIMIT)
        moveDelay++;
        else
        {
            if (!hasHit)
            move();
            moveDelay = 0;
        }
        super.act();
    }      
    public void move()
    {
        if (left)
        {
            if (!blackBetweenX(getX()+getImage().getWidth()+speed))
            moveX(getX()+speed);
            else
            left = false;
        }
        else
        {
            if (!blackBetweenX(getX()-getImage().getWidth()-speed))
            moveX(getX()-speed);
            else
            left = true;
        }
    }
    public boolean noObjectsBelow()
    {
        List<Platform> list = getIntersectingObjects(Platform.class);
        if (list.size() == 0) return true;
        for (int i=0; i<list.size(); i++)
        {
            InGameObjects a = list.get(0);
            int w = a.getImage().getWidth()/2;
            int h = a.getImage().getHeight()/2;
            if (a.getY() > getY()+getImage().getHeight()/2)
            //&& a.getX()+w > getX()&&a.getX()-w<getX())
            return false;
        }
        return true;
    }
    public void fallTest()
    {
        int y1 = getY(), y2 = getY()+getImage().getHeight()/2;
        if (!blackBetweenY(y2+1) )
        {
            isFalling = noObjectsBelow();
            
            if(isFalling)
            FALLSPEED += FALLSPEEDADD;
            else
            FALLSPEED = 0;
        }
        else //on ground
        {
            FALLSPEED = 0;
            gotoNextBlackY(y2);
            if (isFalling)
            for (int i = 0; i < 4; i++)
            {
                getMWorld().addObject(new DustParticle(180),
                getX()-getImage().getWidth()/4,getY()+getImage().getHeight()/2);
                getMWorld().addObject(new DustParticle(0),
                getX()+getImage().getWidth()/4,getY()+getImage().getHeight()/2);
            }
            isFalling = false;
        }
        if (isFalling)
        {
            y2 = y1+getImage().getHeight()/2+(int)FALLSPEED;
            gotoNextBlackY(y2);
        }
    }
    public void moveX(int dX2)
    {
        int dX = getX();
        int height = getImage().getHeight()/2;
        int width = getImage().getWidth()/2;
        int dY = getY();
        if (dX > dX2)//moveleft
        while (dX > dX2 && !isBlackAt(dX-width, dY-height))
        {
            dX--;
            while (isBlackAt(dX, dY+height) && !hasHit)
            dY--;
        }
        else//moveright
        while (dX < dX2 && !isBlackAt(dX+width, dY-height))
        {
            dX++;
            while (isBlackAt(dX, dY+height) && !hasHit)
            dY--;
        }
        setLocation(dX, dY);
        
        int y2 = getY()+getImage().getHeight();
        if (blackBetweenY(getY()+getImage().getHeight()))
        {
            gotoNextBlackY(y2);
        }
    }
}
