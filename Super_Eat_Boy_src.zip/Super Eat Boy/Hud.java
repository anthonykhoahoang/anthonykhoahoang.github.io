import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.util.*;
/**
 * Write a description of class Hud here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */

//Reminder: Hud placed at (138, 41)
//Green veggie bar is -45 degrees at (41, 40)
//Blue carb bar is -10 degree at (12, 51)
//Red protein bar is at -85 degrees at (52, 10)
//Gold insulin bar at (123, 34)
//Water shield bar at (266, 36)
public class Hud  extends HudObject
{
    //Water level variables
    private int waterLevel = 2;
    private int waterLevelMax = 7;
    private int damageReduction = 1;
    
    //Blood sugar variables
    //Let's say bloodSugar is percent based. 50% is the middle.
    private double bloodSugar = 0.5;
    
    //Food meter variables
    private int carbs = 0;
    private int carbsMax = 4;
    private int proteins = 0;
    private int proteinsMax = 4;
    private int veggies = 0;
    private int veggiesMax = 4;
    
    //Insulin variables
    private int insulin = 4;
    private int insulinMax = 4;
    
    private GreenfootSound musicPlayer;
    
    public Hud()
    {
        setImage(new GreenfootImage("images/hud/mainhud.png"));
        musicPlayer = new GreenfootSound("sounds/Music Near The Left Skull Music.mp3");        
    }
    
    public void act() 
    {
        if (bloodSugar > 0.8 || bloodSugar < 0.2)
        {
            if (!musicPlayer.isPlaying())
                musicPlayer.play();
        }
        else if (musicPlayer.isPlaying())
            musicPlayer.stop();
        if (carbs >= carbsMax && proteins >= proteinsMax && veggies >= veggiesMax)
        {
            if (getWorld().getObjects(Win.class).size() == 0)
            getWorld().addObject(new Win(), 400, 225);
        }
    }    
    
    public void updateBloodSugarBar()
    {
        ArrayList<BloodSugarBar> listBloodSugarBar 
            = (ArrayList<BloodSugarBar>) getWorld().getObjects(BloodSugarBar.class);
        for (BloodSugarBar bsg : listBloodSugarBar)
        {
            bsg.setLocation((int)(92 + 168*bloodSugar), 12);
        }
    }
    
    public void setBloodSugar(double bs)
    {
        bloodSugar = bs;
        updateBloodSugarBar();
    }
    
    public boolean isDead()
    {
        return bloodSugar == 0 || bloodSugar == 1;
    }
    
    public void updateFoodMeters()
    {
        ArrayList<FoodBar> listFoodBar = (ArrayList<FoodBar>) getWorld().getObjects(FoodBar.class);
        for (FoodBar fb : listFoodBar)
        {
            if (fb.getColor().equals("Blue"))
                fb.setPercent((double)carbs/(double)carbsMax);
            else if (fb.getColor().equals("Red"))
                fb.setPercent((double)proteins/(double)proteinsMax);
            else
                fb.setPercent((double)veggies/(double)veggiesMax);
            fb.fill();
        }
    }
    public void eatBoyRunCalculation()
    {
        bloodSugar -= (double)waterLevelMax/50000.0 + (double)waterLevel/50000.0;
        if (bloodSugar < 0)
            bloodSugar = 0;
        updateBloodSugarBar();
    }
    
    public void eatBoyHurtCalculation()
    {
        if (waterLevel > 0)
        {
            setWaterLevel(waterLevel - 1);
        }
        else
        {
            bloodSugar += .1;
            if (bloodSugar < 0)
                bloodSugar = 0;
            if (bloodSugar > 1)
                bloodSugar = 1;
            updateBloodSugarBar();
        }
    }
    public void addVeggie()
    {
        if (veggies < veggiesMax)
            veggies++;
       updateFoodMeters();
    }
    
    public void addCarb()
    {
        if (carbs < carbsMax)
            carbs++;
       updateFoodMeters();
    }
    
    public void addProtein()
    {
        if (proteins < proteinsMax)
            proteins++;
       updateFoodMeters();
    }
    
    public void addInsulin()
    {
        if (insulin < insulinMax)
            insulin++;
    }
    
    public int getVeggie()
    {
        return veggies;
    }
    
    public void setVeggie(int amount)
    {
        veggies = amount;
       updateFoodMeters();
    }
    
    public int getInsulin()
    {
        return insulin;
    }
    
    public void setInsulin(int insulin)
    {
        this.insulin = insulin;
        double percent = (double)insulin/(double)insulinMax;
        List<InsulinBar> listInsulin = getWorld().getObjects(InsulinBar.class);
        for (InsulinBar ib : listInsulin)
        {
            ib.setPercent((int)(percent*100));
            ib.fill();
        }
    }
    
    public int getWaterLevel()
    {
        return waterLevel;
    }
    
    public void setWaterLevel(int level)
    {
        this.waterLevel = level;
        List<WaterBar> listWater = getWorld().getObjects(WaterBar.class);
        for (WaterBar wb : listWater)
        {
            wb.setOrbAmount(waterLevel);
            wb.fill();
        }
    }
}
