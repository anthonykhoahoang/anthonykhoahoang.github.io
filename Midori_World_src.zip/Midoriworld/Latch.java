import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.awt.Color;
/**
 * Write a description of class Latch here.
 * 
 * @author Anthony Hoang
 * @version (v1)
 */
public class Latch  extends InGameObjects
{
    private int WIDTH;
    private int HEIGHT;
    private String ID;
    private boolean closed;
    private boolean firstInitialize = true;
    private static GreenfootImage img;
    public Latch(int w, int h, String id, boolean closed)
    {
        WIDTH = w;
        HEIGHT = h;
        ID = id;
        this.closed = closed;
        if (img == null)
        img = new GreenfootImage("latch.png");
        setImage(new GreenfootImage(img));
        getImage().scale(w,h);
    }
    public void act() 
    {
        if (getMWorld().esPause) return;
        if (firstInitialize)
        {
            if (closed) 
            getMWorld().drawBlackOnRGBMap(getX(),getY(),WIDTH,HEIGHT);
            else
            getMWorld().drawWhiteOnRGBMap(getX(),getY(),WIDTH,HEIGHT);
            firstInitialize = false;
        }
        if (closed)
        {
           int t = getImage().getTransparency()+10;
           if (t < 255)
           getImage().setTransparency(t);
        }
        else
        {
           int t = getImage().getTransparency()-10;
           if (t > 20)
           getImage().setTransparency(t);
        }
    }    
    public void switchOpenClose()
    {
        closed = !closed;
        if (closed) 
        getMWorld().drawBlackOnRGBMap(getX(),getY(),WIDTH,HEIGHT);
        else
        getMWorld().drawWhiteOnRGBMap(getX(),getY(),WIDTH,HEIGHT);
        
    }
    public String getID()
    {
        return ID;
    }
}
