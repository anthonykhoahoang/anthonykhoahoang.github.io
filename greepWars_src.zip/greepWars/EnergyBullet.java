import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.util.List;
/**
 * Energybullet uses charged energy to fuel it's power and life length.
 * 
 * @author (Anthony Hoang) 
 * @version (2.0)
 */
public class EnergyBullet extends Bullet
{
    private int damage;
    public EnergyBullet (Vector speed, int rotation, int dmg, Rocket rocket, boolean sound)
    {
        super(speed, rotation, dmg+5, true, rocket);
        setLife(dmg);
        if (sound)
        Greenfoot.playSound("emp.wav");
        damage = dmg;
    }
    public void act() 
    {
        if(getLife() <= 0) 
            getWorld().removeObject(this);
        else 
        {
            move();
            Asteroid asteroid = (Asteroid) getOneIntersectingObject(Asteroid.class);
            Upgrades upgrade = (Upgrades) getOneIntersectingObject(Upgrades.class);
            Enemy enemy = (Enemy) getOneIntersectingObject(Enemy.class);
            if(asteroid != null)
                asteroid.hit(damage);
            else
            if (enemy != null)
            {
                enemy.hit(damage);
                getSpace().addSmallExplosion(getX(),getY());
            }
            else
            if (upgrade != null)
                upgrade.hit(damage, r);
        }
        lowerLife();
    }    
}
