import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class GameOver here.
 * 
 * @author Anthony Hoang
 * @version (v1)
 */
public class Win  extends Title
{
    
    public Win()
    {
        setImage(new GreenfootImage("youwin.png"));
    }
    public void act() 
    {
    }    
}
