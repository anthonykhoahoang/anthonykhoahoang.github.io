import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.util.*;
/**
 * Flame damages enemies around it. It shrivels up as time passes.
 * 
 * @author Anthony Hoang
 * @version 1.1
 */
public class Flame extends Bullet
{
    private int damage;
    public Flame (Vector speed, int rotation, int dmg, boolean sound, Rocket rocket)
    {
        super(speed, rotation, dmg+5, true, rocket);
        setLife(dmg);
        damage = dmg;
    }
    public void act() 
    {
        if(getImage().getWidth() <= 2 || getImage().getHeight() <= 2) 
            getWorld().removeObject(this);
        else 
        {
            getImage().scale(getImage().getWidth()-2, getImage().getHeight()-2);
            move();
            Asteroid asteroid = (Asteroid) getOneIntersectingObject(Asteroid.class);
            Upgrades upgrade = (Upgrades) getOneIntersectingObject(Upgrades.class);
            Enemy enemy = (Enemy) getOneIntersectingObject(Enemy.class);
            if(asteroid != null)
            asteroid.hit(damage);
            if (enemy != null)
            enemy.hit(damage);
            if (upgrade != null)
            upgrade.hit(damage, r);
        }
    }    
}
