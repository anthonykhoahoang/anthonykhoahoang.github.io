import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class AutoText here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class AutoText extends Text
{
    private int acts=0;
    public AutoText(String text, int width, float fSize)
    {
        super(text, width, fSize);
        acts = curString.length()*3;
        //instantText();
    }
    public void act() 
    {
        super.act();
        if (acts < 0 || Greenfoot.mouseClicked(this) || Greenfoot.isKeyDown("enter"))
        {
            acts = curString.length()*3;
            if (nxtFile != null && !curFile.equals(nxtFile))
            {
               // loadNext(nxtFile);
                //delay = 0;
                //super.act();
                //instantText();
                acts = curString.length()*3;
            }
            else
            {
                if (acts < 0)
                closing = true;   
            }
        }
        else
        acts--;
    }    
}
