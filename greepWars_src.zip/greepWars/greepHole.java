import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Releases fast greeps
 * 
 * @author Anthony Hoang
 * @version 1.2
 */
public class greepHole extends Enemy
{
    private int totalPassengers; 
    private int stepCount = 0;
    private int passengersReleased;
    private int releaseDelay;
    
    public greepHole(int numGreeps, int life)
    {
        super (life, 100);
        GreenfootImage image = new GreenfootImage(32,32);
        totalPassengers = numGreeps;
        image.drawOval(0,0, 30, 30);
        image.fillOval(0,0, 30, 30);
        setImage(image);
    }
    public void act() 
    {
        if(!isEmpty() && releaseDelay >= 0) 
        releasePassenger();
        else 
        releaseDelay++;
        if (isEmpty())
        {
            getSpace().removeEnemy();
            getSpace().removeObject(this);
        }
    }    
     /**
     * True if all passengers are out.
     */
    public boolean isEmpty()
    {
        return passengersReleased == totalPassengers;
    }
    
    /**
     * Possibly: Let one of the passengers out. Passengers appear at intervals, 
     * so this may or may not release the passenger.
     */
    private void releasePassenger()
    {
        if(passengersReleased < totalPassengers) 
        {
            stepCount++;
            if(stepCount == 5) 
            {
                getSpace().addEnemy();
                getSpace().addObject(new FastGreeper(getSpace().getGreepRange()), getX(), getY() + 30);
                passengersReleased++;
                stepCount = 0;
            }
        }
    }
}
