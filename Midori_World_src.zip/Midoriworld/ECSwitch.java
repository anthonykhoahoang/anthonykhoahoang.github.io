import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.awt.Color;
/**
 * Write a description of class ECSwitch here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class ECSwitch  extends EventCountAdder
{
    public ECSwitch()
    {
        setImage(new GreenfootImage(20, 30));
        getImage().setColor(Color.GREEN);
        getImage().fill();
        getImage().setTransparency(50);
    }
    public void act() 
    {
        if (getMWorld().esPause) return;
        if (Greenfoot.isKeyDown(getMWorld().use)
        && Greenfoot.isKeyDown(getMWorld().use)
        && getOneIntersectingObject(InGameCharacter.class) != null)
        super.act();
    }    
}
