import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.util.List;
/**
 * Write a description of class CleanWeapon here.
 * 
 * @author Anthony Hoang
 * @version v1
 */
public class CleanWeapon  extends InGameObjects
{
    public boolean hasHit = false;
    public void act() 
    {
        if (getMWorld().esPause) return;
        if (!hasHit)
        checkHit();
    }    
    public void checkHit()
    {
        List<Platform> list0 = getIntersectingObjects(Platform.class);
        if (list0.size() != 0)
        {
            hasHit = true;
            return;
        }
        List<HostileProjectile> list = getIntersectingObjects(HostileProjectile.class);
        List<HostileEnemy> list2 = getIntersectingObjects(HostileEnemy.class);
        if (list.size() > 0)
        {
            HostileProjectile c = list.get(0);
            //if (Math.abs(c.getX()-getX()) < 10 && Math.abs(c.getY()-getY()) < 20)
           // {
                hasHit = true;
                c.hit();
            //}
        }
        if (list2.size() > 0)
        {
            HostileEnemy c = list2.get(0);
           // if (Math.abs(c.getX()-getX()) < 10 && Math.abs(c.getY()-getY()) < 10)
           // {
                hasHit = true;
                c.hit();
           // }
        }
        if (isBlackAt(getX(),getY()))
        hasHit = true;
    }
    public boolean blackBetweenY( int y2)
    {
        int y1 = getY();
        if (y1 < y2)
        return blackBetweenYDown(y2);
        return blackBetweenYUp(y2);
    }
    public boolean blackBetweenYDown(int y2)
    {
        int y1 = getY();
        while (y1 < y2)
        {
            if (isBlackAt(getX(),y1))
            return true;
            y1++;
        }
        return false;
    }
    public boolean blackBetweenYUp(int y2)
    {
        int y1 = getY();
        while (y1 > y2)
        {
            if (isBlackAt(getX(),y1))
            return true;
            y1--;
        }
        return false;
    }
    public void gotoNextBlackY(int y2)
    {
        int y1 = getY();
        if (y1 < y2)
        gotoNextBlackYDown(y2);
        else
        gotoNextBlackYUp(y2);
    }
    public void gotoNextBlackYDown(int y2)
    {
        int y1 = getY();
        while (y1 < y2)
        {
            if (isBlackAt(getX(),y1))
            {                 
                setLocation(getX(), y1-getImage().getHeight()/2);
                return;
            }
            y1++;
        }
        setLocation(getX(), y1-getImage().getHeight()/2);
    }
    public void gotoNextBlackYUp(int y2)
    {
        int y1 = getY();
        while (y1 > y2)
        {
            if (isBlackAt(getX(),y1))
            {
                setLocation(getX(), y1+getImage().getHeight()/2);
                return;
            }
            y1--;
        }
        setLocation(getX(), y1+getImage().getHeight()/2);
    }
    public boolean blackBetweenX(int x2)
    {
        int x1 = getX();
        if (x1 < x2)
        return blackBetweenXRight(x2);
        return blackBetweenXLeft(x2);
    }
    public boolean blackBetweenXRight(int x2)
    {
        int x1 = getX();
        int y1 = getY();
        while (x1 < x2)
        {
            if (isBlackAt(x1, y1))
            return true;
            x1++;
        }
        return false;
    }
    public boolean blackBetweenXLeft(int x2)
    {
        int x1 = getX();
        int y1 = getY();
        while (x1 > x2)
        {
            if (isBlackAt(x1, y1))
            return true;
            x1--;
        }
        return false;
    } 
}
