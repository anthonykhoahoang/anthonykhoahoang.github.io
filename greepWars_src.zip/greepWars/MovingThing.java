import greenfoot.*;  // (World, Actor, GreenfootImage, and Greenfoot)

/**
 * A thing that can move around with a certain speed.
 * 
 * @author Poul Henriksen
 */
public abstract class MovingThing extends Actor
{
    private Vector speed = new Vector();
    
    private double x = 0;
    private double y = 0;
    
    public MovingThing()
    {
    }
    
    /**
     * Create new thing initialised with given speed.
     */
    public MovingThing(Vector speed)
    {
        this.speed = speed;
    }
    
    /**
     * Move forward one step.
     */
    public Vector getVector()
    {
        return speed;
    }
    
    public void move2()
    {
        int r = getRotation();
        double vLength = getSpeed().getLength();
        
        increaseSpeed(new Vector(r, 0.2));
        x = x + speed.getX();
        y = y + speed.getY();
        if(x >= getWorld().getWidth()) 
        {
            x = 0;
        }
        if(x < 0) {
            x = getWorld().getWidth() - 1;
        }
        if(y >= getWorld().getHeight()) {
            y = 0;
        }
        if(y < 0) {
            y = getWorld().getHeight() - 1;
        }
       
        setLocation(x, y);
    }
    public void stop()
    {
        getSpeed().setLength(0);
        getSpeed().setY(0);
        getSpeed().setX(0);
    }
    public void move3()
    {
        x = x + speed.getX();
        y = y + speed.getY();
        /*
        if(x >= getWorld().getWidth()) 
        {
            x = 0;
        }
        if(x < 0) {
            x = getWorld().getWidth() - 1;
        }
        if(y >= getWorld().getHeight()) {
            y = 0;
        }
        if(y < 0) {
            y = getWorld().getHeight() - 1;
        }
        */
        setLocation(x, y);
    }
    public void moveReverse()
    {
        int r = getRotation();
        double vLength = getSpeed().getLength();
        
        //if (vLength < 5)
        increaseSpeed(new Vector(r, -0.2));
        x = x + speed.getX();
        y = y + speed.getY();
        if(x >= getWorld().getWidth()) 
        {
            x = 0;
        }
        if(x < 0) {
            x = getWorld().getWidth() - 1;
        }
        if(y >= getWorld().getHeight()) {
            y = 0;
        }
        if(y < 0) {
            y = getWorld().getHeight() - 1;
        }
        setLocation(x, y);
        /*
        double angle = Math.toRadians( getRotation() +180 );
        int x = (int) Math.round(getX() + Math.cos(angle) * 5);
        int y = (int) Math.round(getY() + Math.sin(angle) * 5);
        setLocation(x, y);
        */
    }
    public void setVector(Vector v)
    {
        speed = v;
    }
    public void move()
    {
        x = x + speed.getX();
        y = y + speed.getY();
        if(x >= (double)getWorld().getWidth())
            x = 0.0D;
        if(x < 0.0D)
            x = getWorld().getWidth() - 1;
        if(y >= (double)getWorld().getHeight())
            y = 0.0D;
        if(y < 0.0D)
            y = getWorld().getHeight() - 1;
        setLocation(x, y);
    }
    public void moveType2()
    {
        x = x + speed.getX();
        y = y + speed.getY();
        if(x >= (double)getWorld().getWidth()-180)
            x = 180.0D;
        if(x < 180.0D)
            x = getWorld().getWidth() - 180;
        if(y >= (double)getWorld().getHeight())
            y = 0.0D;
        if(y < 0.0D)
            y = getWorld().getHeight() - 1;
        setLocation(x, y);
    }
    
    public void setLocation(double x, double y) {
        this.x = x;
        this.y = y;
        super.setLocation((int) x, (int) y);
    }
    
    public void setLocation(int x, int y) {
        setLocation((double) x, (double) y);
    }

    /**
     * Increase the speed with the given vector.
     */
    public void increaseSpeed(Vector s) {
        speed.add(s);
    }
    /**
     * Return the current speed.
     */
    public Vector getSpeed() {
        return speed;
    }

    /**
     * Get the space object itself.
     */
    protected final Space getSpace() 
    {
        return (Space)getWorld();
    }

}