import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class AutoText here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class InstantText extends Text
{
    private int acts=0;
    private boolean firstLoad = true;
    public InstantText(String text, int width, float fSize)
    {
        super(text, width, fSize);
        acts = curString.length()*3;
            instantText();
    }
    public void act() 
    {
        //super.act();
        if (acts < 0 || Greenfoot.mouseClicked(this))
        {
            getLand().removeObject(this);
            /*
            if (nxtFile != null && !curFile.equals(nxtFile))
            {
                loadNext(nxtFile);
                //super.act();
                //instantText();
                acts = curString.length()*2;
            }
            else
            {
                if (acts < 0)
                closing = true;   
            }
            */
        }
        else
        acts--;
    }    
}
