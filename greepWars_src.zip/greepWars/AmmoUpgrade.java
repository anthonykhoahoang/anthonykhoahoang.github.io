import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class AmmoUpgrade here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class AmmoUpgrade extends Upgrades
{
    public AmmoUpgrade(int upgrade)
    {
        super(upgrade);
    }
    public void act() 
    {
        super.act();
    }    
}
