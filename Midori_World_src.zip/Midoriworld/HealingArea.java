import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.util.List;
/**
 * Invisible area that can heal ingamecharacter by 2 hp,
 * every 50 acts
 * 
 * @author Anthony Hoang
 * @version (v1)
 */
public class HealingArea  extends InGameObjects
{
    private int delay = 50;
    public HealingArea(int w, int h)
    {
        setImage(new GreenfootImage(w,h));
        //getImage().fill();
    }
    public void act() 
    {
        if (getMWorld().esPause) return;
        if (delay == 0)
        heal();
        if (delay > 0)
        delay--;
    }    
    public void heal()
    {
        delay = 50;
        InGameCharacter a = (InGameCharacter)getOneIntersectingObject(InGameCharacter.class);
        if (a != null)
        a.heal(2);
    }
}
