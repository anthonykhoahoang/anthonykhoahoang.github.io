import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class HostileEnemy here.
 * 
 * @author Anthony Hoang
 * @version (v1)
 */
public class HostileEnemy  extends InGameHostile
{
    public boolean hasHit = false;
    public void act() 
    {
        if (getMWorld().esPause) return;
        if (hasHit)
        die();
    }   
    public void die()
    {
        getMWorld().addObject(new SmallSmudgeParticle((int)(Math.random()*360)), getX(), getY());
        GreenfootImage img = new GreenfootImage(getImage());
        int w = img.getWidth()-1;
        int h = img.getHeight()-1;
        if (w < 1 || h < 1) 
        {
            for (int i = 0; i < 15; i++)
            getMWorld().addObject(new SmallSmudgeParticle((int)(Math.random()*360)), getX(), getY());
            getMWorld().removeObject(this);
            return;
        }
        else
        img.scale(w,h);
        setImage(img);
    }
    public boolean hasHit()
    {
        return hasHit;
    }
    public void hit()
    {
        hasHit = true;
        for (int i = 0; i < 15; i++)
        {
            getMWorld().addObject(new SmallSmudgeParticle((int)(Math.random()*360)), getX(), getY());
        }
    } 
}
