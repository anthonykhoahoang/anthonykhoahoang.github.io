import greenfoot.*;  // (World, Actor, GreenfootImage, and Greenfoot)
import java.awt.Color;
import java.awt.Font;
/**
 * Allows game to continue from start of level after losing.
 * 
 * @author Anthony Hoang
 * @version 1.0
 */

public class Continue extends Actor
{
    public static final float FONT_SIZE = 38.0f;
    public static final int WIDTH = 225;
    public static final int HEIGHT = 50;
    private GreenfootImage image;
    
    public Continue()
    {
        image = new GreenfootImage(WIDTH, HEIGHT);
        image.setColor(new Color(200, 50, 10, 128));
        image.fillRect(0, 0, WIDTH, HEIGHT);
        Font font = image.getFont();
        font = font.deriveFont(FONT_SIZE);
        image.setFont(font);
        image.setColor(Color.WHITE);
        image.drawString("Continue?", 20 , 38);
        setImage(image);
    }
    
    public void act() 
    {
        image.clear();
        if (Greenfoot.mouseMoved(this))
        {
            image.setColor(new Color(255, 255, 10, 128));
            image.fillRect(0, 0, WIDTH, HEIGHT);
            image.setColor(Color.WHITE);
            image.drawString("Continue?", 20 , 38);
        }
        else
        {
            image.setColor(new Color(200, 50, 10, 128));
            image.fillRect(0, 0, WIDTH, HEIGHT);
            image.setColor(Color.WHITE);
            image.drawString("Continue?", 20 , 38);
        }
        if (Greenfoot.mousePressed(this))
        {
           // getSpace().loadSavedGame();
           getSpace().reloadLevel();
        }
        setImage(image);
        
    }
    public Space getSpace() 
    {
        return (Space)getWorld();
    }
}
