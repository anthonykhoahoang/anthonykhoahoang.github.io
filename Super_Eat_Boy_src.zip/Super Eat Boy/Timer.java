public class Timer 
{
    private long startTime;
    private double runTimeSeconds;
    private double currentTimeSeconds;
    public boolean timeUp = false;
    private int minutes;
    private int seconds;
    private String time;
    private int compareSeconds;
    private boolean usesMinutes;
    /* Examp use:
     * Timer functionTimer = new Timer(10.0); creates a timer that works for ten seconds
     * do{
     * functionTimer.updateTime(); updates the timer without using the string. Is necessary to call on in a loop
     *  *code to do stuff*
     *  }while(!functionTimer.timeUp);
     *  would suggest making a timer inside each method, etc. so that a new timer will be created when the method is 
     *  called instead of having to have a way to reset it. Also, updateTime is necessary
     */
    public Timer(int endMinute)
    {
        this.startTime = System.nanoTime();
        this.runTimeSeconds = endMinute*60;
        this.minutes = (int)(this.runTimeSeconds/60);
        // set starting values for clock based on a start time and an end time in minutes
        this.usesMinutes = true;
    }
    public Timer(double endMinute, boolean useMinutes)
    {
        this.startTime = System.nanoTime();
        this.runTimeSeconds = endMinute*60;
        this.minutes = (int)(this.runTimeSeconds/60);
        // set starting values for clock based on a start time and an end time in minutes
        this.usesMinutes = true;
    }
    public Timer(double seconds) 
    {
        this.startTime = System.nanoTime(); 
        this.runTimeSeconds = seconds;// create a clock that uses only seconds by taking in a double, #.0, only
        this.usesMinutes = false;
    }
    public void updateTime()
    {
        long currentTime = System.nanoTime(); 
        long elapsedTime = currentTime - this.startTime;
        this.currentTimeSeconds = elapsedTime / 1.0E09; // updates the current time for the class, should be used in loop
        if(this.currentTimeSeconds == this.runTimeSeconds) //compare current time to the end time
        {
            this.timeUp = true;
        }
    }
    private void timerMinutesAndSeconds()
    {
        this.seconds = (int) (this.compareSeconds  - this.currentTimeSeconds);  
        if(this.seconds == 0)
        {
            if(this.minutes>=1)
            {
                this.minutes--;
                this.compareSeconds +=60; //increase the compare seconds if there's more minutes, so that 
                // seconds won't be negative
            }
            else if(this.minutes <1)
            {
                this.timeUp = true; // set the boolean so that it can be known when time is up
            }
        }
        if(this.seconds>=10)
        {
            this.time = "TIME "+this.minutes+":"+this.seconds;
        }
        else if(this.seconds < 10)
        {
            this.time = "TIME "+this.minutes+":"+0+this.seconds; // keep the number of digits consistent
        }
        
    }
    public String currentTime()
    {
        if(this.usesMinutes)
        {
            timerMinutesAndSeconds();
        }
        else if(!this.usesMinutes)
        {
            this.seconds = (int)(this.runTimeSeconds - this.currentTimeSeconds);
            this.time = "TIME "+this.seconds; // if the timer is made using double and seconds, it will return seconds
        }
        return this.time;
    }
    public String toString()
    {
        seconds = (int) (runTimeSeconds - this.currentTimeSeconds - this.compareSeconds);   
        if (seconds < 0)
            return "00:00";        
        minutes = seconds / 60;
        seconds -= minutes*60;
        if (minutes < 10)
            time = "0" + minutes;
        else
            time = "" + minutes;
        if (seconds < 10)
            time += ":0" + seconds;
        else
            time += ":" + seconds;
        return time;
    }
}
