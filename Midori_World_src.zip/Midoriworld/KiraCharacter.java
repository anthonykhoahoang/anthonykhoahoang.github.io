import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.util.List;
/**
 * Write a description of class haracter here.
 * 
 * @author Anthony Hoang
 * @version (v1)
 */
public class KiraCharacter  extends Character
{
    public KiraCharacter()
    {
        setImage(new GreenfootImage("kira/kira.png"));
    }
    public void act() 
    {
        super.act();
    }   
    public void blinkEyes()
    {
        List<KiraEyes> listEyes = getMWorld().getObjects(KiraEyes.class);
        if (listEyes.size() == 0 ) return;
        KiraEyes eyes = listEyes.get(0);
        eyesBlinkCount--;
        if (eyesBlinkCount == 0)
        {
            eyes.readyToBlink();
            eyesBlinkCount = 200 + ((int)Math.random()*5)*100;
        }
    } 
    public void placeMouthEyes()
    {
        List<KiraEyes> listEyes = getMWorld().getObjects(KiraEyes.class);
        List<KiraMouth> listMouth = getMWorld().getObjects(KiraMouth.class);
        if (listEyes.size() == 0 || listMouth.size() == 0) return;
        
        KiraEyes eyes = listEyes.get(0);
        KiraMouth mouth = listMouth.get(0);
        
        if (mouth.getY() != getY()-103)
        mouth.setLocation(getX()+3, getY()-103);
        
       if (eyes.getX() != getX()+2 && eyes.getY() != getY()-143)
        eyes.setLocation(getX()+2, getY()-143);
    } 
}
