import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * AlienShip releases Greeps and can hurt you if it contacts you.
 * 
 * @author (Anthony Hoang) 
 * @version (2.0)
 */
public class GreepShip extends Enemy2
{
    private int totalPassengers;     // Total number of passengers in this ship.
    private int stepCount = 0;
    private int passengersReleased;
    private int empDelay;
    private boolean isLeft = false;
    private int releaseDelay;
    
    /**
     * Create a space ship. The parameter specifies at what height to land.
     */
    public GreepShip(int numGreeps, int life)
    {
        super (life, 100);
        totalPassengers = numGreeps;
        empDelay = 0;
        releaseDelay = -20;
    }

    /**
     * Let the ship act: move or release greeps.
     */
    public void act()
    {
        if(!isEmpty() && releaseDelay >= 0) 
        releasePassenger();
        else 
            releaseDelay++;
            if (isLeft)
            moveLeft();
            else
            moveRight();
            
            if (atLeftEdge()) isLeft = false;
            if (atRightEdge()) isLeft = true;
            
    }
    
    /**
     * True if all passengers are out.
     */
    public boolean isEmpty()
    {
        return passengersReleased == totalPassengers;
    }
    
    /**
     * Possibly: Let one of the passengers out. Passengers appear at intervals, 
     * so this may or may not release the passenger.
     */
    private void releasePassenger()
    {
        if(passengersReleased < totalPassengers) 
        {
            stepCount++;
            if(stepCount == 5) 
            {
                getSpace().addEnemy();
                getSpace().addObject(new Greep(), getX(), getY() + 30);
                passengersReleased++;
                stepCount = 0;
            }
        }
    }
}