import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.awt.Color;
import java.awt.Font;
/**
 * Write a description of class ItemMenu here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class ItemMenu extends Battle
{
    private int HEIGHT = 500;
    private int WIDTH = 1000;
    private GreenfootImage image;
    public ItemMenu()
    {
        image = new GreenfootImage(WIDTH, HEIGHT);
        image.setColor(new Color(0, 27, 164, 50));
        image.fillRect(0, 0, WIDTH, HEIGHT);
        image.setColor(new Color(55, 88, 255, 50));
        image.fillRect(3, 3, WIDTH-6, HEIGHT-6);
       // Font font = new Font("Courier", image.getFont().getStyle(), image.getFont().getSize()) ;
        //font = font.deriveFont(20f);
        //image.setFont(font);
        //image.setColor(Color.WHITE);
        //image.drawString(exp, 400, 50);
        setImage(image);
    }
}
