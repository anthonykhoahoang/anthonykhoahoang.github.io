import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class DeadPopsicle here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class DeadPopsicle  extends DeadFood
{
    private static GreenfootImage img;
    
    public DeadPopsicle(int realX, int realY)
    {
        super(realX, realY);
        if (img == null)
            img = new GreenfootImage("images/popsicle/ps1.png"); 
        setImage(img);
    }
    
    public void act() 
    {
        setRotation(getRotation() + 10);
        setRealLocation(getRealX(), getRealY() + 5);
        getWorld().addObject(new LightBlueParticle(90, getRealX(),getRealY()+10), 0, 0);
        super.act();
        if (getWorld().getHeight() + img.getHeight() < getY())
            getWorld().removeObject(this);
    }    
}
