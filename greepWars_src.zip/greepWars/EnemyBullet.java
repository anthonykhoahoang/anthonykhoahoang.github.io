import greenfoot.*;  // (World, Actor, GreenfootImage, and Greenfoot)

/**
 * A enemy bullet that can hit the rocket.
 * 
 * @author Anthony hoang
 */
public class EnemyBullet extends Actor
{
    /** A bullet looses one life each act, and will disappear when life = 0 */
    private int life;
    private int originalLife;
    /** The damage this bullet will deal */
    private int damage;
    
    private Enemy enemy;
    public EnemyBullet(int rotation, int numLife, int numDamage, boolean sound, Enemy e)
    {
        enemy = e;
        life = numLife;
        originalLife = life;
        damage = numDamage;
        setRotation(rotation);
        if (sound)
        Greenfoot.playSound("startBullet.wav");
    }
    public int getDamage()
    {
        return damage;
    }
    public void move()
    {
        double angle = Math.toRadians( getRotation() );
        int x = (int) Math.round(getX() + Math.cos(angle) * 6);
        int y = (int) Math.round(getY() + Math.sin(angle) * 6);
        setLocation(x, y);
    }
    public void act()
    {
        if(life <= 0) 
        {
            life = originalLife;
            getWorld().removeObject(this);
        }
        else 
        {
            move();
            if (atWorldEdge())
            turn(45);
            life--;
        }
    }
    public void hit()
    {
        life = 0;
    }
    public void setDamage(int n)
    {   damage = n; }
    public void setLife(int n)
    {   life = n;   }
    public void turn(int angle)
    {
        setRotation(getRotation() + angle);
    } 
    public boolean atWorldEdge2()
    {
        if(getX() < 200 || getX() > getWorld().getWidth() - 200)
            return true;
        if(getY() < 10 || getY() > getWorld().getHeight() - 10)
            return true;
        else
            return false;
    }
    public boolean atWorldEdge()
    {
        if(getX() < 3 || getX() > getWorld().getWidth() - 3)
            return true;
        if(getY() < 3 || getY() > getWorld().getHeight() - 3)
            return true;
        else
            return false;
    }
}