import greenfoot.*;  // (World, Actor, GreenfootImage, and Greenfoot)
import java.util.List;
/**
 * Aims for high priority enemies and deals a lot of damage.
 * 
 * @author Anthony Hoang
 * version: 2.1
 */
public class HomingMissles extends Bullet
{
    /** A bullet looses one life each act, and will disappear when life = 0 */
    private int life;
    /** The damage this bullet will deal */
    private int damage;
    private int sounds;
    private int bulletLevel;
    
    public HomingMissles(int rotation,  Rocket r)
    {
        super(new Vector(rotation, 20), rotation, 500, false, r);
        setRotation(rotation);
        Greenfoot.playSound("missle.wav");
        damage = 500;
        life = 999;
    }
    /**
     * The bullet will damage asteroids if it hits them.
     */
    public int getDamage()
    {
        return damage;
    }
    public void move()
    {
        double angle = Math.toRadians( getRotation() );
        int x = (int) Math.round(getX() + Math.cos(angle) * 30);
        int y = (int) Math.round(getY() + Math.sin(angle) * 30);
        setLocation(x, y);
    }
    public void act()
    {
        if(life <= 0) 
        {
            getSpace().addObject(new Explosion(), getX(), getY());
            getWorld().removeObject(this);
        }
        else 
        {
            setRotation(getDirectionTowardsEnemy());
            move();
            List<Enemy> a = getObjectsInRange(100, Enemy.class);
            List<Asteroid> b = getObjectsInRange(100, Asteroid.class);
            List<Upgrades> c = getObjectsInRange(100, Upgrades.class);
            if ( getObjectsInRange(10, Enemy.class).size() != 0 || getObjectsInRange(10, Asteroid.class).size() != 0)
            {
                for (Enemy e : a)
                e.hit(damage);
                for(Asteroid ast : b)
                ast.hit(damage);
                for(Upgrades up : c)
                up.hit(damage, r);
                getWorld().addObject(new Explosion(), this.getX(), this.getY());
                getSpace().removeObject(this);
                return;
            }
        }
        life--;
    }
    public List enemyList()
    {
        List enemyList4 = getNeighbours(1000, true, AlienShipBoss2.class);
        List enemyList1 = getNeighbours(1000, true, AlienShipBoss.class);
        List enemyList2 = getNeighbours(1000, true, AlienShip.class);
        List enemyList3 = getNeighbours(1000, true, Asteroid.class);
        List enemyList5 = getNeighbours(1000, true, Enemy.class);
        if(enemyList4.size() != 0)
        return enemyList4;
        else
        if (enemyList1.size() != 0)
        return enemyList1;
        else
        if (enemyList2.size() != 0)
        return enemyList2;
        else
        if(enemyList3.size() != 0)
        return enemyList3;
        else return enemyList5;
    }
    public int getDirectionTowardsEnemy()
    {
        List enemyList = enemyList();
        if (enemyList.size() != 0)
        {
            Actor temp = (Actor)enemyList.get(0);
            int deltaX = (temp.getX() - getX());
            int deltaY = (temp.getY() - getY());
            return ((int) (180 * Math.atan2(deltaY, deltaX) / Math.PI));
        }
        else
        return getRotation();
    }
}