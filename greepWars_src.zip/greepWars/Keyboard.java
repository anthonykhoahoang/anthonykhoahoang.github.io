import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * keyboard that lets you type in stuff
 * 
 * @author Anthony Hoang
 * @version 2.1
 */
public class Keyboard extends Actor
{
    /**
     * Act - do whatever the KeyBoard wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
        // Add your action code here.
    }    
    public Space getSpace()
    {
        return (Space)getWorld();
    }
}
