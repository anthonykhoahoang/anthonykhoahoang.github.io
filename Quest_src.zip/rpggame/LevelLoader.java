import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.awt.Color;
import java.awt.Font;
import java.io.BufferedReader;
import java.io.IOException; 
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URL;
import java.util.*;

/**
 * Write a description of class LevelLoader here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class LevelLoader extends Actor
{
    ArrayList<String> strArray = new ArrayList<String>();
    private String file;
    public LevelLoader (String File)
    {
        // getImage().scale(50,50);
        file = "data/level/"+File+".txt";
        loadFileToArray(file);
    }
    public LevelLoader()
    {

    }
    public void act() 
    {
        setRotation(getRotation()+1);
    }  
    public InputStream openFile(String fileName) throws IOException
    {
        URL url = getClass().getClassLoader().getResource(fileName);
        if(url == null)
        throw new IOException("File not found: " + fileName);
        return url.openStream();
    } 
    public void loadFileToArray(String textFileName)
    {
        StringBuffer sb = new StringBuffer();
        try{
            InputStream is = openFile(textFileName);
            BufferedReader d = new BufferedReader(new InputStreamReader(is));
            String line = d.readLine();
            while(line != null)
            {
                line = d.readLine();
                if (line != null)
                strArray.add(line);
            }
        }
        catch(Exception ex)
        { return ; }
    } 
    public void loadLevel()
    {
        List l = getLand().getObjects(LevelLoader.class);
        for (int i = 0; i < strArray.size(); i++)
        {
            String temp = strArray.get(i);
            //System.out.println(temp);
            read(temp);
        }
        //clearLevelLoaders();
    
        getLand().removeObjects(l);
    }
    public void read(String str)
    {
        int index = 0;
        while (index < str.length() && !str.substring(index, index+1).equals("%") )
        {
            index++;
        }
        if (index != 0)
        {
            String command = str.substring(0,index);
            String parameters = str.substring(index+1, str.length());
            //System.out.println("Command: " + command+"/ parameters: " + parameters);
            execute(command, parameters);
        }
        
    }
    public void execute(String command, String parameter)
    {
        if (command.equals("#clearWorldObjects")) clearWorldObjects();
        if (command.equals("#setBackground")) setBackground(parameter);
        if (command.equals("#scaleSkyeNormal")) scaleSkyeNormal();
        if (command.equals("#scaleSkye")) scaleSkye(parameter);
        if (command.equals("#addHouse")) addHouse(parameter);
        if (command.equals("#setSkyeLoc")) setSkyeLoc (parameter);
        if (command.equals("#addGameBoarder")) addGameBoarder(parameter);
        if (command.equals("#addLevelLoader")) addLevelLoader(parameter);
        if (command.equals("#addFarm")) addFarm(parameter);
        if (command.equals("#addTwoSoldiers")) addTwoSoldiers(parameter);
        if (command.equals("#addFiveSoldiers")) addFiveSoldiers(parameter);
        if (command.equals("#addInfoLoader")) addInfoLoader(parameter);
        if (command.equals("#clearInfoLoader")) clearInfoLoader();
        if (command.equals("#stream0Play")) stream0Play(parameter);
        if (command.equals("#clearText")) clearText();
        if (command.equals("#addTheodore2Soldiers")) addTheodore2Soldiers(parameter);
        if (command.equals("#addSpector_Big")) addSpector_Big(parameter);
        if (command.equals("#addQuestText300")) addQuestText300(parameter);
        if (command.equals("#addTheodore")) addTheodore(parameter);
        
        if (command.equals("#addSkeleton")) addSkeleton(parameter);;
        //if (command.equals("#clearLevelLoaders")) clearLevelLoaders();

    }
    public void addSkeleton( String str)
    {
        int index = 0;
        while (index < str.length() &&!str.substring(index, index+1).equals("%") )
            index++;
        String locx = str.substring(0,index);
        String locy = str.substring(index+1, str.length());
        int x = Integer.parseInt(locx);
        int y = Integer.parseInt(locy);
        getLand().addObject(new Skeleton(), x, y);
    }
    public void addTheodore(String str)
    {
        int index = 0;
        
        while (index < str.length() &&!str.substring(index, index+1).equals("%") )
        index++;
        String file = str.substring(0,index);
        String str2 = str.substring(index+1, str.length());
        
        index = 0;
        while (index < str2.length() &&!str2.substring(index, index+1).equals("%") )
        index++;
        String locx = str2.substring(0,index);
        String locy = str2.substring(index+1, str2.length());
        int x = Integer.parseInt(locx);
        int y = Integer.parseInt(locy);
        double scale = Double.parseDouble(file);
        
        getLand().addObject(new Theodore(scale), x, y);
    }
    public void addQuestText300(String str)
    {
        int index = 0;
        
        while (index < str.length() &&!str.substring(index, index+1).equals("%") )
        index++;
        String file = str.substring(0,index);
        String str2 = str.substring(index+1, str.length());
        
        index = 0;
        while (index < str2.length() &&!str2.substring(index, index+1).equals("%") )
        index++;
        String locx = str2.substring(0,index);
        String locy = str2.substring(index+1, str2.length());
        int x = Integer.parseInt(locx);
        int y = Integer.parseInt(locy);
        
        getLand().addObject(new AutoText(file, 300, 12f), x, y);
    }
    public void addSpector_Big(String str)
    {
        int index = 0;
        while (index < str.length() &&!str.substring(index, index+1).equals("%") )
            index++;
        String locx = str.substring(0,index);
        String locy = str.substring(index+1, str.length());
        int x = Integer.parseInt(locx);
        int y = Integer.parseInt(locy);
        getLand().addObject(new Spector_Big(), x, y);
    }
    public void addTheodore2Soldiers(String str)
    {
        if (getLand().theodoreInParty)
        return;
        int index = 0;
        while (index < str.length() &&!str.substring(index, index+1).equals("%") )
            index++;
        String locx = str.substring(0,index);
        String locy = str.substring(index+1, str.length());
        int x = Integer.parseInt(locx);
        int y = Integer.parseInt(locy);
        getLand().addObject(new Theodore2Soldiers(), x, y);
    }
    public void clearLevelLoaders()
    {
        getLand().removeObjects(getLand().getObjects(LevelLoader.class));
    }
    public void clearText()
    {
        getLand().removeObjects(getLand().getObjects(Text.class));
    }
    public void stream0Play(String str)
    {
        
        int index = 0;
        while (index < str.length() &&!str.substring(index, index+1).equals("%") )
            index++;
        String file = str.substring(0,index);
        String bool = str.substring(index+1, str.length());
        boolean repeat = bool.equals("true");
        
        if (getLand().stream0 != null)
        {
            getLand().stream0.close();
            getLand().removeObject(getLand().stream0);
        }
        getLand().stream0 = new AudioPlayer(file, repeat);
        getLand().addObject(getLand().stream0, 0 , 0);
        getLand().stream0.play();
    }
    public void addInfoLoader(String str)
    {
        int index = 0;
        
        while (index < str.length() &&!str.substring(index, index+1).equals("%") )
        index++;
        String file = str.substring(0,index);
        String str2 = str.substring(index+1, str.length());
        
        index = 0;
        while (index < str2.length() &&!str2.substring(index, index+1).equals("%") )
        index++;
        String locx = str2.substring(0,index);
        String locy = str2.substring(index+1, str2.length());
        int x = Integer.parseInt(locx);
        int y = Integer.parseInt(locy);
        
        getLand().addObject(new InfoLoader(file), x, y);
    }
    public void addFiveSoldiers(String str)
    {
        int index = 0;
        while (index < str.length() &&!str.substring(index, index+1).equals("%") )
            index++;
        String locx = str.substring(0,index);
        String locy = str.substring(index+1, str.length());
        int x = Integer.parseInt(locx);
        int y = Integer.parseInt(locy);
        getLand().addObject(new FiveSoldiers(), x, y);
    }
    public void addTwoSoldiers(String str)
    {
        int index = 0;
        while (index < str.length() &&!str.substring(index, index+1).equals("%") )
            index++;
        String locx = str.substring(0,index);
        String locy = str.substring(index+1, str.length());
        int x = Integer.parseInt(locx);
        int y = Integer.parseInt(locy);
        getLand().addObject(new TwoSoldiers(), x, y);
    }
    public void addFarm(String str)
    {
        int index = 0;
        while (index < str.length() &&!str.substring(index, index+1).equals("%") )
            index++;
        String locx = str.substring(0,index);
        String locy = str.substring(index+1, str.length());
        int x = Integer.parseInt(locx);
        int y = Integer.parseInt(locy);
        getLand().addObject(new Farm(), x, y);
    }
    public void addLevelLoader(String str)
    {
        int index = 0;
        
        while (index < str.length() &&!str.substring(index, index+1).equals("%") )
        index++;
        String file = str.substring(0,index);
        String str2 = str.substring(index+1, str.length());
        
        index = 0;
        while (index < str2.length() &&!str2.substring(index, index+1).equals("%") )
        index++;
        String locx = str2.substring(0,index);
        String locy = str2.substring(index+1, str2.length());
        int x = Integer.parseInt(locx);
        int y = Integer.parseInt(locy);
        
        getLand().addObject(new LevelLoader(file), x, y);
        
    }
    public void addGameBoarder(String str)
    {
        String a = str;
        int[] data = new int[4];
        for (int i = 0; i < 4; i++)
        {
            int index = 0; 
            while (index < a.length() &&!a.substring(index, index+1).equals("%") )
            index++;
            
            data[i] = Integer.parseInt(a.substring(0,index));
            if ( i < 3)
            a = a.substring(index+1, a.length());
        }
        //System.out.println( data[0] + " " +data[1] + " " + data[2] + " " +data[3]);
        getLand().addObject(new GameBoarder(data[0], data[1], false), data[2], data[3]);
    }
    public void setSkyeLoc (String str)
    {
        int index = 0;
        while (index < str.length() &&!str.substring(index, index+1).equals("%") )
            index++;
        String locx = str.substring(0,index);
        String locy = str.substring(index+1, str.length());
        int x = Integer.parseInt(locx);
        int y = Integer.parseInt(locy);
        getLand().skye.setLocation(x, y);
    }
    public void addHouse(String str)
    {
        int index = 0;
        while (index < str.length() &&!str.substring(index, index+1).equals("%") )
            index++;
        String locx = str.substring(0,index);
        String locy = str.substring(index+1, str.length());
        int x = Integer.parseInt(locx);
        int y = Integer.parseInt(locy);
        getLand().addObject(new House(), x, y);
    }
    public void setBackground(String str)
    {
        getLand().setBackground(str);
    }
    public void scaleSkyeNormal()
    {
        getLand().skye.reloadImages();
    }
    public void scaleSkye(String str)
    {
        Double d = new Double (str);
        getLand().skye.scaleImages(d);
    }
    public void clearWorldObjects()
    {
        getLand().removeObjects(getLand().getObjects(WorldObjects.class));
    }
    public void clearInfoLoader()
    {
        getLand().removeObjects(getLand().getObjects(InfoLoader.class));
    }
    public Land getLand()
    {
        return (Land)getWorld();
    }
}
