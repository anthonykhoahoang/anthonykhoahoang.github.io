import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class BT2_2 here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class BT2_3 extends BT2
{
    private int acts = 15;
    public BT2_3( int dmg, boolean sound, Type1 p, int rot)
    {
        super(dmg, sound, p, rot);
    }
    public void act() 
    {
        acts--;
        if (acts <= 15 && acts > 7)
        {
            moveLeft();
        }
        else
        if (acts<= 7 && acts >0)
        moveRight();
        if (acts == 0) acts = 15;
        superAct();
    }    
    public void addToPlane()
    {
        acts= 15;
        super.addToPlane();
    }
}
