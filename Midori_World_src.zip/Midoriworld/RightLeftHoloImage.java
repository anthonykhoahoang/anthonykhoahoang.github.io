import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class RightLeftHoloImage here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class RightLeftHoloImage  extends HoloImage
{
    public RightLeftHoloImage(String pic)
    {
        super(pic);
    }
    public void act() 
    {
        moveLeft();
        super.act();
    }    
    public void moveLeft()
    {
        int x = getX()-1;
        if (x <= 0)
        remove();
        else
        setLocation(x,getY()); 
    }
}
