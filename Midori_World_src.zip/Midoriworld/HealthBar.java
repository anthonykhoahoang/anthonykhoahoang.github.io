import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.awt.Color;
import java.awt.Font;
/**
 * Write a description of class HealthBar here.
 * 
 * @author Anthony Hoang
 * @version (v1)
 */
public class HealthBar  extends InGameObjects
{
    private int tHealth = 0;
    private GreenfootImage image;
    private boolean firstInitialize = true;
    private int delay = 2;
    public HealthBar()
    {
        image = new GreenfootImage(20, 200);
        getImage().clear();
        //image.setTransparency(220);
    }
    public void act() 
    {
        if (getMWorld().gamePause) return;
        if (firstInitialize)
        {
            firstInitialize = false;
            image.setColor(new Color(50,25,150,150));
            tHealth = 200;
            image.fillRect(0, tHealth,20,200);
            Font font = image.getFont();
            font = font.deriveFont(11f);
            image.setColor(Color.WHITE);
            image.drawString("HP", 5, 100);
            setImage(image);
        }
        updateHP();
    }    
    public void updateHP()
    {
        int hp = 200-getMWorld().health*2;
        if (hp == tHealth) return;
        if (hp > tHealth)
        tHealth++;
        else if (hp < tHealth)
        tHealth--;
        image.clear();
        image.setColor(new Color(50,25,150,190));
        image.fillRect(0, tHealth,20,200);
        Font font = image.getFont();
        font = font.deriveFont(11f);
        image.setFont(font);
        image.setColor(Color.WHITE);
        image.drawString("HP", 4, 100);
        //image.drawString("100", 1, 190);
        //image.fillRect(1,175,21,2);
        int n = 100-tHealth/2;
        String s = ""+n+"%";
        font = font.deriveFont(8f);
        image.setFont(font);
        if (s.length()>3)
        image.drawString(s,0,120);
        else image.drawString(s,3,120);
        setImage(image);
    }
}
