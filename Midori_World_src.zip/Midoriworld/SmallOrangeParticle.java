import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class SmallSmudgeParticle here.
 * 
 * @author Anthony Hoang
 * @version v1
 */
public class SmallOrangeParticle  extends Particle
{
    private static GreenfootImage img;
    private int transparency = 150;
    private int transReduce = 5;
    private boolean firstInitialize = true;
    private double x;
    private double y;
    private int r;
    private Vector v = new Vector();
    
    private int curImage = 0;
    private static GreenfootImage[] images;
    
    public SmallOrangeParticle(int r)
    {
        this.r = r;
        if (img == null)
        {
            img = new GreenfootImage("orangeParticle.png");
            img.scale(img.getWidth()/2, img.getHeight()/2);
        }
        if (images == null)
        {
            images = new GreenfootImage[30];
            int n = 0;
            for (int i = 0; i < 30; i++)
            {
                images[i] = new GreenfootImage(img);
                images[i].setTransparency(transparency-n);
                n += transReduce;
            }
        }
        setImage(img);
    }
    public void act() 
    {
        if (getMWorld().esPause) return;
        if (firstInitialize)
        {
            x = getX();
            y = getY();
            firstInitialize = false;
        }
        else
        {
            
            curImage++;
            if (curImage == 30)
            getMWorld().removeObject(this);
            else
            {
                setImage(images[curImage]);
                random();
                move();
            }
            /*
            transparency-=transReduce;
            if (transparency <= 0)
            {
                getWorld().removeObject(this);
            }
            else
            {
                getImage().setTransparency(transparency);
                random();
                move();
            }
            */
        }
    }    
    public void random()
    {
        v.add(new Vector((int)(Math.random()*360),Math.random()*.3));
        v.add(new Vector(270, .04));
    }
    public void move()
    {
        v.add(new Vector(r, .05));
        x+=v.getX();
        y+=v.getY();
        setLocation((int)x,(int)y);
    }
}
