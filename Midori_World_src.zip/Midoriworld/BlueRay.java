import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class BlueRay here.
 * 
 * @author Anthony Hoang
 * @version (v1)
 */
public class BlueRay extends PhoneHolos
{
    private int imageCount;
    private static GreenfootImage image;
    private int WIDTH;
    private int curWidth;
    private int curAction = 0;
    private int delay = 0;
    private int acts = 0;
    private int HEIGHT;
    private boolean firstInitialize = true;
    public BlueRay()
    {
        if (image == null)
        image = new GreenfootImage("blueray.png");
        WIDTH = image.getWidth();
        HEIGHT = image.getHeight();
        curWidth = WIDTH;   
        image.setTransparency(150);
        setImage(new GreenfootImage(image));
        getImage().scale(WIDTH,1);
    }
    public void act() 
    {
        if (getMWorld().gamePause) return;
        if (remove)
        super.act();
        else
        if (firstInitialize)
        {
            int h = getImage().getHeight()+2;
            if (h > HEIGHT)
            firstInitialize = false;
            else
            {
                setImage(new GreenfootImage(image));
                getImage().scale(WIDTH,h);
                setLocation(getX(),getY()-1);
            }
        }
        else
        if (acts == delay)
        {
            acts = 0;
            setImage();
        }
        else acts++;
    }    
    public void setImage()
    {
        if (curAction == 0)
        { 
            curWidth--;
            if (curWidth < 1)
            curAction = 1;
            else
            {
                GreenfootImage i = new GreenfootImage(image);
                i.scale(curWidth,image.getHeight());
                setImage(i);
            }
        }
        if (curAction == 1)
        {
            curWidth++;
            if (curWidth > WIDTH)
            curAction = 2;
            else
            {
                GreenfootImage i = new GreenfootImage(image);
                i.scale(curWidth,image.getHeight());
                i.mirrorHorizontally();
                setImage(i);
            }
        }
        if (curAction == 2)
        {
            curWidth--;
            if (curWidth < 1)
            curAction = 3;
            else
            {
                GreenfootImage i = new GreenfootImage(image);
                i.scale(curWidth,image.getHeight());
                i.mirrorHorizontally();
                setImage(i);
            }
        }
        if (curAction == 3)
        {
            curWidth++;
            if (curWidth > WIDTH)
            curAction = 0;
            else
            {
                GreenfootImage i = new GreenfootImage(image);
                i.scale(curWidth,image.getHeight());
                setImage(i);
            }
        }
    }
}