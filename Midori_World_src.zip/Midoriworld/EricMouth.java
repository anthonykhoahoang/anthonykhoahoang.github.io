import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Mouth moves
 * 
 * @author Anthony Hoang 
 * @version 1
 */
public class EricMouth extends EricFaceParts
{
    private GreenfootImage[] img = new GreenfootImage[5];
    int n = 0;
    int part = 1;
    private int count = 0;
    private int actCount=0;
    private int rDelay = (int)(Math.random()*10);
    public EricMouth()
    {
        img[0] = new GreenfootImage("eric/mouth/mouth1.png");
        img[1] = new GreenfootImage("eric/mouth/mouth2.png");
        img[2] = new GreenfootImage("eric/mouth/mouth3.png");
        img[3] = new GreenfootImage("eric/mouth/mouth4.png");
        img[4] = new GreenfootImage("eric/mouth/mouth5.png");
        setImage(img[0]);
    }
    public void act() 
    {
        //rDelay--;
        if (getMWorld().gamePause) return;
        if (actCount > 0 && rDelay > 5)
        {
            actCount--;
            moveMouth();
        }
        else if (!getImage().equals(img[0]))
        moveMouth();
        rDelay = (int)(Math.random()*30);
    }
    public void setActCount(int n)
    {
        actCount = n;
    }
    public void moveMouth()
    {
        if (count > 0) count=0;
        else
        count++;
        if (count > 0){return;}
        setImage(img[n]);
        if (n < 4 && part == 1)
            n++;
        else
        if (n == 4 && part == 1)
            part = 2;
      
        if (n > 0 && part == 2)
            n--;
        else if (n == 0 && part == 2)
        {
            part = 1;
        }
    }
}
