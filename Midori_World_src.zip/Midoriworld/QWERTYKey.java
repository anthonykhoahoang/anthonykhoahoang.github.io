import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.awt.Color;
import java.awt.Font;
import java.util.List;

/**
 * Write a description of class QWERTYKeys here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class QWERTYKey  extends Keys
{
    private int WIDTH = 60;
    private int HEIGHT= 55;
    private String key;
    private boolean isUpperCase;
    private int delay;
    private int DELAYLIM;
    private GreenfootImage image;
    private GreenfootImage image2;
    private boolean firstInitialize = true;
    
    public QWERTYKey(String k)
    {
        key = k;
        isUpperCase = true;
        delay = DELAYLIM;
        DELAYLIM = 9;
        image = new GreenfootImage(WIDTH, HEIGHT);
        image2 = new GreenfootImage(WIDTH, HEIGHT);
        drawOne();
        drawTwo();
        setImage(image2);
    }
    public void act() 
    {
        if (firstInitialize)
        {
            int t = getImage().getTransparency()+10;
            if (t > 255)
            firstInitialize = false;
            else
            {
                image.setTransparency(t);
                image2.setTransparency(t);
            }
            return;
        }
        if (closing)
        {
            int t = getImage().getTransparency()-15;
            if (t < 0)
            getMWorld().removeObject(this);
            else
            {
                image.setTransparency(t);
                image2.setTransparency(t);
            }
            return;
        }
        
        if (delay <= 0)
        {
            checkKey();
            delay = DELAYLIM;
        }
        else
        delay--;
        if (mouseOverThis())
        {
            if (getImage().equals(image2))
            setImage(image);
        }
        else 
        if (getImage().equals(image))
        setImage(image2);
        if (Greenfoot.mouseClicked(this))
        {
            setImage(image);
            List<Typer> list = getMWorld().getObjects(Typer.class);
            for (Typer t : list)
            t.setString(t.getString()+key);
        }
        if (!Greenfoot.isKeyDown(key.toLowerCase()) && !Greenfoot.isKeyDown(key)
        && !key.equals("_"))
        delay = 0;
        if( key.equals("_") && !Greenfoot.isKeyDown("-")&& !Greenfoot.isKeyDown("-"))
        delay = 0;
        super.act();
    }
    public void checkKey()
    {
        String tKey = key.toLowerCase();
        if (Greenfoot.isKeyDown(tKey) || Greenfoot.isKeyDown(key))
        {
            //setImage(image);
            List<Typer> list = getMWorld().getObjects(Typer.class);
            for (Typer t : list)
            t.setString(t.getString()+key);
        }
        checkUnderScore();
    }
    public void checkUnderScore()
    {
        if (key.equals("_"))
        {
            if (Greenfoot.isKeyDown("-")&&Greenfoot.isKeyDown("-"))//&& Greenfoot.isKeyDown("-"))
            {
                List<Typer> list = getMWorld().getObjects(Typer.class);
                for (Typer t : list)
                t.setString(t.getString()+key);
            }
        }
        //delay = 0;
    }
    public void changeCase()
    {
        if (isUpperCase)
            key.toLowerCase();
        else
            key.toUpperCase();
        isUpperCase = !isUpperCase;
    }
    public void drawOne()
    {
        image.setColor(Color.GRAY);
        image.fill();
        image.setColor(new Color(5, 5, 75 ,150));
        image.fillRect(5, 5, WIDTH-10, HEIGHT-10);
        Font font = image.getFont();
        font = font.deriveFont(30f);
        image.setFont(font);
        image.setColor(Color.WHITE);
        image.drawString(key, 15, 40);
        image.setTransparency(0);
        //setImage(image);
    }
    public void drawTwo()
    {
        image2.setColor(new Color(5, 5, 50 ,150));
        image2.fillRect(5, 5, WIDTH-10, HEIGHT-10);
        Font font = image.getFont();
        font = font.deriveFont(30f);
        image2.setFont(font);
        image2.setColor(Color.WHITE);
        image2.drawString(key, 15, 40);
        image2.setTransparency(0);
        //setImage(image2);
    }
}
