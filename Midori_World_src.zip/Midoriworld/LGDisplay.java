import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.awt.Color;
import java.awt.Font;
/**
 * Write a description of class LGDisplay here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class LGDisplay  extends LogicGate
{
    private GreenfootImage img;
    public LGDisplay(String str)
    {
        img = new GreenfootImage(700,100);
        Font font = img.getFont();
        font = font.deriveFont(35f);
        img.setFont(font);
        img.setColor(Color.WHITE);
        img.drawString(str,10,90);
        setImage(img);
    }
    public void act() 
    {
        // Add your action code here.
    }    
}
