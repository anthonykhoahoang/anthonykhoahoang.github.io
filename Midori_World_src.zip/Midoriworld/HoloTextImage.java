import greenfoot.*;  // (World, Actor, GreenfootImage, and Greenfoot)
import java.awt.Color;
import java.awt.Font;
import java.io.IOException;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URL;
import java.util.StringTokenizer;
import java.util.ArrayList;
/**
 * Reads an input text file 
 * @author Anthony Hoang
 * @version 3.0
 */
public class HoloTextImage extends HoloImage
{
    public float FONT_SIZE;
    public int WIDTH;
    public int HEIGHT;
    private String curString;
    
    private int index;
    private int pos;
    private int hPos;
    
    private String nxtFile;
    private String curFile;
    private boolean closing;
    
    private ArrayList<String> words;
    public GreenfootImage image;
    public boolean firstInitialize = true;
    private int delay = 0;
    public HoloTextImage() 
    {
    }
    public HoloTextImage(String text)
    {
        initialize(text);
    }
    public void initialize(String text)
    {
        WIDTH = 300;
        if (!text.endsWith(".txt"))
        text+= ".txt";
        closing = false;
        words = new ArrayList<String>();
        curFile = text;
        Font font;
        font = new Font("Lucida Console",getImage().getFont().getStyle(), getImage().getFont().getSize());
        if (!font.getFontName().equals("Lucida Console"))
        font = new Font("Monospaced",getImage().getFont().getStyle(), getImage().getFont().getSize());
        font = font.deriveFont(16f); 
        FONT_SIZE = font.getSize();
        String temp = "data/text/holo/"+text;
        curString = getTextFile(temp);
        readStringToArray(curString);
        HEIGHT = calcHeight(curString);
        image = new GreenfootImage(WIDTH,HEIGHT);
        image.setFont(font);
        image.setColor(Color.WHITE);
        
        index = 0;
        pos = (int)(FONT_SIZE)+60;
        hPos = (int)(FONT_SIZE)+60;
        setImage(image);
        
    }
    public void act()
    {
        if (getMWorld().gamePause) return;
        showText();
        if (remove)
        {
            int w = getImage().getWidth()-20;
            int h = getImage().getHeight()-20;
            if (w <= 0 || h<=0)
            getMWorld().removeObject(this);
            else
            getImage().scale(w,h);
        }
    }
    public void drawImage(){ }
    public void addNextText(String nxt) {}
    public void showText()
    {
        if (closing)
        {
            int t = getImage().getTransparency()-10;
            if (t < 10)
            getWorld().removeObject(this);
            else
            getImage().setTransparency(t);
            return;
        }
        if (delay > 0) delay--;
        ///****
        if (words.size() == 0) 
            return;
        words.set(0,checkForKeys(words.get(0)));
        if (words.get(0).equals("@@"))
        {
            words.remove(0);
            nxtFile = words.remove(0);
            
            if (!nxtFile.endsWith(".txt"))
            nxtFile+= ".txt";
        }
        else if (pos > WIDTH-FONT_SIZE/2*words.get(0).length()-(int)FONT_SIZE && index == 0 )
        {
            pos = (int)FONT_SIZE+60;
            hPos += (int)FONT_SIZE*2-FONT_SIZE/1.3;
        }
        else
        {
            String temp = words.get(0).substring(index, index + 1);
            image.drawString(temp, pos, hPos);
            index += temp.length();
            pos += (int)FONT_SIZE/2;
            setImage(image);
            if (index >= words.get(0).length())
            {
                words.remove(0);
                index = 0;
                pos+= FONT_SIZE/2;
            }
        }
    }
    public void close()
    {
        closing = true;
    }
    public String getTextFile(String textFileName)
    {
        String str = "";
        StringBuffer sb = new StringBuffer();
        try{
            URL url = getClass().getClassLoader().getResource(textFileName);
            if(url == null)
            throw new IOException("File not found: " + textFileName);
            InputStream is = url.openStream();
            BufferedReader br = new BufferedReader(new InputStreamReader(is));
            String line = br.readLine();
            while(line != null)
            {
                if (line != null)
                {
                    str += " "+line;
                }
                line = br.readLine();
            }
            is.close();
            br.close();
        }
        catch(Exception ex)
        { 
        }
        return str;
    } 
    public String checkForKeys(String s)
    {
        if (s == null) return s;
        if (s.equals("%left")) return getMWorld().left.toUpperCase();
        if (s.equals("%left2")) return getMWorld().left2.toUpperCase();
        if (s.equals("%right")) return getMWorld().right.toUpperCase();
        if (s.equals("%right2")) return getMWorld().right2.toUpperCase();
        if (s.equals("%jump")) return getMWorld().jump.toUpperCase();
        if (s.equals("%jump2")) return getMWorld().jump2.toUpperCase();
        if (s.equals("%crouch")) return getMWorld().crouch.toUpperCase();
        if (s.equals("%crouch2")) return getMWorld().crouch2.toUpperCase();
        if (s.equals("%use")) return getMWorld().use.toUpperCase();
        if (s.equals("%suitpower")) return getMWorld().suitpower.toUpperCase();
        return s;
    }
    public void readStringToArray(String str)
    {
        StringTokenizer st = new StringTokenizer(str);
        while (st.hasMoreTokens())
        {
            String t = ""+st.nextToken();
            words.add(t);
        }
    }
    public int calcHeight(String str)
    {
        int wordPos = (int)FONT_SIZE+60;
        int numrows = (int)(FONT_SIZE)+60;
        for (int i = 0; i < words.size(); i++)
        {
            wordPos += words.get(i).length()*(int)FONT_SIZE/2;
            wordPos += FONT_SIZE/2;
            if (wordPos > WIDTH-FONT_SIZE)
            {
                wordPos = (int)FONT_SIZE+60;
                wordPos += words.get(i).length()*(int)FONT_SIZE/2;
                numrows += (int)FONT_SIZE*2-FONT_SIZE/1.3;
            }
        }
        return numrows+(int)(FONT_SIZE);
    }
}