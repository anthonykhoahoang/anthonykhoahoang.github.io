import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.util.*;
/**
 * Write a description of class Type1 here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Type1 extends Plane
{
    private GreenfootImage forward = new GreenfootImage("Ship1/ship1.png");
    private GreenfootImage left = new GreenfootImage("Ship1/ship1right.png");
    private GreenfootImage right = new GreenfootImage("Ship1/ship1left.png");
    
    public ArrayList<BT1> BT1 = new ArrayList<BT1>();
    public ArrayList<BT2> BT2 = new ArrayList<BT2>();
    public ArrayList<BT2_2> BT2_2 = new ArrayList<BT2_2>();
    public ArrayList<BT2_3> BT2_3 = new ArrayList<BT2_3>();
    public ArrayList<BT2_4> BT2_4 = new ArrayList<BT2_4>();
    
    /** The minimum delay between firing the gun. */
    private int minGunFireDelay = 5;    
    /** How long ago we fired the gun the last time. */
    private int gunFireDelay = 0;    
    public Type1(int player)
    {
        super(player);
        setImage(forward);
        initiliseBullets();
    }
    public void act() 
    {
        checkKeys();
        checkForUpgrades();
        if (getInvincible() > 0)
        {
            if (getInvincible()%2 == 0)
            setImage(forward);
            else
            setImage(new GreenfootImage(1,1));
            setInvincible(getInvincible()-1);
        }
        else
        checkCollision();
        gunFireDelay++;
    }    
    public void initiliseBullets()
    {
        for (int i = 0; i < 100; i++)
        {
            BT1.add(new BT1(20, false, this, 270));
            BT2.add(new BT2(40, false, this, 270));
            BT2_2.add(new BT2_2(40, false, this, 270));
            BT2_3.add(new BT2_3(40, false, this, 270));
            BT2_4.add(new BT2_4(40, false, this, 270));
        }
    }
    public void addBullet (BulletType2 b)
    {
        if (b instanceof BT2_2)
        BT2_2.add((BT2_2)b);
        else
        if (b instanceof BT2_3)
        BT2_3.add((BT2_3)b);
        else
        if (b instanceof BT2_4)
        BT2_4.add((BT2_4)b);
        else
        if (b instanceof BT2)
        BT2.add((BT2)b);
        else
        BT1.add((BT1)b);
    }
    private void checkKeys() 
    {
        setImage(forward);
        if (Greenfoot.isKeyDown("up") || Greenfoot.isKeyDown("w"))
            moveForward();
        else
        if (Greenfoot.isKeyDown("down") || Greenfoot.isKeyDown("s"))
            moveBackward();
        if(Greenfoot.isKeyDown("left") || Greenfoot.isKeyDown("a"))
        {
            moveLeft();
            setImage(left);
        }
        else
        if(Greenfoot.isKeyDown("right") || Greenfoot.isKeyDown("d")) 
        {
            moveRight();
            setImage(right);
        }
        
        if(Greenfoot.isKeyDown("space")) 
        {
            fire();
        }
    } 
    public void fire() 
    {     
        if(gunFireDelay >= minGunFireDelay) 
        {
            fireBullet();
            gunFireDelay = 0;
        }
    }
    public void fireBT1(int x)
    {
        if (BT1.size() != 0)
        {
            BT1 a = BT1.remove(0);
            getSpace().addObject(a, x,getY()-10);
        }
        else
        getSpace().addObject(new BT1(20, true, this, 270), x ,getY()-10);
    }
    public void fireBT2(int x)
    {
        if (BT2.size() != 0)
        {
            BT2 a = BT2.remove(0);
            getSpace().addObject(a, x, getY()-10);
        }
        else
        getSpace().addObject(new BT2(40, false, this, 270), getX()+10,getY()-10);
    }
    public void fireBT2_2(int x)
    {
        if (BT2_2.size() != 0)
        {
            BT2_2 a = BT2_2.remove(0);
            getSpace().addObject(a, x, getY()-10);
        }
        else
        getSpace().addObject(new BT2_2(40, false, this, 270), getX()+10,getY()-10);
    }
    public void fireBT2_3(int x)
    {
        if (BT2.size() != 0)
        {
            BT2_3 a = BT2_3.remove(0);
            getSpace().addObject(a, x, getY()-10);
        }
        else
        getSpace().addObject(new BT2_3(40, false, this, 270), getX()+10,getY()-10);
    }
    public void fireBT2_4(int x)
    {
        if (BT2_4.size() != 0)
        {
            BT2_4 a = BT2_4.remove(0);
            getSpace().addObject(a, x, getY()-10);
        }
        else
        getSpace().addObject(new BT2_4(40, false, this, 270), getX()+10,getY()-10);
    }
    public void fireBullet()
    {
        Greenfoot.playSound("bullet1.wav");
        if (getWeaponLevel() == 0)
        {
            fireBT1(getX());
        }
        else if (getWeaponLevel() == 1)
        {
            fireBT1(getX()-1);
            fireBT1(getX()+1);
        }
        else if (getWeaponLevel() == 2)
        {
            fireBT1(getX()-5);
            fireBT1(getX()+5);
            fireBT1(getX());
        }
        else if (getWeaponLevel() >= 3 )
        {
            fireBT1(getX()-1);
            fireBT1(getX()+1);
            fireBT1(getX()-5);
            fireBT1(getX()+5);
        }
        if (getWeaponLevel() >= 4 && getWeaponLevel() < 6)
        {
            fireBT2(getX()+15);
            fireBT2_2(getX()-15);
        }
        if (getWeaponLevel() == 5 && getWeaponLevel() < 6)
        {
            fireBT2(getX()+10);
            fireBT2_2(getX()-10);
        }
        if (getWeaponLevel() == 6)
        {
            fireBT2_3(getX()+10);
            fireBT2_3(getX()+15);
            fireBT2_4(getX()-10);
            fireBT2_4(getX()-15);
        }
    }
}
