import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.awt.Color;
import java.awt.Font;
/**
 * Write a description of class KeyBackground here.
 * 
 * @author Anthony Hoang
 * @version (v1)
 */
public class KeyBackground  extends Keys
{
    private GreenfootImage img;
    public KeyBackground()
    {
        img = new GreenfootImage(880,494);
        img.setTransparency(0);
        img.setColor(Color.BLACK);
        img.fill();
        img.setColor(Color.WHITE);
        img.drawString("Click on the key to highlight and change controls.",15, 15);
        Font font = img.getFont();
        font = font.deriveFont(25f);
        img.setFont(font);
        img.drawString("Control Settings", 350,50);
        img.drawString("Move Left", 50, 100);
        img.drawString("Move Right", 350, 100);
        img.drawString("Interact/Use", 650 ,100);
        img.drawString("Jump", 250 ,350);
        img.drawString("Crouch", 550 ,350);
        img.drawString("Suit Power Key",380,242);
        setImage(img);
    }
    public void act() 
    {
        super.act();
    }    
}
