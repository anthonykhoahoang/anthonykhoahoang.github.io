import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)


/**
 * Savegame can save and load a game.
 * 
 * @author Anthony Hoang
 * @version 1.0
 */
public class SaveGame extends Actor
{
    String type;
    public SaveGame()
    {
    }
    public SaveGame(String str)
    {
        type = str;
        if (str.equals("load"))
        setImage("load.png");
        else
        setImage("save.png");
    }
    public void act() 
    {
        if (Greenfoot.mouseClicked(this) )
        {
            setImage("saveloaddone.png");
            if (type.equals("load"))
            {
                if (getSpace().loadSavedGame())
                getSpace().setSystemMessage("Your saved game has been loaded!");
                else
                getSpace().setSystemMessage("There is no saved game yet!");
            }
            if (type.equals("save"))
            {
                getSpace().saveGame();
                getSpace().setSystemMessage("Your game has been saved!");
            }
        }
        else
        {
            
            if (type.equals("load"))
            setImage("load.png");
            else
            setImage("save.png");
        }
    }    
    public Space getSpace() 
    {
        return (Space)getWorld();
    }
}
