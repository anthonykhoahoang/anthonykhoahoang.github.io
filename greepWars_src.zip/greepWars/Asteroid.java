import greenfoot.*;  // (World, Actor, GreenfootImage, and Greenfoot)

/**
 * A rock in space
 * 
 * @author Poul Henriksen
 */
public class Asteroid extends MovingThing
{
    /** Size of this asteroid */
    private int size;
    /** Whether is is exploded */
    private boolean exploded = false;
    /** When the health reaches 0 the asteroid will explode*/
    private int health;
    
    
    public Asteroid()
    {
        this(64);
    }
    
    public Asteroid(int size)
    {
        super(new Vector(Greenfoot.getRandomNumber(360), 2));
        setSize(size);
    }
    
    public Asteroid(int size, Vector speed)
    {
        super(speed);
        setSize(size);
    }
    
    public void act()
    {         
        //Space space = getSpace();
        //if(exploded) return;
        
        move();
    }

    public void setSize(int size) 
    {
        health = size;
        this.size = size;
        GreenfootImage image = new GreenfootImage("rock.gif");
        image.scale(size, size);
        setImage(image);
    }
    
    /**
     * Explodes this asteroid into two smaller asteroids
     */
    private void explode() 
    {
        Space space = getSpace();
        //if(exploded) return;
       // exploded = true;
        
        Greenfoot.playSound("Explosion.wav");
        if (randomChance(10))
        {
            space.addAlienShips(1);
        }
        if (randomChance(4))
        {   
            space.addUpgrades(1);
        }
        if(size <= 16) 
        {
            space.score(30);
            space.checkClear();
            health = size;
            space.removeObject(this);
            return;
        }
        
        int r = getSpeed().getDirection() + Greenfoot.getRandomNumber(45);
        double l = getSpeed().getLength();
        Vector speed1 = new Vector(r + 90, l * 1.2);
        Vector speed2 = new Vector(r - 90, l * 1.2);        
        Asteroid a1 = new Asteroid(size/2, speed1);        
        Asteroid a2 = new Asteroid(size/2, speed2);
        getWorld().addObject(a1, getX(), getY());
        ((Space) getWorld()).addEnemy();
        getWorld().addObject(a2, getX(), getY());
        ((Space) getWorld()).addEnemy();
        a1.move();
        a2.move();
    
        getSpace().score(10);
        health = size;
        getSpace().removeObject(this);
    }
    public void addAsteroid()
    {
        int r = getSpeed().getDirection() + Greenfoot.getRandomNumber(45);
        double l = getSpeed().getLength();
        Vector speed1 = new Vector(r + 90, l * 1.2);
        Vector speed2 = new Vector(r - 90, l * 1.2);  
        if (size == 64)
        {
            Asteroid a1 = null;
            Asteroid a2 = null;
            
            a1 = new Asteroid(size/2, speed1);
            a2 = new Asteroid(size/2, speed2);
            
            getWorld().addObject(a1, getX(), getY());
            getSpace().addEnemy();
            getWorld().addObject(a2, getX(), getY());
            getSpace().addEnemy();
            a1.setVector(speed1);
            a2.setVector(speed2);
            a1.move();
            a2.move();
        }
        else
        if (size == 32)
        {
            Asteroid a1 = null;
            Asteroid a2 = null;
            
            a1 = new Asteroid(size/2, speed1);            
            a2 = new Asteroid(size/2, speed2);
            
            getWorld().addObject(a1, getX(), getY());
            getSpace().addEnemy();
            getWorld().addObject(a2, getX(), getY());
            getSpace().addEnemy();
            a1.setVector(speed1);
            a2.setVector(speed2);
            a1.move();
            a2.move();
        }
    }
    /**
     * Hit this asteroid dealing the given amount of damage.
     */
    public void hit(int damage) 
    {
        //if(exploded) 
            //return;
        health = health - damage;
        if(health <= 0)
        {
            ((Space) getWorld()).removeEnemy();
            getSpace().checkClear();
            if (size == 64)
            getSpace().addAsteroidDestroyed();
            explode();  
            
        }
    }
    protected boolean randomChance(int percent)
    {
        return Greenfoot.getRandomNumber(100) < percent;
    }
    public Object clone()
    {
        try
       { return super.clone();
        }
        catch(Exception ex) {return null;}
        
    }
}