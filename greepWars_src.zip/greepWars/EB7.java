import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class EB7 here.
 * 
 * @author Anthony Hoang
 * @version 2.1
 */
public class EB7 extends EnemyBullet
{
    public EB7(int rotation, int life, boolean sounds, Enemy e)
    {
        super(rotation, life, 35, false, e);
        if (sounds)
        Greenfoot.playSound("bullet7.wav");
    }
}
