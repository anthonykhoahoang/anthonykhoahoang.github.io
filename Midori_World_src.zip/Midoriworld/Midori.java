import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.awt.Color;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
/**
 * Midori world.
 * 
 * @author Anthony Hoang
 * @version X
 */
public class Midori  extends World
{
    private MP3Player mp3MusicPlayer;
    private MP3Player mp3SoundPlayer;
    public int eventCount = 0;
    
    private String eventScript;
    
    private GreenfootImage RGBMap;
    
    public boolean esPause = false;
    public boolean gamePause = false;
    
    private String level;
    public int health = 100;
    public String left, left2, right, right2, jump, jump2, crouch, crouch2, use, suitpower;
    public int curPower = 1;
    
    public String curLoadGameCode;
    
    public Midori() 
    {    
        super(880, 494, 1); 
        performPaintOrder();
        performActOrder();
        getBackground().setColor(Color.BLACK);
        getBackground().fill();
        mp3MusicPlayer = new MP3Player();
        //mp3SoundPlayer = new MP3Player();
        addObject(mp3MusicPlayer,0,0);
        defaultKeys();;
        addEventScript("loadMainMenu.txt");
        addObject(new MenuMapLoader(), 0,0);
        //addEventScript("area_c/preLevelC");
    }
    public void addControlSettingsMenu()
    {
        addObject(new KeyBackground(), 440, 247);
        addObject(new LeftKey(),72,160);
        addObject(new LeftKey2(),190,160);
        addObject(new UseKey(), 717, 160);
        addObject(new RightKey2(), 491, 160);
        addObject(new RightKey(), 372, 160);
        addObject(new JumpKey2(), 356, 412);
        addObject(new JumpKey(), 239, 412);
        addObject(new CrouchKey2(), 676, 412);
        addObject(new CrouchKey(), 555, 412);
        addObject(new DefaultKey(), 766, 32);
        addObject(new KeyMenuReturn(), 769, 466);
        addObject(new SuitPowerKey(), 457,292);
    }
    public void defaultKeys()
    {
        left = "a"; left2 = "left"; right = "d"; 
        right2 = "right"; jump = "space"; jump2 = "up";
        crouch = "s"; crouch2 = "down"; use = "e";
        suitpower = "t";
    }
    public void act()
    {
        openMenu();
    }
    public void openMenu()
    {
        if (Greenfoot.isKeyDown("escape") && Greenfoot.isKeyDown("escape"))
        {
            List list = getObjects(ScreenFade.class);
            List list2 = getObjects(Menu.class);
            if (list.size()<=0 && list2.size()<=1)
            loadInGameMenu();
        }
    }
    public void stopped()
    {
        mp3MusicPlayer.pause();
    }
    public void started()
    {
        mp3MusicPlayer.resume();
    }
    public void addInGameCharacter(int x, int y)
    {
        addObject(new HealthBar(),15,247);
        addObject(new InGameCharacter(),x,y);
    }
    public void removeInGameObjects()
    {
        removeObjects(getObjects(InGameObjects.class));
    }
    public void setRGBMap(String file)
    {
        RGBMap = new GreenfootImage(file);
    }
    public void addNanoSuit(int n)
    {
        addObject(new NanoSuit(n),0,0);
        addObject(new NanoSuitIcon(),27,27);
        addObject(new EnergyBar(),154,15);
    }
    public void addMainBedRoom()
    {
        setBackground(new GreenfootImage("bedroom.jpg"));
    }
    public void addEventScript(String file)
    {
        addObject(new EventScript(file), 0, 0);
    }
    public void addKiraCharacter()
    {
        KiraCharacter character = new KiraCharacter();
        addObject(character, 310, 266);
        addObject(new KiraEyes(), 0, 0);
        addObject(new KiraMouth(), 0, 0);
        character.placeMouthEyes();
    }
    public void addKiraCharacter(int x, int y)
    {
        KiraCharacter character = new KiraCharacter();
        addObject(character, x, y);
        addObject(new KiraEyes(), 0, 0);
        addObject(new KiraMouth(), 0, 0);
        character.placeMouthEyes();
    }
    public void addEricCharacter()
    {
        EricCharacter character = new EricCharacter();
        addObject(character, 310, 315);
        addObject(new EricEyes(), 0, 0);
        addObject(new EricMouth(), 0, 0);
        character.placeMouthEyes();
    }
    public void addEricCharacter(int x, int y)
    {
        EricCharacter character = new EricCharacter();
        addObject(character, x, y);
        addObject(new EricEyes(), 0, 0);
        addObject(new EricMouth(), 0, 0);
        character.placeMouthEyes();
    }
    public void addMidoCharacter()
    {
        MidoCharacter character = new MidoCharacter();
        addObject(character, 310, 263);
        addObject(new MidoEyes(), 0, 0);
        addObject(new MidoMouth(), 0, 0);
        character.placeMouthEyes();
    }
    public void addMidoCharacter(int x, int y)
    {
        MidoCharacter character = new MidoCharacter();
        addObject(character, x, y);
        addObject(new MidoEyes(), 0, 0);
        addObject(new MidoMouth(), 0, 0);
        character.placeMouthEyes();
    }
    public void addScreenFade()
    {
        addObject(new ScreenFade(), 440, 247);
    }
    public void addScreenFadeType2()
    {
        addObject(new ScreenFadeType2(), 440, 247);
    }
    public void addSystemMessage(String file)
    {
        addObject(new SystemMessage(file), 440,200);
    }
    public void saveGame(String file) 
    {
    }
    public void loadGame(String file)
    {
    }
    public void playMP3Music(String file, boolean re)
    {
        mp3MusicPlayer.repeat(re);
        mp3MusicPlayer.playFile("music/"+file);
    }
    public void playSound(String file)
    {
        //mp.playFile("mp3sounds/"+file);
        mp3SoundPlayer.playFile("mp3sounds/"+file);
    }
    public void setRGBColorAt(int x, int y, Color col)
    {
        RGBMap.setColorAt(x,y,col);
    }
    public void setBackgroundColorAt(int x, int y, Color col)
    {
        getBackground().setColorAt(x,y,col);
    }
    public boolean isBlackAt(int x, int y)
    {
        if (x < 0) return false;
        if (y < 0) return false;
        if (y > getHeight()) return false;
        if (x > getWidth()) return false;
        return RGBMap.getColorAt(x,y).equals(Color.BLACK);
    }
    public boolean isGreenAt(int x, int y)
    {
        if (x < 0) return false;
        if (y < 0) return false;
        if (y > getHeight()) return false;
        if (x > getWidth()) return false;
        return RGBMap.getColorAt(x,y).equals(Color.GREEN);
    }
    public void drawBlackOnRGBMap(int x, int y, int w, int h)
    {
        int tX = x-w/2;
        int tY = y-h/2;
        RGBMap.setColor(Color.BLACK);
        RGBMap.fillRect(tX,tY,w,h);
    }
    public void drawWhiteOnRGBMap(int x, int y, int w, int h)
    {
        int tX = x-w/2;
        int tY = y-h/2;
        RGBMap.setColor(Color.WHITE);
        RGBMap.fillRect(tX,tY,w,h);
    }
    public void setCurrentEventScript(String str)
    {
        eventScript = str;
    }
    public void setLevel(String n)
    {
        level = n;
    }
    public void setupLGGame(String bg, String rgb, String ov)
    {
        setRGBMap(rgb);
        setBackground(bg);
        addObject(new LGEncryptedCode(),803,348);
        addObject(new BlueRay(),742,428);
        addObject(new BlueRay(),782,428);
        //addObject(new LGOverlay(new GreenfootImage(ov)),440,247);
        //addObject(new LGDisplay(d),394,19);
        addLGAdder();
    }
    public void addLGAdder()
    {
        addObject(new LGAdder("AND"),565,460);
        addObject(new LGAdder("NOT"),635,460);
        addObject(new LGAdder("NAND"),705,460);
        addObject(new LGAdder("OR"),775,460);
        addObject(new LGAdder("NOR"),845,460);
        addObject(new LGBackBar(),680,462);
    }
    public void loadMainMenu()
    {
        //setBackground("menubackground.jpg");
        addMenuProjectiles();
        addObject(new Title(), 880, 247);
        addObject(new NewGame(), 440, 247);
        addObject(new ControlSetting(), 442, 324);
        addObject(new LoadGame(), 441, 409);
    }
    public void loadInGameMenu()
    {
        gamePause = true;
        addObject(new MenuBackground(),440,247);
        addObject(new Title(), 880, 247);
        addObject(new NewGame(), 440, 247);
        addObject(new ControlSetting(), 442, 324);
        addObject(new LoadGame(), 441, 409);
        addObject(new ReturnToGame(esPause), 769, 466);
        esPause = true;
    }
    public String getCurrentEventScript()
    {
        return eventScript;
    }
    public String getLevel()
    {
        return level;
    }
    public void addMenuProjectiles()
    {
        addObject(new MenuTarget(), 440, 200);
        for (int i = 0; i < 5; i++)
        {
            int x = ((int)Math.random()*800);
            int y = ((int)Math.random()*400);
            addObject(new MenuProjectileGray(),x, y);
            addObject(new MenuProjectileBlue(),x, y);
        }
    }
    public void addQWERTYKeys()
    {
        addObject(new QWERTYKey("Q"),100, 315);
        addObject(new QWERTYKey("W"),155, 315);
        addObject(new QWERTYKey("E"),210, 315);
        addObject(new QWERTYKey("R"),265, 315);
        addObject(new QWERTYKey("T"),320, 315);
        addObject(new QWERTYKey("Y"),375, 315);
        addObject(new QWERTYKey("U"),430, 315);
        addObject(new QWERTYKey("I"),485, 315);
        addObject(new QWERTYKey("O"),540, 315);
        addObject(new QWERTYKey("P"),595, 315);
        addObject(new QWERTYKey("_"),650, 315);
        
        addObject(new QWERTYKey("A"),155, 380);
        addObject(new QWERTYKey("S"),210, 380);
        addObject(new QWERTYKey("D"),265, 380);
        addObject(new QWERTYKey("F"),320, 380);
        addObject(new QWERTYKey("G"),375, 380);
        addObject(new QWERTYKey("H"),430, 380);
        addObject(new QWERTYKey("J"),485, 380);
        addObject(new QWERTYKey("K"),540, 380);
        addObject(new QWERTYKey("L"),595, 380);
        
        addObject(new QWERTYKey("Z"),210, 445);
        addObject(new QWERTYKey("X"),265, 445);
        addObject(new QWERTYKey("C"),320, 445);
        addObject(new QWERTYKey("V"),375, 445);
        addObject(new QWERTYKey("B"),430, 445);
        addObject(new QWERTYKey("N"),485, 445);
        addObject(new QWERTYKey("M"),540, 445);
        
        addObject(new QWERTYKey("1"),725, 400);
        addObject(new QWERTYKey("2"),780, 400);
        addObject(new QWERTYKey("3"),835, 400);
        addObject(new QWERTYKey("4"),725, 335);
        addObject(new QWERTYKey("5"),780, 335);
        addObject(new QWERTYKey("6"),835, 335);
        addObject(new QWERTYKey("7"),725, 275);
        addObject(new QWERTYKey("8"),780, 275);
        addObject(new QWERTYKey("9"),835, 275);
        addObject(new QWERTYKey("0"),780, 210);
    }
    public void performPaintOrder()
    {
        setPaintOrder(
        ScreenFade.class, SystemMessage.class, Typer.class, 
        Menu.class,
        SkipButton.class, CharacterText.class, PhoneHolos.class,
        LGEncryptedCode.class,
        ScreenFadeType2.class,
        MapOverlay.class,CleanWeapon.class,
        HealthBar.class, EnergyBar.class,
        BossCounter.class,
        Particle.class, HostileProjectile.class,
        InGameCharacter.class, HelperBot.class,
        LGGates.class, LGAdder.class, 
        LGBackBar.class,
        CharacterFaceParts.class,
        Character.class);
    }
    public void performActOrder()
    {
        setActOrder(Typer.class,EventScript.class,
        Keys.class, InGameCharacter.class, Platform.class,
        EventCountAdder.class);
    }
}
