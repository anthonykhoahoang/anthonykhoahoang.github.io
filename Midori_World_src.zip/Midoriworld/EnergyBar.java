import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.awt.Color;
import java.awt.Font;
import java.util.List;
/**
 * Write a description of class HealthBar here.
 * 
 * @author Anthony Hoang
 * @version (v1)
 */
public class EnergyBar  extends InGameObjects
{
    private int tEnergy = 0;
    private GreenfootImage image;
    private boolean firstInitialize = true;
    private int delay = 2;
    public EnergyBar()
    {
        image = new GreenfootImage(200, 20);
        getImage().clear();
    }
    public void act() 
    {
        if (getMWorld().gamePause) return;
        if (firstInitialize)
        {
            firstInitialize = false;
            image.setColor(new Color(50,25,150,190));
            tEnergy = 0;
            image.fillRect(tEnergy,20,0,20);
            Font font = image.getFont();
            font = font.deriveFont(11f);
            image.setColor(Color.WHITE);
            image.drawString("Energy", 75, 10);
            setImage(image);
        }
        updateEnergy();
    }    
    public void updateEnergy()
    {
        List<NanoSuit> list = getMWorld().getObjects(NanoSuit.class);
        if (list.size() == 0) return;
        NanoSuit nanosuit = list.get(0);
        int energy = nanosuit.getEnergy();
        if (energy == tEnergy) return;
        if (energy > tEnergy)
        tEnergy++;
        else if (energy < tEnergy)
        tEnergy--;
        image.clear();
        if (nanosuit.getCurPower() == 0)
        image.setColor(Color.RED);
        else
        image.setColor(new Color(50,25,150,220));
        //image.fillRect(0,tEnergy,20,200);
        image.fillRect(0,0,tEnergy*2,20);
        Font font = image.getFont();
        font = font.deriveFont(11f);
        image.setFont(font);
        image.setColor(Color.WHITE);
        image.drawString("Energy:", 71, 13);
        int n = tEnergy;
        image.drawString(""+n+"%",110,13);
        setImage(image);
    }
}
