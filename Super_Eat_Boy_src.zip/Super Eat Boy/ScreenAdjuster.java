import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.util.ArrayList;
/**
 * Write a description of class ScreenAdjuster here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */


public class ScreenAdjuster  extends Actor
{
    private int screenWidth, screenHeight;
    private int speed = 4;
    private int buffer = 40;
    
    public ScreenAdjuster(int screenWidth, int screenHeight)
    {
        this.screenWidth = screenWidth;
        this.screenHeight = screenHeight;
        setImage(new GreenfootImage(1,1));
    }
    
    public void act() 
    {
        adjustScreen();
    }    
    
    public void adjustScreen()
    {
        ArrayList<EatBoy> listEatBoy = (ArrayList<EatBoy>) getWorld().getObjects(EatBoy.class);
        if (listEatBoy.size() > 0)
        {
            EatBoy eb = listEatBoy.get(0);
            int ebX = eb.getRealX();
            int ebY = eb.getRealY();
            int sX = getWorld().getSX();
            int sY = getWorld().getSY();
            getWorld().setScreenLocation(ebX - screenWidth/2, ebY - screenHeight/2);
            /*
            if (Math.abs(ebX-screenWidth/2-sX) > buffer)
            {
                if (ebX - screenWidth/2 > sX)
                    getWorld().setScreenLocation(sX + speed, sY);
                else
                    getWorld().setScreenLocation(sX - speed, sY);
            }
            
            if (Math.abs(ebY-screenHeight/2-sY) > buffer)
            {
                if (ebY - screenHeight/2 > sY)
                    getWorld().setScreenLocation(sX, sY + speed);
                else
                    getWorld().setScreenLocation(sX, sY - speed);
            }
            */
            //getWorld().setScreenLocation(ebX - screenWidth/2, ebY - screenHeight/2);
            
        }
    }
    
    public ScrollWorld getWorld()
    {
        return (ScrollWorld) super.getWorld();
    }
}
