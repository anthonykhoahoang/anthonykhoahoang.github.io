import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class MidoFaceParts here.
 * 
 * @author Anthony Hoang
 * @version 1
 */
public class MidoFaceParts  extends CharacterFaceParts
{
}
