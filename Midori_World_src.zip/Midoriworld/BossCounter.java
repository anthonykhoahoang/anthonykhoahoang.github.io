import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.util.List;
/**
 * Provides basic methods for counters of Boss class
 * 
 * @author Anthony Hoang
 * @version (v1)
 */
public class BossCounter  extends InGameObjects
{
    public void act() 
    {
    }    
    public Boss getBoss()
    {
        List<Boss> list = getMWorld().getObjects(Boss.class);
        if (list.size() == 0) return null;
        return list.get(0);
    } 
    public BossType1 getBossType1()
    {
        List<BossType1> list = getMWorld().getObjects(BossType1.class);
        if (list.size() == 0) return null;
        return list.get(0);
    }
}
