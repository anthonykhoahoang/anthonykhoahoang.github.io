import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.awt.Color;
import java.awt.Font;
/**
 * inserts space in display text
 * 
 * @author Anthony Hoang
 * @version 2.1
 */
public class SpaceKey extends Keyboard
{
    private GreenfootImage image;
    private int acts = 0;
    
    public SpaceKey()
    {
        image = new GreenfootImage(250, 30);
        image.setColor(new Color(255,255,255, 128));
        image.fillRect(0, 0, 250, 30);
        image.setColor(new Color(0, 0, 0, 128));
        image.fillRect(5, 5, 240, 20);
        Font font = new Font("Courier", image.getFont().getStyle(), image.getFont().getSize()) ;
        font = font.deriveFont(30f);
        image.setFont(font);
        image.setColor(Color.WHITE);
        image.drawString(" Space", 20, 25);
        setImage(image);
    }
    public void act() 
    {
        if (Greenfoot.mouseMoved(this))
        {
            image.setColor(Color.RED);
            image.drawString(" Space", 20, 25);
        }
        else
        {
            image.setColor(Color.WHITE);
            image.drawString(" Space", 20, 25);
        }
        if ( (Greenfoot.mouseClicked(this) || Greenfoot.isKeyDown("space")) && acts ==0 )
        {
            acts = -15;
            image.setColor(Color.RED);
            image.drawString(" Space", 20, 25);
            getSpace().keyBoardDisplay.add(" ");
        }
        if (acts != 0)
        acts++;
        setImage(image);
    }    
}
