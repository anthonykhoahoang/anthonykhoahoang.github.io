import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class rocketBooster here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class RocketBooster extends Actor
{
    private Rocket r;
    private GreenfootImage booster =  new GreenfootImage("rocket/rocketBooster.png");
    private GreenfootImage cur  = new GreenfootImage(1,1);
    public RocketBooster (Rocket rocket)
    {
        r = rocket;
        setImage(cur);
    }
    public void act() 
    {
        if (! r.isDead )
        {
        setLocation(r.getX(), r.getY());
        setRotation(r.getRotation());
        if (!((Space)getWorld()).twoP() )
        {
            if (Greenfoot.isKeyDown("up") || Greenfoot.isKeyDown("w") || Greenfoot.isKeyDown("down") || Greenfoot.isKeyDown("s") )
            setImage(booster);
            else
            setImage(cur);
        }
        else
        {
            if ( r instanceof Rocket1 )
            {
                if (Greenfoot.isKeyDown("up") || Greenfoot.isKeyDown("down") )
                setImage(booster);
                else
                setImage(cur);
            }
            else
            {
                if (Greenfoot.isKeyDown("w") || Greenfoot.isKeyDown("s" ) )
                setImage(booster);
                else
                setImage(cur);
            }
        }
    }
        //else
        //cur.clear();
        // Add your action code here.
    }    
}
