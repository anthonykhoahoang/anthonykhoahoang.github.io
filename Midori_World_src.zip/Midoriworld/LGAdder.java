import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class LGAdder here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class LGAdder  extends LogicGate
{
    private GreenfootImage[] images;
    private String type;
    public LGAdder(String type)
    {
        this.type = type;
        setImages();
    }
    public void setImages()
    {
        if (images == null)
        {
            images = new GreenfootImage[5];
            images[0] = new GreenfootImage("logicgates/gateadder/and.png");
            images[1] = new GreenfootImage("logicgates/gateadder/not.png");
            images[2] = new GreenfootImage("logicgates/gateadder/or.png");
            images[3] = new GreenfootImage("logicgates/gateadder/nand.png");
            images[4] = new GreenfootImage("logicgates/gateadder/nor.png");
        }
        if (type.equals("AND")) setImage(images[0]);
        if (type.equals("NOT")) setImage(images[1]);
        if (type.equals("OR")) setImage(images[2]);
        if (type.equals("NAND")) setImage(images[3]);
        if (type.equals("NOR")) setImage(images[4]);
    }
    public void act() 
    {
        if (getMWorld().esPause) return;
        checkClick();
    }    
    public void checkClick()
    {
        if (Greenfoot.mouseClicked(this))
        addGate();
    }
    public void addGate()
    {
        if (type.equals("AND"))
        getMWorld().addObject(new AndGate(),getX(),getY());
        else if (type.equals("NOT"))
        getMWorld().addObject(new NotGate(),getX(),getY());
        else if (type.equals("OR"))
        getMWorld().addObject(new OrGate(),getX(),getY());
        else if (type.equals("NAND"))
        getMWorld().addObject(new NandGate(),getX(),getY());
        else if (type.equals("NOR"))
        getMWorld().addObject(new NorGate(),getX(),getY());
    }
}
