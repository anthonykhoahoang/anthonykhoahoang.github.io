import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class MonsterAdder here.
 * 
 * @author Anthony Hoang
 * @version (v1)
 */
public class MonsterHole  extends InGameObjects
{
    private int r = 1;
    private boolean expand = true;
    private int range;
    public MonsterHole(int range)
    {
        this.range = range;
        setImage(new GreenfootImage(50,50));
    }
    public void act() 
    {
        if (getMWorld().esPause) return;
        if (r < getImage().getWidth() && expand)
        {
            r++;
            int n = getImage().getWidth()/2-r/2;
            getImage().fillOval(n,n,r,r);
            if (r >= getImage().getWidth())
            {
                expand = false;
                addMonster();
            }
        }
        if (r > 0 && !expand)
        {
            getImage().clear();
            r--;
            int n = getImage().getWidth()/2-r/2;
            getImage().fillOval(n,n,r,r);
            if (r <= 0)
            {
                getMWorld().removeObject(this);
            }
        }
    }    
    public void addMonster()
    {
        getMWorld().addObject(new LeftRightSludgeMonster(range),getX(),getY());
    }
}
