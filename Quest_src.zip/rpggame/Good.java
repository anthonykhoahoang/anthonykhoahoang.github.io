import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.awt.Color;
/**
 * Write a description of class Good here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Good extends Battle
{
    private int totalHP;
    private int curHP;
    private int totalMana;
    private int curMana;
    private int smokeDelay = 0;
    private int totalMP = 50;
    private int curMP = 50;
    
    private boolean isDefend = false;
    
    public Good(int hp, int mana)
    {
        totalHP = hp;
        curHP = hp;
        totalMana = mana;
        curMana = mana;
    }
    public void act() 
    {
        // Add your action code here.
    }    
    public void makeRunSmoke()
    {
        if (smokeDelay ==0)
        {
            getLand().addObject(new Smoke(), getX()-5,getY()+15);
            smokeDelay = -2;
        }
        if (smokeDelay < 0) smokeDelay++;
    }
    public void hit(int hp)
    {
        int d = hp;
        if (isDefend) d = d/2;
        curHP -= d;
        if (curHP < 0)
        curHP = 0;
        getLand().addObject(new HitText(d, Color.WHITE), getX()+Greenfoot.getRandomNumber(50),getY()+Greenfoot.getRandomNumber(10));
    }
    public void heal(int hp)
    {
        curHP += hp;
        if (curHP > totalHP)
        curHP = totalHP;
        
        //getLand().addObject(new ImageShrinker("Item/heal.png"), getX(), getY() );
        getLand().addObject(new ImageShrinker("Item/heal.png"), getX()+5, getY()-15 );
        getLand().addObject(new HitText(hp, Color.GREEN), getX()+Greenfoot.getRandomNumber(10), getY()-10 );
    }
    public void setTotalHP(int n)
    {   totalHP = n;    }
    public void setCurHP(int n)
    {   curHP = n;  }
    public void setTotalMana(int n)
    {   totalMana = n;  }
    public void setCurMana (int n)
    {   curMana = n;  }
    public int getTotalHP()
    {   return totalHP; }
    public int getCurHP()
    {   return curHP; }
    public int getTotalMana()
    { return totalMana;  }
    public int getCurMana()
    {   return curMana; }
    public boolean defending()
    {   return isDefend;    }
    public void setDefend(boolean b)
    {   isDefend = b;   }
    public int getTotalMP()
    {   return totalMP;     }
    public int getCurMP()
    {   return curMP;   }
    public void setCurMP(int n)
    {   curMP = n; if (curMP > totalMP) curMP = totalMP; }
    public boolean isDead()
    {   return curHP <= 0;  }
}
