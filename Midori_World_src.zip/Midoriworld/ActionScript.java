import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.io.BufferedReader;
import java.io.IOException; 
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URL;
import java.util.ArrayList;
import java.util.StringTokenizer;
import java.util.List;
import java.awt.Color;
/**
 * Action script class, executes actions for bosses/etc in accordingly
 * 
 * 
 * @author Anthony Hoang
 * @version v2
 */
public class ActionScript extends EventScript
{
    private ArrayList<String> actions;
    //private int index = 0;
    private String file;
    //private int count = -1;
    private InGameObjects obj;
    private int prevLoopIndex = -1;
    private int hpLim = -1;
    
    public ActionScript(){}
    public ActionScript (String File, InGameObjects o)
    {
        actions = new ArrayList<String>();
        file = "data/actionscript/"+File;
        
        if (!file.endsWith(".txt")) //error check
        file+= ".txt";
        
        loadFileToArray(file);
        getImage().clear();
        obj = o;
    }
    public void act() 
    {
        if (getMWorld().esPause) return;
        if (obj instanceof Boss && boss().isPaused()) return;
        if (prevLoopIndex != -1 && hpLim != -1)
        hpLoopCheck();
        checkForNextAction();
    }
    public void hpLoopCheck()
    {
        if (boss().getHP() < hpLim)
        {
            skipToWhileEnd();
            hpLim = -1;
            prevLoopIndex = -1;
        }
    }
    public void skipToWhileEnd()
    {
        while(!actions.get(index).equals("#COMMAND_WHILE_END"))
        index++;
        index++;
    }
    public void checkForNextAction()
    {
        if (index > actions.size()-1) 
            getMWorld().removeObject(this);
        else
            readAction(actions.get(index));
    }
    public void readAction(String str)
    {
        //System.out.println("Command: "+str);
        StringTokenizer st = new StringTokenizer(str);
        String action = "";
        if (st.hasMoreTokens())
        action = st.nextToken();
        ArrayList<String> parameter = new ArrayList<String>();
        while (st.hasMoreTokens())
        {
            parameter.add(st.nextToken());
        }
        execute(action, parameter);
    }
    public void execute(String tempAction, ArrayList<String> parameter)
    {
        if (tempAction == null) index++;
        else if (tempAction.equals("FIRE_SMALLRED_FOLLOW"))
        fireSmallRedFollow();
        else if (tempAction.equals("FIRE_SMALL_RED"))
        fireSmallRed(parameter);
        else if (tempAction.equals("FIRE_RED_FOLLOW"))
        fireRedFollow();
        else if (tempAction.equals("FIRE_RED"))
        fireRed(parameter);
        
        else if (tempAction.equals("RED_EXPLOSION"))
        redExplosion();
        else if (tempAction.equals("RED_EXPLOSION_AMOUNT"))
        redExplosionAmount(parameter);
        else if (tempAction.equals("RED_EXPLOSION_RANDOM"))
        redExplosionRandom();
        
        else if (tempAction.equals("SMALL_RED_EXPLOSION"))
        smallRedExplosion();
        else if (tempAction.equals("SMALL_RED_EXPLOSION_RANDOM"))
        smallRedExplosionRandom();
        else if (tempAction.equals("SMALL_RED_EXPLOSION_AMOUNT"))
        smallRedExplosionAmount(parameter);
        
        else if (tempAction.equals("ENERGY_DRAIN_EXPLOSION"))
        energyDrainExplosion();
        else if (tempAction.equals("ENERGY_DRAIN_EXPLOSION_AMOUNT"))
        energyDrainExplosionAmount(parameter);
        else if (tempAction.equals("ENERGY_DRAIN_EXPLOSION_RANDOM"))
        energyDrainExplosionRandom();

        else if (tempAction.equals("SET_MOVETO"))
        setMoveTo(parameter);
        else if (tempAction.equals("SET_HASHIT"))
        setHasHit(parameter);
        
        else if (tempAction.equals("#COMMAND_WHILE_HP_GREATER_THAN"))
        commandWhileHPGreaterThan(parameter);
        else if (tempAction.equals("#COMMAND_WHILE_END"))
        commandWhileEnd();
        
        else if (tempAction.equals("WAIT_COUNT"))
            waitCount(parameter);
        else if (tempAction.equals("ADD_KIRACAPSULE"))
            addKiraCapsule(parameter);
        
        else index++;
        
        /*
        else 
        {
            index++;
            //System.out.println("Command not found: "+tempEvent);
        }
        */
    }
    public void addKiraCapsule(ArrayList<String> parameter)
    {
        int x = boss().getX();
        int y = boss().getY();
        int dx = Integer.parseInt(parameter.get(0));
        int dy = Integer.parseInt(parameter.get(1));
        getMWorld().addObject(new KiraCapsule(dx,dy),x,y);
        index++;
    }
    public void setHasHit(ArrayList<String> parameter)
    {
        boolean b = parameter.get(0).equals("true");
        boss().setHasHit(b);
        index++;
    }
    public void setMoveTo(ArrayList<String> parameter)
    {
        int x = Integer.parseInt(parameter.get(0));
        int y = Integer.parseInt(parameter.get(1));
        boss().setMoveTo(x,y);
        index++;
    }
    public void commandWhileHPGreaterThan(ArrayList<String> parameter)
    {
        int hp = Integer.parseInt(parameter.get(0));
        if (boss().getHP() > hp)
        {
            prevLoopIndex = index;
            hpLim = hp;
        }
        else
        {
            prevLoopIndex = -1;
            hpLim = -1;
            skipToWhileEnd();
            return;
        }
        index++;
    }
    public void commandWhileEnd()
    {
        if (prevLoopIndex == -1)
        index++;
        else
        index = prevLoopIndex;
    }
    public void fireSmallRedFollow()
    {
        boss().fireSmallRed();
        index++;
    }
    public void fireSmallRed(ArrayList<String> parameter)
    {
        int r = Integer.parseInt(parameter.get(0));
        boss().fireSmallRed(r);
        index++;
    }
    public void fireRedFollow()
    {
        boss().fireRed();
        index++;
    }
    public void fireRed(ArrayList<String> parameter)
    {
        int r = Integer.parseInt(parameter.get(0));
        boss().fireRed(r);
        index++;
    }
    public void redExplosion()
    {
        boss().redExplosion();
        index++;
    }
    public void redExplosionRandom()
    {
        boss().redExplosionRandom();
        index++;
    }
    public void redExplosionAmount(ArrayList<String> parameter)
    {
        int amount = Integer.parseInt(parameter.get(0));
        boss().redExplosion(amount);
        index++;
    }
    
    public void smallRedExplosion()
    {
        boss().smallRedExplosion();
        index++;
    }
    public void smallRedExplosionRandom()
    {
        boss().smallRedExplosionRandom();
        index++;
    }
    public void smallRedExplosionAmount(ArrayList<String> parameter)
    {
        int amount = Integer.parseInt(parameter.get(0));
        boss().smallRedExplosion(amount);
        index++;
    }
    public void fireEnergySpike(ArrayList<String> parameter)
    {
        int r = Integer.parseInt(parameter.get(0));
        boss().fireEnergySpike(r);
        index++;
    }
    public void energyDrainExplosion()
    {
        boss().energyDrainExplosion();
        index++;
    }
    public void energyDrainExplosionRandom()
    {
        boss().energyDrainExplosionRandom();
        index++;
    }
    public void energyDrainExplosionAmount(ArrayList<String> parameter)
    {
        int amount = Integer.parseInt(parameter.get(0));
        boss().energyDrainExplosion(amount);
        index++;
    }
    public Boss boss()
    {
        return (Boss) obj;
    }
    ///*****////
    public void loadFileToArray(String textFileName)
    {
        StringBuffer sb = new StringBuffer();
        try{
            URL url = getClass().getClassLoader().getResource(textFileName);
            if(url == null)
            throw new IOException("File not found: " + textFileName);
            InputStream is = url.openStream();
            BufferedReader br = new BufferedReader(new InputStreamReader(is));
            String line = br.readLine(); 
            while(line != null)
            {
                //System.out.println("READ:" +line);
                if (line != null)
                actions.add(line);
                line = br.readLine();
            }
            is.close();
            br.close();
        }
        catch(Exception ex)
        { System.out.println("File not found");
            return ; }
    } 
    public Midori getMWorld()
    {
        return (Midori) getWorld();
    }
}