import greenfoot.*;  // (World, Actor, GreenfootImage, and Greenfoot)
import java.awt.Color;
import java.awt.Font;
/**
 * Systemmessage displays important system messages to you.
 * 
 * @author Anthony Hoang
 * @version 2.0
 */
public class SystemMessage extends Actor
{
    public static final float FONT_SIZE = 12.0f;
    public static final int WIDTH = 600;
    public static final int HEIGHT = 500;
    private String sysText;
    public SystemMessage()
    {

    }
    public SystemMessage( String txt)
    {
        display(txt, "SYS: ");
    }
    public void display(String str, String prefix)
    {
        GreenfootImage image = new GreenfootImage(700, 15);

        image.setColor(new Color(255,255,255, 128));
        image.fillRect(0, 0, WIDTH, HEIGHT);
        Font font = image.getFont();
        font = font.deriveFont(FONT_SIZE);
        image.setFont(font);
        image.setColor(Color.WHITE);
        image.drawString(prefix + str, 3, 12);
        setImage(image);
    }
}
