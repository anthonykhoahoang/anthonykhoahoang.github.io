import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * fires energy spike to r rotation
 * 
 * @author Anthony Hoang
 * @version (v1)
 */
public class EnergyOutPort  extends EnergyPort
{
    public boolean isDone = false;
    private int rotation;
    private boolean firstInitialize = true;
    private static GreenfootImage image1;
    private static GreenfootImage image2;
    private int delay;
    public EnergyOutPort(int r)
    {
        rotation = r;
        if (image1 == null)
        {
            image1 = new GreenfootImage("energyoutport.png");
            image2 = new GreenfootImage("energyoutport2.png");
        }
        delay = (int)(Math.random()*500);
        setImage(image2);
        
    }
    public void act() 
    {
        if (getMWorld().esPause)
        return;
        if (!isDone && delay <= 0)
        putOutEnergySpike();
        if (delay > 0) delay--;
        if (delay == 100)
        setImage(image2);
        
    }    
    public void done()
    {
        isDone = true;
    }
    public void putOutEnergySpike()
    {
        getMWorld().addObject(new EnergySpike(rotation),getX(),getY());
        delay = 300;
        Greenfoot.playSound("electricsound.wav");
        setImage(image1);
    }
}
