import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.awt.Color;
import java.awt.Font;
/**
 * Write a description of class ReturnToMainMenu here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class ReturnToMainMenu extends GameMode
{
    private GreenfootImage image;
    private int acts = 0;
    
    public ReturnToMainMenu()
    {
        image = new GreenfootImage(320, 30);
        image.setColor(new Color(255,255,255, 128));
        image.fillRect(0, 0, 320, 30);
        image.setColor(new Color(0, 0, 0, 128));
        image.fillRect(5, 5, 310, 20);
        Font font = new Font("Courier", image.getFont().getStyle(), image.getFont().getSize()) ;
        font = font.deriveFont(25f);
        image.setFont(font);
        image.setColor(Color.WHITE);
        image.drawString("Return to Main Menu", 20, 25);
        setImage(image);
    }
    public void act() 
    {
        if (Greenfoot.mouseMoved(this))
        {
            image.setColor(Color.RED);
            image.drawString("Return to Main Menu", 20, 25);
        }
        else
        {
            image.setColor(Color.WHITE);
            image.drawString("Return to Main Menu", 20, 25);
        }
        if ( Greenfoot.mouseClicked(this)  )
        {
            acts = -15;
            image.setColor(Color.RED);
            image.drawString("Return to Main Menu", 20, 25);
            getSpace().loadMainMenu();
        }
        if (acts != 0)
        acts++;
        setImage(image);
    }    
}
