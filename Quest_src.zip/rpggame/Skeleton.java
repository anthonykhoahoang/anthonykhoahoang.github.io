import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class SkeletonWarrior here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Skeleton extends Enemy
{
    /**
     * Act - do whatever the SkeletonWarrior wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
        if (getObjectsInRange(200, InGameChar.class).size() != 0)
        {
            
                getLand().addObject(new InstantText("zombie/encounter", 200, 12f), getX(), getY()-100);
                Greenfoot.delay(50);
                int n = getLand().charLevel;
                getLand().loadBattleType2();
                int delay = 500 - n*10;
                if (delay < 100) delay = 100;
                
            
                getLand().addObject(new SmallFireShard(), getX()+10, getY());
                getLand().addObject(new SmallFireShard(), getX()+10, getY());
                getLand().addObject(new Potion(), getX(), getY());
                
                getLand().addObject(new SkeletonWarrior(n*10-5*(n-3), 0, delay-Greenfoot.getRandomNumber(20), 3*n - 2*(n-1)), 728, 396);
                getLand().addObject(new SkeletonWarrior(n*10-5*(n-3), 0, delay-Greenfoot.getRandomNumber(20), 3*n - 2*(n-1)), 728, 293);
                
                getLand().addObject(new SkeletonMage(n*10-5*(n), 0, delay-Greenfoot.getRandomNumber(20), 3*n - 2*(n-5)  ) , 835, 252);
                getLand().addObject(new SkeletonMage(n*10-5*(n), 0, delay-Greenfoot.getRandomNumber(20), 3*n - 2*(n-5)), 835, 346);
                getLand().addObject(new SkeletonMage(n*10-5*(n), 0, delay-10, 3*n - 2*(n-5)), 835, 436);
                
                //getLand().curEXP += 10;
                getLand().removeObject(this);
        }      
    }    
}
