import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class LeftRightHoloImage here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class LeftRightHoloImage  extends HoloImage
{
    public LeftRightHoloImage(String pic)
    {
        super(pic);
    }
    public void act() 
    {
        moveRight();
        super.act();
    }    
    public void moveRight()
    {
        int x = getX()+1;
        if (x > getMWorld().getWidth()-1)
        remove();
        else
        setLocation(x,getY()); 
    }
}
