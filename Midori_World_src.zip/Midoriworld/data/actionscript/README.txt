	Action scripts are scripts for ingame characters such as bosses.
It extends eventscript, but it is not sugessted to use this as an eventscript.
Commands from eventscript may cause errors; use with caution.

Action List:

FIRE_SMALLRED_FOLLOW //BOSS-fireSmallRed()
FIRE_SMALLRED [int r] //BOSS-fireSmallRed(INT R)
FIRE_RED_FOLLOW //BOSS-fireRed()
FIRE_RED [int r] //BOSS-fireRed(INT R)
RED_EXPLOSION //BOSS-redExplosion()
RED_EXPLOSION_AMOUNT [int amount] //boss-redExplosion(int amount)
RED_EXPLOSION_RANDOM //boss-redExplosionRandom()
SMALL_RED_EXPLOSION //boss : smallRedExplosion()
SMALL_RED_EXPLOSION_RANDOM //smallRedExplosionRandom()
SMALL_RED_EXPLOSION_AMOUNT [int amount] //boss-smallRedExplosion(int amount)
FIRE_ENERGY_SPIKE [INT R] //boss-fireEnergySpike(int r)
ENERGY_DRAIN_EXPLOSION //boss - energyDrainExplosion()
ENERGY_DRAIN_EXPLOSION_AMOUNT [int amount] //boss - energyDrainExplosion(int n)
ENERGY_DRAIN_EXPLOSION_RANDOM //boss-energyDrainExplosionRandom()

ADD_KIRACAPSULE {INT DX, INT DY}

SET_HASHIT {boolean b}


SET_MOVETO [INT X, INT Y]

#COMMAND_WHILE_HP_GREATER_THAN [int HP]
#COMMAND_WHILE_END //ENDS while loop command




*WAIT_COUNT 


