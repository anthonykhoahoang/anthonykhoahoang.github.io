import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.util.List;
/**
 * Write a description of class LevelSwitch here.
 * 
 * @author Anthony Hoang
 * @version (v1)
 */
public class DoorSwitch  extends Switch
{
    private static GreenfootImage image1;
    private static GreenfootImage image2;
    private boolean hasSwitched;
    public DoorSwitch()
    {
        hasSwitched = false;
        if (image1 == null)
        {
            image1 = new GreenfootImage("switch1.png");
            image2 = new GreenfootImage(image1);
            image2.mirrorVertically();
        }
        setImage(image1);
    }
    public void act() 
    {
        if (getMWorld().esPause) return;
        if (!hasSwitched)
        {
            Actor a = getOneIntersectingObject(InGameCharacter.class);
            if (a != null && Greenfoot.isKeyDown(getMWorld().use)
            && Greenfoot.isKeyDown(getMWorld().use))
            {
                Greenfoot.playSound("latch.wav");
                hasSwitched = true;
                setImage(image2);
                List<InGameDoor> l = getMWorld().getObjects(InGameDoor.class);
                if (l.size()!=0)
                {
                    l.get(0).open();
                }
            }
        }
    }    
}