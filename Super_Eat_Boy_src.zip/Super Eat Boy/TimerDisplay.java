import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.awt.Color;
/**
 * Write a description of class TimerDisplay here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class TimerDisplay  extends Actor
{
    private Timer timer;
    
    public TimerDisplay(double minutes)
    {
        timer = new Timer(minutes, true);
        setImage(new GreenfootImage(200, 50));
        getImage().setFont(getImage().getFont().deriveFont(20f));
        getImage().setColor(Color.WHITE);
        getImage().drawString("Timer:", 0, 40);
    }
    
    public void act() 
    {
        getImage().clear();
        timer.updateTime();
        getImage().drawString(timer.toString(), 0, 40);
    }    
}
