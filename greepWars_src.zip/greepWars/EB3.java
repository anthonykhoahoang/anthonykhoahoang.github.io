import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class EB3 here.
 * 
 * @author Anthony Hoang
 * @version 2.1
 */
public class EB3 extends EnemyBullet
{
    public EB3(int rotation, int life, boolean sounds, Enemy e)
    {
        super(rotation, life, 15, false, e);
        if (sounds)
        Greenfoot.playSound("bullet3.wav");
    }
}
