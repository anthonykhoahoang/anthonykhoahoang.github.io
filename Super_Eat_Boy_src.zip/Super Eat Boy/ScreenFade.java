import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.awt.Color;
/**
 * black Fades in/out
 * 
 * @author Anthony Hoang 
 * @version 1
 */
public class ScreenFade  extends Actor
{
    private GreenfootImage img;
    public int currentFade;
    
    private int current;
    public int delay;
    private int increment = 4;
    public ScreenFade()
    {
        initialize();
        img = new GreenfootImage(880, 494);
        img.setColor(Color.BLACK);
        img.fill();
        img.setTransparency(0);
        setImage(img);
    }
    public void initialize()
    {
        delay = 0;
        currentFade = 0;
        current = 0;
        
    }
    public void act() 
    {
        delay++;
        if (img.getTransparency() >= 252 && currentFade == 0)
        {
            currentFade = 1;
            delay = -30;
           // current = 63;
        }
        else if (img.getTransparency() <= 0 && currentFade == 1)
        {
            getWorld().removeObject(this);
            return;
            //currentFade = 0;
            //current = 1;
        }
        if (delay > 0)
        {
            if (currentFade == 0)
            img.setTransparency(img.getTransparency()+increment);
            else
            img.setTransparency(img.getTransparency()-increment);
            delay = 0;
        }
    }    
    
    public ScrollWorld getWorld()
    {
        return (ScrollWorld) super.getWorld();
    }
}
