import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class BadFood here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class BadFood  extends ScrollActor
{
    //Direction facing: 0 = west, 1 = east
    private int direction = 1;
    
    //Fall variables
    private static GreenfootImage fallImg;
    private static double fallSpeedIncrement = 0.2;
    private double fallSpeed = 0.0;
    private boolean isFalling = false;
    
    //Current AIs: "Still", "BackAndForth"
    private String aiType = "Still";
    
    //BackAndForth AI variables
    private boolean goingLeft = true;
    
    //Run variables
    private int runSpeed = 2;
    
    private boolean active = true;
        
    public BadFood(int realX, int realY, String ai, int runSpeed)
    {
        super(realX, realY);
        aiType = ai;
        this.runSpeed = runSpeed;
    }
    
    public void act() 
    {
        super.act();
        if (active)
            aiAction();
    }
    
    public void setActive(boolean active)
    {
        this.active = active;
    }
    
    public boolean isActive()
    {
        return active;
    }
    
    private void aiAction()
    {
        if (aiType.equals("Still"))
            return;
        else if (aiType.equals("BackAndForth"))
        {
            if (goingLeft)
            {
                direction = 0;
                moveLeft();
                if (isWallToWest())
                    goingLeft = false;
            }
            else
            {
                direction = 1;
                moveRight();
                if (isWallToEast())
                    goingLeft = true;
            }
                
        }
    }
    public void die()
    {
    }
    
    private boolean isWallToEast()
    {
        int imgHeight = getImage().getHeight();
        int imgWidth = getImage().getWidth();
        return getWorld().isBlackAt(getRealX() + imgWidth/2, getRealY())
        || getWorld().isBlackAt(getRealX() + imgWidth/2, getRealY() - imgHeight/4);
    }
    
    private boolean isWallToWest()
    {
        int imgHeight = getImage().getHeight();
        int imgWidth = getImage().getWidth();
        return getWorld().isBlackAt(getRealX() - imgWidth/2, getRealY())
        || getWorld().isBlackAt(getRealX() - imgWidth/2, getRealY() - imgHeight/4);
    }
    
    private boolean isWallAbove()
    {
        int imgHeight = getImage().getHeight();
        int imgWidth = getImage().getWidth();
        return getWorld().isBlackAt(getRealX() + imgWidth/2, getRealY() - imgHeight/2)
        || getWorld().isBlackAt(getRealX() - imgWidth/2, getRealY() - imgHeight/2);
    }
    
    private boolean isWallWayAbove()
    {
        int imgHeight = getImage().getHeight();
        int imgWidth = getImage().getWidth();
        return getWorld().isBlackAt(getRealX() + imgWidth/2, getRealY() - 2*imgHeight)
        || getWorld().isBlackAt(getRealX() - imgWidth/2, getRealY() - 2*imgHeight);
    }
    
    private void checkFall()
    {
        int imgHeight = getImage().getHeight();
        int imgWidth = getImage().getWidth();
        isFalling = !isGroundBelow();
        
        if (isFalling)
        {
            fallSpeed += fallSpeedIncrement;
            int oldRealY = getRealY();
            while (!isGroundBelow() && getRealY() - oldRealY < fallSpeed)
                setRealLocation(getRealX(), getRealY() + 1);
        }
        else
        {
            fallSpeed = 0;
        }
    }
    
    private boolean isGroundBelow()
    {
        int imgHeight = getImage().getHeight();
        int imgWidth = getImage().getWidth();
        return getWorld().isBlackAt(getRealX(), getRealY() + imgHeight/2)
        || getWorld().isBlackAt(getRealX() + imgWidth/4, getRealY() + imgHeight/2) 
        || getWorld().isBlackAt(getRealX() - imgWidth/4, getRealY() + imgHeight/2);        
    }
    
    private void moveRight()
    {
        int oldRealX = getRealX();
        while (!isWallToEast() && getRealX() - oldRealX < runSpeed)
        {
            setRealLocation(getRealX() + 1, getRealY());
            if (!isFalling)
            {
                while (isGroundBelow())
                    setRealLocation(getRealX(), getRealY() - 1);
                if (!isGroundBelow())
                        setRealLocation(getRealX(), getRealY() + 1);
                if (!isFalling)
                {
                    int oldRealY = getRealY();
                    int imgHeight = getImage().getHeight();
                    while (!isGroundBelow() && getRealY() - oldRealY < imgHeight/16)
                        setRealLocation(getRealX(), getRealY() + 1);
                }
            }
            
        }
    }
    
    private void moveLeft()
    {
        int oldRealX = getRealX();
        while (!isWallToWest() && Math.abs(getRealX() - oldRealX) < runSpeed)
        {
            setRealLocation(getRealX() - 1, getRealY());
            if (!isFalling)
            {
                while (isGroundBelow())
                    setRealLocation(getRealX(), getRealY() - 1);
                if (!isGroundBelow())
                        setRealLocation(getRealX(), getRealY() + 1);
                if (!isFalling)
                {
                    int oldRealY = getRealY();
                    int imgHeight = getImage().getHeight();
                    while (!isGroundBelow() && getRealY() - oldRealY < imgHeight/16)
                        setRealLocation(getRealX(), getRealY() + 1);
                }
            }
        }
    }
    
    public int getDirection()
    {
        return direction;
    }
}
