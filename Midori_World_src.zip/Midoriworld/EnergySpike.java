import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.util.List;
/**
 * Write a description of class SmallBlueParticle here.
 * 
 * @author Anthony Hoang
 * @version v1
 */
public class EnergySpike  extends Particle
{
    private GreenfootImage img;
    private int transparency = 150;
    private int transReduce = 5;
    private boolean firstInitialize = true;
    private double x;
    private double y;
    private int r;
    private Vector v = new Vector();
    private boolean hasHit = false;
    private boolean stopAct = false;
    private EnergyOutPort eOut;
    public EnergySpike(int r)
    {
        this.r = r;
        img = new GreenfootImage("energySpike.png");
        setImage(img);
        //setImage(new GreenfootImage(img));
    }
    public void act() 
    {
        if (getMWorld().esPause) return;
        setRotation(getRotation()+10);
        if (stopAct) return;
        if (firstInitialize)
        {
            x = getX();
            y = getY();
            eOut = (EnergyOutPort)getOneIntersectingObject(EnergyOutPort.class);
            firstInitialize = false;
        }
        if (!hasHit)
        {
            checkHit();
            checkHit2();
        }
        if (!hasHit)
        move();
        else
        explode();
    }   
    public void stopAct()
    {
        stopAct = true;
        eOut.done();
    }
    public void checkNearEnergyInPort()
    {
        List<EnergyInPort> list = getObjectsInRange(100,EnergyInPort.class);
        if (list.size() > 0)
        return;
    }
    public void explode()
    {
        for (int i = 0; i < 10; i++)
        getMWorld().addObject(new SmallEnergySpike((int)(Math.random()*360)),getX(),getY());

        int w = getImage().getWidth();
        int h = getImage().getHeight();
        if (w <= 5 || h <= 5)
        getMWorld().removeObject(this);
        else
        getImage().scale(w-5, h-5);
    } 
    public void random()
    {
        v.add(new Vector((int)(Math.random()*360),Math.random()*.3));
        v.add(new Vector(270, .04));
    }
    public void move()
    {
        v.add(new Vector(r, .05));
        x+=v.getX();
        y+=v.getY();
        setLocation((int)x,(int)y);
    }
    public void checkHit()
    {
        List<Platform> list3 = getIntersectingObjects(Platform.class);
        if (list3.size() > 0)
        {
            hasHit = true; 
            return;
        }
        if (isBlackAt(getX(),getY()) )
        {
            hasHit = true;
            return;
        }
        List<InGameCharacter> list = getIntersectingObjects(InGameCharacter.class);
        List<HelperBot> list2 = getIntersectingObjects(HelperBot.class);
        if (list.size() > 0)
        {
            InGameCharacter c = list.get(0);
            if (Math.abs(c.getX()-getX()) < 10 && Math.abs(c.getY()-getY()) < 20)
            {
                hasHit = true;
                c.hit(10);
                Greenfoot.playSound("burn.wav");
            }
        }
        if (list2.size() > 0)
        {
            HelperBot c = list2.get(0);
            if (Math.abs(c.getX()-getX()) < 5 && Math.abs(c.getY()-getY()) < 5)
            {
                hasHit = true;
                c.hit();
            }
        }
    }
    public void checkHit2()
    {
        List<HostileProjectile> list = getIntersectingObjects(HostileProjectile.class);
        List<HostileEnemy> list2 = getIntersectingObjects(HostileEnemy.class);
        if (list.size() > 0)
        {
            HostileProjectile c = list.get(0);
            hasHit = true;
            c.hit();
        }
        if (list2.size() > 0)
        {
            HostileEnemy c = list2.get(0);
            hasHit = true;
            c.hit();
        }
        if (isBlackAt(getX(),getY()))
        hasHit = true;
    }
}
