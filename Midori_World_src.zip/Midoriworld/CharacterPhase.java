import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.util.List;
/**
 * Write a description of class CharacterPhase here.
 * 
 * @author Anthony Hoang
 * @version (v1)
 */
public class CharacterPhase  extends Particle
{
    private int transparency = 200;
    private int transReduce = 40;
    private boolean firstInitialize = true;
    public CharacterPhase()
    {
        getImage().clear();
    }
    public void act() 
    {
        if (getMWorld().esPause) return;
        if (firstInitialize)
        {
            List<InGameCharacter> list = getMWorld().getObjects(InGameCharacter.class);
            Actor a = list.get(0);
            setImage(new GreenfootImage(a.getImage()));
            getImage().setTransparency(transparency);
            firstInitialize = false;
        }
        else
        {
            transparency-=transReduce;
            if (transparency <= 0)
            {
                getWorld().removeObject(this);
            }
            else
            {
                getImage().setTransparency(transparency);
            }
        }
    }     
}
