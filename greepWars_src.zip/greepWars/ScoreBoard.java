import greenfoot.*;  // (World, Actor, GreenfootImage, and Greenfoot)
import java.awt.Color;
import java.awt.Font;
import java.util.Calendar;

/**
 * The ScoreBoard is used to display results on the screen. It can display some
 * text and several numbers.
 * 
 * @author M Kolling
 * @version 1.0
 */
public class ScoreBoard extends Actor
{
    public static final float FONT_SIZE = 48.0f;
    public static final int WIDTH = 700;
    public static final int HEIGHT = 500;
    
    /**
     * Create a score board for the final result.
     */
    public ScoreBoard(int score, int numG, int numA, int numS)
    {
        makeImage("Game Over", "Score: ", score, numG, numA, numS );
    }

    /**
     * Make the score board image.
     */
    private void makeImage(String title, String prefix, int score, int greeps, int asteroids, int ships)
    {
        GreenfootImage image = new GreenfootImage(WIDTH, HEIGHT);

        image.setColor(new Color(255,255,255, 128));
        image.fillRect(0, 0, WIDTH, HEIGHT);
        image.setColor(new Color(0, 0, 0, 128));
        image.fillRect(5, 5, WIDTH-10, HEIGHT-10);
        Font font = image.getFont();
        font = font.deriveFont(FONT_SIZE);
        image.setFont(font);
        image.setColor(Color.WHITE);
        image.drawString(title, 60, 100);
        image.drawString(prefix + score, 60, 175);
        image.drawString("Greeps killed: "+greeps, 60, 250);
        image.drawString("Asteroids destroyed: "+asteroids, 60, 325);
        image.drawString( "AlienShips destroyed: "+ships, 60, 400);
        setImage(image);
    }
    public Space getSpace() 
    {
        return (Space)getWorld();
    }
}
