import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class NandGate here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class NandGate  extends LGGates
{
    private static GreenfootImage img;
    public NandGate()
    {
        super("NAND");
        if (img == null)
        img = new GreenfootImage("logicgates/nand.png");
        setImage(img);
    }
    public void act() 
    {
        super.act();
    }    
}
