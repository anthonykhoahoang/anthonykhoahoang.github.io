import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class MagicAttacks here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class MagicAttacks extends Battle
{
    /**
     * Act - do whatever the MagicAttacks wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
        // Add your action code here.
    }    
    public Land getLand()
    {
        return (Land)getWorld();
    }
    public void move()
    {
        double angle = Math.toRadians( getRotation() );
        int x = (int) Math.round(getX() + Math.cos(angle) * getImage().getWidth());
        int y = (int) Math.round(getY() + Math.sin(angle) * getImage().getWidth());
        setLocation(x, y);
    }
}
