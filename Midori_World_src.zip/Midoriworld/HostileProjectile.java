import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.util.List;
/**
 * Write a description of class AttackingHostile here.
 * 
 * @author Anthony Hoang
 * @version (v1)
 */
public class HostileProjectile  extends InGameHostile
{
    public boolean hasHit = false;
    private int damage=10;
    public void act() 
    {
        if (getMWorld().esPause) return;
        if (!hasHit)
        checkHit();
    }    
    public void checkHit()
    {
        List<Platform> list3 = getIntersectingObjects(Platform.class);
        if (list3.size() > 0)
        {
            hasHit = true; 
            return;
        }
        if (isBlackAt(getX(),getY()) )
        {
            hasHit = true;
            return;
        }
        List<InGameCharacter> list = getIntersectingObjects(InGameCharacter.class);
        List<HelperBot> list2 = getIntersectingObjects(HelperBot.class);
        if (list.size() > 0)
        {
            InGameCharacter c = list.get(0);
            if (Math.abs(c.getX()-getX()) < 10 && Math.abs(c.getY()-getY()) < 20)
            {
                hasHit = true;
                c.hit(damage);
                Greenfoot.playSound("burn.wav");
            }
        }
        if (list2.size() > 0)
        {
            HelperBot c = list2.get(0);
            if (Math.abs(c.getX()-getX()) < 5 && Math.abs(c.getY()-getY()) < 5)
            {
                hasHit = true;
                c.hit();
            }
        }
    }
    public void hit()
    {
        hasHit = true;
    }
}
