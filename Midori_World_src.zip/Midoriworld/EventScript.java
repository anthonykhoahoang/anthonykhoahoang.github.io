import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.io.BufferedReader;
import java.io.IOException; 
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URL;
import java.util.ArrayList;
import java.util.StringTokenizer;
import java.util.List;
import java.awt.Color;
/**
 * Event script class, executes events in order
 * 
 * 
 * @author Anthony Hoang
 * @version v1
 */
public class EventScript extends Actor
{
    private ArrayList<String> events;
    public int index = 0;
    private String file;
    public int count = -1;
    public EventScript(){}
    public EventScript (String File)
    {
        events = new ArrayList<String>();
        file = "data/eventscript/"+File;
        
        if (!file.endsWith(".txt")) //error check
        file+= ".txt";
        
        loadFileToArray(file);
        getImage().clear();
    }
    public void act() 
    {
        if (getMWorld().gamePause) return;
        checkForNextEvent();
        //System.out.println(index);
    }
    public void checkForNextEvent()
    {
        if (index > events.size()-1) 
            getMWorld().removeObject(this);
        else
            readEvent(events.get(index));
    }
    public void readEvent(String str)
    {
        //System.out.println("Command: "+str);
        StringTokenizer st = new StringTokenizer(str);
        String event = "";
        if (st.hasMoreTokens())
        event = st.nextToken();
        ArrayList<String> parameter = new ArrayList<String>();
        while (st.hasMoreTokens())
        {
            parameter.add(st.nextToken());
        }
        execute(event, parameter);
    }
    public void skip()
    {
        while (!events.get(index).equals("#COMMAND_SKIP_END"))
        index++;
    }
    public void execute(String tempEvent, ArrayList<String> parameter)
    {
        if (tempEvent == null) index++;
        else if (tempEvent.equals("REMOVE_CHARACTER"))
            removeCharacter();
        else if (tempEvent.equals("REMOVE_MENUOBJECTS"))
            removeMenuObjects();
        else if (tempEvent.equals("REMOVE_PARTICLES"))
            removeParticles();
        else if (tempEvent.equals("REMOVE_INGAME_OBJECTS"))
            removeInGameObjects();
        else if (tempEvent.equals("REMOVE_CHARACTER_TEXT"))
            removeCharacterText();
        else if (tempEvent.equals("REMOVE_PHONEHOLOS"))
            removePhoneHolos();
        else if (tempEvent.equals("REMOVE_HOLOMAP"))
            removeHoloMap();
        else if (tempEvent.equals("REMOVE_HOLOCIRCLE"))
            removeHoloCircle();
        else if (tempEvent.equals("REMOVE_EVENTSCRIPT"))
            removeEventScript();
        else if (tempEvent.equals("REMOVE_MAPOVERLAY"))
            removeMapOverlay();
        else if (tempEvent.equals("REMOVE_HOLOIMAGE"))
            removeHoloImage();
            
        else if (tempEvent.equals("WAIT_FOR_SCREENFADE"))
            waitForScreenFade(parameter);
        else if (tempEvent.equals("WAIT_FOR_SCREENFADE_ADD_EVENT_COUNT"))
            waitForScreenFadeAddEventCount(parameter);
        else if (tempEvent.equals("WAIT_FOR_CHARACTERTEXT"))
            waitForCharacterText();
        else if (tempEvent.equals("WAIT_FOR_CHARACTERTEXT_ADD_EVENT_COUNT"))
            waitForCharacterTextAddEventCount();
        else if (tempEvent.equals("WAIT_FOR_EVENT_COUNT")) 
            waitForEventCount(parameter);
        else if (tempEvent.equals("WAIT_COUNT"))
            waitCount(parameter);
  
        else if (tempEvent.equals("ADD_EVENT_COUNT"))
            addEventCount();
        else if (tempEvent.equals("ADD_EVENT_SCRIPT"))
            addEventScript(parameter);
        else if (tempEvent.equals("ADD_SCREENFADE"))
            addScreenFade();
        else if (tempEvent.equals("ADD_MIDO_CHARACTER"))
            addMidoCharacter();
        else if (tempEvent.equals("ADD_MIDO_CHARACTER_WITH_LOC"))
            addMidoCharacterWithLoc(parameter);
        else if (tempEvent.equals("ADD_MAINBEDROOM"))
            addMainBedRoom();
        else if (tempEvent.equals("ADD_TYPER"))
            addTyper();
        else if (tempEvent.equals("ADD_SYSTEM_MESSAGE"))
            addSystemMessage(parameter);
        else if (tempEvent.equals("ADD_BOUNCY_PLATFORM"))
            addBouncyPlatform(parameter);
        else if (tempEvent.equals("ADD_LEFT_RIGHT_PLATFORM"))
            addLeftRightPlatform(parameter);
        else if (tempEvent.equals("ADD_UP_DOWN_PLATFORM"))
            addUpDownPlatform(parameter);
        else if (tempEvent.equals("ADD_SIN_PLATFORM"))
            addSinPlatform(parameter);
        else if (tempEvent.equals("ADD_CIRCLE_PLATFORM"))
            addCirclePlatform(parameter);
        else if (tempEvent.equals("ADD_FALL_PLATFORM"))
            addFallPlatform(parameter);
        else if (tempEvent.equals("ADD_MIDOTEXT"))
            addMidoText(parameter);
        else if (tempEvent.equals("ADD_INGAME_CHARACTER"))
            addInGameCharacter(parameter);
        else if (tempEvent.equals("ADD_INGAME_DOOR"))
            addInGameDoor(parameter);
        else if (tempEvent.equals("ADD_INGAME_DOORSWITCH"))
            addInGameDoorSwitch(parameter);
        else if (tempEvent.equals("ADD_LEFT_TO_RIGHT_PICTURE"))
            addLeftToRightPicture(parameter);
        else if (tempEvent.equals("ADD_ECADD_QUESTIONMARK"))
            addECAddQuestionMark(parameter);
        else if (tempEvent.equals("ADD_PHONEHOLOLOAD"))
            addPhoneHoloLoad(parameter);
        else if (tempEvent.equals("ADD_PHONEGRAYSCREEN"))
            addPhoneGrayScreen();
        else if (tempEvent.equals("ADD_ERICHOLO"))
            addEricHolo(parameter);
        else if (tempEvent.equals("ADD_BLUERAY"))
            addBlueRay(parameter);
        else if (tempEvent.equals("ADD_GREENRAY"))
            addGreenRay(parameter);
        else if (tempEvent.equals("ADD_PHONE_BUTTON"))
            addPhoneButton();
        else if (tempEvent.equals("ADD_ERICTEXT"))
            addEricText(parameter);
        else if (tempEvent.equals("ADD_HOLOMAP"))
            addHoloMap(parameter);
        else if (tempEvent.equals("ADD_HOLOCIRCLE"))
            addHoloCircle(parameter);
        else if (tempEvent.equals("ADD_GAMEOVER"))
            addGameOver();
        else if (tempEvent.equals("ADD_LEFT_RIGHT_SLUDGE_MONSTER"))
            addLeftRightSludgeMonster(parameter);
        else if (tempEvent.equals("ADD_MONSTERHOLE"))
            addMonsterHole(parameter);
        else if (tempEvent.equals("ADD_LATCH"))
            addLatch(parameter);
        else if (tempEvent.equals("ADD_LATCHSWITCH"))
            addLatchSwitch(parameter);
        else if (tempEvent.equals("ADD_MENU_PROJECTILES"))
            addMenuProjectiles();
        else if (tempEvent.equals("ADD_ENERGYOUTPORT"))
            addEnergyOutPort(parameter);
        else if (tempEvent.equals("ADD_ENERGYINPORT"))
            addEnergyInPort(parameter);
        else if (tempEvent.equals("ADD_ENERGYPORTCHECKER"))
            addEnergyPortChecker();
        else if (tempEvent.equals("ADD_ICEOVERLAY"))
            addIceOverlay();
        else if (tempEvent.equals("ADD_HEALINGAREA"))
            addHealingArea(parameter);
        else if (tempEvent.equals("ADD_SCREENFADETYPE2"))
            addScreenFadeType2();
        else if (tempEvent.equals("ADD_INGAMETARGET"))
            addInGameTarget();
        else if (tempEvent.equals("ADD_REDLIGHTFLASHER"))
            addRedLightFlasher(parameter);
        else if (tempEvent.equals("ADD_ERIC_CHARACTER"))
            addEricCharacter();
        else if (tempEvent.equals("ADD_ERIC_CHARACTER_WITH_LOC"))
            addEricCharacterWithLoc(parameter);
        else if (tempEvent.equals("ADD_KIRA_CHARACTER"))
            addKiraCharacter();
        else if (tempEvent.equals("ADD_KIRA_CHARACTER_WITH_LOC"))
            addKiraCharacterWithLoc(parameter);
        else if (tempEvent.equals("ADD_KIRATEXT"))
            addKiraText(parameter);
        else if (tempEvent.equals("ADD_NANOSUIT"))
            addNanoSuit(parameter);
        else if (tempEvent.equals("ADD_HANG_SLUDGE_MONSTER"))
            addHangSludgeMonster(parameter);
        else if (tempEvent.equals("ADD_HANG_SLUDGE_MONSTER_TYPE2"))
            addHangSludgeMonsterType2(parameter);
        else if (tempEvent.equals("ADD_DEACTIVATEDBOT"))
            addDeactivatedBot(parameter);
        else if (tempEvent.equals("ADD_ECSWITCH"))
            addECSwitch(parameter);
        else if (tempEvent.equals("ADD_ENERGYDRAINPORT"))
            addEnergyDrainPort(parameter);
        else if (tempEvent.equals("ADD_BOTHOLE"))
            addBotHole(parameter);
        else if (tempEvent.equals("ADD_BOTRELEASELATCH"))
            addBotReleaseLatch(parameter);
        else if (tempEvent.equals("ADD_SKIPBUTTON"))
            addSkipButton();
        else if (tempEvent.equals("ADD_LGGATECHECKER"))
            addLGGateChecker(parameter);
        else if (tempEvent.equals("ADD_LGGAMECHECK"))
            addLGGameCheck(parameter);
        else if (tempEvent.equals("ADD_LGFILLER"))
            addLGFiller(parameter);
        else if (tempEvent.equals("ADD_LGDISPLAY"))
            addLGDisplay(parameter);
        else if (tempEvent.equals("ADD_BOSSTYPE1"))
            addBossType1(parameter);
        else if (tempEvent.equals("ADD_HOLOIMAGE"))
            addHoloImage(parameter);
        else if (tempEvent.equals("ADD_HOLOIMAGE_RIGHTLEFT"))
            addHoloImageRightLeft(parameter);
        else if (tempEvent.equals("ADD_HOLOIMAGE_LEFTRIGHT"))
            addHoloImageLeftRight(parameter);
        else if (tempEvent.equals("ADD_HOLOTEXTIMAGE"))
            addHoloTextImage(parameter);
            
        else if (tempEvent.equals("PLAY_MP3_SOUND"))
            playMP3Sound(parameter);
        else if (tempEvent.equals("PLAY_MP3_MUSIC"))
            playMP3Music(parameter);
        else if (tempEvent.equals("PLAY_WAVE_SOUND"))
            playWaveSound(parameter);
        
        else if (tempEvent.equals("STOP_MP3_MUSIC"))
            stopMP3Music();
            
        else if (tempEvent.equals("SET_CURRENT_EVENT_SCRIPT"))
            setCurrentEventScript(parameter);
        else if (tempEvent.equals("SET_LEVEL"))
            setLevel(parameter);
        else if (tempEvent.equals("SET_ES_UNPAUSE"))
            setEsUnpause();
        else if (tempEvent.equals("SET_ES_PAUSE"))
            setEsPause();
        else if (tempEvent.equals("SET_BACKGROUND"))
            setBackground(parameter);
        else if (tempEvent.equals("SET_BACKGROUND_BLACK"))
            setBackgroundBlack();
        else if (tempEvent.equals("SET_HEALTH"))
            setHealth(parameter);
        else if (tempEvent.equals("SET_EVENT_COUNT"))
            setEventCount(parameter); 
        else if (tempEvent.equals("SETUP_LGGAME"))
            setupLGGame(parameter);
        else if (tempEvent.equals("SET_LOADGAMECODE"))
            setLoadGameCode(parameter);
            
            
        else if (tempEvent.equals("CLEAR_BACKGROUND"))
            clearBackground();
        
        else if (tempEvent.equals("LOAD_MAP"))
            loadMap(parameter);
        else if (tempEvent.equals("LOAD_PREVIOUS_EVENTSCRIPT"))
            loadPreviousEventScript();
        else if (tempEvent.equals("LOAD_MAIN_MENU"))
            loadMainMenu();
            
        else if (tempEvent.equals("#COMMAND_EXEC_ALL"))
            commandExecAll();
        else if (tempEvent.equals("#COMMAND_SKIP_END"))
            commandSkipEnd();
        
        else 
        {
            index++;
            //System.out.println("Command not found: "+tempEvent);
        }//events.remove(0);
    }
    public void setLoadGameCode(ArrayList<String> parameter)
    {
        getMWorld().curLoadGameCode = parameter.get(0);
        index++;
    }
    public void addHoloTextImage(ArrayList<String> parameter)
    {
        String f = parameter.get(0);
        int x = Integer.parseInt(parameter.get(1));
        int y = Integer.parseInt(parameter.get(2));
        getMWorld().addObject(new HoloTextImage(f),x,y);
        index++;
    }
    public void removeHoloImage()
    {
        List<HoloImage> list = getMWorld().getObjects(HoloImage.class);
        for (HoloImage h : list) 
        h.remove();
        index++;
    }
    public void addHoloImage(ArrayList<String> parameter)
    {
        String f = parameter.get(0);
        int x = Integer.parseInt(parameter.get(1));
        int y = Integer.parseInt(parameter.get(2));
        getMWorld().addObject(new HoloImage(f),x,y);
        index++;
    }
    public void addHoloImageRightLeft(ArrayList<String> parameter)
    {
        String f = parameter.get(0);
        int x = Integer.parseInt(parameter.get(1));
        int y = Integer.parseInt(parameter.get(2));
        getMWorld().addObject(new RightLeftHoloImage(f),x,y);
        index++;
    }
    public void addHoloImageLeftRight(ArrayList<String> parameter)
    {
        String f = parameter.get(0);
        int x = Integer.parseInt(parameter.get(1));
        int y = Integer.parseInt(parameter.get(2));
        getMWorld().addObject(new LeftRightHoloImage(f),x,y);
        index++;
    }
    public void addBossType1(ArrayList<String> parameter)
    {
        int hp = Integer.parseInt(parameter.get(0));
        String ac = parameter.get(1);
        double dd = Double.parseDouble(parameter.get(2));
        double rr = Double.parseDouble(parameter.get(3));
        int x = Integer.parseInt(parameter.get(4));
        int y = Integer.parseInt(parameter.get(5));
        getMWorld().addObject(new BossType1(hp,ac,dd,rr),x,y);
        index++;
    }
    public void addLGDisplay(ArrayList<String> parameter)
    {
        getMWorld().addObject(new LGDisplay(parameter.get(0)),460,19);
        getMWorld().addObject(new LGDoneButton(),54,38);
        index++;
    }
    public void setupLGGame(ArrayList<String> parameter)
    {
        String bg = "lgmaps/"+parameter.get(0);
        String rgb = "lgmaps/"+parameter.get(1);
        String ov = "lgmaps/"+parameter.get(2);
        getMWorld().setupLGGame(bg,rgb,ov);
        index++;
    }
    public void addLGFiller(ArrayList<String> parameter)
    {
        int d = Integer.parseInt(parameter.get(0));
        getMWorld().addObject(new LGFiller(d),0,0);
        index++;
    }
    public void addLGGameCheck(ArrayList<String> parameter)
    {
        int x = Integer.parseInt(parameter.get(0));
        int y = Integer.parseInt(parameter.get(1));
        getMWorld().addObject(new LGGameCheck(),x,y);
        index++;       
    }
    public void addLGGateChecker(ArrayList<String> parameter)
    {
        String type = parameter.get(0);
        int x = Integer.parseInt(parameter.get(1));
        int y = Integer.parseInt(parameter.get(2));
        getMWorld().addObject(new LGGateChecker(type),x,y);
        index++;
    }
    public void removeMapOverlay()
    {
        List<MapOverlay> list = getMWorld().getObjects(MapOverlay.class);
        for (MapOverlay mo : list)
        mo.close();
        index++;
    }
    public void addSkipButton()
    {
        getMWorld().addObject(new SkipButton(this),831,28);
        index++;
    }
    public void commandSkipEnd()
    {
        getMWorld().removeObjects(getMWorld().getObjects(SkipButton.class));
        List<CharacterText> list = getMWorld().getObjects(CharacterText.class);
        for (CharacterText c : list)
        c.close();
        /*
        List<PhoneHolos> list2 = getMWorld().getObjects(PhoneHolos.class);
        for (PhoneHolos p : list2)
        p.remove();
        getMWorld().eventCount = 0;
        */
        index++;
    }
    public void addBotReleaseLatch(ArrayList<String> parameter)
    {
        int r = Integer.parseInt(parameter.get(0));
        int d = Integer.parseInt(parameter.get(1));
        int x = Integer.parseInt(parameter.get(2));
        int y = Integer.parseInt(parameter.get(3));
        int size = (parameter.size()-4)/2;
        int aX[] = new int[size];
        int aY[] = new int[size];
        int index2 = 0;
        for (int i = 4; i < parameter.size(); i+=2)
        {
            aX[index2] = Integer.parseInt(parameter.get(i));
            aY[index2] = Integer.parseInt(parameter.get(i+1));
            index2++;
        }
        getMWorld().addObject(new BotReleaseSwitch(r,d,aX,aY),x,y);
        index++;
    }
    public void addBotHole(ArrayList<String> parameter)
    {
        int r = Integer.parseInt(parameter.get(0));
        int x = Integer.parseInt(parameter.get(1));
        int y = Integer.parseInt(parameter.get(2));
        getMWorld().addObject(new BotHole(r),x,y);
        index++;
    }
    public void removeEventScript()
    {
        getMWorld().removeObjects(getMWorld().getObjects(EventScript.class));
        index++;
    }
    public void setEventCount(ArrayList<String> parameter)
    {
        int n = Integer.parseInt(parameter.get(0));
        getMWorld().eventCount = n;
        index++;
    }
    public void addEnergyDrainPort(ArrayList<String> parameter)
    {
        int n = Integer.parseInt(parameter.get(0));
        int x = Integer.parseInt(parameter.get(1));
        int y = Integer.parseInt(parameter.get(2));
        getMWorld().addObject(new EnergyDrainPort(n),x,y);
        index++;
    }
    public void addECSwitch(ArrayList<String> parameter)
    {
        int x = Integer.parseInt(parameter.get(0));
        int y = Integer.parseInt(parameter.get(1));
        getMWorld().addObject(new ECSwitch(),x,y);
        index++;
    }
    public void addDeactivatedBot(ArrayList<String> parameter)
    {
        boolean f = parameter.get(0).equals("true");
        int t = Integer.parseInt(parameter.get(1));
        int r = Integer.parseInt(parameter.get(2));
        int x = Integer.parseInt(parameter.get(3));
        int y = Integer.parseInt(parameter.get(4));
        getMWorld().addObject(new DeactivatedBot(f,t,r),x,y);
        index++;
    }
    public void addHangSludgeMonster(ArrayList<String> parameter)
    {
        int r = Integer.parseInt(parameter.get(0));
        int x = Integer.parseInt(parameter.get(1));
        int y = Integer.parseInt(parameter.get(2));
        getMWorld().addObject(new HangSludgeMonster(r),x,y);
        index++;
    }
    public void addHangSludgeMonsterType2(ArrayList<String> parameter)
    {
        int r = Integer.parseInt(parameter.get(0));
        int x = Integer.parseInt(parameter.get(1));
        int y = Integer.parseInt(parameter.get(2));
        getMWorld().addObject(new HangSludgeMonsterType2(r),x,y);
        index++;
    }
    public void addNanoSuit(ArrayList<String> parameter)
    {
        int n = Integer.parseInt(parameter.get(0));
        getMWorld().addNanoSuit(n);
        index++;
    }
    public void addEricCharacter()
    {
        getMWorld().addEricCharacter();
        index++;
    }
    public void addEricCharacterWithLoc(ArrayList<String> parameter)
    {
        int x = Integer.parseInt(parameter.get(0));
        int y = Integer.parseInt(parameter.get(1));
        getMWorld().addEricCharacter(x,y);
        index++;
    }
    public void addKiraCharacter()
    {
        getMWorld().addKiraCharacter();
        index++;
    }
    public void addKiraCharacterWithLoc(ArrayList<String> parameter)
    {
        int x = Integer.parseInt(parameter.get(0));
        int y = Integer.parseInt(parameter.get(1));
        getMWorld().addKiraCharacter(x,y);
        index++;
    }
    public void commandExecAll()
    {
        index++;
        while (!events.get(index).equals("#COMMAND_EXEC_END"))
        {
            checkForNextEvent();
        }
        index++;
    }
    public void addRedLightFlasher(ArrayList<String> parameter)
    {
        int x = Integer.parseInt(parameter.get(0));
        int y = Integer.parseInt(parameter.get(1));
        getMWorld().addObject(new RedLightFlasher(),x,y);
        index++;
    }
    public void addInGameTarget()
    {
        getMWorld().addObject(new InGameTarget(),440,247);
        index++;
    }
    public void addHealingArea(ArrayList<String> parameter)
    {
        int w = Integer.parseInt(parameter.get(0));
        int h = Integer.parseInt(parameter.get(1));
        int x = Integer.parseInt(parameter.get(2));
        int y = Integer.parseInt(parameter.get(3));
        getMWorld().addObject(new HealingArea(w,h),x,y);
        index++;
    }
    public void addIceOverlay()
    {
        getMWorld().addObject(new IceOverlay(), 440, 247);
        index++;
    }
    public void addEnergyPortChecker()
    {
        getMWorld().addObject(new EnergyPortChecker(),0,0);
        index++;
    }
    public void addEnergyInPort(ArrayList<String> parameter)
    {
        int r = Integer.parseInt(parameter.get(0));
        int x = Integer.parseInt(parameter.get(1));
        int y = Integer.parseInt(parameter.get(2));
        getMWorld().addObject(new EnergyInPort(r),x,y);
        index++;
    }
    public void addEnergyOutPort(ArrayList<String> parameter)
    {
        int r = Integer.parseInt(parameter.get(0));
        int x = Integer.parseInt(parameter.get(1));
        int y = Integer.parseInt(parameter.get(2));
        getMWorld().addObject(new EnergyOutPort(r),x,y);
        index++;
    }
    public void addLatch(ArrayList<String> parameter)
    {
        int w = Integer.parseInt(parameter.get(0));
        int h = Integer.parseInt(parameter.get(1));
        String id = parameter.get(2);
        boolean closed = parameter.get(3).equals("true");
        int x = Integer.parseInt(parameter.get(4));
        int y = Integer.parseInt(parameter.get(5));
        getMWorld().addObject(new Latch(w,h,id,closed),x,y);
        index++;
    }
    public void addLatchSwitch(ArrayList<String> parameter)
    {
        int x = Integer.parseInt(parameter.get(0));
        int y = Integer.parseInt(parameter.get(1));
        ArrayList<String> latches = new ArrayList<String>();
        for (int i = 2; i < parameter.size(); i++)
        latches.add(new String(parameter.get(i)));
        getMWorld().addObject(new LatchSwitch(latches),x,y);
        index++;
        
    }
    public void addLeftRightSludgeMonster(ArrayList<String> parameter)
    {
        int r = Integer.parseInt(parameter.get(0));
        int x = Integer.parseInt(parameter.get(1));
        int y = Integer.parseInt(parameter.get(2));
        getMWorld().addObject(new LeftRightSludgeMonster(r),x,y);
        index++;
    }
    public void addMonsterHole(ArrayList<String> parameter)
    {
        int r = Integer.parseInt(parameter.get(0));
        int x = Integer.parseInt(parameter.get(1));
        int y = Integer.parseInt(parameter.get(2));
        getMWorld().addObject(new MonsterHole(r),x,y);
        index++;
    }
    public void setHealth(ArrayList<String> parameter)
    {
        int n = Integer.parseInt(parameter.get(0));
        getMWorld().health = n;
        index++;
    }
    public void loadPreviousEventScript()
    {
        getMWorld().addEventScript(getMWorld().getCurrentEventScript());
        index++;
    }
    public void addGameOver()
    {
        getMWorld().addObject(new GameOver(), 440, 247);
        index++;
    }
    public void stopMP3Music()
    {
        List<MP3Player> list = getMWorld().getObjects(MP3Player.class);
        for (MP3Player mp3 : list)
        mp3.close();
        index++;
    }
    public void removeHoloCircle()
    {
        List<HoloCircle> list = getMWorld().getObjects(HoloCircle.class);
        for (HoloCircle p : list)
        p.remove();
        index++;
    }
    public void removeHoloMap()
    {
        List<HoloMap> list = getMWorld().getObjects(HoloMap.class);
        for (HoloMap p : list)
        p.remove();
        index++;
    }
    public void addHoloCircle(ArrayList<String> parameter)
    {
        int x = Integer.parseInt(parameter.get(0));
        int y = Integer.parseInt(parameter.get(1));
        getMWorld().addObject(new HoloCircle(x,y),0,0);
        index++;
    }
    public void addHoloMap(ArrayList<String> parameter)
    {
        int x = Integer.parseInt(parameter.get(0));
        int y = Integer.parseInt(parameter.get(1));
        getMWorld().addObject(new HoloMap(),x,y);
        index++;
    }
    public void addPhoneButton()
    {
        getMWorld().addObject(new PhoneButton(), 45, 45);
        index++;
    }
    public void removePhoneHolos()
    {
        List<PhoneHolos> list = getMWorld().getObjects(PhoneHolos.class);
        for (PhoneHolos p : list)
        p.remove();
        index++;
    }
    public void addPhoneHoloLoad(ArrayList<String> parameter)
    {
        int x = Integer.parseInt(parameter.get(0));
        int y = Integer.parseInt(parameter.get(1));
        getMWorld().addObject(new PhoneHoloLoad(),x,y);
        index++;
    }
    public void addPhoneGrayScreen()
    {
        getMWorld().addObject(new PhoneGrayScreen(),440,247);
        index++;
    }
    public void addEricHolo(ArrayList<String> parameter)
    {
        int x = Integer.parseInt(parameter.get(0));
        int y = Integer.parseInt(parameter.get(1));
        getMWorld().addObject(new EricHolo(),x,y);
        index++;
    }
    public void addBlueRay(ArrayList<String> parameter)
    {
        int x = Integer.parseInt(parameter.get(0));
        int y = Integer.parseInt(parameter.get(1));
        getMWorld().addObject(new BlueRay(),x,y);
        index++;
    }
    public void addGreenRay(ArrayList<String> parameter)
    {
        int x = Integer.parseInt(parameter.get(0));
        int y = Integer.parseInt(parameter.get(1));
        getMWorld().addObject(new GreenRay(),x,y);
        index++;
    }
    public void setBackgroundBlack()
    {
        getMWorld().getBackground().setColor(Color.BLACK);
        getMWorld().getBackground().fill();
        index++;
    }
    public void removeCharacterText()
    {
        List<CharacterText> list = getMWorld().getObjects(CharacterText.class);
        for (CharacterText c : list)
        c.close();
        index++;
    }
    public void addECAddQuestionMark(ArrayList<String> parameter)
    {
        int x = Integer.parseInt(parameter.get(0));
        int y = Integer.parseInt(parameter.get(1));
        getMWorld().addObject(new ECAddQuestionMark(),x,y);
        index++;
    }
    public void addLeftToRightPicture(ArrayList<String> parameter)
    {
        int d = Integer.parseInt(parameter.get(0));
        String img = parameter.get(1);
        int x = Integer.parseInt(parameter.get(2));
        int y = Integer.parseInt(parameter.get(3));
        getMWorld().addObject(new LeftToRightPicture(d,img),x,y);
        index++;
    }
    public void addInGameDoorSwitch(ArrayList<String> parameter)
    {
        int x = Integer.parseInt(parameter.get(0));
        int y = Integer.parseInt(parameter.get(1));
        getMWorld().addObject(new DoorSwitch(),x,y);
        index++;
    }
    public void addInGameDoor(ArrayList<String> parameter)
    {
        int x = Integer.parseInt(parameter.get(0));
        int y = Integer.parseInt(parameter.get(1));
        getMWorld().addObject(new InGameDoor(),x,y);
        index++;
    }
    public void removeInGameObjects()
    {
        getMWorld().removeInGameObjects();
        index++;
    }
    public void addInGameCharacter(ArrayList<String> parameter)
    {
        int x = Integer.parseInt(parameter.get(0));
        int y = Integer.parseInt(parameter.get(1));
        getMWorld().addInGameCharacter(x,y);
        index++;
    }
    public void loadMap(ArrayList<String> parameter)
    {
        getMWorld().setBackground("maps/"+parameter.get(0));
        getMWorld().setRGBMap("maps/"+parameter.get(1));
        index++;
    }
    public void removeParticles()
    {
        getMWorld().removeObjects(getMWorld().getObjects(Particle.class));
        index++;
    }
    public void clearBackground()
    {
        getMWorld().getBackground().clear();
        index++;
    }
    public void removeMenuObjects()
    {
        List<Menu> list = getMWorld().getObjects(Menu.class);
        for (Menu m : list)
        m.close();
        index++;
    }
    public void waitCount(ArrayList<String> parameter)
    {
        int n = Integer.parseInt(parameter.get(0));
        if (count == -1)
        {
            count = n;
        }
        else
        {
            count--;
            if (count == 0)
            {
                index++;
                count = -1;
            }
        }
    }
    public void addMidoText(ArrayList<String> parameter)
    {
        String file = parameter.get(0);
        int x = Integer.parseInt(parameter.get(1));
        int y = Integer.parseInt(parameter.get(2));
        getMWorld().addObject(new MidoText(file),x,y);
        index++;
    }
    public void addEricText(ArrayList<String> parameter)
    {
        String file = parameter.get(0);
        int x = Integer.parseInt(parameter.get(1));
        int y = Integer.parseInt(parameter.get(2));
        getMWorld().addObject(new EricText(file),x,y);
        index++;
    }
    public void addKiraText(ArrayList<String> parameter)
    {
        String file = parameter.get(0);
        int x = Integer.parseInt(parameter.get(1));
        int y = Integer.parseInt(parameter.get(2));
        getMWorld().addObject(new KiraText(file),x,y);
        index++;
    }
    public void setEsUnpause()
    {
        getMWorld().esPause = false;
        index++;
    }
    public void setEsPause()
    {
        getMWorld().esPause = true;
        index++;
    }
    public void addMenuProjectiles()
    {
        getMWorld().addMenuProjectiles();
        index++;
    }
    public void loadMainMenu()
    {
        getMWorld().loadMainMenu();
        index++;
    }
    public void setLevel(ArrayList<String> parameter)
    {
        getMWorld().setLevel(parameter.get(0));
        index++;
    }
    public void setCurrentEventScript(ArrayList<String> parameter)
    {
        getMWorld().setCurrentEventScript(parameter.get(0));
        index++;
    }
    public void addFallPlatform(ArrayList<String> parameter)
    {
        int t = Integer.parseInt(parameter.get(0));
        int w = Integer.parseInt(parameter.get(1));
        int x = Integer.parseInt(parameter.get(2));
        int y = Integer.parseInt(parameter.get(3));
        getMWorld().addObject(new FallPlatform(t,w),x,y);
        index++;
    }
    public void addCirclePlatform(ArrayList<String> parameter)
    {
        double l = Double.parseDouble(parameter.get(0));
        double d = Double.parseDouble(parameter.get(1));
        int w = Integer.parseInt(parameter.get(2));
        int x = Integer.parseInt(parameter.get(3));
        int y = Integer.parseInt(parameter.get(4));
        getMWorld().addObject(new CirclePlatform(l,d,w),x,y);
        index++;
    }
    public void addSinPlatform(ArrayList<String> parameter)
    {
        int h = Integer.parseInt(parameter.get(0));
        int d = Integer.parseInt(parameter.get(1));
        int s = Integer.parseInt(parameter.get(2));
        int w = Integer.parseInt(parameter.get(3));
        int x = Integer.parseInt(parameter.get(4));
        int y = Integer.parseInt(parameter.get(5));
        getMWorld().addObject(new SinPlatform(h,d,s,w),x,y);
        index++;
    }
    public void addUpDownPlatform(ArrayList<String> parameter)
    {
        int s = Integer.parseInt(parameter.get(0));
        int w = Integer.parseInt(parameter.get(1));
        int x = Integer.parseInt(parameter.get(2));
        int y = Integer.parseInt(parameter.get(3));
        getMWorld().addObject(new UpDownPlatform(s,w),x,y);
        index++;
    }
    public void addLeftRightPlatform(ArrayList<String> parameter)
    {
        int s = Integer.parseInt(parameter.get(0));
        int w = Integer.parseInt(parameter.get(1));
        int x = Integer.parseInt(parameter.get(2));
        int y = Integer.parseInt(parameter.get(3));
        getMWorld().addObject(new LeftRightPlatform(s,w),x,y);
        index++;
    }
    public void addBouncyPlatform(ArrayList<String> parameter)
    {
        int h = Integer.parseInt(parameter.get(0));
        int w = Integer.parseInt(parameter.get(1));
        int s = Integer.parseInt(parameter.get(2));
        int x = Integer.parseInt(parameter.get(3));
        int y = Integer.parseInt(parameter.get(4));
        getMWorld().addObject(new BouncyPlatform(h,w,s),x,y);
        index++;
    }
    public void addTyper()
    {
        getMWorld().addObject(new Typer(), 440, 247);
        index++;
    }
    public void addSystemMessage(ArrayList<String> parameter)
    {
        getMWorld().addSystemMessage(parameter.get(0));
        index++;
    }
    public void removeCharacter()
    {
        getMWorld().removeObjects(getMWorld().getObjects(Character.class));
        getMWorld().removeObjects(getMWorld().getObjects(CharacterFaceParts.class));
        index++;
    }
    public void addMainBedRoom()
    {
        getMWorld().addMainBedRoom();
        index++;
    }
    /*
    public void waitForTextAddEventCount()
    {
        List<Text> list = getMWorld().getObjects(Text.class);
        if (list.size() == 0) 
        {
            index++;
            addEventCount();
            return;
        }
    }   
    public void waitForText()
    {
        List<Text> list = getMWorld().getObjects(Text.class);
        if (list.size() == 0) 
        {
            index++;
            return;
        }
    }
    */
    public void waitForCharacterTextAddEventCount()
    {
        List<CharacterText> list = getMWorld().getObjects(CharacterText.class);
        if (list.size() == 0) 
        {
            index++;
            addEventCount();
            return;
        }
    }   
    public void waitForCharacterText()
    {
        List<CharacterText> list = getMWorld().getObjects(CharacterText.class);
        if (list.size() == 0) 
        {
            index++;
            return;
        }
    }
    public void waitForScreenFadeAddEventCount(ArrayList<String> parameter)
    {
        int n = Integer.parseInt(parameter.get(0));
        List<ScreenFade> list = getMWorld().getObjects(ScreenFade.class);
        if (list.size() == 0)
        {
            index++;
            addEventCount();
            return;
        }
        ScreenFade sf = list.get(0);
        if (sf.currentFade == n)
        {
            addEventCount();
            index++;
        }
    }
    public void waitForScreenFade(ArrayList<String> parameter)
    {
        int n = Integer.parseInt(parameter.get(0));
        List<ScreenFade> list = getMWorld().getObjects(ScreenFade.class);
        if (list.size() == 0)
        {
            index++;
            return;
        }
        boolean isAtCurrentFade = true;
        for (ScreenFade sf : list)
        {
            isAtCurrentFade = isAtCurrentFade && (sf.currentFade == n);
        }
       //ScreenFade sf = list.get(0);
        
        if (isAtCurrentFade)
        {
            index++;
        }
    }
    public void playWaveSound(ArrayList<String> parameter)
    {
        Greenfoot.playSound(parameter.get(0));
        index++;
    }
    public void playMP3Music(ArrayList<String> parameter)
    {
        boolean repeat = parameter.get(1).equals("true");
        getMWorld().playMP3Music(parameter.get(0), repeat);
        
        index++;
    }
    public void playMP3Sound(ArrayList<String> parameter)
    {
        getMWorld().playSound(parameter.get(0));
        index++;
    }
    public void addMidoCharacter()
    {
        getMWorld().addMidoCharacter();
        index++;
    }
    public void addMidoCharacterWithLoc(ArrayList<String> parameter)
    {
        int x = Integer.parseInt(parameter.get(0));
        int y = Integer.parseInt(parameter.get(1));
        getMWorld().addMidoCharacter(x,y);
        index++;
    }
    public void addScreenFade()
    {
        getMWorld().addScreenFade();
        index++;
    }
    public void addScreenFadeType2()
    {
        getMWorld().addScreenFadeType2();
        index++;
    }
    public void addEventScript(ArrayList<String> parameter)
    {
        getMWorld().addEventScript(parameter.get(0));
        index++;
    }
    public void addEventCount()
    {
        getMWorld().eventCount+=1;
        index++;
    }
    public void waitForEventCount(ArrayList<String> parameter)
    {
        int n = Integer.parseInt(parameter.get(0));
        if (getMWorld().eventCount >= n)
        {
            getMWorld().eventCount = 0;
            index++;
        }
    }
    public void setBackground(ArrayList<String> parameter)
    {
        getMWorld().setBackground(parameter.get(0));
        index++;
    }
    
    ///*****////
    public void loadFileToArray(String textFileName)
    {
        StringBuffer sb = new StringBuffer();
        try{
            URL url = getClass().getClassLoader().getResource(textFileName);
            if(url == null)
            throw new IOException("File not found: " + textFileName);
            InputStream is = url.openStream();
            BufferedReader br = new BufferedReader(new InputStreamReader(is));
            String line = br.readLine(); 
            while(line != null)
            {
                //System.out.println("READ:" +line);
                if (line != null)
                events.add(line);
                line = br.readLine();
            }
            is.close();
            br.close();
        }
        catch(Exception ex)
        { System.out.println("File not found");
            return ; }
    } 
    
    public Midori getMWorld()
    {
        return (Midori) getWorld();
    }
}