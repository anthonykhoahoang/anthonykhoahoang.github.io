import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Potion here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Potion extends WorldItems
{
    public void act() 
    {
        if (getObjectsInRange(100, InGameChar.class).size() != 0 && getObjectsInRange(100, Battle.class).size() == 0)
        {
            getLand().addObject(new InstantText("item/potion", 200, 12f), getX(), getY()-100);
            //Greenfoot.delay(20);
            //getLand().removeObjects(getLand().getObjects(InstantText.class) );
            getLand().addItem (new Item("Potion", 1, false));
            getLand().removeObject(this);
        }
    }    
}
