import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Bullet1 - level 1 of the bullet the rocket can shoot.
 * 
 * @author (Anthony Hoang) 
 * @version (2.0)
 */
public class Bullet1 extends Bullet
{
    public Bullet1 (Vector speed, int rotation, int dmg, boolean sounds, Rocket rocket)
    {
        super(speed, rotation, dmg + 5, false, rocket);
        if (sounds)
        Greenfoot.playSound("bullet1.wav");
    }

    public void act() 
    {
        super.act();
    }    
}
