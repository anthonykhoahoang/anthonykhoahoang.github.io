import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.util.List;
/**
 * Write a description of class NanoSuit here.
 * 
 * @author Anthony Hoang
 * @version (v1)
 */
public class NanoSuit  extends InGameObjects
{
    private static GreenfootImage blank;
    private String suitKey;
    private boolean firstInitialize = true;
    private InGameCharacter character;
    private int MAXSUITPOWER;
    private int curPower = 1;
    private boolean active = false;
    private double energy = 100;
    private int keyDelay = 10;
    private int prevPower=1;
    
    public NanoSuit(int n)
    {
        if (blank == null)
        blank = new GreenfootImage(1,1);
        MAXSUITPOWER = n;
        setImage(blank);
    }
    public int getCurPower()
    {
        return curPower;
    }
    public boolean active()
    {
        return active;
    }
    public int getEnergy()
    {
        return (int)energy;
    }
    public double getEnergyD()
    {
        return energy;
    }
    public void act() 
    {
        if (getMWorld().esPause) return;
        if (firstInitialize)
        {
            List<InGameCharacter> list = getMWorld().getObjects(InGameCharacter.class);
            if (list.size() == 0) return;
            character = list.get(0);
            firstInitialize = false;
            suitKey = getMWorld().suitpower;
            curPower = getMWorld().curPower;
            prevPower = curPower;
        }
        if (getMWorld().esPause) return;
        move();
        recharge();
        if (curPower == 0)
        {
            int x;
            if (character.imgRight)
            x = getX()-10+(int)(Math.random()*10);
            else
            x = getX()+3+(int)(Math.random()*10);
            int y = getY()+25-(int)(Math.random()*45);
            if (character.imgRight)
            getMWorld().addObject(new SmokeParticle((int)(Math.random()*90)+180),x,y);
            else
            getMWorld().addObject(new SmokeParticle(-(int)(Math.random()*90)),x,y);
            if (energy >= 50)
            {
                curPower = prevPower;
                active = false;
            }
            return;
        }
        if (keyDelay > 0)
        {
            keyDelay--;
            return;
        }
        else keyDelay = 10;
        if (Greenfoot.isKeyDown(suitKey))
        {
            active = !active;
        }
    }   
    public void recharge()
    {
        if (energy < 100)
        energy += .2;
        if (energy > 100)
        energy = 100;
    }
    public void lowerEnergy(double d)
    {
        energy -= d;
        if (energy < 0)
        energy = 0;
        if (energy == 0)
        {
            if (curPower != 0)
            prevPower = curPower;
            curPower = 0;
            active = true;
        }
    }
    public void move()
    {
        int cx = character.getX();
        int cy = character.getY();
        setLocation(cx,cy);
    }
    private int getAngleTo(double x, double y)
    {
        double deltaX = x - getX();
        double deltaY = y - getY();
        return (int)(180 * Math.atan2(deltaY, deltaX) / Math.PI);
    }
    public Midori getMWorld()
    {
        return (Midori) getWorld();
    }
}
