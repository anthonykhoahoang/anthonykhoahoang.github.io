import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class ParticleBlaster here.
 * 
 * @author Anthony Hoang
 * @version (v1)
 */
public class ParticleBlaster  extends InGameObjects
{
    private int degree = 0;
    private int degreeLimit = 360;
    private boolean inc = true;
    public void act() 
    {
        if (getMWorld().esPause) return;
        //setLocation(getX()+1, getY());
        if (inc)
        {
            degree+=20;
            for (int i = 0; i < 20; i++)
            addParticles();
            if (degree > degreeLimit) inc = false;
        }
        else
        {
            degree+=20;
            for (int i = 0; i < 20; i++)
            addParticles();
            if (degree < 0) inc = true;
        }
    }    
    public void addParticles()
    {
        getMWorld().addObject(new Particle(degree),getX(),getY());
            getMWorld().addObject(new Particle(degree),getX()+1,getY());
            getMWorld().addObject(new Particle(degree),getX()-1,getY());
            getMWorld().addObject(new Particle(degree),getX()-1,getY()-1);
            getMWorld().addObject(new Particle(degree),getX()+1,getY()+1);
            getMWorld().addObject(new Particle(degree),getX(),getY()-1);
            
            
        getMWorld().addObject(new Particle(degree),getX(),getY());
            getMWorld().addObject(new Particle(degree),getX()+1,getY());
            getMWorld().addObject(new Particle(degree),getX()-1,getY());
            getMWorld().addObject(new Particle(degree),getX()-1,getY()-1);
            getMWorld().addObject(new Particle(degree),getX()+1,getY()+1);
            getMWorld().addObject(new Particle(degree),getX(),getY()-1);
            
    }
}
