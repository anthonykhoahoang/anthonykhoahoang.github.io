import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.awt.Color;
import java.awt.Font;

/**
 * Write a description of class EndOfBattleMenu here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Char2EndOfBattleMenu extends EndOfBattleMenu
{
    private int HEIGHT = 500;
    private int WIDTH = 724;
    private GreenfootImage TheodorePic = new GreenfootImage("theodorepic.png");
    private GreenfootImage image;
    private String name = "";
    private int level=1;
    private String exp ="";
    public Char2EndOfBattleMenu(String theodore, int level, String exp)
    {
        name = theodore;
        this.level = level;
        this.exp = exp;
        image = new GreenfootImage(WIDTH, HEIGHT);
        Font font = new Font("Courier", image.getFont().getStyle(), image.getFont().getSize()) ;
        font = font.deriveFont(20f);
        image.setFont(font);
        image.setColor(Color.WHITE);
        image.drawString(exp, 400, 50);
        loadTheodore();
        setImage(image);
    }
    public void act() 
    {
        /*
        if ( Greenfoot.mouseClicked(this))
        {
            if (getLand().stream1 != null)
            getLand().stream1.close();
            if (getLand().stream0 != null) 
            getLand().stream0.play();
            getLand().removeObjects(getLand().getObjects(Battle.class));
            getLand().isBattle = false;
            getLand().removeObjects(getLand().getObjects(EndOfBattleMenu.class));
        }
        */
    }    
    public void loadTheodore()
    {
        TheodorePic.scale (TheodorePic.getWidth()+10, TheodorePic.getHeight()+10);
        String l = "Level "+level;
        image.drawString(name, 450, 85);
        image.drawString(l, 450, 105);
        image.drawImage(TheodorePic, 400, 70);
    }
    public Land getLand()
    {
        return (Land)getWorld();
    }
}
