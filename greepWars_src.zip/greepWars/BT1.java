import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class BT1 here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class BT1 extends BulletType2
{
    public BT1( int dmg, boolean sound, Type1 p, int rot)
    {
        super(dmg, false, p, rot);
        if (sound)
        Greenfoot.playSound("bullet1.wav");
    }
    public void act() 
    {
        super.act();
    }    
}
