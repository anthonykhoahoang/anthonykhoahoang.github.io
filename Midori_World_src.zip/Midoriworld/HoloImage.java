import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class HoloImage here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class HoloImage  extends PhoneHolos
{
    public GreenfootImage img;
    public boolean firstInitialize = true;
    public HoloImage()
    {
    }
    public HoloImage(String pic)
    {
        img = new GreenfootImage(pic);
        img.setTransparency(0);
        setImage(new GreenfootImage(img));
        getImage().scale(1,1);
    }
    public void act() 
    {
        if (getMWorld().gamePause) return;
        if (firstInitialize)
        {
            int t = getImage().getTransparency()+5;
            int w = getImage().getWidth()+5;
            int h = getImage().getHeight()+5;
            if (t > 200 || w > img.getWidth() || h > img.getHeight())
            {
                img.setTransparency(200);
                setImage(img);
                firstInitialize = false;
            }
            else
            {
                getImage().scale(w,h);
                getImage().setTransparency(t);
            }
            return;
        }
        super.act();
    }    
}
