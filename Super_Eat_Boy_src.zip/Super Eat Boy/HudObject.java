import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class HudObjects here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class HudObject  extends Actor
{
    /**
     * Act - do whatever the HudObjects wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
        // Add your action code here.
    }    
    public ScrollWorld getWorld()
    {
        return (ScrollWorld) super.getWorld();
    }
}
