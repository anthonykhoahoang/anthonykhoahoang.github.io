import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Bot hole creates a black hole that will expand, add bot, and then shrink away
 * 
 * @author Anthony Hoang
 * @version (v1)
 */
public class BotHole  extends InGameObjects
{
    private int r = 1;
    private boolean expand = true;
    private int range;
    public BotHole(int range)
    {
        this.range = range;
        setImage(new GreenfootImage(40,40));
    }
    public void act() 
    {
        if (getMWorld().esPause) return;
        if (r < getImage().getWidth() && expand)
        {
            r++;
            int n = getImage().getWidth()/2-r/2;
            getImage().fillOval(n,n,r,r);
            if (r >= getImage().getWidth())
            {
                expand = false;
                addBot();
            }
        }
        if (r > 0 && !expand)
        {
            getImage().clear();
            r--;
            int n = getImage().getWidth()/2-r/2;
            getImage().fillOval(n,n,r,r);
            if (r <= 0)
            {
                getMWorld().removeObject(this);
            }
        }
    }    
    public void addBot()
    {
        getMWorld().addObject(new StandardHelperBot(range,false),getX(),getY());
    }
}
