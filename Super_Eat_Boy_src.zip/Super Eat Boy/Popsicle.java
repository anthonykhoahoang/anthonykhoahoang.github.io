import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Popsicle here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Popsicle  extends BadFood
{
    private static GreenfootImage[] moveAnim;
    private static GreenfootImage[] shootAnim;    
    
    //Animation variables
    private int maxAnimDelay = 4;
    private int curAnim = 0;
    private int curAnimDelay = maxAnimDelay;
    
    public Popsicle(int realX, int realY)
    {
        super(realX, realY, "BackAndForth", 2);
        if (moveAnim == null)
            loadImages();
    }
    
    public Popsicle(int realX, int realY, String ai, int speed)
    {
        super(realX, realY, ai, speed);
        if (moveAnim == null)
            loadImages();
    }
    
    public void loadImages()
    {
        moveAnim = new GreenfootImage[24];
        moveAnim[0] = new GreenfootImage("images/popsicle/ps1.png");
        moveAnim[1] = new GreenfootImage("images/popsicle/ps2.png");
        moveAnim[2] = new GreenfootImage("images/popsicle/ps3.png");
        moveAnim[3] = new GreenfootImage("images/popsicle/ps4.png");
        moveAnim[4] = new GreenfootImage("images/popsicle/ps5.png");
        moveAnim[5] = new GreenfootImage("images/popsicle/ps6.png");
        moveAnim[6] = new GreenfootImage("images/popsicle/ps7.png");
        moveAnim[7] = new GreenfootImage("images/popsicle/ps8.png");
        moveAnim[8] = new GreenfootImage("images/popsicle/ps9.png");
        moveAnim[9] = new GreenfootImage("images/popsicle/ps10.png");
        moveAnim[10] = new GreenfootImage("images/popsicle/ps11.png");
        moveAnim[11] = new GreenfootImage("images/popsicle/ps12.png");
        moveAnim[12] = new GreenfootImage("images/popsicle/ps13.png");
        moveAnim[13] = new GreenfootImage("images/popsicle/ps14.png");
        moveAnim[14] = new GreenfootImage("images/popsicle/ps15.png");
        moveAnim[15] = new GreenfootImage("images/popsicle/ps16.png");
        moveAnim[16] = new GreenfootImage("images/popsicle/ps17.png");
        moveAnim[17] = new GreenfootImage("images/popsicle/ps18.png");
        moveAnim[18] = new GreenfootImage("images/popsicle/ps19.png");
        moveAnim[19] = new GreenfootImage("images/popsicle/ps20.png");
        moveAnim[20] = new GreenfootImage("images/popsicle/ps21.png");
        moveAnim[21] = new GreenfootImage("images/popsicle/ps22.png");
        moveAnim[22] = new GreenfootImage("images/popsicle/ps23.png");
        moveAnim[23] = new GreenfootImage("images/popsicle/ps24.png");
        
        shootAnim = new GreenfootImage[2];
        shootAnim[0] = new GreenfootImage("images/popsicle/shoot1.png");
        shootAnim[1] = new GreenfootImage("images/popsicle/shoot2.png");
    }
    
    public void act() 
    {
        animate();
        super.act();
    }    

    public void animate()
    {
        if (curAnimDelay >= maxAnimDelay)
        {
            if (curAnim >= moveAnim.length)
                curAnim = 0;
            setImage(new GreenfootImage(moveAnim[curAnim]));
            if (getDirection() == 0)
                getImage().mirrorHorizontally();
            curAnim++;
            curAnimDelay = 0;
        }
        else
            curAnimDelay++;
    }
    
    public void die()
    {
        for (int i = 0; i < 360; i+=10)
            getWorld().addObject(new LightBlueParticle(i, getRealX(), getRealY()+10), 0, 0);
        getWorld().addObject(new DeadPopsicle(getRealX(), getRealY()), 0, 0);
        getWorld().removeObject(this);
    }    
}
