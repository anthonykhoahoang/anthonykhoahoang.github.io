import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Plane here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Plane extends MovingThing
{
    private int speed = 8;
    private int lives = 2;
    private int weaponLevel = 0;
    private int player;
    private int invincible = 40;
    private boolean isDead = false;
    public Plane( int player)
    {
        this.player = player;
    }
    public void act() 
    {
        getSpace().life1.updateImage2(lives);
    }    
    public boolean atLeftEdge()
    {
        if (getX() < 200)
        return true;
        return false;
    }
    public void checkCollision()
    {
        Enemy2 a = (Enemy2)getOneIntersectingObject(Enemy2.class);
        EnemyBullet b = (EnemyBullet) getOneIntersectingObject(EnemyBullet.class);
        if (a!= null)
        {
            getSpace(). addSmallExplosion(getX(),getY());
            a.hit(200);
            lives--;
            weaponLevel = 0;
            checkLife();
            invincible = 40;
        }
        else
        if (b != null)
        {
            getSpace(). addSmallExplosion(getX(),getY());
            getSpace().removeObject(b);
            lives--;
            weaponLevel = 0;
            checkLife();
            invincible = 40;
        }
    }
    public boolean isDead()
    {   return isDead;  }
    public void checkLife()
    {
        getSpace().life1.updateImage2(lives);
        if (lives <= 0)
        {
            isDead = true;
            getSpace().gameOver2();
            getSpace().removeObject(this);
        }
    }
    public void checkForUpgrades()
    {
        WeaponLevelUpgrade b = (WeaponLevelUpgrade)getOneIntersectingObject(WeaponLevelUpgrade.class);
        if (b != null)
        {
            getSpace().removeObject(b);
            Greenfoot.playSound("pickUpgrade.wav");
            raiseWeaponLevel();
        }
    }
    public void setInvincible(int n)
    {   invincible = n; }
    public int getInvincible()
    {   return invincible;  }
    public int getWeaponLevel()
    {   return weaponLevel; }
    public void raiseWeaponLevel()
    {   weaponLevel++;
        if (weaponLevel > 6) weaponLevel = 6;
        getSpace().weaponLevel1.updateImage2(weaponLevel);
    }
    public boolean atRightEdge()
    {
        if ( getX() > getWorld().getWidth() - 200)
        return true;
        return false;
    }
    public boolean atWorldEdge()
    {
        if(getX() < 200 || getX() > getWorld().getWidth() - 200)
            return true;
        if(getY() < 10 || getY() > getWorld().getHeight() - 10)
            return true;
        else
            return false;
    }
    public int getLives()
    {   return lives;   }
    public void addLife()
    {
        lives ++;
        checkLife();
    }
    public int getPlayer()
    {
        return player;
    }
    public void moveForward()
    {
        setLocation(getX(), getY()-speed);
    }
    public void moveBackward()
    {
        setLocation(getX(), getY()+speed);
    }
    public void moveLeft()
    {
        if (!atLeftEdge())
        setLocation(getX()-speed, getY());
    }
    public void moveRight()
    {
        if (!atRightEdge())
        setLocation(getX()+speed, getY());
    }
}
