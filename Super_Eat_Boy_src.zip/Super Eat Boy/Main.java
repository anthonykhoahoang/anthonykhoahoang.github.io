
public class Main
{

    public static void main(String[] commandLineArguments)
	{
		try
		{ 
			Process p = Runtime.getRuntime().exec("cmd /c java -jar SuperEatBoy.jar");
		}
		catch(Exception exc){System.out.println(exc.toString());}
	}

}