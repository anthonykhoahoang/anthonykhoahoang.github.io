import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Cloud here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Cloud extends Misc
{
    private static GreenfootImage[] images;
    private int imageNo = 0;
    public Cloud()
    {
        getImage().scale(getImage().getWidth()*2, getImage().getHeight()*2);
        images = new GreenfootImage[100];
        initialiseImages();
    }
    public void act()
    {
        if(atBottomEdge()) 
        {
            if (imageNo == 99)
            {
                setLocation(getX(),0);
            }
            else
            {
                setImage(images[imageNo]);
                imageNo++;
            }
        }
        else 
        {
            if (atTopEdge() && imageNo != 0)
            {
                setImage(images[imageNo]);
                imageNo--;
            }
            else
            moveForward();
        }
    }
    
    public void initialiseImages()
    {
        for (int i = 0; i < 100; i++)
        {
            images[i] = new GreenfootImage(getImage());
            images[i].scale(getImage().getWidth(),getImage().getHeight()-i*2);
        }
    }
    public boolean atWorldEdge()
    {
        if(getX() < 180 || getX() > getWorld().getWidth() - 180)
            return true;
        if(getY() < 10 || getY() > getWorld().getHeight()-10)
            return true;
        else
            return false;
    }
    public void moveForward()
    {
        setLocation(getX(), getY()+1);
    }
    public boolean atBottomEdge()
    {
        if (getY() > getWorld().getHeight() - 10)
            return true;
        return false;
    }
    public boolean atTopEdge()
    {
        if(getY() < 10 )
            return true;
        return false;
    }
}