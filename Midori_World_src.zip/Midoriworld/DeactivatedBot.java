import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Deactivated bot can be activated when ingamecharacter
 * is near, and the use key is pressed
 * 
 * @author Anthony Hoang
 * @version (v1)
 */
public class DeactivatedBot  extends InGameObjects
{
    private boolean willFollow;
    private int botType;
    private int range;
    private boolean initiated = false;
    public DeactivatedBot(boolean willFollow, int botType, int range)
    {
        this.botType = botType;
        this.willFollow = willFollow;
        this.range = range;
        setImage(new GreenfootImage("helperbot/helperbot.png"));
    }
    public void act() 
    {
        if (getMWorld().esPause) return;
        if (initiated)
        {
            int t = getImage().getTransparency()-50;
            if (t < 0)
            getMWorld().removeObject(this);
            else
            {
                getImage().setTransparency(t);
                int x = getX()-10+(int)(Math.random()*10);
                int y = getY()+10-(int)(Math.random()*10);
                getMWorld().addObject(new SmokeParticle((int)(Math.random()*360)),x,y);
            }
        }
        else
        checkForChar();
    }    
    public void checkForChar()
    {
        String key = getMWorld().use;
        Actor a = getOneIntersectingObject(InGameCharacter.class);
        if (a != null && Greenfoot.isKeyDown(key) && Greenfoot.isKeyDown(key))
        {
            initiated = true;
            if (botType == 0)
            getMWorld().addObject(new StandardHelperBot(),getX(),getY());
            if (botType == 1)
            getMWorld().addObject(new StandardHelperBot(range),getX(),getY());
        }
    }
}
