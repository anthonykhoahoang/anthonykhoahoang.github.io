import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Ice overlay hurts ingamecharacter every 100 acts
 * 
 * @author Atnhony haong
 * @version 1
 */
public class IceOverlay  extends MapOverlay
{
    private boolean inc = false;
    private int delay = 100;
    public IceOverlay()
    {
        setImage(new GreenfootImage("iceoverlay.png"));
        getImage().scale(880,494);
        getImage().setTransparency(200);
    }
    public void act() 
    {
        if (getMWorld().esPause) return;
        if (inc)
        {
            delay++;
            if (delay > 100)
            {
                inc = false;
                InGameCharacter a = (InGameCharacter)getOneIntersectingObject(InGameCharacter.class);
                if (a != null)
                a.hit(1);
            }
        }
        else
        {
            delay--;
            if (delay < 0)
            {
                inc = true;
                InGameCharacter a = (InGameCharacter)getOneIntersectingObject(InGameCharacter.class);
                if (a != null)
                a.hit(1);
            }
        }
        super.act();
    }    
}
