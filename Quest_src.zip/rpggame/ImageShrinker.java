import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class ImageShrinker here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class ImageShrinker extends Battle
{
    private GreenfootImage image;
    public ImageShrinker(String s)
    {
        image = new GreenfootImage(s);
        setImage(image);
    }
    public void act() 
    {
        if (image.getWidth() <=1 || image.getHeight() <=1)
        getLand().removeObject(this);
        else
        {
            setLocation(getX()+1, getY() -1);
            image.scale(getImage().getWidth()-1, getImage().getHeight()-1);
            setImage(image);
        }
    }    
}
