import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class MenuTarget here.
 * 
 * @author Anthony Hoang
 * @version (v1)
 */
public class MenuTarget  extends MenuObjects
{
    private Vector v;
    private double degree=0;
    private double degreeAdd=2;
    private double length=3;
    private double x=400;
    private double y=200;
    private boolean firstInitialize = true;
    public MenuTarget()
    {
        setImage(new GreenfootImage(100,100));
    }
    public void act() 
    {
        if (closing)
        {
            getMWorld().removeObject(this);
            return;
        }
        if (firstInitialize)
        {
            x=getX();
            y=getY();
            firstInitialize = false;
        }
        move2();
    }    
    public void move2()
    {
        v = new Vector((int)degree, length);
        degree+=degreeAdd;
        if (degree >= 360)
        degree = 0;
        x+=v.getX();
        y+=v.getY();
        if (x > getWorld().getWidth()) x = getWorld().getWidth();
        if (x < 0) x = 0;
        if (y > getWorld().getHeight()) y = getWorld().getHeight();
        if (y < 0) y = 0;
        setLocation((int)x, (int) y);
    }
    public void explode()
    {
        for (int i = 0; i < 10; i++)
        getMWorld().addObject(new SmallBlueParticle((int)(Math.random()*360)),getX(),getY());
    }
    public void move()
    {
        if (getOneIntersectingObject(MenuProjectileBlue.class) != null)
        {
            int n = (int)(Math.random()*5);
            if (n == 0)
            setLocation (300,300);
            if (n == 1)
            setLocation (300, getMWorld().getHeight()-300);
            if (n == 2)
            setLocation (getMWorld().getWidth()-300, 300);
            if (n == 3)
            setLocation (getMWorld().getWidth()-300, getMWorld().getHeight()-300);
            if (n==4)
            setLocation (440, 247);
        }
    }
}
