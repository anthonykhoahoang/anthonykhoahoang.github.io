import greenfoot.*;  // (World, Actor, GreenfootImage, and Greenfoot)
import java.util.List;

/**
 * A space ship boss. It comes from space and will attack you
 */
public class AlienShipBoss2 extends Enemy
{
    private int minGunFireDelay;    
    /** How long ago we fired the gun the last time. */
    private int gunFireDelay = 0;    
    
    private int numActs;
    private int coolDown;
    
    /** Delay time for AAS attack */
    private int aasDelay = 400;
     
    private int numActsMax;
    private int damage;
    private int coolDownDelay;
    /**
     * Create a space ship. The parameter specifies at what height to land.
     */
    public AlienShipBoss2(int life, int maxActs, int bulletDamage, int coolDelay)
    {
        super(life, 1000);
        setImage("enemyShip/spaceShipBoss2.png");
        minGunFireDelay = 3;
        gunFireDelay = 0;
        numActs = 0;
        coolDown = 0;
        numActsMax = maxActs;
        damage = bulletDamage;
        coolDownDelay = coolDelay;        
    } 
    public AlienShipBoss2(int a, int b)
    {
        super(a, b);
    }
    public AlienShipBoss2(int life, int maxActs, int bulletDamage, int coolDelay, boolean isBossThree)
    {
        super(life, 1000);
        setImage("enemyShip/spaceShipBoss3.png");
        minGunFireDelay = 2;
        gunFireDelay = 0;
        numActs = 0;
        coolDown = 0;
        numActsMax = maxActs;
        damage = bulletDamage;
        coolDownDelay = coolDelay;
    }

    /**
     * Let the ship act: move or release greeps.
     */
    
    public void act() 
    {
        getSpace().bossLife.setLocation(this.getX(), this.getY() + getImage().getWidth() / 2);
        getSpace().bossLife.updateImage2(this.healthPercent());
        if (getEmpDelay() >= 0)
        {
            if(numActs > numActsMax)
            {
                shootRayGun();
                gunFireDelay++;
            }
        
            if (numActs > numActsMax+20)
            numActs = 0;
            numActs++;
            if (numActs > 0)
                coolDown++;
            if (coolDown == coolDownDelay)
            {
                numActs = -40;
                coolDown = 0;
            }
            aasDelay--;
            if (aasDelay <= 0)
            {
                AAS();
                aasDelay = 100;
            }
            move();
            
            if (randomChance(10))
            turn(10);
        }
        else
        super.act();
    }    
    public void shootRayGun()
    {
        if(gunFireDelay >= minGunFireDelay) 
        {
            EB7 b = new EB7( turnToShipInt(), 70, true, this);
            getWorld().addObject(b, getX(), getY());
            b.move();
            gunFireDelay = 0;
        }         
    }
    public void AAS()
    {
        int r = getRotation();
        for (int i = 0; i < 360; i++)
        {
            EB5 b = new EB5(r, 80, false,this);
            getWorld().addObject(b, getX(), getY());
            b.move();
            
            r += 5;
        }
        Greenfoot.playSound("aas.wav");
    }
}