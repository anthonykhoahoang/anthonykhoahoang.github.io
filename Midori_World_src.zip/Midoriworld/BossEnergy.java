import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.awt.Color;
import java.awt.Font;
/**
 * Displays the current Energy level of boss
 * 
 * @author Anthony Hoang
 * @version (v1)
 */
public class BossEnergy  extends BossCounter
{
    private int tEnergy = 0;
    private GreenfootImage image;
    private boolean firstInitialize = true;
    private int delay = 2;
    
    public BossEnergy()
    {
        image = new GreenfootImage(10, 400);
        getImage().clear();
    }
    public void act() 
    {
        if (getMWorld().gamePause) return;
        if (firstInitialize)
        {
            firstInitialize = false;
            //image.setColor(new Color(50,25,150,150));
            tEnergy = 400;
            //image.fillRect(0, tEnergy,20,400);
            
            Font font = image.getFont();
            font = font.deriveFont(11f);
            image.setColor(Color.WHITE);
            image.drawString("E", 2, 200);
            setImage(image);
        }
        updateEnergy();
    }    
    public void updateEnergy()
    {
        if (getBossType1() == null) return;
        double percent = getBossType1().getDownDelay()/getBossType1().getDownDelayMax();
        int energy = (int)(getImage().getHeight()*percent);
        
        if (energy == tEnergy) return;
        if (energy > tEnergy)
        tEnergy += (int)getBossType1().getRechargeRate();
        else if (energy < tEnergy)
        tEnergy -= (int)getBossType1().getRechargeRate();
        image.clear();
        if (!getBossType1().isPaused())
        image.setColor(new Color(50,205,100,190));
        else
        image.setColor(new Color(200,105,100,190));
        //image.setColor(new Color(50,205,100,190));
        image.fillRect(0,getImage().getHeight()-tEnergy,20,400);
        Font font = image.getFont();
        font = font.deriveFont(11f);
        image.setFont(font);
        image.setColor(Color.WHITE);
        image.drawString("E", 2, 200);
        setImage(image);
    }
}
