import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Spector_Big_2 here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Spector_Big extends Enemy
{
    private boolean willAttack = false;
    private int numActs = 0;
    public void act() 
    {
        if (getObjectsInRange(200, InGameChar.class).size() != 0)
        willAttack = true;
        if (willAttack)
        {
            Actor a = (Actor)getObjectsInRange(200, InGameChar.class).get(0);
            
            getLand().addObject(new InstantText("zombie/encounter", 200, 12f), a.getX(), a.getY()-100);
            Greenfoot.playSound("zombie_groan.wav");
            Greenfoot.delay(50);
            int n = getLand().charLevel;
            getLand().loadBattleType2();
            int delay = 400 - n*10;
            if (delay < 100) delay = 100;
            
            getLand().addObject(new SmallFireShard(), getX()+10, getY());
            getLand().addObject(new SmallFireShard(), getX()+10, getY());
            getLand().addObject(new Potion(), getX(), getY());
            
            getLand().addObject(new Spector(n*10-5*(n-3), 0, delay-Greenfoot.getRandomNumber(20), 3*n - 2*(n-1)), 728, 396);
            getLand().addObject(new Spector(n*10-5*(n-3), 0, delay-Greenfoot.getRandomNumber(20), 3*n - 2*(n-1)), 728, 293);
            getLand().addObject(new Zombie(n*10-5*(n-1), 0, delay-Greenfoot.getRandomNumber(20), 3*n - 2*(n-2)  ) , 835, 252);
            getLand().addObject(new Zombie(n*10-5*(n-1), 0, delay-Greenfoot.getRandomNumber(20), 3*n - 2*(n-2)), 835, 346);
            getLand().addObject(new Zombie(n*10-5*(n-1), 0, delay, 3*n - 2*(n-2)), 835, 436);
            //getLand().curEXP += 10;
            getLand().removeObject(this);
            
            
        }
    }    
}
