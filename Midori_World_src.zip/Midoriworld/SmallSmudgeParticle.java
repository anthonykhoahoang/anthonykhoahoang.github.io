import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class SmallSmudgeParticle here.
 * 
 * @author Anthony Hoang
 * @version v1
 */
public class SmallSmudgeParticle  extends Particle
{
    private static GreenfootImage img;
    private int transparency = 150;
    private int transReduce = 5;
    private boolean firstInitialize = true;
    private double x;
    private double y;
    private int r;
    private Vector v = new Vector();
    private int curImage = 0;
    private static GreenfootImage[] images;
    public SmallSmudgeParticle(int r)
    {
        this.r = r;
        if (img == null)
        {
            img = new GreenfootImage("greenStuff.png");
            img.scale(img.getWidth()/2, img.getHeight()/2);
        }
        if (images == null)
        {
            images = new GreenfootImage[30];
            int n = 0;
            for (int i = 0; i < 30; ++i)
            {
                images[i] = new GreenfootImage(img);
                images[i].setTransparency(this.transparency - n);
                n += this.transReduce;
            }
        }
        setImage(images[this.curImage]);
    }
    public void act() 
    {
        if (getMWorld().esPause) return;
        if (firstInitialize)
        {
            x = getX();
            y = getY();
            firstInitialize = false;
        }
        else
        {
            curImage += 1;
            if (curImage == 30) 
            {
                getMWorld().removeObject(this);
            }
            else 
            {
                setImage(images[curImage]);
                random();
                move();
            }
        }
    }    
    public void random()
    {
        v.add(new Vector((int)(Math.random()*360),Math.random()*.2));
    }
    public void move()
    {
        v.add(new Vector(r, .2));
        x+=v.getX();
        y+=v.getY();
        setLocation((int)x,(int)y);
    }
}
