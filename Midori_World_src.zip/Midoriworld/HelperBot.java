import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.util.List;
/**
 * provides Basic methods of clean bots
 * 
 * @author Anthony Hoang
 * @version (v1)
 */
public class HelperBot  extends InGameObjects
{
    private Vector v;
    private double x=0, y=0;
    private boolean firstInitialize = true;
    private double rot;
    private double rotAdd;
    public boolean hasHit = false;
    private int crashDelay = 100;
    private int randomer = (int)(Math.random()*10);
    private double spinSpeed = Math.random()*.8;
    private boolean follow;
    public HelperBot()
    {
        follow = false;
        rot = 0;
        rotAdd = 5;
    }
    public HelperBot(boolean follow)
    {
        this.follow = follow;
        rot = 0;
        rotAdd = 5;
    }
    
    public void act() 
    {
        if (getMWorld().gamePause) return;
        if (firstInitialize)
        {
            x = getX();
            y = getY();
            firstInitialize = false;
        }
        else
        {
            if (hasHit)
            crash();
            else
            move();
        }
    }
    public void crash()
    {
        if (getMWorld().esPause) return;
        if (crashDelay > 0)
        {
            getMWorld().addObject(new SmokeParticle((int)(Math.random()*10+180)),getX(),getY());
            v = new Vector(80,3);
            x+=v.getX();
            y+=v.getY();
            if (x > getWorld().getWidth()) x = getWorld().getWidth();
            if (x < 0) x = 0;
            if (y > getWorld().getHeight()) y = getWorld().getHeight();
            if (y < 0) y = 0;
            crashDelay--;
            if (blackBetweenY((int)y)||blackBetweenX((int)x))
            {
                for (int i = 0; i < 10; i++)
                getMWorld().addObject(new SmokeParticle((int)(Math.random()*360)),getX(),getY());
                getMWorld().addObject(new SmallOrangeParticle((int)(Math.random()*360)),getX(),getY());
                crashDelay = -1;
                //getWorld().removeObject(this);
            }
            else
            setLocation((int)x, (int)y);
        }
        else if (crashDelay <= 0)
        {
            for (int i = 0; i < 5; i++)
            getMWorld().addObject(new SmokeParticle((int)(Math.random()*360)),getX(),getY());
            getMWorld().addObject(new SmallOrangeParticle((int)(Math.random()*360)),getX(),getY());
            getMWorld().addObject(new SmallYellowParticle((int)(Math.random()*360)),getX(),getY());
            crashDelay--;
            if (crashDelay < -6)
            getMWorld().removeObject(this);
        }
        
    }
    public void hit()
    {
        hasHit = true;
        for (int i = 0; i < 15; i++)
        {
            getMWorld().addObject(new SmokeParticle((int)(Math.random()*360)),getX(),getY());
        }
    }
    public void move()
    {
        v = new Vector((int)rot,spinSpeed);
        rot+=rotAdd;
        if (rot >= 360) rot = 0;
        x+=v.getX();
        y+=v.getY();

        List<Actor> a = getMWorld().getObjects(InGameCharacter.class);
        if (a.size()!=0 && follow)
        {
            Actor actor = a.get(0);
            if (actor != null)
            {
                int ax = actor.getX(), ay = actor.getY()-actor.getImage().getHeight();
                int r = getAngleTo(ax+randomer, ay);
                
                if (Math.abs(ax-getX()+randomer) > 10 || Math.abs(ay-getY()) > 10)
                {
                    v = new Vector(r, 2.0);
                    x+=v.getX();
                    y+=v.getY();
                }
            }
        }
        setLocation((int)x, (int)y);
    }
    private int getAngleTo(double x, double y)
    {
        double deltaX = x - getX();
        double deltaY = y - getY();
        return (int)(180 * Math.atan2(deltaY, deltaX) / Math.PI);
    }
    public boolean blackBetweenY( int y2)
    {
        int y1 = getY();
        if (y1 < y2)
        return blackBetweenYDown(y2);
        return blackBetweenYUp(y2);
    }
    public boolean blackBetweenYDown(int y2)
    {
        int y1 = getY();
        while (y1 < y2)
        {
            if (isBlackAt(getX(),y1))
            return true;
            y1++;
        }
        return false;
    }
    public boolean blackBetweenYUp(int y2)
    {
        int y1 = getY();
        while (y1 > y2)
        {
            if (isBlackAt(getX(),y1))
            return true;
            y1--;
        }
        return false;
    }
    public void gotoNextBlackY(int y2)
    {
        int y1 = getY();
        if (y1 < y2)
        gotoNextBlackYDown(y2);
        else
        gotoNextBlackYUp(y2);
    }
    public void gotoNextBlackYDown(int y2)
    {
        int y1 = getY();
        while (y1 < y2)
        {
            if (isBlackAt(getX(),y1))
            {                 
                setLocation(getX(), y1-getImage().getHeight()/2);
                return;
            }
            y1++;
        }
        setLocation(getX(), y1-getImage().getHeight()/2);
    }
    public void gotoNextBlackYUp(int y2)
    {
        int y1 = getY();
        while (y1 > y2)
        {
            if (isBlackAt(getX(),y1))
            {
                setLocation(getX(), y1+getImage().getHeight()/2);
                return;
            }
            y1--;
        }
        setLocation(getX(), y1+getImage().getHeight()/2);
    }
    public boolean blackBetweenX(int x2)
    {
        int x1 = getX();
        if (x1 < x2)
        return blackBetweenXRight(x2);
        return blackBetweenXLeft(x2);
    }
    public boolean blackBetweenXRight(int x2)
    {
        int x1 = getX();
        int y1 = getY();
        while (x1 < x2)
        {
            if (isBlackAt(x1, y1))
            return true;
            x1++;
        }
        return false;
    }
    public boolean blackBetweenXLeft(int x2)
    {
        int x1 = getX();
        int y1 = getY();
        while (x1 > x2)
        {
            if (isBlackAt(x1, y1))
            return true;
            x1--;
        }
        return false;
    }   
    public Midori getMWorld()
    {
        return (Midori) getWorld();
    }
}
