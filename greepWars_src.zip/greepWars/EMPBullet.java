import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * EMPbullets can stop machines from moving for a certain amount of time.
 * 
 * @author (Anthony Hoang) 
 * @version (2.0)
 */
public class EMPBullet extends Bullet
{
    
    public EMPBullet(Vector speed, int rotation, Rocket rock)
    {
        super (speed, rotation, 0, false, rock);
    }
    public void act() 
    {
        if(getLife() <= 0) 
        {
            setLife(40);
            getWorld().removeObject(this);
        }
        else
        {
            move();
            AlienShip alianship = (AlienShip) getOneIntersectingObject(AlienShip.class);
            AlienShipBoss alianshipBoss = (AlienShipBoss) getOneIntersectingObject(AlienShipBoss.class);
            AlienShipBoss2 alianshipBoss2 = (AlienShipBoss2) getOneIntersectingObject(AlienShipBoss2.class);
            if(alianship != null)
            {
                alianship.setEmpDelay();
            }
            else
            if(alianshipBoss != null)
            {
                alianshipBoss.setEmpDelay();
            }
            else
            if(alianshipBoss2 != null)
            {
                alianshipBoss2.setEmpDelay();
            }
        }
        lowerLife();
    }
}
