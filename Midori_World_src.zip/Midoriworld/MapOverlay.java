import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Provides basic method for mapoverlays
 * 
 * @author aNTHONY Hoang
 * @version 1
 */
public class MapOverlay  extends InGameObjects
{
    private boolean closed = false;
    public void act() 
    {
        if (closed)
        {
            int t = getImage().getTransparency()-5;
            if (t < 0)
            getMWorld().removeObject(this);
            else
            getImage().setTransparency(t);
        }
    }   
    public void close()
    {
        closed = true;
    }
}
