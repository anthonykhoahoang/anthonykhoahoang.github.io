import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class DeadFood here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class DeadFood  extends ScrollActor
{
    public DeadFood(int realX, int realY)
    {
        super(realX, realY);
    }
    public void act() 
    {
        super.act();
    }    
}
