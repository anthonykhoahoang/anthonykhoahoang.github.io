import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.util.*;
import java.awt.Color;
/**
 * Write a description of class BattleSoldier here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class BattleSoldier extends Bad
{
    private GreenfootImage normal = new GreenfootImage("Battle/Soldier/soldier.png");
    private GreenfootImage attack = new GreenfootImage("Battle/Soldier/soldierAttack.png");
    private GreenfootImage hit = new GreenfootImage("Battle/Soldier/soldierAttack2.png");
    
    private int fightDelay;
    private int numActs =0;
    private int returnToPosDelay = -15;
    private int dmg;
    
    private Good curGood;
    private boolean isAttacking = false;
    private boolean isInPos = true;
    
    private int[] prevPosition = new int[2];
    
    public BattleSoldier(int hp, int mana, int fd, int damage)
    {
        super(hp,mana);
        dmg = damage;
        fightDelay = fd;
        setImage(normal);
    }
    public void act() 
    {
         if (numActs >= fightDelay)
         {
             numActs = -fightDelay;
             attack(getRandomGood());
         }
         numActs++;
         checkAttack();
         super.act();
    }    
    public void checkAttack()
    {
        if (isAttacking)
        {
            turnToGoodGuy();
            makeRunSmoke();
            move();
            setRotation(0);
            setImage(attack);
            List<Good> gList = getIntersectingObjects(Good.class);
            for (Good g : gList)
            if (g != null && !g.isDead())
            {
                getLand().addObject(new Slash(), g.getX(), g.getY());
                g.hit(dmg);
                if ( g.defending())
                Greenfoot.playSound("sword-ching-sound.wav");
                else
                Greenfoot.playSound("slash2.wav");
                isAttacking = false;
                isInPos = false;
                setImage(hit);
            }
        }
        if (!isInPos )
        {
            if (returnToPosDelay == 0)
            {
                setImage(normal);
                for (int i = 0; i < 2; i++)
                {
                    turnToStartPos();
                    move();
                    setRotation(0);
                    int n = prevPosition[0]+prevPosition[1]-getX()-getY();
                    if (n < 5 && n > -5)
                    {
                        i = 5;
                        isInPos = true;
                        returnToPosDelay= -15;
                        numActs = 0;
                    }
                }
            }
            else
            if (returnToPosDelay < 0 ) returnToPosDelay++;
        }
    }
    public void setPrevPos(int x, int y)
    {
        prevPosition[0] = x;
        prevPosition[1] = y;
    }
    public void move()
    {
        double angle = Math.toRadians( getRotation() );
        int x = (int) Math.round(getX() + Math.cos(angle) * getImage().getWidth()/3);
        int y = (int) Math.round(getY() + Math.sin(angle) * getImage().getWidth()/3);
        setLocation(x, y);
    }
    public void attack(Good g)
    {
        setPrevPos(getX(),getY());
        curGood = g;
        if (g != null)
        isAttacking = true;
    }
    public Good getRandomGood()
    {
        List<Good> a = getLand().getObjects(Good.class);
        for (int i = 0; i < a.size(); i++)
        {
            if (a.get(i).getCurHP() == 0)
            a.remove(i);
        }
        if (a.size()!=0)
        {
            int n = Greenfoot.getRandomNumber(a.size());
            return (Good)a.get(n);
        }
        return null;
    }
    public void turnToGoodGuy()
    {
        if (curGood.getCurHP() <= 0)
        curGood = getRandomGood();
        int deltaX = (curGood.getX() - getX());
        int deltaY = (curGood.getY() - getY());
        setRotation((int) (180 * Math.atan2(deltaY, deltaX) / Math.PI));
    }
    public void turnToStartPos()
    {
        int deltaX = (prevPosition[0] - getX());
        int deltaY = (prevPosition[1] - getY());
        setRotation((int) (180 * Math.atan2(deltaY, deltaX) / Math.PI));
    }
    
}
