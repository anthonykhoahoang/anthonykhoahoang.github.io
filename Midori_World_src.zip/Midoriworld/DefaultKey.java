import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.awt.Color;
import java.awt.Font;
/**
 * Write a description of class ReturnToLoginMenu here.
 * 
 * @author Anthony Hoang
 * @version (v1)
 */
public class DefaultKey  extends Keys
{
    private int WIDTH = 220;
    private int HEIGHT= 50;
    private GreenfootImage image;
    private GreenfootImage image2;
    public DefaultKey()
    {
        image = new GreenfootImage(WIDTH, HEIGHT);
        image2 = new GreenfootImage(WIDTH, HEIGHT);
        drawOne();
        drawTwo();
        setImage(image2);
        getImage().setTransparency(0);
    }
    public void act() 
    {
        if (mouseOverThis() )
        {
            if (getImage().equals(image2))
            setImage(image);
        }
        else if (getImage().equals(image))
        setImage(image2);
        if (Greenfoot.mouseClicked(this))
        {
            getMWorld().defaultKeys();
            select();
        }
        super.act();
    }    
    public void drawOne()
    {
        image.setColor(Color.GRAY);
        image.fill();
        image.setColor(new Color(5, 5, 75 ,150));
        image.fillRect(5, 5, WIDTH-10, HEIGHT-10);
        Font font = image.getFont();
        font = font.deriveFont(25f);
        image.setFont(font);
        image.setColor(Color.WHITE);
        image.drawString("Default Controls", 19, 32);
        //setImage(image);
    }
    public void drawTwo()
    {
        image2.setColor(new Color(5, 5, 50 ,150));
        image2.fillRect(5, 5, WIDTH-10, HEIGHT-10);
        Font font = image.getFont();
        font = font.deriveFont(25f);
        image2.setFont(font);
        image2.setColor(Color.WHITE);
        image2.drawString("Default Controls", 19, 32);
       // setImage(image2);
    }
}
