import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Title here.
 * 
 * @author Anthony Hoang
 * @version (v1)
 */
public class Title  extends Menu
{
    private boolean left = true;
    private boolean firstInitialize = true;
    private double x;
    public Title()
    {
        setImage(new GreenfootImage("title.png"));
        getImage().setTransparency(0);
    }
    public void act() 
    {
        if (firstInitialize)
        {
            x = getX();
            int t = getImage().getTransparency()+5;
            if (t > 230)
            firstInitialize = false;
            else
            getImage().setTransparency(t);
        }
        if (closing)
        {
            int t = getImage().getTransparency()-10;
            if (t < 0)
            getWorld().removeObject(this);
            else
            getImage().setTransparency(t);
            return;
        }
       if (left)
       {
           x-=0.5;
           if (x < 300)
           left = false;
           else setLocation((int)x, getY());
       }
       else
       {
           x+=0.5;
           if (x >= 600)
           left = true;
           else setLocation((int)x,getY());
       }
    }    
}
