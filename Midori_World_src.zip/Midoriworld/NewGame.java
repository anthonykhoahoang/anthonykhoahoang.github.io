import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.awt.Color;
import java.awt.Font;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URL;
import java.util.List;
/**
 * Write a description of class NewAccountMenu here.
 * 
 * @author Anthony Hoang
 * @version (v1)
 */
public class NewGame  extends Menu
{
    private int WIDTH = 165;
    private int HEIGHT= 50;
    private GreenfootImage image;
    private GreenfootImage image2;
    private String user;
    private String pass;
    private boolean firstInitialize = true;
    public NewGame()
    {
        image = new GreenfootImage(WIDTH, HEIGHT);
        image2 = new GreenfootImage(WIDTH, HEIGHT);
        drawOne();
        image.setTransparency(0);
        image2.setTransparency(0);
        setImage(image2);
    }
    public void act() 
    {
        if (firstInitialize)
        {
            int t = getImage().getTransparency()+5;
            if (t > 255)
            firstInitialize = false;
            else
            {
                image.setTransparency(t);
                image2.setTransparency(t);
            }
        }
        if (closing)
        {
            int t = getImage().getTransparency()-10;
            if (t < 0)
            getMWorld().removeObject(this);
            else
            {
                image.setTransparency(t);
                image2.setTransparency(t);
            }
            return;
        }
        String key = ""+Greenfoot.getKey();
        if (mouseOverThis() )
        {
            if (getImage().equals(image2))
            setImage(image);
        }
        else 
        if (getImage().equals(image))
        setImage(image2);
        
        if (Greenfoot.mouseClicked(this))
        {
            getMWorld().removeObjects(getMWorld().getObjects(EventScript.class));
            getMWorld().eventCount = 0;
            getMWorld().addEventScript("newGame.txt");
            getMWorld().gamePause = false;
            //getMWorld().removeObjects();
        }
    }    
    public void drawOne()
    {
        image.setColor(Color.GRAY);
        image.fill();
        image.setColor(new Color(5, 5, 75 ,150));
        image.fillRect(5, 5, WIDTH-10, HEIGHT-10);
        Font font = image.getFont();
        font = font.deriveFont(25f);
        image.setFont(font);
        image.setColor(Color.WHITE);
        image.drawString("New Game", 19, 32);
        image2.setColor(new Color(5, 5, 50 ,150));
        image2.fillRect(5, 5, WIDTH-10, HEIGHT-10);
        font = image.getFont();
        font = font.deriveFont(25f);
        image2.setFont(font);
        image2.setColor(Color.WHITE);
        image2.drawString("New Game", 19, 32);
    }
}
