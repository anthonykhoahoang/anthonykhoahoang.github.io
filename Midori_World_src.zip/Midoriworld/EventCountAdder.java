import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.util.List;
/**
 * Write a description of class EventCountAdder here.
 * 
 * @author Anthony Hoang
 * @version (v1)
 */
public class EventCountAdder  extends InGameObjects
{
    public boolean hasAdded = false;
    public void act() 
    {
        if (getMWorld().esPause) return;
        if (!hasAdded)
        {
            List<Actor> list = getObjectsInRange(80, InGameCharacter.class);
            List<Actor> list2 = getObjectsInRange(80, InGameTarget.class);
            if (list.size() - list2.size() != 0)
            {
                hasAdded = true;
                getMWorld().eventCount++;
            }
        }
    }
}    
