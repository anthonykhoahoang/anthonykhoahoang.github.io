import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.awt.Color;
import java.awt.Font;
import java.util.List;
/**
 * Write a description of class EricText here.
 * 
 * @author Anthony Hoang
 * @version (v1)
 */
public class EricText  extends CharacterText
{   
    private GreenfootImage temp;
    public EricText(String text)
    {
        super(text, "Eric Weis");
        drawImage();
    }
    public void close()
    {
        super.close();
        List<EricMouth> list = getMWorld().getObjects(EricMouth.class);
        for (EricMouth m : list)
        m.setActCount(0);
    }
    public void addNextText(String nxt)
    {
        getMWorld().addObject(new EricText(nxt),getX(),getY());
    }
    public void act() 
    {
        if (getMWorld().gamePause) return;
        if (getImage().equals(image))
        super.act();
        else if (temp.getTransparency() < 200)
        {
            temp.setTransparency(temp.getTransparency()+20);
        }
        else setImage(image);
        if (firstInitialize && getImage().equals(image))
        {
            List<EricMouth> list = getMWorld().getObjects(EricMouth.class);
            for (EricMouth m : list)
                m.setActCount(talkLength);
            firstInitialize = false;
        }
    }    
    public void drawImage()
    {
        image = new GreenfootImage(WIDTH, HEIGHT);
        image.setColor(Color.WHITE);
        image.fillRect(57,20,120,35);
        image.setColor(Color.BLACK);
        Font font = image.getFont();
        font = font.deriveFont(17f);
        image.setFont(font);
        image.drawString(name, 65, 40);
        
        font = font.deriveFont(12f); 
        image.setFont(font);
        
        image.setColor(new Color(200, 200, 200, 200));
        image.fillRect(55, 50 ,WIDTH,HEIGHT);
        image.setColor(Color.BLACK);
        image.fillRect(60, 55 , WIDTH-65, HEIGHT-60);
        image.setTransparency(200);
        image.drawImage(new GreenfootImage("ericsmall.png"), 5,5);
        image.setColor(Color.WHITE);
        
        //font = new Font("Lucida Console", image.getFont().getStyle(), image.getFont().getSize()) ;
        //font = new Font("DejaVu Sans Mono", image.getFont().getStyle(), image.getFont().getSize()) ;
        //font = new Font("Microsoft Sans Serif", image.getFont().getStyle(), image.getFont().getSize()) ;
        font = new Font("Monospaced",image.getFont().getStyle(), image.getFont().getSize());
        font = font.deriveFont(16f); 
        image.setFont(font);
        
        temp = new GreenfootImage(image);
        temp.setTransparency(0);
        //setImage(image);
        //delay = 10;
        setImage(temp);
    }
}
