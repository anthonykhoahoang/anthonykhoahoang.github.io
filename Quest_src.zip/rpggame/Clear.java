import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.awt.Color;
import java.awt.Font;
/**
 * Write a description of class BackSpace here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Clear extends Keyboard
{
    private GreenfootImage image;
    private int acts = 0;
    
    public Clear()
    {
        image = new GreenfootImage(200, 50);
        image.setColor(new Color(255,255,255, 128));
        image.fillRect(0, 0, 200, 50);
        image.setColor(new Color(0, 0, 0, 128));
        image.fillRect(5, 5, 190, 40);
        Font font = new Font("Courier", image.getFont().getStyle(), image.getFont().getSize()) ;
        font = font.deriveFont(50f);
        image.setFont(font);
        image.setColor(Color.WHITE);
        image.drawString("Clear", 30, 40);
        setImage(image);
    }
    public void act() 
    {
        if (Greenfoot.mouseMoved(this))
        {
            image.setColor(Color.RED);
            image.drawString("Clear", 30, 40);
        }
        else
        {
            image.setColor(Color.WHITE);
            image.drawString("Clear", 30, 40);
        }
        if ( Greenfoot.mouseClicked(this) && acts ==0 )
        {
            Greenfoot.playSound("click.wav");
            acts = -10;
            image.setColor(Color.RED);
            image.drawString("Clear", 30, 40);
            getLand().d.clear();
        }
        if (acts != 0)
        acts++;
        setImage(image);
    }    
}
