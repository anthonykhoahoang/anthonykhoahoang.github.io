import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class OrGate here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class OrGate  extends LGGates
{
    private static GreenfootImage img;
    public OrGate()
    {
        super("OR");
        if (img == null)
        img = new GreenfootImage("logicgates/or.png");
        setImage(img);
    }
    public void act() 
    {
        super.act();
    }    
}
